# Stage 2B evidence

Final primary data: primary-reviewed.json (21 repeats, one thread, CPU 0).
Additional common-prefix replay: shared.json. Two-thread subset: block.json.
Route-only rank-growth capture: growth-telemetry.json; its times are not benchmark evidence.
normal/ and control/: frozen build manifests, compiler diagnostics, focused actual
production/replay/trace/microprobe assembly, build and full CTest output. No binaries.
contract.json: strict flags/hashes, production byte identity and export equality.
semantics.json: all differential cases (lists include detailed disagreements).
compat-retained.json: 2700 compatibility/quality cases against integrated baseline.
perf-unavailable.log: counter-access failure, no machine policy changes attempted.

Historical evidence (not used in final tables): smoke.json from initial replay
prototype, primary.json from pre-review campaign before per-repeat helper rc and
prefix identity reporting. Historical freeze manifests preserve earlier build
identities; those /tmp build directories remain on disk. final-* directory names
were staging names before the separate phase-profile build, not final scientific data.

Measured C code frozen at 7ff034cf8a143bf27770b449efd8b1f25616b22a.
Primary harness dcf0430, common-prefix/block harness ed5701d, growth harness 10af3aa.
Use tracked experiments/tail_scan_bench.py and tests/test_tail_scan_diagnostics.py.
The report has exact reproduction commands and measurement-boundary limitations.
JSON uses Python's NaN encoding for unavailable relx; raw timings are seconds.
