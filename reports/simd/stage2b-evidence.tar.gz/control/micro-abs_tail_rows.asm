
/tmp/abs-stage2b-measured-control/tail.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000022c30 <abs_tail_rows>:
   22c30:	f3 0f 1e fa          	endbr64
   22c34:	41 57                	push   r15
   22c36:	41 56                	push   r14
   22c38:	41 55                	push   r13
   22c3a:	41 54                	push   r12
   22c3c:	49 89 d4             	mov    r12,rdx
   22c3f:	55                   	push   rbp
   22c40:	48 89 cd             	mov    rbp,rcx
   22c43:	49 63 c9             	movsxd rcx,r9d
   22c46:	53                   	push   rbx
   22c47:	48 89 fb             	mov    rbx,rdi
   22c4a:	48 8d 3c 09          	lea    rdi,[rcx+rcx*1]
   22c4e:	49 89 cd             	mov    r13,rcx
   22c51:	48 83 ec 58          	sub    rsp,0x58
   22c55:	48 8b 94 24 a0 00 00 	mov    rdx,QWORD PTR [rsp+0xa0]
   22c5c:	00 
   22c5d:	48 89 74 24 18       	mov    QWORD PTR [rsp+0x18],rsi
   22c62:	be 08 00 00 00       	mov    esi,0x8
   22c67:	48 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],rcx
   22c6c:	44 8b bc 24 90 00 00 	mov    r15d,DWORD PTR [rsp+0x90]
   22c73:	00 
   22c74:	48 89 54 24 20       	mov    QWORD PTR [rsp+0x20],rdx
   22c79:	4c 8b b4 24 98 00 00 	mov    r14,QWORD PTR [rsp+0x98]
   22c80:	00 
   22c81:	44 89 44 24 0c       	mov    DWORD PTR [rsp+0xc],r8d
   22c86:	e8 00 00 00 00       	call   22c8b <abs_tail_rows+0x5b>
   22c8b:	48 8b 4c 24 10       	mov    rcx,QWORD PTR [rsp+0x10]
   22c90:	48 8b 54 24 20       	mov    rdx,QWORD PTR [rsp+0x20]
   22c95:	48 85 c0             	test   rax,rax
   22c98:	0f 84 b2 04 00 00    	je     23150 <abs_tail_rows+0x520>
   22c9e:	49 89 c1             	mov    r9,rax
   22ca1:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
   22ca5:	85 c0                	test   eax,eax
   22ca7:	0f 84 56 02 00 00    	je     22f03 <abs_tail_rows+0x2d3>
   22cad:	c4 41 30 57 c9       	vxorps xmm9,xmm9,xmm9
   22cb2:	45 85 ff             	test   r15d,r15d
   22cb5:	41 89 c7             	mov    r15d,eax
   22cb8:	44 89 ee             	mov    esi,r13d
   22cbb:	c5 b3 2a c0          	vcvtsi2sd xmm0,xmm9,eax
   22cbf:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
   22cc3:	b8 00 00 00 00       	mov    eax,0x0
   22cc8:	4c 89 e7             	mov    rdi,r12
   22ccb:	c5 7b 10 1d 00 00 00 	vmovsd xmm11,QWORD PTR [rip+0x0]        # 22cd3 <abs_tail_rows+0xa3>
   22cd2:	00 
   22cd3:	41 0f 44 c7          	cmove  eax,r15d
   22cd7:	48 89 54 24 28       	mov    QWORD PTR [rsp+0x28],rdx
   22cdc:	48 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],rcx
   22ce1:	c5 a3 5e d8          	vdivsd xmm3,xmm11,xmm0
   22ce5:	89 44 24 20          	mov    DWORD PTR [rsp+0x20],eax
   22ce9:	c5 fb 11 5c 24 48    	vmovsd QWORD PTR [rsp+0x48],xmm3
   22cef:	e8 fc d3 fd ff       	call   f0 <norm2>
   22cf4:	48 8b 4c 24 10       	mov    rcx,QWORD PTR [rsp+0x10]
   22cf9:	48 b8 89 6c 4e ec 98 	movabs rax,0x82efa98ec4e6c89
   22d00:	fa 2e 08 
   22d03:	48 ba b9 e5 e4 1c 6d 	movabs rdx,0xbf58476d1ce4e5b9
   22d0a:	47 58 bf 
   22d0d:	49 31 c6             	xor    r14,rax
   22d10:	48 b8 15 7c 4a 7f b9 	movabs rax,0x9e3779b97f4a7c15
   22d17:	79 37 9e 
   22d1a:	4c 01 f0             	add    rax,r14
   22d1d:	48 89 c6             	mov    rsi,rax
   22d20:	48 c1 ee 1e          	shr    rsi,0x1e
   22d24:	48 31 f0             	xor    rax,rsi
   22d27:	48 0f af c2          	imul   rax,rdx
   22d2b:	48 8b 54 24 28       	mov    rdx,QWORD PTR [rsp+0x28]
   22d30:	48 89 c6             	mov    rsi,rax
   22d33:	48 c1 ee 1b          	shr    rsi,0x1b
   22d37:	48 31 c6             	xor    rsi,rax
   22d3a:	48 b8 eb 11 31 13 bb 	movabs rax,0x94d049bb133111eb
   22d41:	49 d0 94 
   22d44:	48 0f af f0          	imul   rsi,rax
   22d48:	48 89 f0             	mov    rax,rsi
   22d4b:	48 c1 e8 1f          	shr    rax,0x1f
   22d4f:	48 31 f0             	xor    rax,rsi
   22d52:	45 85 ff             	test   r15d,r15d
   22d55:	0f 8e a8 01 00 00    	jle    22f03 <abs_tail_rows+0x2d3>
   22d5b:	c4 c1 7b 58 db       	vaddsd xmm3,xmm0,xmm11
   22d60:	48 89 4c 24 38       	mov    QWORD PTR [rsp+0x38],rcx
   22d65:	c4 41 09 57 f6       	vxorpd xmm14,xmm14,xmm14
   22d6a:	49 89 d8             	mov    r8,rbx
   22d6d:	49 be 00 8e 7b 92 74 	movabs r14,0x3307c374927b8e00
   22d74:	c3 07 33 
   22d77:	31 db                	xor    ebx,ebx
   22d79:	c7 44 24 28 00 00 00 	mov    DWORD PTR [rsp+0x28],0x0
   22d80:	00 
   22d81:	4c 8d 14 cd 00 00 00 	lea    r10,[rcx*8+0x0]
   22d88:	00 
   22d89:	49 01 c6             	add    r14,rax
   22d8c:	48 89 54 24 40       	mov    QWORD PTR [rsp+0x40],rdx
   22d91:	4e 8d 5c 15 00       	lea    r11,[rbp+r10*1+0x0]
   22d96:	44 89 ea             	mov    edx,r13d
   22d99:	4d 89 f7             	mov    r15,r14
   22d9c:	4d 89 cd             	mov    r13,r9
   22d9f:	c4 41 79 28 fe       	vmovapd xmm15,xmm14
   22da4:	c5 fb 11 5c 24 30    	vmovsd QWORD PTR [rsp+0x30],xmm3
   22daa:	c5 7b 10 15 00 00 00 	vmovsd xmm10,QWORD PTR [rip+0x0]        # 22db2 <abs_tail_rows+0x182>
   22db1:	00 
   22db2:	c4 41 79 28 ee       	vmovapd xmm13,xmm14
   22db7:	4d 01 d1             	add    r9,r10
   22dba:	48 be ce 61 2f 9c 26 	movabs rsi,0x5d8fc1269c2f61ce
   22dc1:	c1 8f 5d 
   22dc4:	4c 8d 34 30          	lea    r14,[rax+rsi*1]
   22dc8:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
   22dcf:	00 
   22dd0:	85 d2                	test   edx,edx
   22dd2:	0f 8e c0 01 00 00    	jle    22f98 <abs_tail_rows+0x368>
   22dd8:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
   22ddc:	31 c0                	xor    eax,eax
   22dde:	c5 f9 28 fe          	vmovapd xmm7,xmm6
   22de2:	c5 79 28 c6          	vmovapd xmm8,xmm6
   22de6:	c5 f9 28 c6          	vmovapd xmm0,xmm6
   22dea:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   22df1:	00 00 00 00 
   22df5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   22dfc:	00 00 00 00 
   22e00:	c4 c1 7b 10 0c 00    	vmovsd xmm1,QWORD PTR [r8+rax*1]
   22e06:	c4 42 f1 b9 04 04    	vfmadd231sd xmm8,xmm1,QWORD PTR [r12+rax*1]
   22e0c:	c4 e2 f1 b9 7c 05 00 	vfmadd231sd xmm7,xmm1,QWORD PTR [rbp+rax*1+0x0]
   22e13:	c4 c2 f1 b9 34 03    	vfmadd231sd xmm6,xmm1,QWORD PTR [r11+rax*1]
   22e19:	48 83 c0 08          	add    rax,0x8
   22e1d:	49 39 c2             	cmp    r10,rax
   22e20:	c4 e2 f1 b9 c1       	vfmadd231sd xmm0,xmm1,xmm1
   22e25:	75 d9                	jne    22e00 <abs_tail_rows+0x1d0>
   22e27:	c4 c1 79 2f c5       	vcomisd xmm0,xmm13
   22e2c:	0f 86 76 01 00 00    	jbe    22fa8 <abs_tail_rows+0x378>
   22e32:	48 bf 00 00 00 00 00 	movabs rdi,0x7ff0000000000000
   22e39:	00 f0 7f 
   22e3c:	c4 e1 f9 7e c0       	vmovq  rax,xmm0
   22e41:	c4 e2 f8 f2 c7       	andn   rax,rax,rdi
   22e46:	0f 84 5c 01 00 00    	je     22fa8 <abs_tail_rows+0x378>
   22e4c:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
   22e50:	c5 a3 5e c0          	vdivsd xmm0,xmm11,xmm0
   22e54:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   22e59:	39 5c 24 20          	cmp    DWORD PTR [rsp+0x20],ebx
   22e5d:	c5 fb 10 14 d8       	vmovsd xmm2,QWORD PTR [rax+rbx*8]
   22e62:	8d 43 01             	lea    eax,[rbx+0x1]
   22e65:	c5 eb 59 d8          	vmulsd xmm3,xmm2,xmm0
   22e69:	0f 8e 91 01 00 00    	jle    23000 <abs_tail_rows+0x3d0>
   22e6f:	c5 c9 54 35 00 00 00 	vandpd xmm6,xmm6,XMMWORD PTR [rip+0x0]        # 22e77 <abs_tail_rows+0x247>
   22e76:	00 
   22e77:	c5 c1 54 3d 00 00 00 	vandpd xmm7,xmm7,XMMWORD PTR [rip+0x0]        # 22e7f <abs_tail_rows+0x24f>
   22e7e:	00 
   22e7f:	c5 cb 5f f7          	vmaxsd xmm6,xmm6,xmm7
   22e83:	c5 cb 59 f0          	vmulsd xmm6,xmm6,xmm0
   22e87:	c5 f9 2f 35 00 00 00 	vcomisd xmm6,QWORD PTR [rip+0x0]        # 22e8f <abs_tail_rows+0x25f>
   22e8e:	00 
   22e8f:	77 2a                	ja     22ebb <abs_tail_rows+0x28b>
   22e91:	c4 c1 6b 5c d0       	vsubsd xmm2,xmm2,xmm8
   22e96:	c5 eb 59 d0          	vmulsd xmm2,xmm2,xmm0
   22e9a:	c5 e1 54 05 00 00 00 	vandpd xmm0,xmm3,XMMWORD PTR [rip+0x0]        # 22ea2 <abs_tail_rows+0x272>
   22ea1:	00 
   22ea2:	c5 fb 58 44 24 30    	vaddsd xmm0,xmm0,QWORD PTR [rsp+0x30]
   22ea8:	c5 e9 54 15 00 00 00 	vandpd xmm2,xmm2,XMMWORD PTR [rip+0x0]        # 22eb0 <abs_tail_rows+0x280>
   22eaf:	00 
   22eb0:	c4 c1 7b 59 c2       	vmulsd xmm0,xmm0,xmm10
   22eb5:	c5 f9 2f d0          	vcomisd xmm2,xmm0
   22eb9:	76 05                	jbe    22ec0 <abs_tail_rows+0x290>
   22ebb:	83 44 24 28 01       	add    DWORD PTR [rsp+0x28],0x1
   22ec0:	48 bf eb 11 31 13 bb 	movabs rdi,0x94d049bb133111eb
   22ec7:	49 d0 94 
   22eca:	48 83 c3 01          	add    rbx,0x1
   22ece:	4d 01 d0             	add    r8,r10
   22ed1:	49 01 ff             	add    r15,rdi
   22ed4:	48 bf b9 e5 e4 1c 6d 	movabs rdi,0xbf58476d1ce4e5b9
   22edb:	47 58 bf 
   22ede:	49 01 fe             	add    r14,rdi
   22ee1:	39 44 24 0c          	cmp    DWORD PTR [rsp+0xc],eax
   22ee5:	0f 8f e5 fe ff ff    	jg     22dd0 <abs_tail_rows+0x1a0>
   22eeb:	4d 89 e9             	mov    r9,r13
   22eee:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
   22ef3:	41 89 d5             	mov    r13d,edx
   22ef6:	c5 33 2a 4c 24 28    	vcvtsi2sd xmm9,xmm9,DWORD PTR [rsp+0x28]
   22efc:	48 8b 54 24 40       	mov    rdx,QWORD PTR [rsp+0x40]
   22f01:	eb 0f                	jmp    22f12 <abs_tail_rows+0x2e2>
   22f03:	c4 41 31 57 c9       	vxorpd xmm9,xmm9,xmm9
   22f08:	c4 41 79 28 f1       	vmovapd xmm14,xmm9
   22f0d:	c4 41 79 28 f9       	vmovapd xmm15,xmm9
   22f12:	45 85 ed             	test   r13d,r13d
   22f15:	48 c7 42 18 00 00 00 	mov    QWORD PTR [rdx+0x18],0x0
   22f1c:	00 
   22f1d:	48 c7 42 20 00 00 00 	mov    QWORD PTR [rdx+0x20],0x0
   22f24:	00 
   22f25:	c5 7b 11 0a          	vmovsd QWORD PTR [rdx],xmm9
   22f29:	c5 7b 11 7a 08       	vmovsd QWORD PTR [rdx+0x8],xmm15
   22f2e:	c5 7b 11 72 10       	vmovsd QWORD PTR [rdx+0x10],xmm14
   22f33:	7e 47                	jle    22f7c <abs_tail_rows+0x34c>
   22f35:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   22f39:	4c 89 c8             	mov    rax,r9
   22f3c:	49 8d 34 c9          	lea    rsi,[r9+rcx*8]
   22f40:	c5 f9 28 c8          	vmovapd xmm1,xmm0
   22f44:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   22f4a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   22f51:	00 00 00 00 
   22f55:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   22f5c:	00 00 00 00 
   22f60:	c5 f3 58 08          	vaddsd xmm1,xmm1,QWORD PTR [rax]
   22f64:	c5 fb 58 04 c8       	vaddsd xmm0,xmm0,QWORD PTR [rax+rcx*8]
   22f69:	48 83 c0 08          	add    rax,0x8
   22f6d:	48 39 c6             	cmp    rsi,rax
   22f70:	75 ee                	jne    22f60 <abs_tail_rows+0x330>
   22f72:	c5 fb 11 4a 18       	vmovsd QWORD PTR [rdx+0x18],xmm1
   22f77:	c5 fb 11 42 20       	vmovsd QWORD PTR [rdx+0x20],xmm0
   22f7c:	48 83 c4 58          	add    rsp,0x58
   22f80:	4c 89 cf             	mov    rdi,r9
   22f83:	5b                   	pop    rbx
   22f84:	5d                   	pop    rbp
   22f85:	41 5c                	pop    r12
   22f87:	41 5d                	pop    r13
   22f89:	41 5e                	pop    r14
   22f8b:	41 5f                	pop    r15
   22f8d:	e9 00 00 00 00       	jmp    22f92 <abs_tail_rows+0x362>
   22f92:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   22f98:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
   22f9c:	c5 f9 28 fe          	vmovapd xmm7,xmm6
   22fa0:	c5 79 28 c6          	vmovapd xmm8,xmm6
   22fa4:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   22fa8:	89 d6                	mov    esi,edx
   22faa:	4c 89 c7             	mov    rdi,r8
   22fad:	89 54 24 10          	mov    DWORD PTR [rsp+0x10],edx
   22fb1:	e8 3a d1 fd ff       	call   f0 <norm2>
   22fb6:	8b 54 24 10          	mov    edx,DWORD PTR [rsp+0x10]
   22fba:	c4 c1 79 2f c5       	vcomisd xmm0,xmm13
   22fbf:	0f 85 8b fe ff ff    	jne    22e50 <abs_tail_rows+0x220>
   22fc5:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
   22fca:	8d 43 01             	lea    eax,[rbx+0x1]
   22fcd:	c5 fb 10 04 de       	vmovsd xmm0,QWORD PTR [rsi+rbx*8]
   22fd2:	c5 f9 54 05 00 00 00 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x0]        # 22fda <abs_tail_rows+0x3aa>
   22fd9:	00 
   22fda:	c4 c1 79 2f c2       	vcomisd xmm0,xmm10
   22fdf:	0f 87 d6 fe ff ff    	ja     22ebb <abs_tail_rows+0x28b>
   22fe5:	8b 74 24 20          	mov    esi,DWORD PTR [rsp+0x20]
   22fe9:	39 de                	cmp    esi,ebx
   22feb:	0f 4e f0             	cmovle esi,eax
   22fee:	89 74 24 20          	mov    DWORD PTR [rsp+0x20],esi
   22ff2:	e9 c9 fe ff ff       	jmp    22ec0 <abs_tail_rows+0x290>
   22ff7:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
   22ffe:	00 00 
   23000:	4c 89 fe             	mov    rsi,r15
   23003:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # 2300b <abs_tail_rows+0x3db>
   2300a:	00 
   2300b:	48 bf b9 e5 e4 1c 6d 	movabs rdi,0xbf58476d1ce4e5b9
   23012:	47 58 bf 
   23015:	c5 7b 10 64 24 48    	vmovsd xmm12,QWORD PTR [rsp+0x48]
   2301b:	48 c1 ee 1e          	shr    rsi,0x1e
   2301f:	4c 31 fe             	xor    rsi,r15
   23022:	48 0f af f7          	imul   rsi,rdi
   23026:	48 89 f1             	mov    rcx,rsi
   23029:	48 c1 e9 1b          	shr    rcx,0x1b
   2302d:	48 31 f1             	xor    rcx,rsi
   23030:	48 be eb 11 31 13 bb 	movabs rsi,0x94d049bb133111eb
   23037:	49 d0 94 
   2303a:	48 0f af ce          	imul   rcx,rsi
   2303e:	48 89 ce             	mov    rsi,rcx
   23041:	48 c1 ee 1f          	shr    rsi,0x1f
   23045:	48 31 ce             	xor    rsi,rcx
   23048:	4c 89 f1             	mov    rcx,r14
   2304b:	48 c1 ee 0b          	shr    rsi,0xb
   2304f:	48 c1 e9 1e          	shr    rcx,0x1e
   23053:	c4 e1 b3 2a ce       	vcvtsi2sd xmm1,xmm9,rsi
   23058:	48 89 ce             	mov    rsi,rcx
   2305b:	c5 f9 28 e1          	vmovapd xmm4,xmm1
   2305f:	c4 e2 d1 99 25 00 00 	vfmadd132sd xmm4,xmm5,QWORD PTR [rip+0x0]        # 23068 <abs_tail_rows+0x438>
   23066:	00 00 
   23068:	4c 31 f6             	xor    rsi,r14
   2306b:	48 0f af f7          	imul   rsi,rdi
   2306f:	48 89 f1             	mov    rcx,rsi
   23072:	c4 c1 5b 59 e4       	vmulsd xmm4,xmm4,xmm12
   23077:	48 c1 e9 1b          	shr    rcx,0x1b
   2307b:	48 31 f1             	xor    rcx,rsi
   2307e:	48 be eb 11 31 13 bb 	movabs rsi,0x94d049bb133111eb
   23085:	49 d0 94 
   23088:	48 0f af ce          	imul   rcx,rsi
   2308c:	48 89 ce             	mov    rsi,rcx
   2308f:	48 c1 ee 1f          	shr    rsi,0x1f
   23093:	48 31 ce             	xor    rsi,rcx
   23096:	48 c1 ee 0b          	shr    rsi,0xb
   2309a:	85 d2                	test   edx,edx
   2309c:	c4 e1 b3 2a ce       	vcvtsi2sd xmm1,xmm9,rsi
   230a1:	c5 f9 28 e9          	vmovapd xmm5,xmm1
   230a5:	c5 fb 10 0d 00 00 00 	vmovsd xmm1,QWORD PTR [rip+0x0]        # 230ad <abs_tail_rows+0x47d>
   230ac:	00 
   230ad:	c4 e2 f1 99 2d 00 00 	vfmadd132sd xmm5,xmm1,QWORD PTR [rip+0x0]        # 230b6 <abs_tail_rows+0x486>
   230b4:	00 00 
   230b6:	c4 c1 53 59 cc       	vmulsd xmm1,xmm5,xmm12
   230bb:	0f 8e 7c 00 00 00    	jle    2313d <abs_tail_rows+0x50d>
   230c1:	c5 fb 59 ec          	vmulsd xmm5,xmm0,xmm4
   230c5:	c5 7b 11 44 24 20    	vmovsd QWORD PTR [rsp+0x20],xmm8
   230cb:	31 c9                	xor    ecx,ecx
   230cd:	c5 79 28 c1          	vmovapd xmm8,xmm1
   230d1:	c5 7b 59 e1          	vmulsd xmm12,xmm0,xmm1
   230d5:	c5 fb 11 44 24 10    	vmovsd QWORD PTR [rsp+0x10],xmm0
   230db:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   230df:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   230e6:	00 00 00 00 
   230ea:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   230f1:	00 00 00 00 
   230f5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   230fc:	00 00 00 00 
   23100:	c4 c1 7b 10 04 08    	vmovsd xmm0,QWORD PTR [r8+rcx*1]
   23106:	c5 f9 28 cd          	vmovapd xmm1,xmm5
   2310a:	c4 c2 f9 a9 4c 0d 00 	vfmadd213sd xmm1,xmm0,QWORD PTR [r13+rcx*1+0x0]
   23111:	c4 c1 7b 11 4c 0d 00 	vmovsd QWORD PTR [r13+rcx*1+0x0],xmm1
   23118:	c4 c2 99 a9 04 09    	vfmadd213sd xmm0,xmm12,QWORD PTR [r9+rcx*1]
   2311e:	c4 c1 7b 11 04 09    	vmovsd QWORD PTR [r9+rcx*1],xmm0
   23124:	48 83 c1 08          	add    rcx,0x8
   23128:	49 39 ca             	cmp    r10,rcx
   2312b:	75 d3                	jne    23100 <abs_tail_rows+0x4d0>
   2312d:	c5 79 29 c1          	vmovapd xmm1,xmm8
   23131:	c5 fb 10 44 24 10    	vmovsd xmm0,QWORD PTR [rsp+0x10]
   23137:	c5 7b 10 44 24 20    	vmovsd xmm8,QWORD PTR [rsp+0x20]
   2313d:	c4 62 e1 b9 fc       	vfmadd231sd xmm15,xmm3,xmm4
   23142:	c4 62 e1 b9 f1       	vfmadd231sd xmm14,xmm3,xmm1
   23147:	89 44 24 20          	mov    DWORD PTR [rsp+0x20],eax
   2314b:	e9 1f fd ff ff       	jmp    22e6f <abs_tail_rows+0x23f>
   23150:	48 8b 05 00 00 00 00 	mov    rax,QWORD PTR [rip+0x0]        # 23157 <abs_tail_rows+0x527>
   23157:	48 89 02             	mov    QWORD PTR [rdx],rax
   2315a:	48 83 c4 58          	add    rsp,0x58
   2315e:	5b                   	pop    rbx
   2315f:	5d                   	pop    rbp
   23160:	41 5c                	pop    r12
   23162:	41 5d                	pop    r13
   23164:	41 5e                	pop    r14
   23166:	41 5f                	pop    r15
   23168:	c3                   	ret
