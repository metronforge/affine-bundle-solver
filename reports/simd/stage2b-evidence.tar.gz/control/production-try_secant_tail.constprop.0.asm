/tmp/abs-stage2b-measured-control/CMakeFiles/abs_router_obj.dir/src/bsolver.c.o:     file format elf64-x86-64


Disassembly of section .text:

000000000000a720 <try_secant_tail.constprop.0>:
    a720:	41 57                	push   r15
    a722:	45 89 cf             	mov    r15d,r9d
    a725:	41 56                	push   r14
    a727:	41 55                	push   r13
    a729:	41 54                	push   r12
    a72b:	55                   	push   rbp
    a72c:	53                   	push   rbx
    a72d:	49 63 d8             	movsxd rbx,r8d
    a730:	48 81 ec f8 01 00 00 	sub    rsp,0x1f8
    a737:	48 8b 84 24 40 02 00 	mov    rax,QWORD PTR [rsp+0x240]
    a73e:	00 
    a73f:	48 89 74 24 30       	mov    QWORD PTR [rsp+0x30],rsi
    a744:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    a749:	4c 8b a4 24 30 02 00 	mov    r12,QWORD PTR [rsp+0x230]
    a750:	00 
    a751:	48 89 94 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rdx
    a758:	00 
    a759:	89 4c 24 14          	mov    DWORD PTR [rsp+0x14],ecx
    a75d:	4c 89 e6             	mov    rsi,r12
    a760:	89 5c 24 10          	mov    DWORD PTR [rsp+0x10],ebx
    a764:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
    a76b:	00 
    a76c:	64 48 8b 3c 25 28 00 	mov    rdi,QWORD PTR fs:0x28
    a773:	00 00 
    a775:	48 89 bc 24 e8 01 00 	mov    QWORD PTR [rsp+0x1e8],rdi
    a77c:	00 
    a77d:	48 8d bc 24 20 01 00 	lea    rdi,[rsp+0x120]
    a784:	00 
    a785:	48 89 7c 24 60       	mov    QWORD PTR [rsp+0x60],rdi
    a78a:	e8 31 c9 ff ff       	call   70c0 <bs_copy>
    a78f:	85 c0                	test   eax,eax
    a791:	74 32                	je     a7c5 <try_secant_tail.constprop.0+0xa5>
    a793:	41 ba ff ff ff ff    	mov    r10d,0xffffffff
    a799:	48 8b 84 24 e8 01 00 	mov    rax,QWORD PTR [rsp+0x1e8]
    a7a0:	00 
    a7a1:	64 48 2b 04 25 28 00 	sub    rax,QWORD PTR fs:0x28
    a7a8:	00 00 
    a7aa:	0f 85 ff 18 00 00    	jne    c0af <try_secant_tail.constprop.0+0x198f>
    a7b0:	48 81 c4 f8 01 00 00 	add    rsp,0x1f8
    a7b7:	44 89 d0             	mov    eax,r10d
    a7ba:	5b                   	pop    rbx
    a7bb:	5d                   	pop    rbp
    a7bc:	41 5c                	pop    r12
    a7be:	41 5d                	pop    r13
    a7c0:	41 5e                	pop    r14
    a7c2:	41 5f                	pop    r15
    a7c4:	c3                   	ret
    a7c5:	48 89 d8             	mov    rax,rbx
    a7c8:	48 89 5c 24 50       	mov    QWORD PTR [rsp+0x50],rbx
    a7cd:	48 c1 e0 04          	shl    rax,0x4
    a7d1:	48 89 c7             	mov    rdi,rax
    a7d4:	48 89 84 24 10 01 00 	mov    QWORD PTR [rsp+0x110],rax
    a7db:	00 
    a7dc:	e8 00 00 00 00       	call   a7e1 <try_secant_tail.constprop.0+0xc1>
    a7e1:	48 8d 3c 1b          	lea    rdi,[rbx+rbx*1]
    a7e5:	be 08 00 00 00       	mov    esi,0x8
    a7ea:	49 89 c6             	mov    r14,rax
    a7ed:	e8 00 00 00 00       	call   a7f2 <try_secant_tail.constprop.0+0xd2>
    a7f2:	4d 85 f6             	test   r14,r14
    a7f5:	48 89 c3             	mov    rbx,rax
    a7f8:	0f 84 85 18 00 00    	je     c083 <try_secant_tail.constprop.0+0x1963>
    a7fe:	48 85 c0             	test   rax,rax
    a801:	0f 84 7c 18 00 00    	je     c083 <try_secant_tail.constprop.0+0x1963>
    a807:	48 ba 15 7c 4a 7f b9 	movabs rdx,0x9e3779b97f4a7c15
    a80e:	79 37 9e 
    a811:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    a816:	4c 89 f7             	mov    rdi,r14
    a819:	48 b8 d0 31 9f 29 22 	movabs rax,0xa4093822299f31d0
    a820:	38 09 a4 
    a823:	48 33 84 24 38 02 00 	xor    rax,QWORD PTR [rsp+0x238]
    a82a:	00 
    a82b:	48 c7 84 24 d0 01 00 	mov    QWORD PTR [rsp+0x1d0],0x0
    a832:	00 00 00 00 00 
    a837:	48 c7 84 24 d8 01 00 	mov    QWORD PTR [rsp+0x1d8],0x0
    a83e:	00 00 00 00 00 
    a843:	48 01 d0             	add    rax,rdx
    a846:	48 89 c2             	mov    rdx,rax
    a849:	48 c1 ea 1e          	shr    rdx,0x1e
    a84d:	48 31 c2             	xor    rdx,rax
    a850:	48 b8 b9 e5 e4 1c 6d 	movabs rax,0xbf58476d1ce4e5b9
    a857:	47 58 bf 
    a85a:	48 0f af d0          	imul   rdx,rax
    a85e:	48 89 d0             	mov    rax,rdx
    a861:	48 c1 e8 1b          	shr    rax,0x1b
    a865:	48 31 d0             	xor    rax,rdx
    a868:	48 ba eb 11 31 13 bb 	movabs rdx,0x94d049bb133111eb
    a86f:	49 d0 94 
    a872:	48 0f af c2          	imul   rax,rdx
    a876:	48 89 c2             	mov    rdx,rax
    a879:	48 c1 ea 1f          	shr    rdx,0x1f
    a87d:	48 31 c2             	xor    rdx,rax
    a880:	48 89 d0             	mov    rax,rdx
    a883:	48 ba 03 ed 92 d1 32 	movabs rdx,0xd1b54a32d192ed03
    a88a:	4a b5 d1 
    a88d:	48 01 c2             	add    rdx,rax
    a890:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
    a897:	00 
    a898:	e8 a3 7e ff ff       	call   2740 <secant_refresh>
    a89d:	48 8b 7c 24 50       	mov    rdi,QWORD PTR [rsp+0x50]
    a8a2:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    a8a7:	48 ba 06 da 25 a3 65 	movabs rdx,0xa36a9465a325da06
    a8ae:	94 6a a3 
    a8b1:	48 03 94 24 e0 00 00 	add    rdx,QWORD PTR [rsp+0xe0]
    a8b8:	00 
    a8b9:	48 8d 2c fd 00 00 00 	lea    rbp,[rdi*8+0x0]
    a8c0:	00 
    a8c1:	4d 8d 2c 2e          	lea    r13,[r14+rbp*1]
    a8c5:	4c 89 ef             	mov    rdi,r13
    a8c8:	e8 73 7e ff ff       	call   2740 <secant_refresh>
    a8cd:	e8 00 00 00 00       	call   a8d2 <try_secant_tail.constprop.0+0x1b2>
    a8d2:	89 84 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],eax
    a8d9:	41 8b 44 24 04       	mov    eax,DWORD PTR [r12+0x4]
    a8de:	89 04 24             	mov    DWORD PTR [rsp],eax
    a8e1:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    a8e5:	44 29 f8             	sub    eax,r15d
    a8e8:	85 c0                	test   eax,eax
    a8ea:	0f 8e a5 13 00 00    	jle    bc95 <try_secant_tail.constprop.0+0x1575>
    a8f0:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
    a8f4:	c5 fb 10 1d 00 00 00 	vmovsd xmm3,QWORD PTR [rip+0x0]        # a8fc <try_secant_tail.constprop.0+0x1dc>
    a8fb:	00 
    a8fc:	c5 d3 2a c0          	vcvtsi2sd xmm0,xmm5,eax
    a900:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
    a904:	c5 fb 11 5c 24 20    	vmovsd QWORD PTR [rsp+0x20],xmm3
    a90a:	c5 e3 5e e0          	vdivsd xmm4,xmm3,xmm0
    a90e:	c5 fb 11 a4 24 d8 00 	vmovsd QWORD PTR [rsp+0xd8],xmm4
    a915:	00 00 
    a917:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    a91b:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    a922:	00 
    a923:	e8 c8 57 ff ff       	call   f0 <norm2>
    a928:	be 01 00 00 00       	mov    esi,0x1
    a92d:	bf 00 08 00 00       	mov    edi,0x800
    a932:	c5 fb 11 84 24 a8 00 	vmovsd QWORD PTR [rsp+0xa8],xmm0
    a939:	00 00 
    a93b:	e8 00 00 00 00       	call   a940 <try_secant_tail.constprop.0+0x220>
    a940:	48 8b 54 24 50       	mov    rdx,QWORD PTR [rsp+0x50]
    a945:	be 08 00 00 00       	mov    esi,0x8
    a94a:	4c 63 a4 24 d0 00 00 	movsxd r12,DWORD PTR [rsp+0xd0]
    a951:	00 
    a952:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    a957:	49 0f af d4          	imul   rdx,r12
    a95b:	48 8d 3c 12          	lea    rdi,[rdx+rdx*1]
    a95f:	48 89 54 24 18       	mov    QWORD PTR [rsp+0x18],rdx
    a964:	e8 00 00 00 00       	call   a969 <try_secant_tail.constprop.0+0x249>
    a969:	4b 8d 3c 24          	lea    rdi,[r12+r12*1]
    a96d:	be 08 00 00 00       	mov    esi,0x8
    a972:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    a977:	e8 00 00 00 00       	call   a97c <try_secant_tail.constprop.0+0x25c>
    a97c:	48 83 7c 24 58 00    	cmp    QWORD PTR [rsp+0x58],0x0
    a982:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    a989:	00 
    a98a:	48 89 c7             	mov    rdi,rax
    a98d:	0f 94 c0             	sete   al
    a990:	48 83 7c 24 68 00    	cmp    QWORD PTR [rsp+0x68],0x0
    a996:	0f 94 c1             	sete   cl
    a999:	08 c8                	or     al,cl
    a99b:	0f 85 c1 16 00 00    	jne    c062 <try_secant_tail.constprop.0+0x1942>
    a9a1:	48 85 ff             	test   rdi,rdi
    a9a4:	0f 84 b8 16 00 00    	je     c062 <try_secant_tail.constprop.0+0x1942>
    a9aa:	8b 94 24 24 01 00 00 	mov    edx,DWORD PTR [rsp+0x124]
    a9b1:	44 39 7c 24 14       	cmp    DWORD PTR [rsp+0x14],r15d
    a9b6:	44 8b 84 24 2c 01 00 	mov    r8d,DWORD PTR [rsp+0x12c]
    a9bd:	00 
    a9be:	89 54 24 08          	mov    DWORD PTR [rsp+0x8],edx
    a9c2:	0f 8e b1 02 00 00    	jle    ac79 <try_secant_tail.constprop.0+0x559>
    a9c8:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    a9cc:	48 8b 54 24 18       	mov    rdx,QWORD PTR [rsp+0x18]
    a9d1:	44 89 7c 24 38       	mov    DWORD PTR [rsp+0x38],r15d
    a9d6:	4d 89 ea             	mov    r10,r13
    a9d9:	48 b9 15 7c 4a 7f b9 	movabs rcx,0x9e3779b97f4a7c15
    a9e0:	79 37 9e 
    a9e3:	c7 44 24 18 00 00 00 	mov    DWORD PTR [rsp+0x18],0x0
    a9ea:	00 
    a9eb:	48 b8 89 6c 4e ec 98 	movabs rax,0x82efa98ec4e6c89
    a9f2:	fa 2e 08 
    a9f5:	48 33 84 24 38 02 00 	xor    rax,QWORD PTR [rsp+0x238]
    a9fc:	00 
    a9fd:	c7 84 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],0x0
    aa04:	00 00 00 00 
    aa08:	48 01 c8             	add    rax,rcx
    aa0b:	48 89 c1             	mov    rcx,rax
    aa0e:	48 c1 e9 1e          	shr    rcx,0x1e
    aa12:	48 31 c1             	xor    rcx,rax
    aa15:	48 b8 b9 e5 e4 1c 6d 	movabs rax,0xbf58476d1ce4e5b9
    aa1c:	47 58 bf 
    aa1f:	48 0f af c8          	imul   rcx,rax
    aa23:	48 89 c8             	mov    rax,rcx
    aa26:	48 c1 e8 1b          	shr    rax,0x1b
    aa2a:	48 31 c8             	xor    rax,rcx
    aa2d:	48 b9 eb 11 31 13 bb 	movabs rcx,0x94d049bb133111eb
    aa34:	49 d0 94 
    aa37:	48 0f af c1          	imul   rax,rcx
    aa3b:	48 89 c1             	mov    rcx,rax
    aa3e:	48 c1 e9 1f          	shr    rcx,0x1f
    aa42:	48 31 c1             	xor    rcx,rax
    aa45:	89 f0                	mov    eax,esi
    aa47:	c1 e8 1f             	shr    eax,0x1f
    aa4a:	48 89 8c 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rcx
    aa51:	00 
    aa52:	01 f0                	add    eax,esi
    aa54:	d1 f8                	sar    eax,1
    aa56:	39 04 24             	cmp    DWORD PTR [rsp],eax
    aa59:	0f 9d c1             	setge  cl
    aa5c:	83 bc 24 d0 00 00 00 	cmp    DWORD PTR [rsp+0xd0],0x1
    aa63:	01 
    aa64:	0f 9f c0             	setg   al
    aa67:	48 c1 e2 04          	shl    rdx,0x4
    aa6b:	21 c1                	and    ecx,eax
    aa6d:	4c 89 e0             	mov    rax,r12
    aa70:	44 8d 24 36          	lea    r12d,[rsi+rsi*1]
    aa74:	48 89 94 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rdx
    aa7b:	00 
    aa7c:	48 c1 e0 04          	shl    rax,0x4
    aa80:	48 8d 34 2b          	lea    rsi,[rbx+rbp*1]
    aa84:	88 4c 24 3f          	mov    BYTE PTR [rsp+0x3f],cl
    aa88:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
    aa8f:	00 
    aa90:	48 01 f8             	add    rax,rdi
    aa93:	44 89 c7             	mov    edi,r8d
    aa96:	48 89 b4 24 18 01 00 	mov    QWORD PTR [rsp+0x118],rsi
    aa9d:	00 
    aa9e:	48 89 84 24 08 01 00 	mov    QWORD PTR [rsp+0x108],rax
    aaa5:	00 
    aaa6:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
    aaad:	00 00 00 
    aab0:	85 ff                	test   edi,edi
    aab2:	0f 85 a6 13 00 00    	jne    be5e <try_secant_tail.constprop.0+0x173e>
    aab8:	89 7c 24 40          	mov    DWORD PTR [rsp+0x40],edi
    aabc:	45 89 fb             	mov    r11d,r15d
    aabf:	8b 4c 24 08          	mov    ecx,DWORD PTR [rsp+0x8]
    aac3:	39 4c 24 10          	cmp    DWORD PTR [rsp+0x10],ecx
    aac7:	0f 8e fc 03 00 00    	jle    aec9 <try_secant_tail.constprop.0+0x7a9>
    aacd:	83 7c 24 18 1f       	cmp    DWORD PTR [rsp+0x18],0x1f
    aad2:	0f 9f c0             	setg   al
    aad5:	84 44 24 3f          	test   BYTE PTR [rsp+0x3f],al
    aad9:	74 22                	je     aafd <try_secant_tail.constprop.0+0x3dd>
    aadb:	44 39 5c 24 38       	cmp    DWORD PTR [rsp+0x38],r11d
    aae0:	7f 1b                	jg     aafd <try_secant_tail.constprop.0+0x3dd>
    aae2:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    aae6:	44 29 d8             	sub    eax,r11d
    aae9:	48 98                	cdqe
    aaeb:	48 0f af 44 24 50    	imul   rax,QWORD PTR [rsp+0x50]
    aaf1:	48 3d 3f 42 0f 00    	cmp    rax,0xf423f
    aaf7:	0f 8f 03 06 00 00    	jg     b100 <try_secant_tail.constprop.0+0x9e0>
    aafd:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    ab01:	4d 63 cb             	movsxd r9,r11d
    ab04:	49 89 e8             	mov    r8,rbp
    ab07:	4d 0f af c1          	imul   r8,r9
    ab0b:	4c 03 44 24 28       	add    r8,QWORD PTR [rsp+0x28]
    ab10:	85 c9                	test   ecx,ecx
    ab12:	0f 8e 2f 03 00 00    	jle    ae47 <try_secant_tail.constprop.0+0x727>
    ab18:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
    ab1c:	48 8b 94 24 38 01 00 	mov    rdx,QWORD PTR [rsp+0x138]
    ab23:	00 
    ab24:	31 c0                	xor    eax,eax
    ab26:	c5 79 28 c6          	vmovapd xmm8,xmm6
    ab2a:	c5 f9 28 fe          	vmovapd xmm7,xmm6
    ab2e:	c5 f9 28 ce          	vmovapd xmm1,xmm6
    ab32:	0f 1f 00             	nop    DWORD PTR [rax]
    ab35:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    ab3c:	00 00 00 00 
    ab40:	c4 c1 7b 10 04 00    	vmovsd xmm0,QWORD PTR [r8+rax*1]
    ab46:	c4 e2 f9 b9 3c 02    	vfmadd231sd xmm7,xmm0,QWORD PTR [rdx+rax*1]
    ab4c:	c4 42 f9 b9 04 06    	vfmadd231sd xmm8,xmm0,QWORD PTR [r14+rax*1]
    ab52:	c4 c2 f9 b9 34 02    	vfmadd231sd xmm6,xmm0,QWORD PTR [r10+rax*1]
    ab58:	48 83 c0 08          	add    rax,0x8
    ab5c:	48 39 c5             	cmp    rbp,rax
    ab5f:	c4 e2 f9 b9 c8       	vfmadd231sd xmm1,xmm0,xmm0
    ab64:	75 da                	jne    ab40 <try_secant_tail.constprop.0+0x420>
    ab66:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
    ab6a:	c5 f9 2f c8          	vcomisd xmm1,xmm0
    ab6e:	0f 86 e4 02 00 00    	jbe    ae58 <try_secant_tail.constprop.0+0x738>
    ab74:	48 b8 00 00 00 00 00 	movabs rax,0x7ff0000000000000
    ab7b:	00 f0 7f 
    ab7e:	c4 e1 f9 7e c9       	vmovq  rcx,xmm1
    ab83:	c4 e2 f0 f2 c0       	andn   rax,rcx,rax
    ab88:	0f 84 ca 02 00 00    	je     ae58 <try_secant_tail.constprop.0+0x738>
    ab8e:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
    ab92:	c5 fb 10 6c 24 20    	vmovsd xmm5,QWORD PTR [rsp+0x20]
    ab98:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    ab9d:	44 39 5c 24 38       	cmp    DWORD PTR [rsp+0x38],r11d
    aba2:	c5 d3 5e c9          	vdivsd xmm1,xmm5,xmm1
    aba6:	c4 21 7b 10 0c c8    	vmovsd xmm9,QWORD PTR [rax+r9*8]
    abac:	c4 c1 73 59 d1       	vmulsd xmm2,xmm1,xmm9
    abb1:	0f 8e 0b 0b 00 00    	jle    b6c2 <try_secant_tail.constprop.0+0xfa2>
    abb7:	c5 c9 54 35 00 00 00 	vandpd xmm6,xmm6,XMMWORD PTR [rip+0x0]        # abbf <try_secant_tail.constprop.0+0x49f>
    abbe:	00 
    abbf:	c5 39 54 05 00 00 00 	vandpd xmm8,xmm8,XMMWORD PTR [rip+0x0]        # abc7 <try_secant_tail.constprop.0+0x4a7>
    abc6:	00 
    abc7:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # abcf <try_secant_tail.constprop.0+0x4af>
    abce:	00 
    abcf:	c4 c1 4b 5f f0       	vmaxsd xmm6,xmm6,xmm8
    abd4:	c5 cb 59 f1          	vmulsd xmm6,xmm6,xmm1
    abd8:	c5 f9 2f f0          	vcomisd xmm6,xmm0
    abdc:	77 42                	ja     ac20 <try_secant_tail.constprop.0+0x500>
    abde:	c5 e9 54 05 00 00 00 	vandpd xmm0,xmm2,XMMWORD PTR [rip+0x0]        # abe6 <try_secant_tail.constprop.0+0x4c6>
    abe5:	00 
    abe6:	c5 b3 5c ff          	vsubsd xmm7,xmm9,xmm7
    abea:	c5 fb 10 a4 24 a8 00 	vmovsd xmm4,QWORD PTR [rsp+0xa8]
    abf1:	00 00 
    abf3:	c5 db 58 54 24 20    	vaddsd xmm2,xmm4,QWORD PTR [rsp+0x20]
    abf9:	c5 c3 59 c9          	vmulsd xmm1,xmm7,xmm1
    abfd:	c5 fb 58 c2          	vaddsd xmm0,xmm0,xmm2
    ac01:	c5 fb 59 05 00 00 00 	vmulsd xmm0,xmm0,QWORD PTR [rip+0x0]        # ac09 <try_secant_tail.constprop.0+0x4e9>
    ac08:	00 
    ac09:	c5 f1 54 0d 00 00 00 	vandpd xmm1,xmm1,XMMWORD PTR [rip+0x0]        # ac11 <try_secant_tail.constprop.0+0x4f1>
    ac10:	00 
    ac11:	c5 f9 2f c8          	vcomisd xmm1,xmm0
    ac15:	0f 86 9d 0c 00 00    	jbe    b8b8 <try_secant_tail.constprop.0+0x1198>
    ac1b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    ac20:	8b 84 24 20 01 00 00 	mov    eax,DWORD PTR [rsp+0x120]
    ac27:	4c 89 c7             	mov    rdi,r8
    ac2a:	89 c6                	mov    esi,eax
    ac2c:	89 04 24             	mov    DWORD PTR [rsp],eax
    ac2f:	e8 bc 54 ff ff       	call   f0 <norm2>
    ac34:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
    ac38:	c5 f9 2f c1          	vcomisd xmm0,xmm1
    ac3c:	0f 85 ae 02 00 00    	jne    aef0 <try_secant_tail.constprop.0+0x7d0>
    ac42:	c5 31 54 0d 00 00 00 	vandpd xmm9,xmm9,XMMWORD PTR [rip+0x0]        # ac4a <try_secant_tail.constprop.0+0x52a>
    ac49:	00 
    ac4a:	c5 79 2f 0d 00 00 00 	vcomisd xmm9,QWORD PTR [rip+0x0]        # ac52 <try_secant_tail.constprop.0+0x532>
    ac51:	00 
    ac52:	45 89 df             	mov    r15d,r11d
    ac55:	0f 87 99 13 00 00    	ja     bff4 <try_secant_tail.constprop.0+0x18d4>
    ac5b:	83 44 24 18 01       	add    DWORD PTR [rsp+0x18],0x1
    ac60:	8b bc 24 2c 01 00 00 	mov    edi,DWORD PTR [rsp+0x12c]
    ac67:	41 83 c7 01          	add    r15d,0x1
    ac6b:	44 39 7c 24 14       	cmp    DWORD PTR [rsp+0x14],r15d
    ac70:	0f 8f 3a fe ff ff    	jg     aab0 <try_secant_tail.constprop.0+0x390>
    ac76:	41 89 f8             	mov    r8d,edi
    ac79:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    ac7e:	44 89 04 24          	mov    DWORD PTR [rsp],r8d
    ac82:	e8 00 00 00 00       	call   ac87 <try_secant_tail.constprop.0+0x567>
    ac87:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    ac8c:	e8 00 00 00 00       	call   ac91 <try_secant_tail.constprop.0+0x571>
    ac91:	48 8b bc 24 a0 00 00 	mov    rdi,QWORD PTR [rsp+0xa0]
    ac98:	00 
    ac99:	e8 00 00 00 00       	call   ac9e <try_secant_tail.constprop.0+0x57e>
    ac9e:	44 8b 04 24          	mov    r8d,DWORD PTR [rsp]
    aca2:	45 85 c0             	test   r8d,r8d
    aca5:	0f 85 f7 13 00 00    	jne    c0a2 <try_secant_tail.constprop.0+0x1982>
    acab:	8b 7c 24 08          	mov    edi,DWORD PTR [rsp+0x8]
    acaf:	39 7c 24 10          	cmp    DWORD PTR [rsp+0x10],edi
    acb3:	4c 8d bc 24 d0 01 00 	lea    r15,[rsp+0x1d0]
    acba:	00 
    acbb:	49 89 dc             	mov    r12,rbx
    acbe:	4c 8d ac 24 e0 01 00 	lea    r13,[rsp+0x1e0]
    acc5:	00 
    acc6:	0f 84 4a 12 00 00    	je     bf16 <try_secant_tail.constprop.0+0x17f6>
    accc:	c4 c1 7b 10 07       	vmovsd xmm0,QWORD PTR [r15]
    acd1:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    acd6:	4c 89 e6             	mov    rsi,r12
    acd9:	e8 c2 b9 ff ff       	call   66a0 <bs_check_certified.constprop.0>
    acde:	83 f8 01             	cmp    eax,0x1
    ace1:	0f 85 ad 11 00 00    	jne    be94 <try_secant_tail.constprop.0+0x1774>
    ace7:	49 83 c7 08          	add    r15,0x8
    aceb:	49 01 ec             	add    r12,rbp
    acee:	4d 39 fd             	cmp    r13,r15
    acf1:	75 d9                	jne    accc <try_secant_tail.constprop.0+0x5ac>
    acf3:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    acf8:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # ad00 <try_secant_tail.constprop.0+0x5e0>
    acff:	00 
    ad00:	89 04 24             	mov    DWORD PTR [rsp],eax
    ad03:	4c 8d 8c 24 60 01 00 	lea    r9,[rsp+0x160]
    ad0a:	00 
    ad0b:	44 8b 44 24 10       	mov    r8d,DWORD PTR [rsp+0x10]
    ad10:	8b 4c 24 14          	mov    ecx,DWORD PTR [rsp+0x14]
    ad14:	48 8b 94 24 38 01 00 	mov    rdx,QWORD PTR [rsp+0x138]
    ad1b:	00 
    ad1c:	48 8b 74 24 30       	mov    rsi,QWORD PTR [rsp+0x30]
    ad21:	e8 2a 59 ff ff       	call   650 <compat_scan_fused>
    ad26:	48 8b bc 24 30 01 00 	mov    rdi,QWORD PTR [rsp+0x130]
    ad2d:	00 
    ad2e:	44 8b 14 24          	mov    r10d,DWORD PTR [rsp]
    ad32:	85 c0                	test   eax,eax
    ad34:	0f 85 62 11 00 00    	jne    be9c <try_secant_tail.constprop.0+0x177c>
    ad3a:	48 8b 8c 24 00 01 00 	mov    rcx,QWORD PTR [rsp+0x100]
    ad41:	00 
    ad42:	8b 84 24 24 01 00 00 	mov    eax,DWORD PTR [rsp+0x124]
    ad49:	48 8b b4 24 e8 00 00 	mov    rsi,QWORD PTR [rsp+0xe8]
    ad50:	00 
    ad51:	c5 fb 10 84 24 60 01 	vmovsd xmm0,QWORD PTR [rsp+0x160]
    ad58:	00 00 
    ad5a:	48 85 c9             	test   rcx,rcx
    ad5d:	c7 06 02 00 00 00    	mov    DWORD PTR [rsi],0x2
    ad63:	89 46 04             	mov    DWORD PTR [rsi+0x4],eax
    ad66:	c5 fb 11 46 18       	vmovsd QWORD PTR [rsi+0x18],xmm0
    ad6b:	0f 84 6c 11 00 00    	je     bedd <try_secant_tail.constprop.0+0x17bd>
    ad71:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    ad75:	85 f6                	test   esi,esi
    ad77:	0f 8e 91 12 00 00    	jle    c00e <try_secant_tail.constprop.0+0x18ee>
    ad7d:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
    ad81:	48 8b 94 24 38 01 00 	mov    rdx,QWORD PTR [rsp+0x138]
    ad88:	00 
    ad89:	31 c0                	xor    eax,eax
    ad8b:	c5 f9 28 d3          	vmovapd xmm2,xmm3
    ad8f:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    ad94:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    ad9b:	00 00 00 00 
    ad9f:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    ada6:	00 00 00 00 
    adaa:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    adb1:	00 00 00 00 
    adb5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    adbc:	00 00 00 00 
    adc0:	c5 fb 10 0c 01       	vmovsd xmm1,QWORD PTR [rcx+rax*1]
    adc5:	c5 fb 10 04 02       	vmovsd xmm0,QWORD PTR [rdx+rax*1]
    adca:	48 83 c0 08          	add    rax,0x8
    adce:	48 39 c5             	cmp    rbp,rax
    add1:	c5 fb 5c c1          	vsubsd xmm0,xmm0,xmm1
    add5:	c4 e2 f1 b9 d9       	vfmadd231sd xmm3,xmm1,xmm1
    adda:	c4 e2 f9 b9 d0       	vfmadd231sd xmm2,xmm0,xmm0
    addf:	75 df                	jne    adc0 <try_secant_tail.constprop.0+0x6a0>
    ade1:	c5 eb 51 d2          	vsqrtsd xmm2,xmm2,xmm2
    ade5:	c5 e3 51 c3          	vsqrtsd xmm0,xmm3,xmm3
    ade9:	c5 fb 58 05 00 00 00 	vaddsd xmm0,xmm0,QWORD PTR [rip+0x0]        # adf1 <try_secant_tail.constprop.0+0x6d1>
    adf0:	00 
    adf1:	c5 eb 5e d0          	vdivsd xmm2,xmm2,xmm0
    adf5:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    adfc:	00 
    adfd:	44 89 54 24 10       	mov    DWORD PTR [rsp+0x10],r10d
    ae02:	c7 40 0c 01 00 00 00 	mov    DWORD PTR [rax+0xc],0x1
    ae09:	c5 fb 11 50 20       	vmovsd QWORD PTR [rax+0x20],xmm2
    ae0e:	e8 00 00 00 00       	call   ae13 <try_secant_tail.constprop.0+0x6f3>
    ae13:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    ae1a:	00 
    ae1b:	e8 00 00 00 00       	call   ae20 <try_secant_tail.constprop.0+0x700>
    ae20:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    ae27:	00 
    ae28:	e8 00 00 00 00       	call   ae2d <try_secant_tail.constprop.0+0x70d>
    ae2d:	4c 89 f7             	mov    rdi,r14
    ae30:	e8 00 00 00 00       	call   ae35 <try_secant_tail.constprop.0+0x715>
    ae35:	48 89 df             	mov    rdi,rbx
    ae38:	e8 00 00 00 00       	call   ae3d <try_secant_tail.constprop.0+0x71d>
    ae3d:	44 8b 54 24 10       	mov    r10d,DWORD PTR [rsp+0x10]
    ae42:	e9 52 f9 ff ff       	jmp    a799 <try_secant_tail.constprop.0+0x79>
    ae47:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
    ae4b:	c5 79 28 c6          	vmovapd xmm8,xmm6
    ae4f:	c5 f9 28 fe          	vmovapd xmm7,xmm6
    ae53:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    ae58:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    ae5c:	4c 89 c7             	mov    rdi,r8
    ae5f:	e8 8c 52 ff ff       	call   f0 <norm2>
    ae64:	c5 f9 28 c8          	vmovapd xmm1,xmm0
    ae68:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
    ae6c:	c5 f9 2f c8          	vcomisd xmm1,xmm0
    ae70:	0f 85 1c fd ff ff    	jne    ab92 <try_secant_tail.constprop.0+0x472>
    ae76:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    ae7b:	c4 21 7b 10 0c c8    	vmovsd xmm9,QWORD PTR [rax+r9*8]
    ae81:	c5 b1 54 05 00 00 00 	vandpd xmm0,xmm9,XMMWORD PTR [rip+0x0]        # ae89 <try_secant_tail.constprop.0+0x769>
    ae88:	00 
    ae89:	c5 f9 2f 05 00 00 00 	vcomisd xmm0,QWORD PTR [rip+0x0]        # ae91 <try_secant_tail.constprop.0+0x771>
    ae90:	00 
    ae91:	0f 87 89 fd ff ff    	ja     ac20 <try_secant_tail.constprop.0+0x500>
    ae97:	8b 4c 24 38          	mov    ecx,DWORD PTR [rsp+0x38]
    ae9b:	41 8d 43 01          	lea    eax,[r11+0x1]
    ae9f:	44 39 d9             	cmp    ecx,r11d
    aea2:	0f 4e c8             	cmovle ecx,eax
    aea5:	39 44 24 14          	cmp    DWORD PTR [rsp+0x14],eax
    aea9:	89 4c 24 38          	mov    DWORD PTR [rsp+0x38],ecx
    aead:	0f 8e 51 11 00 00    	jle    c004 <try_secant_tail.constprop.0+0x18e4>
    aeb3:	83 44 24 18 01       	add    DWORD PTR [rsp+0x18],0x1
    aeb8:	8b 4c 24 08          	mov    ecx,DWORD PTR [rsp+0x8]
    aebc:	41 89 c3             	mov    r11d,eax
    aebf:	39 4c 24 10          	cmp    DWORD PTR [rsp+0x10],ecx
    aec3:	0f 8f 04 fc ff ff    	jg     aacd <try_secant_tail.constprop.0+0x3ad>
    aec9:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    aece:	e8 00 00 00 00       	call   aed3 <try_secant_tail.constprop.0+0x7b3>
    aed3:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    aed8:	e8 00 00 00 00       	call   aedd <try_secant_tail.constprop.0+0x7bd>
    aedd:	48 8b bc 24 a0 00 00 	mov    rdi,QWORD PTR [rsp+0xa0]
    aee4:	00 
    aee5:	e8 00 00 00 00       	call   aeea <try_secant_tail.constprop.0+0x7ca>
    aeea:	e9 bc fd ff ff       	jmp    acab <try_secant_tail.constprop.0+0x58b>
    aeef:	90                   	nop
    aef0:	c5 fb 10 64 24 20    	vmovsd xmm4,QWORD PTR [rsp+0x20]
    aef6:	4c 63 2c 24          	movsxd r13,DWORD PTR [rsp]
    aefa:	4c 8b bc 24 40 01 00 	mov    r15,QWORD PTR [rsp+0x140]
    af01:	00 
    af02:	48 8b b4 24 30 01 00 	mov    rsi,QWORD PTR [rsp+0x130]
    af09:	00 
    af0a:	c5 db 5e c8          	vdivsd xmm1,xmm4,xmm0
    af0e:	4c 89 e8             	mov    rax,r13
    af11:	49 c1 e5 03          	shl    r13,0x3
    af15:	4f 8d 0c 2f          	lea    r9,[r15+r13*1]
    af19:	85 c0                	test   eax,eax
    af1b:	4b 8d 14 29          	lea    rdx,[r9+r13*1]
    af1f:	c4 c1 73 59 e9       	vmulsd xmm5,xmm1,xmm9
    af24:	c5 fb 11 6c 24 48    	vmovsd QWORD PTR [rsp+0x48],xmm5
    af2a:	0f 8e a1 09 00 00    	jle    b8d1 <try_secant_tail.constprop.0+0x11b1>
    af30:	31 c0                	xor    eax,eax
    af32:	0f 1f 00             	nop    DWORD PTR [rax]
    af35:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    af3c:	00 00 00 00 
    af40:	c4 c1 73 59 04 00    	vmulsd xmm0,xmm1,QWORD PTR [r8+rax*1]
    af46:	c4 c1 7b 11 04 07    	vmovsd QWORD PTR [r15+rax*1],xmm0
    af4c:	c4 c1 7b 11 04 01    	vmovsd QWORD PTR [r9+rax*1],xmm0
    af52:	48 83 c0 08          	add    rax,0x8
    af56:	49 39 c5             	cmp    r13,rax
    af59:	75 e5                	jne    af40 <try_secant_tail.constprop.0+0x820>
    af5b:	8b 0c 24             	mov    ecx,DWORD PTR [rsp]
    af5e:	49 89 d0             	mov    r8,rdx
    af61:	8b 54 24 08          	mov    edx,DWORD PTR [rsp+0x8]
    af65:	4c 89 cf             	mov    rdi,r9
    af68:	44 89 9c 24 88 00 00 	mov    DWORD PTR [rsp+0x88],r11d
    af6f:	00 
    af70:	4c 89 94 24 80 00 00 	mov    QWORD PTR [rsp+0x80],r10
    af77:	00 
    af78:	4c 89 4c 24 70       	mov    QWORD PTR [rsp+0x70],r9
    af7d:	e8 7e 74 ff ff       	call   2400 <project_cgs2>
    af82:	4c 8b 4c 24 70       	mov    r9,QWORD PTR [rsp+0x70]
    af87:	8b 34 24             	mov    esi,DWORD PTR [rsp]
    af8a:	c5 fb 11 84 24 c0 00 	vmovsd QWORD PTR [rsp+0xc0],xmm0
    af91:	00 00 
    af93:	4c 89 cf             	mov    rdi,r9
    af96:	e8 55 51 ff ff       	call   f0 <norm2>
    af9b:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    afa2:	00 
    afa3:	31 c0                	xor    eax,eax
    afa5:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
    afa9:	44 8b 9c 24 88 00 00 	mov    r11d,DWORD PTR [rsp+0x88]
    afb0:	00 
    afb1:	4c 8b 94 24 80 00 00 	mov    r10,QWORD PTR [rsp+0x80]
    afb8:	00 
    afb9:	c5 f9 28 d8          	vmovapd xmm3,xmm0
    afbd:	0f 1f 00             	nop    DWORD PTR [rax]
    afc0:	c4 c1 7b 10 04 07    	vmovsd xmm0,QWORD PTR [r15+rax*1]
    afc6:	c5 fb 59 04 07       	vmulsd xmm0,xmm0,QWORD PTR [rdi+rax*1]
    afcb:	48 83 c0 08          	add    rax,0x8
    afcf:	49 39 c5             	cmp    r13,rax
    afd2:	c5 f3 58 c8          	vaddsd xmm1,xmm1,xmm0
    afd6:	75 e8                	jne    afc0 <try_secant_tail.constprop.0+0x8a0>
    afd8:	c5 fb 10 6c 24 48    	vmovsd xmm5,QWORD PTR [rsp+0x48]
    afde:	c5 d3 5c e1          	vsubsd xmm4,xmm5,xmm1
    afe2:	c5 fb 11 a4 24 b0 00 	vmovsd QWORD PTR [rsp+0xb0],xmm4
    afe9:	00 00 
    afeb:	8b 34 24             	mov    esi,DWORD PTR [rsp]
    afee:	4c 89 8c 24 98 00 00 	mov    QWORD PTR [rsp+0x98],r9
    aff5:	00 
    aff6:	c5 fb 11 9c 24 80 00 	vmovsd QWORD PTR [rsp+0x80],xmm3
    affd:	00 00 
    afff:	4c 89 94 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r10
    b006:	00 
    b007:	44 89 9c 24 88 00 00 	mov    DWORD PTR [rsp+0x88],r11d
    b00e:	00 
    b00f:	e8 dc 50 ff ff       	call   f0 <norm2>
    b014:	db ac 24 50 01 00 00 	fld    TBYTE PTR [rsp+0x150]
    b01b:	c5 fb 11 84 24 b8 00 	vmovsd QWORD PTR [rsp+0xb8],xmm0
    b022:	00 00 
    b024:	db 7c 24 70          	fstp   TBYTE PTR [rsp+0x70]
    b028:	c5 f8 77             	vzeroupper
    b02b:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # b032 <try_secant_tail.constprop.0+0x912>
    b032:	e8 00 00 00 00       	call   b037 <try_secant_tail.constprop.0+0x917>
    b037:	44 8b 9c 24 88 00 00 	mov    r11d,DWORD PTR [rsp+0x88]
    b03e:	00 
    b03f:	c5 fb 10 9c 24 80 00 	vmovsd xmm3,QWORD PTR [rsp+0x80]
    b046:	00 00 
    b048:	4c 8b 94 24 90 00 00 	mov    r10,QWORD PTR [rsp+0x90]
    b04f:	00 
    b050:	4c 8b 8c 24 98 00 00 	mov    r9,QWORD PTR [rsp+0x98]
    b057:	00 
    b058:	d9 ee                	fldz
    b05a:	c5 fb 10 90 00 00 00 	vmovsd xmm2,QWORD PTR [rax+0x0]
    b061:	00 
    b062:	db 6c 24 70          	fld    TBYTE PTR [rsp+0x70]
    b066:	db f1                	fcomi  st,st(1)
    b068:	dd d9                	fstp   st(1)
    b06a:	0f 86 00 03 00 00    	jbe    b370 <try_secant_tail.constprop.0+0xc50>
    b070:	d9 c0                	fld    st(0)
    b072:	d9 fa                	fsqrt
    b074:	dd 5c 24 70          	fstp   QWORD PTR [rsp+0x70]
    b078:	c5 fb 10 44 24 70    	vmovsd xmm0,QWORD PTR [rsp+0x70]
    b07e:	c5 f9 2f c2          	vcomisd xmm0,xmm2
    b082:	76 08                	jbe    b08c <try_secant_tail.constprop.0+0x96c>
    b084:	c5 fb 11 80 00 00 00 	vmovsd QWORD PTR [rax+0x0],xmm0
    b08b:	00 
    b08c:	c5 f9 2f 05 00 00 00 	vcomisd xmm0,QWORD PTR [rip+0x0]        # b094 <try_secant_tail.constprop.0+0x974>
    b093:	00 
    b094:	0f 82 a6 03 00 00    	jb     b440 <try_secant_tail.constprop.0+0xd20>
    b09a:	dd d8                	fstp   st(0)
    b09c:	eb 02                	jmp    b0a0 <try_secant_tail.constprop.0+0x980>
    b09e:	dd d8                	fstp   st(0)
    b0a0:	45 89 df             	mov    r15d,r11d
    b0a3:	45 85 ff             	test   r15d,r15d
    b0a6:	0f 88 ac 07 00 00    	js     b858 <try_secant_tail.constprop.0+0x1138>
    b0ac:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # b0b3 <try_secant_tail.constprop.0+0x993>
    b0b3:	e8 00 00 00 00       	call   b0b8 <try_secant_tail.constprop.0+0x998>
    b0b8:	8b a8 00 00 00 00    	mov    ebp,DWORD PTR [rax+0x0]
    b0be:	83 80 00 00 00 00 01 	add    DWORD PTR [rax+0x0],0x1
    b0c5:	85 ed                	test   ebp,ebp
    b0c7:	4c 63 e5             	movsxd r12,ebp
    b0ca:	0f 8e 6b 07 00 00    	jle    b83b <try_secant_tail.constprop.0+0x111b>
    b0d0:	48 05 00 00 00 00    	add    rax,0x0
    b0d6:	4c 63 e5             	movsxd r12,ebp
    b0d9:	4a 8d 14 a0          	lea    rdx,[rax+r12*4]
    b0dd:	eb 0e                	jmp    b0ed <try_secant_tail.constprop.0+0x9cd>
    b0df:	90                   	nop
    b0e0:	48 83 c0 04          	add    rax,0x4
    b0e4:	48 39 c2             	cmp    rdx,rax
    b0e7:	0f 84 49 07 00 00    	je     b836 <try_secant_tail.constprop.0+0x1116>
    b0ed:	44 3b 38             	cmp    r15d,DWORD PTR [rax]
    b0f0:	75 ee                	jne    b0e0 <try_secant_tail.constprop.0+0x9c0>
    b0f2:	e9 61 07 00 00       	jmp    b858 <try_secant_tail.constprop.0+0x1138>
    b0f7:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
    b0fe:	00 00 
    b100:	8b 4c 24 14          	mov    ecx,DWORD PTR [rsp+0x14]
    b104:	41 8d 83 00 08 00 00 	lea    eax,[r11+0x800]
    b10b:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    b110:	4c 89 54 24 08       	mov    QWORD PTR [rsp+0x8],r10
    b115:	44 89 1c 24          	mov    DWORD PTR [rsp],r11d
    b119:	39 c8                	cmp    eax,ecx
    b11b:	0f 4f c1             	cmovg  eax,ecx
    b11e:	31 f6                	xor    esi,esi
    b120:	b9 00 08 00 00       	mov    ecx,0x800
    b125:	41 89 c5             	mov    r13d,eax
    b128:	89 44 24 38          	mov    DWORD PTR [rsp+0x38],eax
    b12c:	45 29 dd             	sub    r13d,r11d
    b12f:	4d 63 fd             	movsxd r15,r13d
    b132:	4c 89 fa             	mov    rdx,r15
    b135:	e8 00 00 00 00       	call   b13a <try_secant_tail.constprop.0+0xa1a>
    b13a:	48 8b 8c 24 f8 00 00 	mov    rcx,QWORD PTR [rsp+0xf8]
    b141:	00 
    b142:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    b147:	31 f6                	xor    esi,esi
    b149:	48 89 ca             	mov    rdx,rcx
    b14c:	e8 00 00 00 00       	call   b151 <try_secant_tail.constprop.0+0xa31>
    b151:	48 8b 8c 24 f0 00 00 	mov    rcx,QWORD PTR [rsp+0xf0]
    b158:	00 
    b159:	48 8b bc 24 a0 00 00 	mov    rdi,QWORD PTR [rsp+0xa0]
    b160:	00 
    b161:	31 f6                	xor    esi,esi
    b163:	48 89 ca             	mov    rdx,rcx
    b166:	e8 00 00 00 00       	call   b16b <try_secant_tail.constprop.0+0xa4b>
    b16b:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    b170:	44 8b 1c 24          	mov    r11d,DWORD PTR [rsp]
    b174:	31 d2                	xor    edx,edx
    b176:	48 8b 8c 24 c8 00 00 	mov    rcx,QWORD PTR [rsp+0xc8]
    b17d:	00 
    b17e:	48 8b b4 24 a0 00 00 	mov    rsi,QWORD PTR [rsp+0xa0]
    b185:	00 
    b186:	44 89 ac 24 c0 01 00 	mov    DWORD PTR [rsp+0x1c0],r13d
    b18d:	00 
    b18e:	c5 fb 10 a4 24 a8 00 	vmovsd xmm4,QWORD PTR [rsp+0xa8]
    b195:	00 00 
    b197:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    b19c:	48 89 bc 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rdi
    b1a3:	00 
    b1a4:	48 8d 3d 05 81 ff ff 	lea    rdi,[rip+0xffffffffffff8105]        # 32b0 <try_secant_tail._omp_fn.0>
    b1ab:	48 89 8c 24 78 01 00 	mov    QWORD PTR [rsp+0x178],rcx
    b1b2:	00 
    b1b3:	48 8b 0d 00 00 00 00 	mov    rcx,QWORD PTR [rip+0x0]        # b1ba <try_secant_tail.constprop.0+0xa9a>
    b1ba:	48 89 b4 24 b0 01 00 	mov    QWORD PTR [rsp+0x1b0],rsi
    b1c1:	00 
    b1c2:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
    b1c7:	48 89 8c 24 70 01 00 	mov    QWORD PTR [rsp+0x170],rcx
    b1ce:	00 
    b1cf:	48 8b 4c 24 30       	mov    rcx,QWORD PTR [rsp+0x30]
    b1d4:	48 89 b4 24 a0 01 00 	mov    QWORD PTR [rsp+0x1a0],rsi
    b1db:	00 
    b1dc:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    b1e0:	48 89 8c 24 68 01 00 	mov    QWORD PTR [rsp+0x168],rcx
    b1e7:	00 
    b1e8:	48 8b 4c 24 28       	mov    rcx,QWORD PTR [rsp+0x28]
    b1ed:	c5 fb 11 a4 24 98 01 	vmovsd QWORD PTR [rsp+0x198],xmm4
    b1f4:	00 00 
    b1f6:	c5 fb 10 a4 24 d8 00 	vmovsd xmm4,QWORD PTR [rsp+0xd8]
    b1fd:	00 00 
    b1ff:	89 b4 24 b8 01 00 00 	mov    DWORD PTR [rsp+0x1b8],esi
    b206:	48 8d b4 24 60 01 00 	lea    rsi,[rsp+0x160]
    b20d:	00 
    b20e:	48 89 8c 24 60 01 00 	mov    QWORD PTR [rsp+0x160],rcx
    b215:	00 
    b216:	31 c9                	xor    ecx,ecx
    b218:	44 89 9c 24 bc 01 00 	mov    DWORD PTR [rsp+0x1bc],r11d
    b21f:	00 
    b220:	48 89 84 24 a8 01 00 	mov    QWORD PTR [rsp+0x1a8],rax
    b227:	00 
    b228:	4c 89 b4 24 88 01 00 	mov    QWORD PTR [rsp+0x188],r14
    b22f:	00 
    b230:	48 89 74 24 48       	mov    QWORD PTR [rsp+0x48],rsi
    b235:	c5 fb 11 a4 24 90 01 	vmovsd QWORD PTR [rsp+0x190],xmm4
    b23c:	00 00 
    b23e:	e8 00 00 00 00       	call   b243 <try_secant_tail.constprop.0+0xb23>
    b243:	8b bc 24 d0 00 00 00 	mov    edi,DWORD PTR [rsp+0xd0]
    b24a:	44 8b 1c 24          	mov    r11d,DWORD PTR [rsp]
    b24e:	4c 8b 54 24 08       	mov    r10,QWORD PTR [rsp+0x8]
    b253:	85 ff                	test   edi,edi
    b255:	0f 8e a9 00 00 00    	jle    b304 <try_secant_tail.constprop.0+0xbe4>
    b25b:	c5 fb 10 94 24 d0 01 	vmovsd xmm2,QWORD PTR [rsp+0x1d0]
    b262:	00 00 
    b264:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    b268:	c5 fb 10 8c 24 d8 01 	vmovsd xmm1,QWORD PTR [rsp+0x1d8]
    b26f:	00 00 
    b271:	85 f6                	test   esi,esi
    b273:	7e 4d                	jle    b2c2 <try_secant_tail.constprop.0+0xba2>
    b275:	48 8b 54 24 68       	mov    rdx,QWORD PTR [rsp+0x68]
    b27a:	48 8b b4 24 10 01 00 	mov    rsi,QWORD PTR [rsp+0x110]
    b281:	00 
    b282:	31 c9                	xor    ecx,ecx
    b284:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
    b288:	31 c0                	xor    eax,eax
    b28a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    b291:	00 00 00 00 
    b295:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    b29c:	00 00 00 00 
    b2a0:	c5 fb 10 04 c3       	vmovsd xmm0,QWORD PTR [rbx+rax*8]
    b2a5:	c5 fb 58 04 c2       	vaddsd xmm0,xmm0,QWORD PTR [rdx+rax*8]
    b2aa:	c5 fb 11 04 c3       	vmovsd QWORD PTR [rbx+rax*8],xmm0
    b2af:	48 83 c0 01          	add    rax,0x1
    b2b3:	41 39 c4             	cmp    r12d,eax
    b2b6:	7f e8                	jg     b2a0 <try_secant_tail.constprop.0+0xb80>
    b2b8:	83 c1 01             	add    ecx,0x1
    b2bb:	48 01 f2             	add    rdx,rsi
    b2be:	39 cf                	cmp    edi,ecx
    b2c0:	75 c6                	jne    b288 <try_secant_tail.constprop.0+0xb68>
    b2c2:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    b2c9:	00 
    b2ca:	48 8b 94 24 08 01 00 	mov    rdx,QWORD PTR [rsp+0x108]
    b2d1:	00 
    b2d2:	0f 1f 00             	nop    DWORD PTR [rax]
    b2d5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    b2dc:	00 00 00 00 
    b2e0:	c5 eb 58 10          	vaddsd xmm2,xmm2,QWORD PTR [rax]
    b2e4:	c5 f3 58 48 08       	vaddsd xmm1,xmm1,QWORD PTR [rax+0x8]
    b2e9:	48 83 c0 10          	add    rax,0x10
    b2ed:	48 39 c2             	cmp    rdx,rax
    b2f0:	75 ee                	jne    b2e0 <try_secant_tail.constprop.0+0xbc0>
    b2f2:	c5 fb 11 94 24 d0 01 	vmovsd QWORD PTR [rsp+0x1d0],xmm2
    b2f9:	00 00 
    b2fb:	c5 fb 11 8c 24 d8 01 	vmovsd QWORD PTR [rsp+0x1d8],xmm1
    b302:	00 00 
    b304:	45 85 ed             	test   r13d,r13d
    b307:	0f 8e 08 05 00 00    	jle    b815 <try_secant_tail.constprop.0+0x10f5>
    b30d:	48 8b 54 24 58       	mov    rdx,QWORD PTR [rsp+0x58]
    b312:	31 c0                	xor    eax,eax
    b314:	eb 17                	jmp    b32d <try_secant_tail.constprop.0+0xc0d>
    b316:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
    b31d:	00 00 00 
    b320:	48 83 c0 01          	add    rax,0x1
    b324:	49 39 c7             	cmp    r15,rax
    b327:	0f 84 e8 04 00 00    	je     b815 <try_secant_tail.constprop.0+0x10f5>
    b32d:	80 3c 02 00          	cmp    BYTE PTR [rdx+rax*1],0x0
    b331:	74 ed                	je     b320 <try_secant_tail.constprop.0+0xc00>
    b333:	8b 94 24 2c 01 00 00 	mov    edx,DWORD PTR [rsp+0x12c]
    b33a:	8b bc 24 24 01 00 00 	mov    edi,DWORD PTR [rsp+0x124]
    b341:	85 d2                	test   edx,edx
    b343:	89 7c 24 08          	mov    DWORD PTR [rsp+0x8],edi
    b347:	0f 85 9d 0c 00 00    	jne    bfea <try_secant_tail.constprop.0+0x18ca>
    b34d:	48 8b 74 24 30       	mov    rsi,QWORD PTR [rsp+0x30]
    b352:	41 01 c3             	add    r11d,eax
    b355:	49 89 e8             	mov    r8,rbp
    b358:	49 63 c3             	movsxd rax,r11d
    b35b:	4c 0f af c0          	imul   r8,rax
    b35f:	c5 7b 10 0c c6       	vmovsd xmm9,QWORD PTR [rsi+rax*8]
    b364:	4c 03 44 24 28       	add    r8,QWORD PTR [rsp+0x28]
    b369:	e9 b2 f8 ff ff       	jmp    ac20 <try_secant_tail.constprop.0+0x500>
    b36e:	66 90                	xchg   ax,ax
    b370:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
    b374:	c5 f9 2f c2          	vcomisd xmm0,xmm2
    b378:	76 0b                	jbe    b385 <try_secant_tail.constprop.0+0xc65>
    b37a:	48 c7 80 00 00 00 00 	mov    QWORD PTR [rax+0x0],0x0
    b381:	00 00 00 00 
    b385:	c5 fb 10 25 00 00 00 	vmovsd xmm4,QWORD PTR [rip+0x0]        # b38d <try_secant_tail.constprop.0+0xc6d>
    b38c:	00 
    b38d:	c5 f9 2f dc          	vcomisd xmm3,xmm4
    b391:	0f 86 e8 00 00 00    	jbe    b47f <try_secant_tail.constprop.0+0xd5f>
    b397:	c5 f9 28 c4          	vmovapd xmm0,xmm4
    b39b:	c5 e3 5c d0          	vsubsd xmm2,xmm3,xmm0
    b39f:	c5 f9 2f 15 00 00 00 	vcomisd xmm2,QWORD PTR [rip+0x0]        # b3a7 <try_secant_tail.constprop.0+0xc87>
    b3a6:	00 
    b3a7:	0f 86 b8 00 00 00    	jbe    b465 <try_secant_tail.constprop.0+0xd45>
    b3ad:	44 8b 84 24 24 01 00 	mov    r8d,DWORD PTR [rsp+0x124]
    b3b4:	00 
    b3b5:	44 39 04 24          	cmp    DWORD PTR [rsp],r8d
    b3b9:	0f 8e df fc ff ff    	jle    b09e <try_secant_tail.constprop.0+0x97e>
    b3bf:	8b 84 24 28 01 00 00 	mov    eax,DWORD PTR [rsp+0x128]
    b3c6:	41 39 c0             	cmp    r8d,eax
    b3c9:	0f 8c 99 05 00 00    	jl     b968 <try_secant_tail.constprop.0+0x1248>
    b3cf:	dd d8                	fstp   st(0)
    b3d1:	83 f8 07             	cmp    eax,0x7
    b3d4:	8b 94 24 20 01 00 00 	mov    edx,DWORD PTR [rsp+0x120]
    b3db:	0f 8f 96 08 00 00    	jg     bc77 <try_secant_tail.constprop.0+0x1557>
    b3e1:	41 bf 08 00 00 00    	mov    r15d,0x8
    b3e7:	44 39 fa             	cmp    edx,r15d
    b3ea:	44 0f 4e fa          	cmovle r15d,edx
    b3ee:	44 39 f8             	cmp    eax,r15d
    b3f1:	7d 1e                	jge    b411 <try_secant_tail.constprop.0+0xcf1>
    b3f3:	48 b8 ff ff ff ff ff 	movabs rax,0x1fffffffffffffff
    b3fa:	ff ff 1f 
    b3fd:	48 63 f2             	movsxd rsi,edx
    b400:	31 d2                	xor    edx,edx
    b402:	49 63 cf             	movsxd rcx,r15d
    b405:	48 f7 f6             	div    rsi
    b408:	48 39 c8             	cmp    rax,rcx
    b40b:	0f 83 a0 08 00 00    	jae    bcb1 <try_secant_tail.constprop.0+0x1591>
    b411:	8b 84 24 2c 01 00 00 	mov    eax,DWORD PTR [rsp+0x12c]
    b418:	85 c0                	test   eax,eax
    b41a:	0f 85 39 0a 00 00    	jne    be59 <try_secant_tail.constprop.0+0x1739>
    b420:	41 83 c3 01          	add    r11d,0x1
    b424:	44 39 5c 24 14       	cmp    DWORD PTR [rsp+0x14],r11d
    b429:	0f 8e 29 0c 00 00    	jle    c058 <try_secant_tail.constprop.0+0x1938>
    b42f:	83 44 24 18 01       	add    DWORD PTR [rsp+0x18],0x1
    b434:	44 89 44 24 08       	mov    DWORD PTR [rsp+0x8],r8d
    b439:	e9 81 f6 ff ff       	jmp    aabf <try_secant_tail.constprop.0+0x39f>
    b43e:	66 90                	xchg   ax,ax
    b440:	c5 fb 58 54 24 20    	vaddsd xmm2,xmm0,QWORD PTR [rsp+0x20]
    b446:	c5 fb 10 25 00 00 00 	vmovsd xmm4,QWORD PTR [rip+0x0]        # b44e <try_secant_tail.constprop.0+0xd2e>
    b44d:	00 
    b44e:	c5 eb 59 d4          	vmulsd xmm2,xmm2,xmm4
    b452:	c4 e2 e9 99 c0       	vfmadd132sd xmm0,xmm2,xmm0
    b457:	c5 f9 2f d8          	vcomisd xmm3,xmm0
    b45b:	0f 87 3a ff ff ff    	ja     b39b <try_secant_tail.constprop.0+0xc7b>
    b461:	dd d8                	fstp   st(0)
    b463:	eb 02                	jmp    b467 <try_secant_tail.constprop.0+0xd47>
    b465:	dd d8                	fstp   st(0)
    b467:	c5 fb 58 c3          	vaddsd xmm0,xmm0,xmm3
    b46b:	c5 fb 10 15 00 00 00 	vmovsd xmm2,QWORD PTR [rip+0x0]        # b473 <try_secant_tail.constprop.0+0xd53>
    b472:	00 
    b473:	c5 f9 2f d0          	vcomisd xmm2,xmm0
    b477:	0f 86 23 fc ff ff    	jbe    b0a0 <try_secant_tail.constprop.0+0x980>
    b47d:	eb 02                	jmp    b481 <try_secant_tail.constprop.0+0xd61>
    b47f:	dd d8                	fstp   st(0)
    b481:	c5 fb 10 6c 24 48    	vmovsd xmm5,QWORD PTR [rsp+0x48]
    b487:	c5 d1 54 05 00 00 00 	vandpd xmm0,xmm5,XMMWORD PTR [rip+0x0]        # b48f <try_secant_tail.constprop.0+0xd6f>
    b48e:	00 
    b48f:	c5 fb 58 44 24 20    	vaddsd xmm0,xmm0,QWORD PTR [rsp+0x20]
    b495:	8b 84 24 24 01 00 00 	mov    eax,DWORD PTR [rsp+0x124]
    b49c:	c5 fb 58 84 24 b8 00 	vaddsd xmm0,xmm0,QWORD PTR [rsp+0xb8]
    b4a3:	00 00 
    b4a5:	c5 fb 59 05 00 00 00 	vmulsd xmm0,xmm0,QWORD PTR [rip+0x0]        # b4ad <try_secant_tail.constprop.0+0xd8d>
    b4ac:	00 
    b4ad:	c5 fb 10 ac 24 b0 00 	vmovsd xmm5,QWORD PTR [rsp+0xb0]
    b4b4:	00 00 
    b4b6:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    b4ba:	c5 d1 54 0d 00 00 00 	vandpd xmm1,xmm5,XMMWORD PTR [rip+0x0]        # b4c2 <try_secant_tail.constprop.0+0xda2>
    b4c1:	00 
    b4c2:	c5 f9 2f c8          	vcomisd xmm1,xmm0
    b4c6:	0f 86 74 04 00 00    	jbe    b940 <try_secant_tail.constprop.0+0x1220>
    b4cc:	39 04 24             	cmp    DWORD PTR [rsp],eax
    b4cf:	4d 89 f9             	mov    r9,r15
    b4d2:	45 89 df             	mov    r15d,r11d
    b4d5:	0f 84 19 0b 00 00    	je     bff4 <try_secant_tail.constprop.0+0x18d4>
    b4db:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    b4e0:	4c 89 ce             	mov    rsi,r9
    b4e3:	e8 98 73 ff ff       	call   2880 <local_dependency_svd>
    b4e8:	83 f8 01             	cmp    eax,0x1
    b4eb:	0f 85 b2 fb ff ff    	jne    b0a3 <try_secant_tail.constprop.0+0x983>
    b4f1:	8b 84 24 24 01 00 00 	mov    eax,DWORD PTR [rsp+0x124]
    b4f8:	c7 84 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],0x1
    b4ff:	01 00 00 00 
    b503:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    b507:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    b50c:	e8 00 00 00 00       	call   b511 <try_secant_tail.constprop.0+0xdf1>
    b511:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    b516:	e8 00 00 00 00       	call   b51b <try_secant_tail.constprop.0+0xdfb>
    b51b:	48 8b bc 24 a0 00 00 	mov    rdi,QWORD PTR [rsp+0xa0]
    b522:	00 
    b523:	e8 00 00 00 00       	call   b528 <try_secant_tail.constprop.0+0xe08>
    b528:	48 8d b4 24 60 01 00 	lea    rsi,[rsp+0x160]
    b52f:	00 
    b530:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    b537:	00 
    b538:	8b 7c 24 08          	mov    edi,DWORD PTR [rsp+0x8]
    b53c:	48 c7 84 24 70 01 00 	mov    QWORD PTR [rsp+0x170],0x0
    b543:	00 00 00 00 00 
    b548:	c7 84 24 78 01 00 00 	mov    DWORD PTR [rsp+0x178],0x0
    b54f:	00 00 00 00 
    b553:	8b 4c 24 14          	mov    ecx,DWORD PTR [rsp+0x14]
    b557:	89 78 04             	mov    DWORD PTR [rax+0x4],edi
    b55a:	8b 7c 24 10          	mov    edi,DWORD PTR [rsp+0x10]
    b55e:	c7 00 03 00 00 00    	mov    DWORD PTR [rax],0x3
    b564:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
    b56b:	00 
    b56c:	89 bc 24 9c 01 00 00 	mov    DWORD PTR [rsp+0x19c],edi
    b573:	48 89 84 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rax
    b57a:	00 
    b57b:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    b580:	89 8c 24 98 01 00 00 	mov    DWORD PTR [rsp+0x198],ecx
    b587:	48 89 84 24 88 01 00 	mov    QWORD PTR [rsp+0x188],rax
    b58e:	00 
    b58f:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    b594:	48 c7 84 24 60 01 00 	mov    QWORD PTR [rsp+0x160],0x0
    b59b:	00 00 00 00 00 
    b5a0:	48 89 84 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rax
    b5a7:	00 
    b5a8:	48 63 c1             	movsxd rax,ecx
    b5ab:	48 0f af 44 24 50    	imul   rax,QWORD PTR [rsp+0x50]
    b5b1:	c7 84 24 68 01 00 00 	mov    DWORD PTR [rsp+0x168],0x0
    b5b8:	00 00 00 00 
    b5bc:	48 3d 3f 42 0f 00    	cmp    rax,0xf423f
    b5c2:	0f 9f c2             	setg   dl
    b5c5:	81 ff 7f 01 00 00    	cmp    edi,0x17f
    b5cb:	48 8d 3d 9e 4e ff ff 	lea    rdi,[rip+0xffffffffffff4e9e]        # 470 <relres._omp_fn.0>
    b5d2:	0f 9e c0             	setle  al
    b5d5:	31 c9                	xor    ecx,ecx
    b5d7:	21 c2                	and    edx,eax
    b5d9:	83 f2 01             	xor    edx,0x1
    b5dc:	0f b6 d2             	movzx  edx,dl
    b5df:	e8 00 00 00 00       	call   b5e4 <try_secant_tail.constprop.0+0xec4>
    b5e4:	db ac 24 70 01 00 00 	fld    TBYTE PTR [rsp+0x170]
    b5eb:	db ac 24 60 01 00 00 	fld    TBYTE PTR [rsp+0x160]
    b5f2:	d9 ee                	fldz
    b5f4:	df f1                	fcomip st,st(1)
    b5f6:	0f 84 ee 08 00 00    	je     beea <try_secant_tail.constprop.0+0x17ca>
    b5fc:	d9 fa                	fsqrt
    b5fe:	d9 c9                	fxch   st(1)
    b600:	48 8b 8c 24 00 01 00 	mov    rcx,QWORD PTR [rsp+0x100]
    b607:	00 
    b608:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    b60f:	00 
    b610:	48 85 c9             	test   rcx,rcx
    b613:	d9 fa                	fsqrt
    b615:	de f1                	fdivrp st(1),st
    b617:	dd 58 18             	fstp   QWORD PTR [rax+0x18]
    b61a:	0f 84 0f 0a 00 00    	je     c02f <try_secant_tail.constprop.0+0x190f>
    b620:	8b 7c 24 10          	mov    edi,DWORD PTR [rsp+0x10]
    b624:	85 ff                	test   edi,edi
    b626:	0f 8e 10 0a 00 00    	jle    c03c <try_secant_tail.constprop.0+0x191c>
    b62c:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
    b630:	48 8b 94 24 38 01 00 	mov    rdx,QWORD PTR [rsp+0x138]
    b637:	00 
    b638:	31 c0                	xor    eax,eax
    b63a:	c5 f9 28 d3          	vmovapd xmm2,xmm3
    b63e:	c5 fb 10 0c 01       	vmovsd xmm1,QWORD PTR [rcx+rax*1]
    b643:	c5 fb 10 04 02       	vmovsd xmm0,QWORD PTR [rdx+rax*1]
    b648:	48 83 c0 08          	add    rax,0x8
    b64c:	48 39 c5             	cmp    rbp,rax
    b64f:	c5 fb 5c c1          	vsubsd xmm0,xmm0,xmm1
    b653:	c4 e2 f1 b9 d9       	vfmadd231sd xmm3,xmm1,xmm1
    b658:	c4 e2 f9 b9 d0       	vfmadd231sd xmm2,xmm0,xmm0
    b65d:	75 df                	jne    b63e <try_secant_tail.constprop.0+0xf1e>
    b65f:	c5 eb 51 d2          	vsqrtsd xmm2,xmm2,xmm2
    b663:	c5 e3 51 db          	vsqrtsd xmm3,xmm3,xmm3
    b667:	c5 e3 58 1d 00 00 00 	vaddsd xmm3,xmm3,QWORD PTR [rip+0x0]        # b66f <try_secant_tail.constprop.0+0xf4f>
    b66e:	00 
    b66f:	c5 eb 5e d3          	vdivsd xmm2,xmm2,xmm3
    b673:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    b67a:	00 
    b67b:	c5 fb 11 50 20       	vmovsd QWORD PTR [rax+0x20],xmm2
    b680:	48 8b bc 24 30 01 00 	mov    rdi,QWORD PTR [rsp+0x130]
    b687:	00 
    b688:	e8 00 00 00 00       	call   b68d <try_secant_tail.constprop.0+0xf6d>
    b68d:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    b694:	00 
    b695:	e8 00 00 00 00       	call   b69a <try_secant_tail.constprop.0+0xf7a>
    b69a:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    b6a1:	00 
    b6a2:	e8 00 00 00 00       	call   b6a7 <try_secant_tail.constprop.0+0xf87>
    b6a7:	4c 89 f7             	mov    rdi,r14
    b6aa:	e8 00 00 00 00       	call   b6af <try_secant_tail.constprop.0+0xf8f>
    b6af:	48 89 df             	mov    rdi,rbx
    b6b2:	e8 00 00 00 00       	call   b6b7 <try_secant_tail.constprop.0+0xf97>
    b6b7:	41 ba 01 00 00 00    	mov    r10d,0x1
    b6bd:	e9 d7 f0 ff ff       	jmp    a799 <try_secant_tail.constprop.0+0x79>
    b6c2:	41 8d 43 01          	lea    eax,[r11+0x1]
    b6c6:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
    b6ca:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # b6d2 <try_secant_tail.constprop.0+0xfb2>
    b6d1:	00 
    b6d2:	48 be eb 11 31 13 bb 	movabs rsi,0x94d049bb133111eb
    b6d9:	49 d0 94 
    b6dc:	c5 7b 10 a4 24 d8 00 	vmovsd xmm12,QWORD PTR [rsp+0xd8]
    b6e3:	00 00 
    b6e5:	48 63 d0             	movsxd rdx,eax
    b6e8:	89 44 24 38          	mov    DWORD PTR [rsp+0x38],eax
    b6ec:	48 b9 15 7c 4a 7f b9 	movabs rcx,0x9e3779b97f4a7c15
    b6f3:	79 37 9e 
    b6f6:	48 89 d0             	mov    rax,rdx
    b6f9:	48 03 8c 24 c8 00 00 	add    rcx,QWORD PTR [rsp+0xc8]
    b700:	00 
    b701:	48 0f af c6          	imul   rax,rsi
    b705:	48 01 c8             	add    rax,rcx
    b708:	48 89 c7             	mov    rdi,rax
    b70b:	48 c1 ef 1e          	shr    rdi,0x1e
    b70f:	48 31 f8             	xor    rax,rdi
    b712:	48 bf b9 e5 e4 1c 6d 	movabs rdi,0xbf58476d1ce4e5b9
    b719:	47 58 bf 
    b71c:	48 0f af c7          	imul   rax,rdi
    b720:	48 0f af d7          	imul   rdx,rdi
    b724:	49 89 c1             	mov    r9,rax
    b727:	49 c1 e9 1b          	shr    r9,0x1b
    b72b:	4c 31 c8             	xor    rax,r9
    b72e:	48 0f af c6          	imul   rax,rsi
    b732:	49 89 c1             	mov    r9,rax
    b735:	49 c1 e9 1f          	shr    r9,0x1f
    b739:	4c 31 c8             	xor    rax,r9
    b73c:	48 c1 e8 0b          	shr    rax,0xb
    b740:	c4 e1 db 2a c0       	vcvtsi2sd xmm0,xmm4,rax
    b745:	48 8d 04 0a          	lea    rax,[rdx+rcx*1]
    b749:	c5 f9 28 d8          	vmovapd xmm3,xmm0
    b74d:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # b755 <try_secant_tail.constprop.0+0x1035>
    b754:	00 
    b755:	48 89 c2             	mov    rdx,rax
    b758:	48 c1 ea 1e          	shr    rdx,0x1e
    b75c:	c4 e2 f9 99 dd       	vfmadd132sd xmm3,xmm0,xmm5
    b761:	48 31 d0             	xor    rax,rdx
    b764:	48 0f af c7          	imul   rax,rdi
    b768:	c4 c1 63 59 dc       	vmulsd xmm3,xmm3,xmm12
    b76d:	48 89 c2             	mov    rdx,rax
    b770:	48 c1 ea 1b          	shr    rdx,0x1b
    b774:	48 31 c2             	xor    rdx,rax
    b777:	48 0f af d6          	imul   rdx,rsi
    b77b:	48 89 d0             	mov    rax,rdx
    b77e:	48 c1 e8 1f          	shr    rax,0x1f
    b782:	48 31 d0             	xor    rax,rdx
    b785:	8b 54 24 10          	mov    edx,DWORD PTR [rsp+0x10]
    b789:	48 c1 e8 0b          	shr    rax,0xb
    b78d:	c4 e1 db 2a e0       	vcvtsi2sd xmm4,xmm4,rax
    b792:	c4 e2 f9 99 e5       	vfmadd132sd xmm4,xmm0,xmm5
    b797:	85 d2                	test   edx,edx
    b799:	c4 c1 5b 59 e4       	vmulsd xmm4,xmm4,xmm12
    b79e:	7e 4a                	jle    b7ea <try_secant_tail.constprop.0+0x10ca>
    b7a0:	c5 73 59 d3          	vmulsd xmm10,xmm1,xmm3
    b7a4:	48 8b 94 24 18 01 00 	mov    rdx,QWORD PTR [rsp+0x118]
    b7ab:	00 
    b7ac:	31 c0                	xor    eax,eax
    b7ae:	c5 f3 59 ec          	vmulsd xmm5,xmm1,xmm4
    b7b2:	0f 1f 00             	nop    DWORD PTR [rax]
    b7b5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    b7bc:	00 00 00 00 
    b7c0:	c4 c1 7b 10 04 00    	vmovsd xmm0,QWORD PTR [r8+rax*1]
    b7c6:	c4 41 79 28 da       	vmovapd xmm11,xmm10
    b7cb:	c4 62 f9 a9 1c 03    	vfmadd213sd xmm11,xmm0,QWORD PTR [rbx+rax*1]
    b7d1:	c5 7b 11 1c 03       	vmovsd QWORD PTR [rbx+rax*1],xmm11
    b7d6:	c4 e2 d1 a9 04 02    	vfmadd213sd xmm0,xmm5,QWORD PTR [rdx+rax*1]
    b7dc:	c5 fb 11 04 02       	vmovsd QWORD PTR [rdx+rax*1],xmm0
    b7e1:	48 83 c0 08          	add    rax,0x8
    b7e5:	48 39 c5             	cmp    rbp,rax
    b7e8:	75 d6                	jne    b7c0 <try_secant_tail.constprop.0+0x10a0>
    b7ea:	c4 e2 e9 a9 9c 24 d0 	vfmadd213sd xmm3,xmm2,QWORD PTR [rsp+0x1d0]
    b7f1:	01 00 00 
    b7f4:	c4 e2 e9 a9 a4 24 d8 	vfmadd213sd xmm4,xmm2,QWORD PTR [rsp+0x1d8]
    b7fb:	01 00 00 
    b7fe:	c5 fb 11 9c 24 d0 01 	vmovsd QWORD PTR [rsp+0x1d0],xmm3
    b805:	00 00 
    b807:	c5 fb 11 a4 24 d8 01 	vmovsd QWORD PTR [rsp+0x1d8],xmm4
    b80e:	00 00 
    b810:	e9 a2 f3 ff ff       	jmp    abb7 <try_secant_tail.constprop.0+0x497>
    b815:	8b 84 24 24 01 00 00 	mov    eax,DWORD PTR [rsp+0x124]
    b81c:	44 01 6c 24 18       	add    DWORD PTR [rsp+0x18],r13d
    b821:	8b bc 24 2c 01 00 00 	mov    edi,DWORD PTR [rsp+0x12c]
    b828:	44 8b 7c 24 38       	mov    r15d,DWORD PTR [rsp+0x38]
    b82d:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    b831:	e9 35 f4 ff ff       	jmp    ac6b <try_secant_tail.constprop.0+0x54b>
    b836:	83 fd 40             	cmp    ebp,0x40
    b839:	74 1d                	je     b858 <try_secant_tail.constprop.0+0x1138>
    b83b:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # b842 <try_secant_tail.constprop.0+0x1122>
    b842:	e8 00 00 00 00       	call   b847 <try_secant_tail.constprop.0+0x1127>
    b847:	83 c5 01             	add    ebp,0x1
    b84a:	89 a8 00 00 00 00    	mov    DWORD PTR [rax+0x0],ebp
    b850:	46 89 bc a0 00 00 00 	mov    DWORD PTR [rax+r12*4+0x0],r15d
    b857:	00 
    b858:	48 8b bc 24 30 01 00 	mov    rdi,QWORD PTR [rsp+0x130]
    b85f:	00 
    b860:	e8 00 00 00 00       	call   b865 <try_secant_tail.constprop.0+0x1145>
    b865:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    b86c:	00 
    b86d:	e8 00 00 00 00       	call   b872 <try_secant_tail.constprop.0+0x1152>
    b872:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    b879:	00 
    b87a:	e8 00 00 00 00       	call   b87f <try_secant_tail.constprop.0+0x115f>
    b87f:	4c 89 f7             	mov    rdi,r14
    b882:	e8 00 00 00 00       	call   b887 <try_secant_tail.constprop.0+0x1167>
    b887:	48 89 df             	mov    rdi,rbx
    b88a:	e8 00 00 00 00       	call   b88f <try_secant_tail.constprop.0+0x116f>
    b88f:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    b894:	e8 00 00 00 00       	call   b899 <try_secant_tail.constprop.0+0x1179>
    b899:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    b89e:	e8 00 00 00 00       	call   b8a3 <try_secant_tail.constprop.0+0x1183>
    b8a3:	48 8b bc 24 a0 00 00 	mov    rdi,QWORD PTR [rsp+0xa0]
    b8aa:	00 
    b8ab:	e8 00 00 00 00       	call   b8b0 <try_secant_tail.constprop.0+0x1190>
    b8b0:	45 31 d2             	xor    r10d,r10d
    b8b3:	e9 e1 ee ff ff       	jmp    a799 <try_secant_tail.constprop.0+0x79>
    b8b8:	41 83 c3 01          	add    r11d,0x1
    b8bc:	44 39 5c 24 14       	cmp    DWORD PTR [rsp+0x14],r11d
    b8c1:	0f 8e 3d 07 00 00    	jle    c004 <try_secant_tail.constprop.0+0x18e4>
    b8c7:	83 44 24 18 01       	add    DWORD PTR [rsp+0x18],0x1
    b8cc:	e9 ee f1 ff ff       	jmp    aabf <try_secant_tail.constprop.0+0x39f>
    b8d1:	49 89 d0             	mov    r8,rdx
    b8d4:	8b 54 24 08          	mov    edx,DWORD PTR [rsp+0x8]
    b8d8:	4c 89 cf             	mov    rdi,r9
    b8db:	89 c1                	mov    ecx,eax
    b8dd:	4c 89 94 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r10
    b8e4:	00 
    b8e5:	44 89 9c 24 80 00 00 	mov    DWORD PTR [rsp+0x80],r11d
    b8ec:	00 
    b8ed:	4c 89 4c 24 70       	mov    QWORD PTR [rsp+0x70],r9
    b8f2:	e8 09 6b ff ff       	call   2400 <project_cgs2>
    b8f7:	4c 8b 4c 24 70       	mov    r9,QWORD PTR [rsp+0x70]
    b8fc:	8b 34 24             	mov    esi,DWORD PTR [rsp]
    b8ff:	c5 fb 11 84 24 c0 00 	vmovsd QWORD PTR [rsp+0xc0],xmm0
    b906:	00 00 
    b908:	4c 89 cf             	mov    rdi,r9
    b90b:	e8 e0 47 ff ff       	call   f0 <norm2>
    b910:	c5 fb 10 64 24 48    	vmovsd xmm4,QWORD PTR [rsp+0x48]
    b916:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    b91d:	00 
    b91e:	44 8b 9c 24 80 00 00 	mov    r11d,DWORD PTR [rsp+0x80]
    b925:	00 
    b926:	4c 8b 94 24 88 00 00 	mov    r10,QWORD PTR [rsp+0x88]
    b92d:	00 
    b92e:	c5 f9 28 d8          	vmovapd xmm3,xmm0
    b932:	c5 fb 11 a4 24 b0 00 	vmovsd QWORD PTR [rsp+0xb0],xmm4
    b939:	00 00 
    b93b:	e9 ab f6 ff ff       	jmp    afeb <try_secant_tail.constprop.0+0x8cb>
    b940:	8b 84 24 2c 01 00 00 	mov    eax,DWORD PTR [rsp+0x12c]
    b947:	85 c0                	test   eax,eax
    b949:	0f 85 0f 05 00 00    	jne    be5e <try_secant_tail.constprop.0+0x173e>
    b94f:	41 83 c3 01          	add    r11d,0x1
    b953:	44 39 5c 24 14       	cmp    DWORD PTR [rsp+0x14],r11d
    b958:	0f 8f 69 ff ff ff    	jg     b8c7 <try_secant_tail.constprop.0+0x11a7>
    b95e:	e9 66 f5 ff ff       	jmp    aec9 <try_secant_tail.constprop.0+0x7a9>
    b963:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    b968:	c5 fb 10 8c 24 b0 00 	vmovsd xmm1,QWORD PTR [rsp+0xb0]
    b96f:	00 00 
    b971:	8b 7c 24 40          	mov    edi,DWORD PTR [rsp+0x40]
    b975:	45 89 df             	mov    r15d,r11d
    b978:	4d 89 eb             	mov    r11,r13
    b97b:	48 8b 8c 24 30 01 00 	mov    rcx,QWORD PTR [rsp+0x130]
    b982:	00 
    b983:	49 63 d0             	movsxd rdx,r8d
    b986:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    b989:	49 0f af d3          	imul   rdx,r11
    b98d:	48 01 ca             	add    rdx,rcx
    b990:	85 c0                	test   eax,eax
    b992:	7e 20                	jle    b9b4 <try_secant_tail.constprop.0+0x1294>
    b994:	c5 fb 10 6c 24 20    	vmovsd xmm5,QWORD PTR [rsp+0x20]
    b99a:	31 c0                	xor    eax,eax
    b99c:	c5 d3 5e d3          	vdivsd xmm2,xmm5,xmm3
    b9a0:	c4 c1 6b 59 04 01    	vmulsd xmm0,xmm2,QWORD PTR [r9+rax*1]
    b9a6:	c5 fb 11 04 02       	vmovsd QWORD PTR [rdx+rax*1],xmm0
    b9ab:	48 83 c0 08          	add    rax,0x8
    b9af:	49 39 c3             	cmp    r11,rax
    b9b2:	75 ec                	jne    b9a0 <try_secant_tail.constprop.0+0x1280>
    b9b4:	41 83 f8 5f          	cmp    r8d,0x5f
    b9b8:	48 63 84 24 20 01 00 	movsxd rax,DWORD PTR [rsp+0x120]
    b9bf:	00 
    b9c0:	0f 8e c7 03 00 00    	jle    bd8d <try_secant_tail.constprop.0+0x166d>
    b9c6:	d9 ee                	fldz
    b9c8:	d9 c9                	fxch   st(1)
    b9ca:	db f1                	fcomi  st,st(1)
    b9cc:	dd d9                	fstp   st(1)
    b9ce:	0f 86 ae 03 00 00    	jbe    bd82 <try_secant_tail.constprop.0+0x1662>
    b9d4:	d9 c0                	fld    st(0)
    b9d6:	c5 e3 58 15 00 00 00 	vaddsd xmm2,xmm3,QWORD PTR [rip+0x0]        # b9de <try_secant_tail.constprop.0+0x12be>
    b9dd:	00 
    b9de:	c5 fb 10 ac 24 c0 00 	vmovsd xmm5,QWORD PTR [rsp+0xc0]
    b9e5:	00 00 
    b9e7:	d9 fa                	fsqrt
    b9e9:	c5 d3 5e d2          	vdivsd xmm2,xmm5,xmm2
    b9ed:	dd 5c 24 18          	fstp   QWORD PTR [rsp+0x18]
    b9f1:	c5 fb 10 44 24 18    	vmovsd xmm0,QWORD PTR [rsp+0x18]
    b9f7:	c4 e2 d9 99 c2       	vfmadd132sd xmm0,xmm4,xmm2
    b9fc:	c5 fb 11 44 24 18    	vmovsd QWORD PTR [rsp+0x18],xmm0
    ba02:	dd 44 24 18          	fld    QWORD PTR [rsp+0x18]
    ba06:	d8 c8                	fmul   st,st(0)
    ba08:	d8 c0                	fadd   st,st(0)
    ba0a:	85 c0                	test   eax,eax
    ba0c:	0f 8e be 04 00 00    	jle    bed0 <try_secant_tail.constprop.0+0x17b0>
    ba12:	48 89 d6             	mov    rsi,rdx
    ba15:	48 8d 04 c2          	lea    rax,[rdx+rax*8]
    ba19:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    ba1d:	0f 1f 00             	nop    DWORD PTR [rax]
    ba20:	c5 fb 10 06          	vmovsd xmm0,QWORD PTR [rsi]
    ba24:	48 83 c6 08          	add    rsi,0x8
    ba28:	48 39 f0             	cmp    rax,rsi
    ba2b:	c5 fb 59 c0          	vmulsd xmm0,xmm0,xmm0
    ba2f:	c5 eb 58 d0          	vaddsd xmm2,xmm2,xmm0
    ba33:	75 eb                	jne    ba20 <try_secant_tail.constprop.0+0x1300>
    ba35:	c5 eb 5c 44 24 20    	vsubsd xmm0,xmm2,QWORD PTR [rsp+0x20]
    ba3b:	c5 f9 54 05 00 00 00 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x0]        # ba43 <try_secant_tail.constprop.0+0x1323>
    ba42:	00 
    ba43:	c5 fb 58 e4          	vaddsd xmm4,xmm0,xmm4
    ba47:	c5 fb 11 64 24 18    	vmovsd QWORD PTR [rsp+0x18],xmm4
    ba4d:	dd 44 24 18          	fld    QWORD PTR [rsp+0x18]
    ba51:	d8 c8                	fmul   st,st(0)
    ba53:	d9 ca                	fxch   st(2)
    ba55:	de c1                	faddp  st(1),st
    ba57:	de c1                	faddp  st(1),st
    ba59:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    ba5c:	db bc 24 50 01 00 00 	fstp   TBYTE PTR [rsp+0x150]
    ba63:	85 c0                	test   eax,eax
    ba65:	7e 32                	jle    ba99 <try_secant_tail.constprop.0+0x1379>
    ba67:	c5 f3 5e db          	vdivsd xmm3,xmm1,xmm3
    ba6b:	48 8b b4 24 38 01 00 	mov    rsi,QWORD PTR [rsp+0x138]
    ba72:	00 
    ba73:	31 c0                	xor    eax,eax
    ba75:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    ba7c:	00 00 00 00 
    ba80:	c5 fb 10 04 02       	vmovsd xmm0,QWORD PTR [rdx+rax*1]
    ba85:	c4 e2 e1 a9 04 06    	vfmadd213sd xmm0,xmm3,QWORD PTR [rsi+rax*1]
    ba8b:	c5 fb 11 04 06       	vmovsd QWORD PTR [rsi+rax*1],xmm0
    ba90:	48 83 c0 08          	add    rax,0x8
    ba94:	49 39 c3             	cmp    r11,rax
    ba97:	75 e7                	jne    ba80 <try_secant_tail.constprop.0+0x1360>
    ba99:	8b b4 24 2c 01 00 00 	mov    esi,DWORD PTR [rsp+0x12c]
    baa0:	41 8d 40 01          	lea    eax,[r8+0x1]
    baa4:	89 84 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],eax
    baab:	85 f6                	test   esi,esi
    baad:	89 74 24 18          	mov    DWORD PTR [rsp+0x18],esi
    bab1:	0f 85 60 05 00 00    	jne    c017 <try_secant_tail.constprop.0+0x18f7>
    bab7:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    babb:	39 c6                	cmp    esi,eax
    babd:	0f 84 32 04 00 00    	je     bef5 <try_secant_tail.constprop.0+0x17d5>
    bac3:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    baca:	48 89 4c 24 40       	mov    QWORD PTR [rsp+0x40],rcx
    bacf:	49 89 d9             	mov    r9,rbx
    bad2:	4d 89 f3             	mov    r11,r14
    bad5:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    badc:	00 
    badd:	41 bd 02 00 00 00    	mov    r13d,0x2
    bae3:	83 c0 01             	add    eax,0x1
    bae6:	89 04 24             	mov    DWORD PTR [rsp],eax
    bae9:	e8 02 46 ff ff       	call   f0 <norm2>
    baee:	4c 63 44 24 08       	movsxd r8,DWORD PTR [rsp+0x8]
    baf3:	c5 fb 10 35 00 00 00 	vmovsd xmm6,QWORD PTR [rip+0x0]        # bafb <try_secant_tail.constprop.0+0x13db>
    bafa:	00 
    bafb:	c5 fb 11 84 24 a8 00 	vmovsd QWORD PTR [rsp+0xa8],xmm0
    bb02:	00 00 
    bb04:	4c 0f af c5          	imul   r8,rbp
    bb08:	4c 03 44 24 40       	add    r8,QWORD PTR [rsp+0x40]
    bb0d:	4c 89 c3             	mov    rbx,r8
    bb10:	45 89 e0             	mov    r8d,r12d
    bb13:	4d 89 d4             	mov    r12,r10
    bb16:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    bb1a:	85 c0                	test   eax,eax
    bb1c:	0f 8e 3f 02 00 00    	jle    bd61 <try_secant_tail.constprop.0+0x1641>
    bb22:	31 c0                	xor    eax,eax
    bb24:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
    bb28:	66 90                	xchg   ax,ax
    bb2a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    bb31:	00 00 00 00 
    bb35:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    bb3c:	00 00 00 00 
    bb40:	c4 c1 7b 10 04 06    	vmovsd xmm0,QWORD PTR [r14+rax*1]
    bb46:	c5 fb 59 04 03       	vmulsd xmm0,xmm0,QWORD PTR [rbx+rax*1]
    bb4b:	48 83 c0 08          	add    rax,0x8
    bb4f:	48 39 c5             	cmp    rbp,rax
    bb52:	c5 f3 58 c8          	vaddsd xmm1,xmm1,xmm0
    bb56:	75 e8                	jne    bb40 <try_secant_tail.constprop.0+0x1420>
    bb58:	31 c0                	xor    eax,eax
    bb5a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    bb60:	c5 fb 10 04 03       	vmovsd xmm0,QWORD PTR [rbx+rax*1]
    bb65:	c4 c2 f1 ad 04 06    	vfnmadd213sd xmm0,xmm1,QWORD PTR [r14+rax*1]
    bb6b:	c4 c1 7b 11 04 06    	vmovsd QWORD PTR [r14+rax*1],xmm0
    bb71:	48 83 c0 08          	add    rax,0x8
    bb75:	48 39 c5             	cmp    rbp,rax
    bb78:	75 e6                	jne    bb60 <try_secant_tail.constprop.0+0x1440>
    bb7a:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    bb7e:	4c 89 f7             	mov    rdi,r14
    bb81:	e8 6a 45 ff ff       	call   f0 <norm2>
    bb86:	c5 f9 2f f0          	vcomisd xmm6,xmm0
    bb8a:	77 3b                	ja     bbc7 <try_secant_tail.constprop.0+0x14a7>
    bb8c:	c5 fb 10 6c 24 20    	vmovsd xmm5,QWORD PTR [rsp+0x20]
    bb92:	4c 89 f0             	mov    rax,r14
    bb95:	c5 d3 5e c0          	vdivsd xmm0,xmm5,xmm0
    bb99:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    bba0:	c5 fb 59 08          	vmulsd xmm1,xmm0,QWORD PTR [rax]
    bba4:	48 83 c0 08          	add    rax,0x8
    bba8:	c5 fb 11 48 f8       	vmovsd QWORD PTR [rax-0x8],xmm1
    bbad:	49 39 c4             	cmp    r12,rax
    bbb0:	75 ee                	jne    bba0 <try_secant_tail.constprop.0+0x1480>
    bbb2:	41 83 ed 01          	sub    r13d,0x1
    bbb6:	0f 84 91 00 00 00    	je     bc4d <try_secant_tail.constprop.0+0x152d>
    bbbc:	49 01 ee             	add    r14,rbp
    bbbf:	49 01 ec             	add    r12,rbp
    bbc2:	e9 5b ff ff ff       	jmp    bb22 <try_secant_tail.constprop.0+0x1402>
    bbc7:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    bbcc:	4c 89 f7             	mov    rdi,r14
    bbcf:	4c 89 5c 24 70       	mov    QWORD PTR [rsp+0x70],r11
    bbd4:	49 01 ee             	add    r14,rbp
    bbd7:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    bbde:	4c 89 8c 24 80 00 00 	mov    QWORD PTR [rsp+0x80],r9
    bbe5:	00 
    bbe6:	49 01 ec             	add    r12,rbp
    bbe9:	4c 89 54 24 48       	mov    QWORD PTR [rsp+0x48],r10
    bbee:	8d 14 c5 00 00 00 00 	lea    edx,[rax*8+0x0]
    bbf5:	44 89 44 24 40       	mov    DWORD PTR [rsp+0x40],r8d
    bbfa:	29 c2                	sub    edx,eax
    bbfc:	c5 fb 11 74 24 08    	vmovsd QWORD PTR [rsp+0x8],xmm6
    bc02:	48 b8 03 ed 92 d1 32 	movabs rax,0xd1b54a32d192ed03
    bc09:	4a b5 d1 
    bc0c:	83 c2 0a             	add    edx,0xa
    bc0f:	44 29 ea             	sub    edx,r13d
    bc12:	48 63 d2             	movsxd rdx,edx
    bc15:	48 0f af d0          	imul   rdx,rax
    bc19:	48 03 94 24 e0 00 00 	add    rdx,QWORD PTR [rsp+0xe0]
    bc20:	00 
    bc21:	e8 1a 6b ff ff       	call   2740 <secant_refresh>
    bc26:	41 83 ed 01          	sub    r13d,0x1
    bc2a:	c5 fb 10 74 24 08    	vmovsd xmm6,QWORD PTR [rsp+0x8]
    bc30:	44 8b 44 24 40       	mov    r8d,DWORD PTR [rsp+0x40]
    bc35:	4c 8b 54 24 48       	mov    r10,QWORD PTR [rsp+0x48]
    bc3a:	4c 8b 5c 24 70       	mov    r11,QWORD PTR [rsp+0x70]
    bc3f:	4c 8b 8c 24 80 00 00 	mov    r9,QWORD PTR [rsp+0x80]
    bc46:	00 
    bc47:	0f 85 c9 fe ff ff    	jne    bb16 <try_secant_tail.constprop.0+0x13f6>
    bc4d:	8b 84 24 24 01 00 00 	mov    eax,DWORD PTR [rsp+0x124]
    bc54:	45 89 c4             	mov    r12d,r8d
    bc57:	4d 89 de             	mov    r14,r11
    bc5a:	4c 89 cb             	mov    rbx,r9
    bc5d:	8b bc 24 2c 01 00 00 	mov    edi,DWORD PTR [rsp+0x12c]
    bc64:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    bc68:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    bc6b:	89 84 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],eax
    bc72:	e9 f0 ef ff ff       	jmp    ac67 <try_secant_tail.constprop.0+0x547>
    bc77:	85 d2                	test   edx,edx
    bc79:	8d 4a 03             	lea    ecx,[rdx+0x3]
    bc7c:	44 8d 3c 85 00 00 00 	lea    r15d,[rax*4+0x0]
    bc83:	00 
    bc84:	0f 49 ca             	cmovns ecx,edx
    bc87:	c1 f9 02             	sar    ecx,0x2
    bc8a:	39 c8                	cmp    eax,ecx
    bc8c:	44 0f 4f fa          	cmovg  r15d,edx
    bc90:	e9 59 f7 ff ff       	jmp    b3ee <try_secant_tail.constprop.0+0xcce>
    bc95:	c5 fb 10 1d 00 00 00 	vmovsd xmm3,QWORD PTR [rip+0x0]        # bc9d <try_secant_tail.constprop.0+0x157d>
    bc9c:	00 
    bc9d:	c5 fb 11 5c 24 20    	vmovsd QWORD PTR [rsp+0x20],xmm3
    bca3:	c5 fb 11 9c 24 d8 00 	vmovsd QWORD PTR [rsp+0xd8],xmm3
    bcaa:	00 00 
    bcac:	e9 66 ec ff ff       	jmp    a917 <try_secant_tail.constprop.0+0x1f7>
    bcb1:	48 0f af ce          	imul   rcx,rsi
    bcb5:	48 8b bc 24 30 01 00 	mov    rdi,QWORD PTR [rsp+0x130]
    bcbc:	00 
    bcbd:	4c 89 54 24 70       	mov    QWORD PTR [rsp+0x70],r10
    bcc2:	44 89 5c 24 48       	mov    DWORD PTR [rsp+0x48],r11d
    bcc7:	4c 89 8c 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r9
    bcce:	00 
    bccf:	48 8d 34 cd 00 00 00 	lea    rsi,[rcx*8+0x0]
    bcd6:	00 
    bcd7:	c5 fb 11 9c 24 80 00 	vmovsd QWORD PTR [rsp+0x80],xmm3
    bcde:	00 00 
    bce0:	c5 fb 11 a4 24 88 00 	vmovsd QWORD PTR [rsp+0x88],xmm4
    bce7:	00 00 
    bce9:	e8 00 00 00 00       	call   bcee <try_secant_tail.constprop.0+0x15ce>
    bcee:	44 8b 5c 24 48       	mov    r11d,DWORD PTR [rsp+0x48]
    bcf3:	4c 8b 54 24 70       	mov    r10,QWORD PTR [rsp+0x70]
    bcf8:	48 85 c0             	test   rax,rax
    bcfb:	44 8b 84 24 24 01 00 	mov    r8d,DWORD PTR [rsp+0x124]
    bd02:	00 
    bd03:	48 89 c1             	mov    rcx,rax
    bd06:	0f 84 05 f7 ff ff    	je     b411 <try_secant_tail.constprop.0+0xcf1>
    bd0c:	44 89 d8             	mov    eax,r11d
    bd0f:	4d 89 eb             	mov    r11,r13
    bd12:	45 89 fd             	mov    r13d,r15d
    bd15:	48 89 8c 24 30 01 00 	mov    QWORD PTR [rsp+0x130],rcx
    bd1c:	00 
    bd1d:	44 89 ac 24 28 01 00 	mov    DWORD PTR [rsp+0x128],r13d
    bd24:	00 
    bd25:	8b 7c 24 40          	mov    edi,DWORD PTR [rsp+0x40]
    bd29:	41 89 c7             	mov    r15d,eax
    bd2c:	db ac 24 50 01 00 00 	fld    TBYTE PTR [rsp+0x150]
    bd33:	4c 8b 8c 24 90 00 00 	mov    r9,QWORD PTR [rsp+0x90]
    bd3a:	00 
    bd3b:	c5 fb 10 8c 24 b0 00 	vmovsd xmm1,QWORD PTR [rsp+0xb0]
    bd42:	00 00 
    bd44:	c5 fb 10 a4 24 88 00 	vmovsd xmm4,QWORD PTR [rsp+0x88]
    bd4b:	00 00 
    bd4d:	c5 fb 10 9c 24 80 00 	vmovsd xmm3,QWORD PTR [rsp+0x80]
    bd54:	00 00 
    bd56:	e9 28 fc ff ff       	jmp    b983 <try_secant_tail.constprop.0+0x1263>
    bd5b:	49 01 ee             	add    r14,rbp
    bd5e:	49 01 ec             	add    r12,rbp
    bd61:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    bd65:	4c 89 f7             	mov    rdi,r14
    bd68:	e8 83 43 ff ff       	call   f0 <norm2>
    bd6d:	c5 f9 2f f0          	vcomisd xmm6,xmm0
    bd71:	0f 87 50 fe ff ff    	ja     bbc7 <try_secant_tail.constprop.0+0x14a7>
    bd77:	41 83 ed 01          	sub    r13d,0x1
    bd7b:	75 de                	jne    bd5b <try_secant_tail.constprop.0+0x163b>
    bd7d:	e9 cb fe ff ff       	jmp    bc4d <try_secant_tail.constprop.0+0x152d>
    bd82:	d9 05 00 00 00 00    	fld    DWORD PTR [rip+0x0]        # bd88 <try_secant_tail.constprop.0+0x1668>
    bd88:	e9 7d fc ff ff       	jmp    ba0a <try_secant_tail.constprop.0+0x12ea>
    bd8d:	85 c0                	test   eax,eax
    bd8f:	0f 8e 93 02 00 00    	jle    c028 <try_secant_tail.constprop.0+0x1908>
    bd95:	4c 63 c8             	movsxd r9,eax
    bd98:	48 89 d6             	mov    rsi,rdx
    bd9b:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    bd9f:	4e 8d 0c ca          	lea    r9,[rdx+r9*8]
    bda3:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    bdaa:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    bdb1:	00 00 00 00 
    bdb5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    bdbc:	00 00 00 00 
    bdc0:	c5 fb 10 06          	vmovsd xmm0,QWORD PTR [rsi]
    bdc4:	48 83 c6 08          	add    rsi,0x8
    bdc8:	49 39 f1             	cmp    r9,rsi
    bdcb:	c5 fb 59 c0          	vmulsd xmm0,xmm0,xmm0
    bdcf:	c5 eb 58 d0          	vaddsd xmm2,xmm2,xmm0
    bdd3:	75 eb                	jne    bdc0 <try_secant_tail.constprop.0+0x16a0>
    bdd5:	c5 eb 5c 64 24 20    	vsubsd xmm4,xmm2,QWORD PTR [rsp+0x20]
    bddb:	c5 fb 11 64 24 18    	vmovsd QWORD PTR [rsp+0x18],xmm4
    bde1:	dd 44 24 18          	fld    QWORD PTR [rsp+0x18]
    bde5:	d8 c8                	fmul   st,st(0)
    bde7:	45 85 c0             	test   r8d,r8d
    bdea:	7e 66                	jle    be52 <try_secant_tail.constprop.0+0x1732>
    bdec:	85 c0                	test   eax,eax
    bdee:	7e 62                	jle    be52 <try_secant_tail.constprop.0+0x1732>
    bdf0:	4c 8d 0c c5 00 00 00 	lea    r9,[rax*8+0x0]
    bdf7:	00 
    bdf8:	48 89 ce             	mov    rsi,rcx
    bdfb:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    be00:	31 c0                	xor    eax,eax
    be02:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    be06:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
    be0a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    be11:	00 00 00 00 
    be15:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    be1c:	00 00 00 00 
    be20:	c5 fb 10 04 02       	vmovsd xmm0,QWORD PTR [rdx+rax*1]
    be25:	c5 fb 59 04 06       	vmulsd xmm0,xmm0,QWORD PTR [rsi+rax*1]
    be2a:	48 83 c0 08          	add    rax,0x8
    be2e:	49 39 c1             	cmp    r9,rax
    be31:	c5 eb 58 d0          	vaddsd xmm2,xmm2,xmm0
    be35:	75 e9                	jne    be20 <try_secant_tail.constprop.0+0x1700>
    be37:	c5 fb 11 54 24 18    	vmovsd QWORD PTR [rsp+0x18],xmm2
    be3d:	dd 44 24 18          	fld    QWORD PTR [rsp+0x18]
    be41:	83 c7 01             	add    edi,0x1
    be44:	4c 01 ce             	add    rsi,r9
    be47:	44 39 c7             	cmp    edi,r8d
    be4a:	d8 c8                	fmul   st,st(0)
    be4c:	d8 c0                	fadd   st,st(0)
    be4e:	de c1                	faddp  st(1),st
    be50:	75 ae                	jne    be00 <try_secant_tail.constprop.0+0x16e0>
    be52:	de c1                	faddp  st(1),st
    be54:	e9 00 fc ff ff       	jmp    ba59 <try_secant_tail.constprop.0+0x1339>
    be59:	44 89 44 24 08       	mov    DWORD PTR [rsp+0x8],r8d
    be5e:	48 8d b4 24 60 01 00 	lea    rsi,[rsp+0x160]
    be65:	00 
    be66:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    be6b:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    be6f:	e8 00 00 00 00       	call   be74 <try_secant_tail.constprop.0+0x1754>
    be74:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    be79:	e8 00 00 00 00       	call   be7e <try_secant_tail.constprop.0+0x175e>
    be7e:	48 8b bc 24 a0 00 00 	mov    rdi,QWORD PTR [rsp+0xa0]
    be85:	00 
    be86:	e8 00 00 00 00       	call   be8b <try_secant_tail.constprop.0+0x176b>
    be8b:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    be8f:	e9 9c f6 ff ff       	jmp    b530 <try_secant_tail.constprop.0+0xe10>
    be94:	48 8b bc 24 30 01 00 	mov    rdi,QWORD PTR [rsp+0x130]
    be9b:	00 
    be9c:	e8 00 00 00 00       	call   bea1 <try_secant_tail.constprop.0+0x1781>
    bea1:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    bea8:	00 
    bea9:	e8 00 00 00 00       	call   beae <try_secant_tail.constprop.0+0x178e>
    beae:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    beb5:	00 
    beb6:	e8 00 00 00 00       	call   bebb <try_secant_tail.constprop.0+0x179b>
    bebb:	4c 89 f7             	mov    rdi,r14
    bebe:	e8 00 00 00 00       	call   bec3 <try_secant_tail.constprop.0+0x17a3>
    bec3:	48 89 df             	mov    rdi,rbx
    bec6:	e8 00 00 00 00       	call   becb <try_secant_tail.constprop.0+0x17ab>
    becb:	e9 e0 f9 ff ff       	jmp    b8b0 <try_secant_tail.constprop.0+0x1190>
    bed0:	dd 05 00 00 00 00    	fld    QWORD PTR [rip+0x0]        # bed6 <try_secant_tail.constprop.0+0x17b6>
    bed6:	d9 ca                	fxch   st(2)
    bed8:	e9 78 fb ff ff       	jmp    ba55 <try_secant_tail.constprop.0+0x1335>
    bedd:	c5 fb 10 15 00 00 00 	vmovsd xmm2,QWORD PTR [rip+0x0]        # bee5 <try_secant_tail.constprop.0+0x17c5>
    bee4:	00 
    bee5:	e9 0b ef ff ff       	jmp    adf5 <try_secant_tail.constprop.0+0x6d5>
    beea:	dd d8                	fstp   st(0)
    beec:	d9 e8                	fld1
    beee:	d9 c9                	fxch   st(1)
    bef0:	e9 0b f7 ff ff       	jmp    b600 <try_secant_tail.constprop.0+0xee0>
    bef5:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    befa:	e8 00 00 00 00       	call   beff <try_secant_tail.constprop.0+0x17df>
    beff:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    bf04:	e8 00 00 00 00       	call   bf09 <try_secant_tail.constprop.0+0x17e9>
    bf09:	48 8b bc 24 a0 00 00 	mov    rdi,QWORD PTR [rsp+0xa0]
    bf10:	00 
    bf11:	e8 00 00 00 00       	call   bf16 <try_secant_tail.constprop.0+0x17f6>
    bf16:	44 8b 7c 24 10       	mov    r15d,DWORD PTR [rsp+0x10]
    bf1b:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # bf23 <try_secant_tail.constprop.0+0x1803>
    bf22:	00 
    bf23:	4c 8d 8c 24 60 01 00 	lea    r9,[rsp+0x160]
    bf2a:	00 
    bf2b:	8b 4c 24 14          	mov    ecx,DWORD PTR [rsp+0x14]
    bf2f:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    bf34:	48 8b 94 24 38 01 00 	mov    rdx,QWORD PTR [rsp+0x138]
    bf3b:	00 
    bf3c:	48 8b 74 24 30       	mov    rsi,QWORD PTR [rsp+0x30]
    bf41:	45 89 f8             	mov    r8d,r15d
    bf44:	e8 07 47 ff ff       	call   650 <compat_scan_fused>
    bf49:	48 8b 8c 24 00 01 00 	mov    rcx,QWORD PTR [rsp+0x100]
    bf50:	00 
    bf51:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    bf58:	00 
    bf59:	c5 fb 10 84 24 60 01 	vmovsd xmm0,QWORD PTR [rsp+0x160]
    bf60:	00 00 
    bf62:	83 f8 01             	cmp    eax,0x1
    bf65:	19 c0                	sbb    eax,eax
    bf67:	44 89 7f 04          	mov    DWORD PTR [rdi+0x4],r15d
    bf6b:	83 e0 fe             	and    eax,0xfffffffe
    bf6e:	c5 fb 11 47 18       	vmovsd QWORD PTR [rdi+0x18],xmm0
    bf73:	83 c0 03             	add    eax,0x3
    bf76:	48 85 c9             	test   rcx,rcx
    bf79:	89 07                	mov    DWORD PTR [rdi],eax
    bf7b:	0f 84 ca 00 00 00    	je     c04b <try_secant_tail.constprop.0+0x192b>
    bf81:	45 85 ff             	test   r15d,r15d
    bf84:	0f 8e bb 00 00 00    	jle    c045 <try_secant_tail.constprop.0+0x1925>
    bf8a:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    bf8e:	48 8b 94 24 38 01 00 	mov    rdx,QWORD PTR [rsp+0x138]
    bf95:	00 
    bf96:	31 c0                	xor    eax,eax
    bf98:	c5 f9 28 ca          	vmovapd xmm1,xmm2
    bf9c:	c5 fb 10 1c 01       	vmovsd xmm3,QWORD PTR [rcx+rax*1]
    bfa1:	c5 fb 10 04 02       	vmovsd xmm0,QWORD PTR [rdx+rax*1]
    bfa6:	48 83 c0 08          	add    rax,0x8
    bfaa:	48 39 c5             	cmp    rbp,rax
    bfad:	c5 fb 5c c3          	vsubsd xmm0,xmm0,xmm3
    bfb1:	c4 e2 e1 b9 d3       	vfmadd231sd xmm2,xmm3,xmm3
    bfb6:	c4 e2 f9 b9 c8       	vfmadd231sd xmm1,xmm0,xmm0
    bfbb:	75 df                	jne    bf9c <try_secant_tail.constprop.0+0x187c>
    bfbd:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
    bfc1:	c5 eb 51 d2          	vsqrtsd xmm2,xmm2,xmm2
    bfc5:	c5 eb 58 15 00 00 00 	vaddsd xmm2,xmm2,QWORD PTR [rip+0x0]        # bfcd <try_secant_tail.constprop.0+0x18ad>
    bfcc:	00 
    bfcd:	c5 f3 5e ca          	vdivsd xmm1,xmm1,xmm2
    bfd1:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    bfd8:	00 
    bfd9:	c7 40 0c 00 00 00 00 	mov    DWORD PTR [rax+0xc],0x0
    bfe0:	c5 fb 11 48 20       	vmovsd QWORD PTR [rax+0x20],xmm1
    bfe5:	e9 96 f6 ff ff       	jmp    b680 <try_secant_tail.constprop.0+0xf60>
    bfea:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    bfef:	e9 72 fe ff ff       	jmp    be66 <try_secant_tail.constprop.0+0x1746>
    bff4:	c7 84 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],0x1
    bffb:	01 00 00 00 
    bfff:	e9 03 f5 ff ff       	jmp    b507 <try_secant_tail.constprop.0+0xde7>
    c004:	44 8b 44 24 40       	mov    r8d,DWORD PTR [rsp+0x40]
    c009:	e9 6b ec ff ff       	jmp    ac79 <try_secant_tail.constprop.0+0x559>
    c00e:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    c012:	e9 de ed ff ff       	jmp    adf5 <try_secant_tail.constprop.0+0x6d5>
    c017:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    c01b:	48 8d b4 24 60 01 00 	lea    rsi,[rsp+0x160]
    c022:	00 
    c023:	e9 3e fe ff ff       	jmp    be66 <try_secant_tail.constprop.0+0x1746>
    c028:	d9 e8                	fld1
    c02a:	e9 b8 fd ff ff       	jmp    bde7 <try_secant_tail.constprop.0+0x16c7>
    c02f:	c5 fb 10 15 00 00 00 	vmovsd xmm2,QWORD PTR [rip+0x0]        # c037 <try_secant_tail.constprop.0+0x1917>
    c036:	00 
    c037:	e9 37 f6 ff ff       	jmp    b673 <try_secant_tail.constprop.0+0xf53>
    c03c:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    c040:	e9 2e f6 ff ff       	jmp    b673 <try_secant_tail.constprop.0+0xf53>
    c045:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
    c049:	eb 86                	jmp    bfd1 <try_secant_tail.constprop.0+0x18b1>
    c04b:	c5 fb 10 0d 00 00 00 	vmovsd xmm1,QWORD PTR [rip+0x0]        # c053 <try_secant_tail.constprop.0+0x1933>
    c052:	00 
    c053:	e9 79 ff ff ff       	jmp    bfd1 <try_secant_tail.constprop.0+0x18b1>
    c058:	44 89 44 24 08       	mov    DWORD PTR [rsp+0x8],r8d
    c05d:	e9 67 ee ff ff       	jmp    aec9 <try_secant_tail.constprop.0+0x7a9>
    c062:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    c067:	e8 00 00 00 00       	call   c06c <try_secant_tail.constprop.0+0x194c>
    c06c:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    c071:	e8 00 00 00 00       	call   c076 <try_secant_tail.constprop.0+0x1956>
    c076:	48 8b bc 24 a0 00 00 	mov    rdi,QWORD PTR [rsp+0xa0]
    c07d:	00 
    c07e:	e8 00 00 00 00       	call   c083 <try_secant_tail.constprop.0+0x1963>
    c083:	4c 89 f7             	mov    rdi,r14
    c086:	e8 00 00 00 00       	call   c08b <try_secant_tail.constprop.0+0x196b>
    c08b:	48 89 df             	mov    rdi,rbx
    c08e:	e8 00 00 00 00       	call   c093 <try_secant_tail.constprop.0+0x1973>
    c093:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    c098:	e8 33 40 ff ff       	call   d0 <bs_free>
    c09d:	e9 f1 e6 ff ff       	jmp    a793 <try_secant_tail.constprop.0+0x73>
    c0a2:	48 8d b4 24 60 01 00 	lea    rsi,[rsp+0x160]
    c0a9:	00 
    c0aa:	e9 81 f4 ff ff       	jmp    b530 <try_secant_tail.constprop.0+0xe10>
    c0af:	e8 00 00 00 00       	call   c0b4 <try_secant_tail.constprop.0+0x1994>
