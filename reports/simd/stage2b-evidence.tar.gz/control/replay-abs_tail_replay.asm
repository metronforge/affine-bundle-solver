/tmp/abs-stage2b-measured-control/tail.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000022b50 <abs_tail_replay>:
   22b50:	f3 0f 1e fa          	endbr64
   22b54:	53                   	push   rbx
   22b55:	48 83 ec 38          	sub    rsp,0x38
   22b59:	64 48 8b 1c 25 28 00 	mov    rbx,QWORD PTR fs:0x28
   22b60:	00 00 
   22b62:	48 89 5c 24 30       	mov    QWORD PTR [rsp+0x30],rbx
   22b67:	48 8b 5c 24 50       	mov    rbx,QWORD PTR [rsp+0x50]
   22b6c:	48 8d 44 24 08       	lea    rax,[rsp+0x8]
   22b71:	48 c7 44 24 08 00 00 	mov    QWORD PTR [rsp+0x8],0x0
   22b78:	00 00 
   22b7a:	48 c7 44 24 10 00 00 	mov    QWORD PTR [rsp+0x10],0x0
   22b81:	00 00 
   22b83:	48 c7 44 24 18 00 00 	mov    QWORD PTR [rsp+0x18],0x0
   22b8a:	00 00 
   22b8c:	48 c7 44 24 20 00 00 	mov    QWORD PTR [rsp+0x20],0x0
   22b93:	00 00 
   22b95:	48 c7 44 24 28 00 00 	mov    QWORD PTR [rsp+0x28],0x0
   22b9c:	00 00 
   22b9e:	50                   	push   rax
   22b9f:	ff 74 24 50          	push   QWORD PTR [rsp+0x50]
   22ba3:	41 51                	push   r9
   22ba5:	45 89 c1             	mov    r9d,r8d
   22ba8:	41 89 c8             	mov    r8d,ecx
   22bab:	89 d1                	mov    ecx,edx
   22bad:	31 d2                	xor    edx,edx
   22baf:	e8 ec 7c fe ff       	call   a8a0 <try_secant_tail.constprop.0>
   22bb4:	c5 f8 57 c0          	vxorps xmm0,xmm0,xmm0
   22bb8:	c5 fb 2a 4c 24 20    	vcvtsi2sd xmm1,xmm0,DWORD PTR [rsp+0x20]
   22bbe:	c5 f9 13 0b          	vmovlpd QWORD PTR [rbx],xmm1
   22bc2:	c5 fb 2a 4c 24 24    	vcvtsi2sd xmm1,xmm0,DWORD PTR [rsp+0x24]
   22bc8:	c5 f9 13 4b 08       	vmovlpd QWORD PTR [rbx+0x8],xmm1
   22bcd:	c5 fb 2a 4c 24 28    	vcvtsi2sd xmm1,xmm0,DWORD PTR [rsp+0x28]
   22bd3:	c5 f9 13 4b 10       	vmovlpd QWORD PTR [rbx+0x10],xmm1
   22bd8:	c5 fb 2a 4c 24 2c    	vcvtsi2sd xmm1,xmm0,DWORD PTR [rsp+0x2c]
   22bde:	c5 fb 2a c0          	vcvtsi2sd xmm0,xmm0,eax
   22be2:	c5 f9 13 4b 18       	vmovlpd QWORD PTR [rbx+0x18],xmm1
   22be7:	c5 fb 10 4c 24 30    	vmovsd xmm1,QWORD PTR [rsp+0x30]
   22bed:	c5 f9 13 43 38       	vmovlpd QWORD PTR [rbx+0x38],xmm0
   22bf2:	c5 fb 11 4b 20       	vmovsd QWORD PTR [rbx+0x20],xmm1
   22bf7:	c5 fb 10 4c 24 38    	vmovsd xmm1,QWORD PTR [rsp+0x38]
   22bfd:	c5 fb 11 4b 28       	vmovsd QWORD PTR [rbx+0x28],xmm1
   22c02:	c5 fb 10 4c 24 40    	vmovsd xmm1,QWORD PTR [rsp+0x40]
   22c08:	48 83 c4 20          	add    rsp,0x20
   22c0c:	c5 fb 11 4b 30       	vmovsd QWORD PTR [rbx+0x30],xmm1
   22c11:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   22c16:	64 48 2b 04 25 28 00 	sub    rax,QWORD PTR fs:0x28
   22c1d:	00 00 
   22c1f:	75 06                	jne    22c27 <abs_tail_replay+0xd7>
   22c21:	48 83 c4 30          	add    rsp,0x30
   22c25:	5b                   	pop    rbx
   22c26:	c3                   	ret
   22c27:	e8 00 00 00 00       	call   22c2c <abs_tail_replay+0xdc>
