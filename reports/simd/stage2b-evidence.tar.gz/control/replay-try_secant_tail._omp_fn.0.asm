/tmp/abs-stage2b-measured-control/tail.o:     file format elf64-x86-64


Disassembly of section .text:

00000000000032b0 <try_secant_tail._omp_fn.0>:
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	41 57                	push   r15
    32b6:	49 89 ff             	mov    r15,rdi
    32b9:	41 56                	push   r14
    32bb:	41 55                	push   r13
    32bd:	41 54                	push   r12
    32bf:	55                   	push   rbp
    32c0:	53                   	push   rbx
    32c1:	48 83 ec 48          	sub    rsp,0x48
    32c5:	e8 00 00 00 00       	call   32ca <try_secant_tail._omp_fn.0+0x1a>
    32ca:	89 c3                	mov    ebx,eax
    32cc:	e8 00 00 00 00       	call   32d1 <try_secant_tail._omp_fn.0+0x21>
    32d1:	89 c1                	mov    ecx,eax
    32d3:	41 8b 47 60          	mov    eax,DWORD PTR [r15+0x60]
    32d7:	99                   	cdq
    32d8:	f7 f9                	idiv   ecx
    32da:	39 d3                	cmp    ebx,edx
    32dc:	8d 48 01             	lea    ecx,[rax+0x1]
    32df:	0f 4c c1             	cmovl  eax,ecx
    32e2:	b9 00 00 00 00       	mov    ecx,0x0
    32e7:	0f 4c d1             	cmovl  edx,ecx
    32ea:	89 c1                	mov    ecx,eax
    32ec:	0f af cb             	imul   ecx,ebx
    32ef:	01 ca                	add    edx,ecx
    32f1:	8d 0c 10             	lea    ecx,[rax+rdx*1]
    32f4:	39 ca                	cmp    edx,ecx
    32f6:	0f 8d f7 02 00 00    	jge    35f3 <try_secant_tail._omp_fn.0+0x343>
    32fc:	48 63 f3             	movsxd rsi,ebx
    32ff:	4d 8b 67 40          	mov    r12,QWORD PTR [r15+0x40]
    3303:	4d 63 47 5c          	movsxd r8,DWORD PTR [r15+0x5c]
    3307:	89 c0                	mov    eax,eax
    3309:	48 89 f3             	mov    rbx,rsi
    330c:	48 c1 e6 04          	shl    rsi,0x4
    3310:	49 03 77 50          	add    rsi,QWORD PTR [r15+0x50]
    3314:	4d 63 4f 58          	movsxd r9,DWORD PTR [r15+0x58]
    3318:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    331d:	49 8b 77 20          	mov    rsi,QWORD PTR [r15+0x20]
    3321:	4c 89 c1             	mov    rcx,r8
    3324:	c4 41 28 57 d2       	vxorps xmm10,xmm10,xmm10
    3329:	49 0f af d9          	imul   rbx,r9
    332d:	4d 8b 57 28          	mov    r10,QWORD PTR [r15+0x28]
    3331:	c4 41 7b 10 5f 10    	vmovsd xmm11,QWORD PTR [r15+0x10]
    3337:	4d 89 ce             	mov    r14,r9
    333a:	48 89 74 24 10       	mov    QWORD PTR [rsp+0x10],rsi
    333f:	48 63 f2             	movsxd rsi,edx
    3342:	c5 7b 10 25 00 00 00 	vmovsd xmm12,QWORD PTR [rip+0x0]        # 334a <try_secant_tail._omp_fn.0+0x9a>
    3349:	00 
    334a:	49 c1 e1 03          	shl    r9,0x3
    334e:	49 01 f4             	add    r12,rsi
    3351:	c4 c1 1b 58 5f 38    	vaddsd xmm3,xmm12,QWORD PTR [r15+0x38]
    3357:	4f 8d 1c 0a          	lea    r11,[r10+r9*1]
    335b:	49 01 f0             	add    r8,rsi
    335e:	4c 01 e0             	add    rax,r12
    3361:	49 8b 77 08          	mov    rsi,QWORD PTR [r15+0x8]
    3365:	48 c1 e3 04          	shl    rbx,0x4
    3369:	c4 41 7b 10 4f 30    	vmovsd xmm9,QWORD PTR [r15+0x30]
    336f:	48 89 44 24 08       	mov    QWORD PTR [rsp+0x8],rax
    3374:	8d 44 11 01          	lea    eax,[rcx+rdx*1+0x1]
    3378:	49 03 5f 48          	add    rbx,QWORD PTR [r15+0x48]
    337c:	44 29 e0             	sub    eax,r12d
    337f:	c5 7b 10 05 00 00 00 	vmovsd xmm8,QWORD PTR [rip+0x0]        # 3387 <try_secant_tail._omp_fn.0+0xd7>
    3386:	00 
    3387:	4e 8d 2c c6          	lea    r13,[rsi+r8*8]
    338b:	4a 8d 2c 0b          	lea    rbp,[rbx+r9*1]
    338f:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    3393:	c5 fb 10 3d 00 00 00 	vmovsd xmm7,QWORD PTR [rip+0x0]        # 339b <try_secant_tail._omp_fn.0+0xeb>
    339a:	00 
    339b:	4d 0f af c1          	imul   r8,r9
    339f:	48 b8 15 7c 4a 7f b9 	movabs rax,0x9e3779b97f4a7c15
    33a6:	79 37 9e 
    33a9:	49 03 47 18          	add    rax,QWORD PTR [r15+0x18]
    33ad:	4d 03 07             	add    r8,QWORD PTR [r15]
    33b0:	c5 fb 11 5c 24 38    	vmovsd QWORD PTR [rsp+0x38],xmm3
    33b6:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    33bb:	c5 7b 11 5c 24 18    	vmovsd QWORD PTR [rsp+0x18],xmm11
    33c1:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    33c8:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
    33cc:	45 85 f6             	test   r14d,r14d
    33cf:	c5 79 28 fe          	vmovapd xmm15,xmm6
    33d3:	c5 79 28 ee          	vmovapd xmm13,xmm6
    33d7:	0f 8e 33 02 00 00    	jle    3610 <try_secant_tail._omp_fn.0+0x360>
    33dd:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    33e2:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
    33e6:	c5 79 28 fe          	vmovapd xmm15,xmm6
    33ea:	c5 79 28 ee          	vmovapd xmm13,xmm6
    33ee:	c5 f9 28 c6          	vmovapd xmm0,xmm6
    33f2:	48 8b 50 18          	mov    rdx,QWORD PTR [rax+0x18]
    33f6:	31 c0                	xor    eax,eax
    33f8:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
    33ff:	00 
    3400:	c4 c1 7b 10 14 00    	vmovsd xmm2,QWORD PTR [r8+rax*1]
    3406:	c4 62 e9 b9 2c 02    	vfmadd231sd xmm13,xmm2,QWORD PTR [rdx+rax*1]
    340c:	c4 42 e9 b9 3c 02    	vfmadd231sd xmm15,xmm2,QWORD PTR [r10+rax*1]
    3412:	c4 c2 e9 b9 34 03    	vfmadd231sd xmm6,xmm2,QWORD PTR [r11+rax*1]
    3418:	48 83 c0 08          	add    rax,0x8
    341c:	49 39 c1             	cmp    r9,rax
    341f:	c4 e2 e9 b9 c2       	vfmadd231sd xmm0,xmm2,xmm2
    3424:	75 da                	jne    3400 <try_secant_tail._omp_fn.0+0x150>
    3426:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    342a:	c5 f9 2f c2          	vcomisd xmm0,xmm2
    342e:	0f 86 dc 01 00 00    	jbe    3610 <try_secant_tail._omp_fn.0+0x360>
    3434:	48 b8 00 00 00 00 00 	movabs rax,0x7ff0000000000000
    343b:	00 f0 7f 
    343e:	c4 e1 f9 7e c7       	vmovq  rdi,xmm0
    3443:	c4 e2 c0 f2 c0       	andn   rax,rdi,rax
    3448:	0f 84 c2 01 00 00    	je     3610 <try_secant_tail._omp_fn.0+0x360>
    344e:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
    3452:	8b 44 24 2c          	mov    eax,DWORD PTR [rsp+0x2c]
    3456:	c5 9b 5e c0          	vdivsd xmm0,xmm12,xmm0
    345a:	48 be eb 11 31 13 bb 	movabs rsi,0x94d049bb133111eb
    3461:	49 d0 94 
    3464:	48 bf b9 e5 e4 1c 6d 	movabs rdi,0xbf58476d1ce4e5b9
    346b:	47 58 bf 
    346e:	44 01 e0             	add    eax,r12d
    3471:	48 98                	cdqe
    3473:	48 89 c1             	mov    rcx,rax
    3476:	48 0f af ce          	imul   rcx,rsi
    347a:	48 03 4c 24 30       	add    rcx,QWORD PTR [rsp+0x30]
    347f:	49 89 cf             	mov    r15,rcx
    3482:	49 c1 ef 1e          	shr    r15,0x1e
    3486:	49 31 cf             	xor    r15,rcx
    3489:	4c 0f af ff          	imul   r15,rdi
    348d:	4c 89 fa             	mov    rdx,r15
    3490:	48 c1 ea 1b          	shr    rdx,0x1b
    3494:	4c 31 fa             	xor    rdx,r15
    3497:	48 0f af d6          	imul   rdx,rsi
    349b:	49 89 d7             	mov    r15,rdx
    349e:	49 c1 ef 1f          	shr    r15,0x1f
    34a2:	49 31 d7             	xor    r15,rdx
    34a5:	48 ba ce d3 b3 09 b2 	movabs rdx,0x2a87fdb209b3d3ce
    34ac:	fd 87 2a 
    34af:	48 0f af c2          	imul   rax,rdx
    34b3:	49 c1 ef 0b          	shr    r15,0xb
    34b7:	c4 c1 ab 2a df       	vcvtsi2sd xmm3,xmm10,r15
    34bc:	c4 c2 c1 99 d8       	vfmadd132sd xmm3,xmm7,xmm8
    34c1:	c4 c1 7b 59 55 00    	vmulsd xmm2,xmm0,QWORD PTR [r13+0x0]
    34c7:	48 01 c8             	add    rax,rcx
    34ca:	48 89 c2             	mov    rdx,rax
    34cd:	48 c1 ea 1e          	shr    rdx,0x1e
    34d1:	c4 c1 63 59 d9       	vmulsd xmm3,xmm3,xmm9
    34d6:	48 31 c2             	xor    rdx,rax
    34d9:	48 0f af d7          	imul   rdx,rdi
    34dd:	48 89 d0             	mov    rax,rdx
    34e0:	48 c1 e8 1b          	shr    rax,0x1b
    34e4:	48 31 c2             	xor    rdx,rax
    34e7:	48 0f af d6          	imul   rdx,rsi
    34eb:	48 89 d0             	mov    rax,rdx
    34ee:	48 c1 e8 1f          	shr    rax,0x1f
    34f2:	48 31 c2             	xor    rdx,rax
    34f5:	48 c1 ea 0b          	shr    rdx,0xb
    34f9:	45 85 f6             	test   r14d,r14d
    34fc:	c4 e1 ab 2a e2       	vcvtsi2sd xmm4,xmm10,rdx
    3501:	c4 c2 c1 99 e0       	vfmadd132sd xmm4,xmm7,xmm8
    3506:	c4 c1 5b 59 e1       	vmulsd xmm4,xmm4,xmm9
    350b:	7e 5e                	jle    356b <try_secant_tail._omp_fn.0+0x2bb>
    350d:	c5 7b 59 db          	vmulsd xmm11,xmm0,xmm3
    3511:	31 c0                	xor    eax,eax
    3513:	c5 7b 59 f4          	vmulsd xmm14,xmm0,xmm4
    3517:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
    351e:	00 
    351f:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    3526:	00 00 00 00 
    352a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    3531:	00 00 00 00 
    3535:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    353c:	00 00 00 00 
    3540:	c4 c1 7b 10 0c 00    	vmovsd xmm1,QWORD PTR [r8+rax*1]
    3546:	c5 79 29 dd          	vmovapd xmm5,xmm11
    354a:	c4 e2 f1 a9 2c 03    	vfmadd213sd xmm5,xmm1,QWORD PTR [rbx+rax*1]
    3550:	c5 fb 11 2c 03       	vmovsd QWORD PTR [rbx+rax*1],xmm5
    3555:	c4 e2 89 a9 4c 05 00 	vfmadd213sd xmm1,xmm14,QWORD PTR [rbp+rax*1+0x0]
    355c:	c5 fb 11 4c 05 00    	vmovsd QWORD PTR [rbp+rax*1+0x0],xmm1
    3562:	48 83 c0 08          	add    rax,0x8
    3566:	49 39 c1             	cmp    r9,rax
    3569:	75 d5                	jne    3540 <try_secant_tail._omp_fn.0+0x290>
    356b:	c5 c9 54 35 00 00 00 	vandpd xmm6,xmm6,XMMWORD PTR [rip+0x0]        # 3573 <try_secant_tail._omp_fn.0+0x2c3>
    3572:	00 
    3573:	c5 01 54 3d 00 00 00 	vandpd xmm15,xmm15,XMMWORD PTR [rip+0x0]        # 357b <try_secant_tail._omp_fn.0+0x2cb>
    357a:	00 
    357b:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    3580:	c4 c1 4b 5f f7       	vmaxsd xmm6,xmm6,xmm15
    3585:	c4 e2 e9 a9 18       	vfmadd213sd xmm3,xmm2,QWORD PTR [rax]
    358a:	c4 e2 e9 a9 60 08    	vfmadd213sd xmm4,xmm2,QWORD PTR [rax+0x8]
    3590:	c5 cb 59 f0          	vmulsd xmm6,xmm6,xmm0
    3594:	c5 f9 2f 35 00 00 00 	vcomisd xmm6,QWORD PTR [rip+0x0]        # 359c <try_secant_tail._omp_fn.0+0x2ec>
    359b:	00 
    359c:	c5 fb 11 18          	vmovsd QWORD PTR [rax],xmm3
    35a0:	c5 fb 11 60 08       	vmovsd QWORD PTR [rax+0x8],xmm4
    35a5:	77 31                	ja     35d8 <try_secant_tail._omp_fn.0+0x328>
    35a7:	c5 e9 54 1d 00 00 00 	vandpd xmm3,xmm2,XMMWORD PTR [rip+0x0]        # 35af <try_secant_tail._omp_fn.0+0x2ff>
    35ae:	00 
    35af:	c4 c1 7b 10 55 00    	vmovsd xmm2,QWORD PTR [r13+0x0]
    35b5:	c5 e3 58 5c 24 38    	vaddsd xmm3,xmm3,QWORD PTR [rsp+0x38]
    35bb:	c5 e3 59 5c 24 18    	vmulsd xmm3,xmm3,QWORD PTR [rsp+0x18]
    35c1:	c4 c1 6b 5c cd       	vsubsd xmm1,xmm2,xmm13
    35c6:	c5 f3 59 c0          	vmulsd xmm0,xmm1,xmm0
    35ca:	c5 f9 54 05 00 00 00 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x0]        # 35d2 <try_secant_tail._omp_fn.0+0x322>
    35d1:	00 
    35d2:	c5 f9 2f c3          	vcomisd xmm0,xmm3
    35d6:	76 05                	jbe    35dd <try_secant_tail._omp_fn.0+0x32d>
    35d8:	41 c6 04 24 01       	mov    BYTE PTR [r12],0x1
    35dd:	49 83 c4 01          	add    r12,0x1
    35e1:	49 83 c5 08          	add    r13,0x8
    35e5:	4d 01 c8             	add    r8,r9
    35e8:	4c 39 64 24 08       	cmp    QWORD PTR [rsp+0x8],r12
    35ed:	0f 85 d5 fd ff ff    	jne    33c8 <try_secant_tail._omp_fn.0+0x118>
    35f3:	48 83 c4 48          	add    rsp,0x48
    35f7:	5b                   	pop    rbx
    35f8:	5d                   	pop    rbp
    35f9:	41 5c                	pop    r12
    35fb:	41 5d                	pop    r13
    35fd:	41 5e                	pop    r14
    35ff:	41 5f                	pop    r15
    3601:	e9 00 00 00 00       	jmp    3606 <try_secant_tail._omp_fn.0+0x356>
    3606:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
    360d:	00 00 00 
    3610:	44 89 f6             	mov    esi,r14d
    3613:	4c 89 c7             	mov    rdi,r8
    3616:	e8 d5 ca ff ff       	call   f0 <norm2>
    361b:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    361f:	c5 f9 2f c2          	vcomisd xmm0,xmm2
    3623:	0f 85 29 fe ff ff    	jne    3452 <try_secant_tail._omp_fn.0+0x1a2>
    3629:	c4 c1 7b 10 45 00    	vmovsd xmm0,QWORD PTR [r13+0x0]
    362f:	c5 f9 54 05 00 00 00 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x0]        # 3637 <try_secant_tail._omp_fn.0+0x387>
    3636:	00 
    3637:	c5 f9 2f 44 24 18    	vcomisd xmm0,QWORD PTR [rsp+0x18]
    363d:	76 9e                	jbe    35dd <try_secant_tail._omp_fn.0+0x32d>
    363f:	41 c6 04 24 01       	mov    BYTE PTR [r12],0x1
    3644:	eb 97                	jmp    35dd <try_secant_tail._omp_fn.0+0x32d>
