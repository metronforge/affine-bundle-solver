/tmp/abs-stage2b-measured-control/tail.o:     file format elf64-x86-64


Disassembly of section .text:

000000000000a8a0 <try_secant_tail.constprop.0>:
    a8a0:	41 57                	push   r15
    a8a2:	45 89 cf             	mov    r15d,r9d
    a8a5:	41 56                	push   r14
    a8a7:	41 55                	push   r13
    a8a9:	41 54                	push   r12
    a8ab:	55                   	push   rbp
    a8ac:	53                   	push   rbx
    a8ad:	49 63 d8             	movsxd rbx,r8d
    a8b0:	48 81 ec f8 01 00 00 	sub    rsp,0x1f8
    a8b7:	48 8b 84 24 40 02 00 	mov    rax,QWORD PTR [rsp+0x240]
    a8be:	00 
    a8bf:	48 89 74 24 30       	mov    QWORD PTR [rsp+0x30],rsi
    a8c4:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    a8c9:	4c 8b a4 24 30 02 00 	mov    r12,QWORD PTR [rsp+0x230]
    a8d0:	00 
    a8d1:	48 89 94 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rdx
    a8d8:	00 
    a8d9:	89 4c 24 14          	mov    DWORD PTR [rsp+0x14],ecx
    a8dd:	4c 89 e6             	mov    rsi,r12
    a8e0:	89 5c 24 10          	mov    DWORD PTR [rsp+0x10],ebx
    a8e4:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
    a8eb:	00 
    a8ec:	64 48 8b 3c 25 28 00 	mov    rdi,QWORD PTR fs:0x28
    a8f3:	00 00 
    a8f5:	48 89 bc 24 e8 01 00 	mov    QWORD PTR [rsp+0x1e8],rdi
    a8fc:	00 
    a8fd:	48 8d bc 24 20 01 00 	lea    rdi,[rsp+0x120]
    a904:	00 
    a905:	48 89 7c 24 60       	mov    QWORD PTR [rsp+0x60],rdi
    a90a:	e8 b1 c7 ff ff       	call   70c0 <bs_copy>
    a90f:	85 c0                	test   eax,eax
    a911:	74 32                	je     a945 <try_secant_tail.constprop.0+0xa5>
    a913:	41 ba ff ff ff ff    	mov    r10d,0xffffffff
    a919:	48 8b 84 24 e8 01 00 	mov    rax,QWORD PTR [rsp+0x1e8]
    a920:	00 
    a921:	64 48 2b 04 25 28 00 	sub    rax,QWORD PTR fs:0x28
    a928:	00 00 
    a92a:	0f 85 ff 18 00 00    	jne    c22f <try_secant_tail.constprop.0+0x198f>
    a930:	48 81 c4 f8 01 00 00 	add    rsp,0x1f8
    a937:	44 89 d0             	mov    eax,r10d
    a93a:	5b                   	pop    rbx
    a93b:	5d                   	pop    rbp
    a93c:	41 5c                	pop    r12
    a93e:	41 5d                	pop    r13
    a940:	41 5e                	pop    r14
    a942:	41 5f                	pop    r15
    a944:	c3                   	ret
    a945:	48 89 d8             	mov    rax,rbx
    a948:	48 89 5c 24 50       	mov    QWORD PTR [rsp+0x50],rbx
    a94d:	48 c1 e0 04          	shl    rax,0x4
    a951:	48 89 c7             	mov    rdi,rax
    a954:	48 89 84 24 10 01 00 	mov    QWORD PTR [rsp+0x110],rax
    a95b:	00 
    a95c:	e8 00 00 00 00       	call   a961 <try_secant_tail.constprop.0+0xc1>
    a961:	48 8d 3c 1b          	lea    rdi,[rbx+rbx*1]
    a965:	be 08 00 00 00       	mov    esi,0x8
    a96a:	49 89 c6             	mov    r14,rax
    a96d:	e8 00 00 00 00       	call   a972 <try_secant_tail.constprop.0+0xd2>
    a972:	4d 85 f6             	test   r14,r14
    a975:	48 89 c3             	mov    rbx,rax
    a978:	0f 84 85 18 00 00    	je     c203 <try_secant_tail.constprop.0+0x1963>
    a97e:	48 85 c0             	test   rax,rax
    a981:	0f 84 7c 18 00 00    	je     c203 <try_secant_tail.constprop.0+0x1963>
    a987:	48 ba 15 7c 4a 7f b9 	movabs rdx,0x9e3779b97f4a7c15
    a98e:	79 37 9e 
    a991:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    a996:	4c 89 f7             	mov    rdi,r14
    a999:	48 b8 d0 31 9f 29 22 	movabs rax,0xa4093822299f31d0
    a9a0:	38 09 a4 
    a9a3:	48 33 84 24 38 02 00 	xor    rax,QWORD PTR [rsp+0x238]
    a9aa:	00 
    a9ab:	48 c7 84 24 d0 01 00 	mov    QWORD PTR [rsp+0x1d0],0x0
    a9b2:	00 00 00 00 00 
    a9b7:	48 c7 84 24 d8 01 00 	mov    QWORD PTR [rsp+0x1d8],0x0
    a9be:	00 00 00 00 00 
    a9c3:	48 01 d0             	add    rax,rdx
    a9c6:	48 89 c2             	mov    rdx,rax
    a9c9:	48 c1 ea 1e          	shr    rdx,0x1e
    a9cd:	48 31 c2             	xor    rdx,rax
    a9d0:	48 b8 b9 e5 e4 1c 6d 	movabs rax,0xbf58476d1ce4e5b9
    a9d7:	47 58 bf 
    a9da:	48 0f af d0          	imul   rdx,rax
    a9de:	48 89 d0             	mov    rax,rdx
    a9e1:	48 c1 e8 1b          	shr    rax,0x1b
    a9e5:	48 31 d0             	xor    rax,rdx
    a9e8:	48 ba eb 11 31 13 bb 	movabs rdx,0x94d049bb133111eb
    a9ef:	49 d0 94 
    a9f2:	48 0f af c2          	imul   rax,rdx
    a9f6:	48 89 c2             	mov    rdx,rax
    a9f9:	48 c1 ea 1f          	shr    rdx,0x1f
    a9fd:	48 31 c2             	xor    rdx,rax
    aa00:	48 89 d0             	mov    rax,rdx
    aa03:	48 ba 03 ed 92 d1 32 	movabs rdx,0xd1b54a32d192ed03
    aa0a:	4a b5 d1 
    aa0d:	48 01 c2             	add    rdx,rax
    aa10:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
    aa17:	00 
    aa18:	e8 23 7d ff ff       	call   2740 <secant_refresh>
    aa1d:	48 8b 7c 24 50       	mov    rdi,QWORD PTR [rsp+0x50]
    aa22:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    aa27:	48 ba 06 da 25 a3 65 	movabs rdx,0xa36a9465a325da06
    aa2e:	94 6a a3 
    aa31:	48 03 94 24 e0 00 00 	add    rdx,QWORD PTR [rsp+0xe0]
    aa38:	00 
    aa39:	48 8d 2c fd 00 00 00 	lea    rbp,[rdi*8+0x0]
    aa40:	00 
    aa41:	4d 8d 2c 2e          	lea    r13,[r14+rbp*1]
    aa45:	4c 89 ef             	mov    rdi,r13
    aa48:	e8 f3 7c ff ff       	call   2740 <secant_refresh>
    aa4d:	e8 00 00 00 00       	call   aa52 <try_secant_tail.constprop.0+0x1b2>
    aa52:	89 84 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],eax
    aa59:	41 8b 44 24 04       	mov    eax,DWORD PTR [r12+0x4]
    aa5e:	89 04 24             	mov    DWORD PTR [rsp],eax
    aa61:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    aa65:	44 29 f8             	sub    eax,r15d
    aa68:	85 c0                	test   eax,eax
    aa6a:	0f 8e a5 13 00 00    	jle    be15 <try_secant_tail.constprop.0+0x1575>
    aa70:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
    aa74:	c5 fb 10 1d 00 00 00 	vmovsd xmm3,QWORD PTR [rip+0x0]        # aa7c <try_secant_tail.constprop.0+0x1dc>
    aa7b:	00 
    aa7c:	c5 d3 2a c0          	vcvtsi2sd xmm0,xmm5,eax
    aa80:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
    aa84:	c5 fb 11 5c 24 20    	vmovsd QWORD PTR [rsp+0x20],xmm3
    aa8a:	c5 e3 5e e0          	vdivsd xmm4,xmm3,xmm0
    aa8e:	c5 fb 11 a4 24 d8 00 	vmovsd QWORD PTR [rsp+0xd8],xmm4
    aa95:	00 00 
    aa97:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    aa9b:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    aaa2:	00 
    aaa3:	e8 48 56 ff ff       	call   f0 <norm2>
    aaa8:	be 01 00 00 00       	mov    esi,0x1
    aaad:	bf 00 08 00 00       	mov    edi,0x800
    aab2:	c5 fb 11 84 24 a8 00 	vmovsd QWORD PTR [rsp+0xa8],xmm0
    aab9:	00 00 
    aabb:	e8 00 00 00 00       	call   aac0 <try_secant_tail.constprop.0+0x220>
    aac0:	48 8b 54 24 50       	mov    rdx,QWORD PTR [rsp+0x50]
    aac5:	be 08 00 00 00       	mov    esi,0x8
    aaca:	4c 63 a4 24 d0 00 00 	movsxd r12,DWORD PTR [rsp+0xd0]
    aad1:	00 
    aad2:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    aad7:	49 0f af d4          	imul   rdx,r12
    aadb:	48 8d 3c 12          	lea    rdi,[rdx+rdx*1]
    aadf:	48 89 54 24 18       	mov    QWORD PTR [rsp+0x18],rdx
    aae4:	e8 00 00 00 00       	call   aae9 <try_secant_tail.constprop.0+0x249>
    aae9:	4b 8d 3c 24          	lea    rdi,[r12+r12*1]
    aaed:	be 08 00 00 00       	mov    esi,0x8
    aaf2:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    aaf7:	e8 00 00 00 00       	call   aafc <try_secant_tail.constprop.0+0x25c>
    aafc:	48 83 7c 24 58 00    	cmp    QWORD PTR [rsp+0x58],0x0
    ab02:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    ab09:	00 
    ab0a:	48 89 c7             	mov    rdi,rax
    ab0d:	0f 94 c0             	sete   al
    ab10:	48 83 7c 24 68 00    	cmp    QWORD PTR [rsp+0x68],0x0
    ab16:	0f 94 c1             	sete   cl
    ab19:	08 c8                	or     al,cl
    ab1b:	0f 85 c1 16 00 00    	jne    c1e2 <try_secant_tail.constprop.0+0x1942>
    ab21:	48 85 ff             	test   rdi,rdi
    ab24:	0f 84 b8 16 00 00    	je     c1e2 <try_secant_tail.constprop.0+0x1942>
    ab2a:	8b 94 24 24 01 00 00 	mov    edx,DWORD PTR [rsp+0x124]
    ab31:	44 39 7c 24 14       	cmp    DWORD PTR [rsp+0x14],r15d
    ab36:	44 8b 84 24 2c 01 00 	mov    r8d,DWORD PTR [rsp+0x12c]
    ab3d:	00 
    ab3e:	89 54 24 08          	mov    DWORD PTR [rsp+0x8],edx
    ab42:	0f 8e b1 02 00 00    	jle    adf9 <try_secant_tail.constprop.0+0x559>
    ab48:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    ab4c:	48 8b 54 24 18       	mov    rdx,QWORD PTR [rsp+0x18]
    ab51:	44 89 7c 24 38       	mov    DWORD PTR [rsp+0x38],r15d
    ab56:	4d 89 ea             	mov    r10,r13
    ab59:	48 b9 15 7c 4a 7f b9 	movabs rcx,0x9e3779b97f4a7c15
    ab60:	79 37 9e 
    ab63:	c7 44 24 18 00 00 00 	mov    DWORD PTR [rsp+0x18],0x0
    ab6a:	00 
    ab6b:	48 b8 89 6c 4e ec 98 	movabs rax,0x82efa98ec4e6c89
    ab72:	fa 2e 08 
    ab75:	48 33 84 24 38 02 00 	xor    rax,QWORD PTR [rsp+0x238]
    ab7c:	00 
    ab7d:	c7 84 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],0x0
    ab84:	00 00 00 00 
    ab88:	48 01 c8             	add    rax,rcx
    ab8b:	48 89 c1             	mov    rcx,rax
    ab8e:	48 c1 e9 1e          	shr    rcx,0x1e
    ab92:	48 31 c1             	xor    rcx,rax
    ab95:	48 b8 b9 e5 e4 1c 6d 	movabs rax,0xbf58476d1ce4e5b9
    ab9c:	47 58 bf 
    ab9f:	48 0f af c8          	imul   rcx,rax
    aba3:	48 89 c8             	mov    rax,rcx
    aba6:	48 c1 e8 1b          	shr    rax,0x1b
    abaa:	48 31 c8             	xor    rax,rcx
    abad:	48 b9 eb 11 31 13 bb 	movabs rcx,0x94d049bb133111eb
    abb4:	49 d0 94 
    abb7:	48 0f af c1          	imul   rax,rcx
    abbb:	48 89 c1             	mov    rcx,rax
    abbe:	48 c1 e9 1f          	shr    rcx,0x1f
    abc2:	48 31 c1             	xor    rcx,rax
    abc5:	89 f0                	mov    eax,esi
    abc7:	c1 e8 1f             	shr    eax,0x1f
    abca:	48 89 8c 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rcx
    abd1:	00 
    abd2:	01 f0                	add    eax,esi
    abd4:	d1 f8                	sar    eax,1
    abd6:	39 04 24             	cmp    DWORD PTR [rsp],eax
    abd9:	0f 9d c1             	setge  cl
    abdc:	83 bc 24 d0 00 00 00 	cmp    DWORD PTR [rsp+0xd0],0x1
    abe3:	01 
    abe4:	0f 9f c0             	setg   al
    abe7:	48 c1 e2 04          	shl    rdx,0x4
    abeb:	21 c1                	and    ecx,eax
    abed:	4c 89 e0             	mov    rax,r12
    abf0:	44 8d 24 36          	lea    r12d,[rsi+rsi*1]
    abf4:	48 89 94 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rdx
    abfb:	00 
    abfc:	48 c1 e0 04          	shl    rax,0x4
    ac00:	48 8d 34 2b          	lea    rsi,[rbx+rbp*1]
    ac04:	88 4c 24 3f          	mov    BYTE PTR [rsp+0x3f],cl
    ac08:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
    ac0f:	00 
    ac10:	48 01 f8             	add    rax,rdi
    ac13:	44 89 c7             	mov    edi,r8d
    ac16:	48 89 b4 24 18 01 00 	mov    QWORD PTR [rsp+0x118],rsi
    ac1d:	00 
    ac1e:	48 89 84 24 08 01 00 	mov    QWORD PTR [rsp+0x108],rax
    ac25:	00 
    ac26:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
    ac2d:	00 00 00 
    ac30:	85 ff                	test   edi,edi
    ac32:	0f 85 a6 13 00 00    	jne    bfde <try_secant_tail.constprop.0+0x173e>
    ac38:	89 7c 24 40          	mov    DWORD PTR [rsp+0x40],edi
    ac3c:	45 89 fb             	mov    r11d,r15d
    ac3f:	8b 4c 24 08          	mov    ecx,DWORD PTR [rsp+0x8]
    ac43:	39 4c 24 10          	cmp    DWORD PTR [rsp+0x10],ecx
    ac47:	0f 8e fc 03 00 00    	jle    b049 <try_secant_tail.constprop.0+0x7a9>
    ac4d:	83 7c 24 18 1f       	cmp    DWORD PTR [rsp+0x18],0x1f
    ac52:	0f 9f c0             	setg   al
    ac55:	84 44 24 3f          	test   BYTE PTR [rsp+0x3f],al
    ac59:	74 22                	je     ac7d <try_secant_tail.constprop.0+0x3dd>
    ac5b:	44 39 5c 24 38       	cmp    DWORD PTR [rsp+0x38],r11d
    ac60:	7f 1b                	jg     ac7d <try_secant_tail.constprop.0+0x3dd>
    ac62:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    ac66:	44 29 d8             	sub    eax,r11d
    ac69:	48 98                	cdqe
    ac6b:	48 0f af 44 24 50    	imul   rax,QWORD PTR [rsp+0x50]
    ac71:	48 3d 3f 42 0f 00    	cmp    rax,0xf423f
    ac77:	0f 8f 03 06 00 00    	jg     b280 <try_secant_tail.constprop.0+0x9e0>
    ac7d:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    ac81:	4d 63 cb             	movsxd r9,r11d
    ac84:	49 89 e8             	mov    r8,rbp
    ac87:	4d 0f af c1          	imul   r8,r9
    ac8b:	4c 03 44 24 28       	add    r8,QWORD PTR [rsp+0x28]
    ac90:	85 c9                	test   ecx,ecx
    ac92:	0f 8e 2f 03 00 00    	jle    afc7 <try_secant_tail.constprop.0+0x727>
    ac98:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
    ac9c:	48 8b 94 24 38 01 00 	mov    rdx,QWORD PTR [rsp+0x138]
    aca3:	00 
    aca4:	31 c0                	xor    eax,eax
    aca6:	c5 79 28 c6          	vmovapd xmm8,xmm6
    acaa:	c5 f9 28 fe          	vmovapd xmm7,xmm6
    acae:	c5 f9 28 ce          	vmovapd xmm1,xmm6
    acb2:	0f 1f 00             	nop    DWORD PTR [rax]
    acb5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    acbc:	00 00 00 00 
    acc0:	c4 c1 7b 10 04 00    	vmovsd xmm0,QWORD PTR [r8+rax*1]
    acc6:	c4 e2 f9 b9 3c 02    	vfmadd231sd xmm7,xmm0,QWORD PTR [rdx+rax*1]
    accc:	c4 42 f9 b9 04 06    	vfmadd231sd xmm8,xmm0,QWORD PTR [r14+rax*1]
    acd2:	c4 c2 f9 b9 34 02    	vfmadd231sd xmm6,xmm0,QWORD PTR [r10+rax*1]
    acd8:	48 83 c0 08          	add    rax,0x8
    acdc:	48 39 c5             	cmp    rbp,rax
    acdf:	c4 e2 f9 b9 c8       	vfmadd231sd xmm1,xmm0,xmm0
    ace4:	75 da                	jne    acc0 <try_secant_tail.constprop.0+0x420>
    ace6:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
    acea:	c5 f9 2f c8          	vcomisd xmm1,xmm0
    acee:	0f 86 e4 02 00 00    	jbe    afd8 <try_secant_tail.constprop.0+0x738>
    acf4:	48 b8 00 00 00 00 00 	movabs rax,0x7ff0000000000000
    acfb:	00 f0 7f 
    acfe:	c4 e1 f9 7e c9       	vmovq  rcx,xmm1
    ad03:	c4 e2 f0 f2 c0       	andn   rax,rcx,rax
    ad08:	0f 84 ca 02 00 00    	je     afd8 <try_secant_tail.constprop.0+0x738>
    ad0e:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
    ad12:	c5 fb 10 6c 24 20    	vmovsd xmm5,QWORD PTR [rsp+0x20]
    ad18:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    ad1d:	44 39 5c 24 38       	cmp    DWORD PTR [rsp+0x38],r11d
    ad22:	c5 d3 5e c9          	vdivsd xmm1,xmm5,xmm1
    ad26:	c4 21 7b 10 0c c8    	vmovsd xmm9,QWORD PTR [rax+r9*8]
    ad2c:	c4 c1 73 59 d1       	vmulsd xmm2,xmm1,xmm9
    ad31:	0f 8e 0b 0b 00 00    	jle    b842 <try_secant_tail.constprop.0+0xfa2>
    ad37:	c5 c9 54 35 00 00 00 	vandpd xmm6,xmm6,XMMWORD PTR [rip+0x0]        # ad3f <try_secant_tail.constprop.0+0x49f>
    ad3e:	00 
    ad3f:	c5 39 54 05 00 00 00 	vandpd xmm8,xmm8,XMMWORD PTR [rip+0x0]        # ad47 <try_secant_tail.constprop.0+0x4a7>
    ad46:	00 
    ad47:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # ad4f <try_secant_tail.constprop.0+0x4af>
    ad4e:	00 
    ad4f:	c4 c1 4b 5f f0       	vmaxsd xmm6,xmm6,xmm8
    ad54:	c5 cb 59 f1          	vmulsd xmm6,xmm6,xmm1
    ad58:	c5 f9 2f f0          	vcomisd xmm6,xmm0
    ad5c:	77 42                	ja     ada0 <try_secant_tail.constprop.0+0x500>
    ad5e:	c5 e9 54 05 00 00 00 	vandpd xmm0,xmm2,XMMWORD PTR [rip+0x0]        # ad66 <try_secant_tail.constprop.0+0x4c6>
    ad65:	00 
    ad66:	c5 b3 5c ff          	vsubsd xmm7,xmm9,xmm7
    ad6a:	c5 fb 10 a4 24 a8 00 	vmovsd xmm4,QWORD PTR [rsp+0xa8]
    ad71:	00 00 
    ad73:	c5 db 58 54 24 20    	vaddsd xmm2,xmm4,QWORD PTR [rsp+0x20]
    ad79:	c5 c3 59 c9          	vmulsd xmm1,xmm7,xmm1
    ad7d:	c5 fb 58 c2          	vaddsd xmm0,xmm0,xmm2
    ad81:	c5 fb 59 05 00 00 00 	vmulsd xmm0,xmm0,QWORD PTR [rip+0x0]        # ad89 <try_secant_tail.constprop.0+0x4e9>
    ad88:	00 
    ad89:	c5 f1 54 0d 00 00 00 	vandpd xmm1,xmm1,XMMWORD PTR [rip+0x0]        # ad91 <try_secant_tail.constprop.0+0x4f1>
    ad90:	00 
    ad91:	c5 f9 2f c8          	vcomisd xmm1,xmm0
    ad95:	0f 86 9d 0c 00 00    	jbe    ba38 <try_secant_tail.constprop.0+0x1198>
    ad9b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    ada0:	8b 84 24 20 01 00 00 	mov    eax,DWORD PTR [rsp+0x120]
    ada7:	4c 89 c7             	mov    rdi,r8
    adaa:	89 c6                	mov    esi,eax
    adac:	89 04 24             	mov    DWORD PTR [rsp],eax
    adaf:	e8 3c 53 ff ff       	call   f0 <norm2>
    adb4:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
    adb8:	c5 f9 2f c1          	vcomisd xmm0,xmm1
    adbc:	0f 85 ae 02 00 00    	jne    b070 <try_secant_tail.constprop.0+0x7d0>
    adc2:	c5 31 54 0d 00 00 00 	vandpd xmm9,xmm9,XMMWORD PTR [rip+0x0]        # adca <try_secant_tail.constprop.0+0x52a>
    adc9:	00 
    adca:	c5 79 2f 0d 00 00 00 	vcomisd xmm9,QWORD PTR [rip+0x0]        # add2 <try_secant_tail.constprop.0+0x532>
    add1:	00 
    add2:	45 89 df             	mov    r15d,r11d
    add5:	0f 87 99 13 00 00    	ja     c174 <try_secant_tail.constprop.0+0x18d4>
    addb:	83 44 24 18 01       	add    DWORD PTR [rsp+0x18],0x1
    ade0:	8b bc 24 2c 01 00 00 	mov    edi,DWORD PTR [rsp+0x12c]
    ade7:	41 83 c7 01          	add    r15d,0x1
    adeb:	44 39 7c 24 14       	cmp    DWORD PTR [rsp+0x14],r15d
    adf0:	0f 8f 3a fe ff ff    	jg     ac30 <try_secant_tail.constprop.0+0x390>
    adf6:	41 89 f8             	mov    r8d,edi
    adf9:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    adfe:	44 89 04 24          	mov    DWORD PTR [rsp],r8d
    ae02:	e8 00 00 00 00       	call   ae07 <try_secant_tail.constprop.0+0x567>
    ae07:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    ae0c:	e8 00 00 00 00       	call   ae11 <try_secant_tail.constprop.0+0x571>
    ae11:	48 8b bc 24 a0 00 00 	mov    rdi,QWORD PTR [rsp+0xa0]
    ae18:	00 
    ae19:	e8 00 00 00 00       	call   ae1e <try_secant_tail.constprop.0+0x57e>
    ae1e:	44 8b 04 24          	mov    r8d,DWORD PTR [rsp]
    ae22:	45 85 c0             	test   r8d,r8d
    ae25:	0f 85 f7 13 00 00    	jne    c222 <try_secant_tail.constprop.0+0x1982>
    ae2b:	8b 7c 24 08          	mov    edi,DWORD PTR [rsp+0x8]
    ae2f:	39 7c 24 10          	cmp    DWORD PTR [rsp+0x10],edi
    ae33:	4c 8d bc 24 d0 01 00 	lea    r15,[rsp+0x1d0]
    ae3a:	00 
    ae3b:	49 89 dc             	mov    r12,rbx
    ae3e:	4c 8d ac 24 e0 01 00 	lea    r13,[rsp+0x1e0]
    ae45:	00 
    ae46:	0f 84 4a 12 00 00    	je     c096 <try_secant_tail.constprop.0+0x17f6>
    ae4c:	c4 c1 7b 10 07       	vmovsd xmm0,QWORD PTR [r15]
    ae51:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    ae56:	4c 89 e6             	mov    rsi,r12
    ae59:	e8 42 b8 ff ff       	call   66a0 <bs_check_certified.constprop.0>
    ae5e:	83 f8 01             	cmp    eax,0x1
    ae61:	0f 85 ad 11 00 00    	jne    c014 <try_secant_tail.constprop.0+0x1774>
    ae67:	49 83 c7 08          	add    r15,0x8
    ae6b:	49 01 ec             	add    r12,rbp
    ae6e:	4d 39 fd             	cmp    r13,r15
    ae71:	75 d9                	jne    ae4c <try_secant_tail.constprop.0+0x5ac>
    ae73:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    ae78:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # ae80 <try_secant_tail.constprop.0+0x5e0>
    ae7f:	00 
    ae80:	89 04 24             	mov    DWORD PTR [rsp],eax
    ae83:	4c 8d 8c 24 60 01 00 	lea    r9,[rsp+0x160]
    ae8a:	00 
    ae8b:	44 8b 44 24 10       	mov    r8d,DWORD PTR [rsp+0x10]
    ae90:	8b 4c 24 14          	mov    ecx,DWORD PTR [rsp+0x14]
    ae94:	48 8b 94 24 38 01 00 	mov    rdx,QWORD PTR [rsp+0x138]
    ae9b:	00 
    ae9c:	48 8b 74 24 30       	mov    rsi,QWORD PTR [rsp+0x30]
    aea1:	e8 aa 57 ff ff       	call   650 <compat_scan_fused>
    aea6:	48 8b bc 24 30 01 00 	mov    rdi,QWORD PTR [rsp+0x130]
    aead:	00 
    aeae:	44 8b 14 24          	mov    r10d,DWORD PTR [rsp]
    aeb2:	85 c0                	test   eax,eax
    aeb4:	0f 85 62 11 00 00    	jne    c01c <try_secant_tail.constprop.0+0x177c>
    aeba:	48 8b 8c 24 00 01 00 	mov    rcx,QWORD PTR [rsp+0x100]
    aec1:	00 
    aec2:	8b 84 24 24 01 00 00 	mov    eax,DWORD PTR [rsp+0x124]
    aec9:	48 8b b4 24 e8 00 00 	mov    rsi,QWORD PTR [rsp+0xe8]
    aed0:	00 
    aed1:	c5 fb 10 84 24 60 01 	vmovsd xmm0,QWORD PTR [rsp+0x160]
    aed8:	00 00 
    aeda:	48 85 c9             	test   rcx,rcx
    aedd:	c7 06 02 00 00 00    	mov    DWORD PTR [rsi],0x2
    aee3:	89 46 04             	mov    DWORD PTR [rsi+0x4],eax
    aee6:	c5 fb 11 46 18       	vmovsd QWORD PTR [rsi+0x18],xmm0
    aeeb:	0f 84 6c 11 00 00    	je     c05d <try_secant_tail.constprop.0+0x17bd>
    aef1:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    aef5:	85 f6                	test   esi,esi
    aef7:	0f 8e 91 12 00 00    	jle    c18e <try_secant_tail.constprop.0+0x18ee>
    aefd:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
    af01:	48 8b 94 24 38 01 00 	mov    rdx,QWORD PTR [rsp+0x138]
    af08:	00 
    af09:	31 c0                	xor    eax,eax
    af0b:	c5 f9 28 d3          	vmovapd xmm2,xmm3
    af0f:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    af14:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    af1b:	00 00 00 00 
    af1f:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    af26:	00 00 00 00 
    af2a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    af31:	00 00 00 00 
    af35:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    af3c:	00 00 00 00 
    af40:	c5 fb 10 0c 01       	vmovsd xmm1,QWORD PTR [rcx+rax*1]
    af45:	c5 fb 10 04 02       	vmovsd xmm0,QWORD PTR [rdx+rax*1]
    af4a:	48 83 c0 08          	add    rax,0x8
    af4e:	48 39 c5             	cmp    rbp,rax
    af51:	c5 fb 5c c1          	vsubsd xmm0,xmm0,xmm1
    af55:	c4 e2 f1 b9 d9       	vfmadd231sd xmm3,xmm1,xmm1
    af5a:	c4 e2 f9 b9 d0       	vfmadd231sd xmm2,xmm0,xmm0
    af5f:	75 df                	jne    af40 <try_secant_tail.constprop.0+0x6a0>
    af61:	c5 eb 51 d2          	vsqrtsd xmm2,xmm2,xmm2
    af65:	c5 e3 51 c3          	vsqrtsd xmm0,xmm3,xmm3
    af69:	c5 fb 58 05 00 00 00 	vaddsd xmm0,xmm0,QWORD PTR [rip+0x0]        # af71 <try_secant_tail.constprop.0+0x6d1>
    af70:	00 
    af71:	c5 eb 5e d0          	vdivsd xmm2,xmm2,xmm0
    af75:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    af7c:	00 
    af7d:	44 89 54 24 10       	mov    DWORD PTR [rsp+0x10],r10d
    af82:	c7 40 0c 01 00 00 00 	mov    DWORD PTR [rax+0xc],0x1
    af89:	c5 fb 11 50 20       	vmovsd QWORD PTR [rax+0x20],xmm2
    af8e:	e8 00 00 00 00       	call   af93 <try_secant_tail.constprop.0+0x6f3>
    af93:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    af9a:	00 
    af9b:	e8 00 00 00 00       	call   afa0 <try_secant_tail.constprop.0+0x700>
    afa0:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    afa7:	00 
    afa8:	e8 00 00 00 00       	call   afad <try_secant_tail.constprop.0+0x70d>
    afad:	4c 89 f7             	mov    rdi,r14
    afb0:	e8 00 00 00 00       	call   afb5 <try_secant_tail.constprop.0+0x715>
    afb5:	48 89 df             	mov    rdi,rbx
    afb8:	e8 00 00 00 00       	call   afbd <try_secant_tail.constprop.0+0x71d>
    afbd:	44 8b 54 24 10       	mov    r10d,DWORD PTR [rsp+0x10]
    afc2:	e9 52 f9 ff ff       	jmp    a919 <try_secant_tail.constprop.0+0x79>
    afc7:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
    afcb:	c5 79 28 c6          	vmovapd xmm8,xmm6
    afcf:	c5 f9 28 fe          	vmovapd xmm7,xmm6
    afd3:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    afd8:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    afdc:	4c 89 c7             	mov    rdi,r8
    afdf:	e8 0c 51 ff ff       	call   f0 <norm2>
    afe4:	c5 f9 28 c8          	vmovapd xmm1,xmm0
    afe8:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
    afec:	c5 f9 2f c8          	vcomisd xmm1,xmm0
    aff0:	0f 85 1c fd ff ff    	jne    ad12 <try_secant_tail.constprop.0+0x472>
    aff6:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    affb:	c4 21 7b 10 0c c8    	vmovsd xmm9,QWORD PTR [rax+r9*8]
    b001:	c5 b1 54 05 00 00 00 	vandpd xmm0,xmm9,XMMWORD PTR [rip+0x0]        # b009 <try_secant_tail.constprop.0+0x769>
    b008:	00 
    b009:	c5 f9 2f 05 00 00 00 	vcomisd xmm0,QWORD PTR [rip+0x0]        # b011 <try_secant_tail.constprop.0+0x771>
    b010:	00 
    b011:	0f 87 89 fd ff ff    	ja     ada0 <try_secant_tail.constprop.0+0x500>
    b017:	8b 4c 24 38          	mov    ecx,DWORD PTR [rsp+0x38]
    b01b:	41 8d 43 01          	lea    eax,[r11+0x1]
    b01f:	44 39 d9             	cmp    ecx,r11d
    b022:	0f 4e c8             	cmovle ecx,eax
    b025:	39 44 24 14          	cmp    DWORD PTR [rsp+0x14],eax
    b029:	89 4c 24 38          	mov    DWORD PTR [rsp+0x38],ecx
    b02d:	0f 8e 51 11 00 00    	jle    c184 <try_secant_tail.constprop.0+0x18e4>
    b033:	83 44 24 18 01       	add    DWORD PTR [rsp+0x18],0x1
    b038:	8b 4c 24 08          	mov    ecx,DWORD PTR [rsp+0x8]
    b03c:	41 89 c3             	mov    r11d,eax
    b03f:	39 4c 24 10          	cmp    DWORD PTR [rsp+0x10],ecx
    b043:	0f 8f 04 fc ff ff    	jg     ac4d <try_secant_tail.constprop.0+0x3ad>
    b049:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    b04e:	e8 00 00 00 00       	call   b053 <try_secant_tail.constprop.0+0x7b3>
    b053:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    b058:	e8 00 00 00 00       	call   b05d <try_secant_tail.constprop.0+0x7bd>
    b05d:	48 8b bc 24 a0 00 00 	mov    rdi,QWORD PTR [rsp+0xa0]
    b064:	00 
    b065:	e8 00 00 00 00       	call   b06a <try_secant_tail.constprop.0+0x7ca>
    b06a:	e9 bc fd ff ff       	jmp    ae2b <try_secant_tail.constprop.0+0x58b>
    b06f:	90                   	nop
    b070:	c5 fb 10 64 24 20    	vmovsd xmm4,QWORD PTR [rsp+0x20]
    b076:	4c 63 2c 24          	movsxd r13,DWORD PTR [rsp]
    b07a:	4c 8b bc 24 40 01 00 	mov    r15,QWORD PTR [rsp+0x140]
    b081:	00 
    b082:	48 8b b4 24 30 01 00 	mov    rsi,QWORD PTR [rsp+0x130]
    b089:	00 
    b08a:	c5 db 5e c8          	vdivsd xmm1,xmm4,xmm0
    b08e:	4c 89 e8             	mov    rax,r13
    b091:	49 c1 e5 03          	shl    r13,0x3
    b095:	4f 8d 0c 2f          	lea    r9,[r15+r13*1]
    b099:	85 c0                	test   eax,eax
    b09b:	4b 8d 14 29          	lea    rdx,[r9+r13*1]
    b09f:	c4 c1 73 59 e9       	vmulsd xmm5,xmm1,xmm9
    b0a4:	c5 fb 11 6c 24 48    	vmovsd QWORD PTR [rsp+0x48],xmm5
    b0aa:	0f 8e a1 09 00 00    	jle    ba51 <try_secant_tail.constprop.0+0x11b1>
    b0b0:	31 c0                	xor    eax,eax
    b0b2:	0f 1f 00             	nop    DWORD PTR [rax]
    b0b5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    b0bc:	00 00 00 00 
    b0c0:	c4 c1 73 59 04 00    	vmulsd xmm0,xmm1,QWORD PTR [r8+rax*1]
    b0c6:	c4 c1 7b 11 04 07    	vmovsd QWORD PTR [r15+rax*1],xmm0
    b0cc:	c4 c1 7b 11 04 01    	vmovsd QWORD PTR [r9+rax*1],xmm0
    b0d2:	48 83 c0 08          	add    rax,0x8
    b0d6:	49 39 c5             	cmp    r13,rax
    b0d9:	75 e5                	jne    b0c0 <try_secant_tail.constprop.0+0x820>
    b0db:	8b 0c 24             	mov    ecx,DWORD PTR [rsp]
    b0de:	49 89 d0             	mov    r8,rdx
    b0e1:	8b 54 24 08          	mov    edx,DWORD PTR [rsp+0x8]
    b0e5:	4c 89 cf             	mov    rdi,r9
    b0e8:	44 89 9c 24 88 00 00 	mov    DWORD PTR [rsp+0x88],r11d
    b0ef:	00 
    b0f0:	4c 89 94 24 80 00 00 	mov    QWORD PTR [rsp+0x80],r10
    b0f7:	00 
    b0f8:	4c 89 4c 24 70       	mov    QWORD PTR [rsp+0x70],r9
    b0fd:	e8 fe 72 ff ff       	call   2400 <project_cgs2>
    b102:	4c 8b 4c 24 70       	mov    r9,QWORD PTR [rsp+0x70]
    b107:	8b 34 24             	mov    esi,DWORD PTR [rsp]
    b10a:	c5 fb 11 84 24 c0 00 	vmovsd QWORD PTR [rsp+0xc0],xmm0
    b111:	00 00 
    b113:	4c 89 cf             	mov    rdi,r9
    b116:	e8 d5 4f ff ff       	call   f0 <norm2>
    b11b:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    b122:	00 
    b123:	31 c0                	xor    eax,eax
    b125:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
    b129:	44 8b 9c 24 88 00 00 	mov    r11d,DWORD PTR [rsp+0x88]
    b130:	00 
    b131:	4c 8b 94 24 80 00 00 	mov    r10,QWORD PTR [rsp+0x80]
    b138:	00 
    b139:	c5 f9 28 d8          	vmovapd xmm3,xmm0
    b13d:	0f 1f 00             	nop    DWORD PTR [rax]
    b140:	c4 c1 7b 10 04 07    	vmovsd xmm0,QWORD PTR [r15+rax*1]
    b146:	c5 fb 59 04 07       	vmulsd xmm0,xmm0,QWORD PTR [rdi+rax*1]
    b14b:	48 83 c0 08          	add    rax,0x8
    b14f:	49 39 c5             	cmp    r13,rax
    b152:	c5 f3 58 c8          	vaddsd xmm1,xmm1,xmm0
    b156:	75 e8                	jne    b140 <try_secant_tail.constprop.0+0x8a0>
    b158:	c5 fb 10 6c 24 48    	vmovsd xmm5,QWORD PTR [rsp+0x48]
    b15e:	c5 d3 5c e1          	vsubsd xmm4,xmm5,xmm1
    b162:	c5 fb 11 a4 24 b0 00 	vmovsd QWORD PTR [rsp+0xb0],xmm4
    b169:	00 00 
    b16b:	8b 34 24             	mov    esi,DWORD PTR [rsp]
    b16e:	4c 89 8c 24 98 00 00 	mov    QWORD PTR [rsp+0x98],r9
    b175:	00 
    b176:	c5 fb 11 9c 24 80 00 	vmovsd QWORD PTR [rsp+0x80],xmm3
    b17d:	00 00 
    b17f:	4c 89 94 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r10
    b186:	00 
    b187:	44 89 9c 24 88 00 00 	mov    DWORD PTR [rsp+0x88],r11d
    b18e:	00 
    b18f:	e8 5c 4f ff ff       	call   f0 <norm2>
    b194:	db ac 24 50 01 00 00 	fld    TBYTE PTR [rsp+0x150]
    b19b:	c5 fb 11 84 24 b8 00 	vmovsd QWORD PTR [rsp+0xb8],xmm0
    b1a2:	00 00 
    b1a4:	db 7c 24 70          	fstp   TBYTE PTR [rsp+0x70]
    b1a8:	c5 f8 77             	vzeroupper
    b1ab:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # b1b2 <try_secant_tail.constprop.0+0x912>
    b1b2:	e8 00 00 00 00       	call   b1b7 <try_secant_tail.constprop.0+0x917>
    b1b7:	44 8b 9c 24 88 00 00 	mov    r11d,DWORD PTR [rsp+0x88]
    b1be:	00 
    b1bf:	c5 fb 10 9c 24 80 00 	vmovsd xmm3,QWORD PTR [rsp+0x80]
    b1c6:	00 00 
    b1c8:	4c 8b 94 24 90 00 00 	mov    r10,QWORD PTR [rsp+0x90]
    b1cf:	00 
    b1d0:	4c 8b 8c 24 98 00 00 	mov    r9,QWORD PTR [rsp+0x98]
    b1d7:	00 
    b1d8:	d9 ee                	fldz
    b1da:	c5 fb 10 90 00 00 00 	vmovsd xmm2,QWORD PTR [rax+0x0]
    b1e1:	00 
    b1e2:	db 6c 24 70          	fld    TBYTE PTR [rsp+0x70]
    b1e6:	db f1                	fcomi  st,st(1)
    b1e8:	dd d9                	fstp   st(1)
    b1ea:	0f 86 00 03 00 00    	jbe    b4f0 <try_secant_tail.constprop.0+0xc50>
    b1f0:	d9 c0                	fld    st(0)
    b1f2:	d9 fa                	fsqrt
    b1f4:	dd 5c 24 70          	fstp   QWORD PTR [rsp+0x70]
    b1f8:	c5 fb 10 44 24 70    	vmovsd xmm0,QWORD PTR [rsp+0x70]
    b1fe:	c5 f9 2f c2          	vcomisd xmm0,xmm2
    b202:	76 08                	jbe    b20c <try_secant_tail.constprop.0+0x96c>
    b204:	c5 fb 11 80 00 00 00 	vmovsd QWORD PTR [rax+0x0],xmm0
    b20b:	00 
    b20c:	c5 f9 2f 05 00 00 00 	vcomisd xmm0,QWORD PTR [rip+0x0]        # b214 <try_secant_tail.constprop.0+0x974>
    b213:	00 
    b214:	0f 82 a6 03 00 00    	jb     b5c0 <try_secant_tail.constprop.0+0xd20>
    b21a:	dd d8                	fstp   st(0)
    b21c:	eb 02                	jmp    b220 <try_secant_tail.constprop.0+0x980>
    b21e:	dd d8                	fstp   st(0)
    b220:	45 89 df             	mov    r15d,r11d
    b223:	45 85 ff             	test   r15d,r15d
    b226:	0f 88 ac 07 00 00    	js     b9d8 <try_secant_tail.constprop.0+0x1138>
    b22c:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # b233 <try_secant_tail.constprop.0+0x993>
    b233:	e8 00 00 00 00       	call   b238 <try_secant_tail.constprop.0+0x998>
    b238:	8b a8 00 00 00 00    	mov    ebp,DWORD PTR [rax+0x0]
    b23e:	83 80 00 00 00 00 01 	add    DWORD PTR [rax+0x0],0x1
    b245:	85 ed                	test   ebp,ebp
    b247:	4c 63 e5             	movsxd r12,ebp
    b24a:	0f 8e 6b 07 00 00    	jle    b9bb <try_secant_tail.constprop.0+0x111b>
    b250:	48 05 00 00 00 00    	add    rax,0x0
    b256:	4c 63 e5             	movsxd r12,ebp
    b259:	4a 8d 14 a0          	lea    rdx,[rax+r12*4]
    b25d:	eb 0e                	jmp    b26d <try_secant_tail.constprop.0+0x9cd>
    b25f:	90                   	nop
    b260:	48 83 c0 04          	add    rax,0x4
    b264:	48 39 c2             	cmp    rdx,rax
    b267:	0f 84 49 07 00 00    	je     b9b6 <try_secant_tail.constprop.0+0x1116>
    b26d:	44 3b 38             	cmp    r15d,DWORD PTR [rax]
    b270:	75 ee                	jne    b260 <try_secant_tail.constprop.0+0x9c0>
    b272:	e9 61 07 00 00       	jmp    b9d8 <try_secant_tail.constprop.0+0x1138>
    b277:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
    b27e:	00 00 
    b280:	8b 4c 24 14          	mov    ecx,DWORD PTR [rsp+0x14]
    b284:	41 8d 83 00 08 00 00 	lea    eax,[r11+0x800]
    b28b:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    b290:	4c 89 54 24 08       	mov    QWORD PTR [rsp+0x8],r10
    b295:	44 89 1c 24          	mov    DWORD PTR [rsp],r11d
    b299:	39 c8                	cmp    eax,ecx
    b29b:	0f 4f c1             	cmovg  eax,ecx
    b29e:	31 f6                	xor    esi,esi
    b2a0:	b9 00 08 00 00       	mov    ecx,0x800
    b2a5:	41 89 c5             	mov    r13d,eax
    b2a8:	89 44 24 38          	mov    DWORD PTR [rsp+0x38],eax
    b2ac:	45 29 dd             	sub    r13d,r11d
    b2af:	4d 63 fd             	movsxd r15,r13d
    b2b2:	4c 89 fa             	mov    rdx,r15
    b2b5:	e8 00 00 00 00       	call   b2ba <try_secant_tail.constprop.0+0xa1a>
    b2ba:	48 8b 8c 24 f8 00 00 	mov    rcx,QWORD PTR [rsp+0xf8]
    b2c1:	00 
    b2c2:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    b2c7:	31 f6                	xor    esi,esi
    b2c9:	48 89 ca             	mov    rdx,rcx
    b2cc:	e8 00 00 00 00       	call   b2d1 <try_secant_tail.constprop.0+0xa31>
    b2d1:	48 8b 8c 24 f0 00 00 	mov    rcx,QWORD PTR [rsp+0xf0]
    b2d8:	00 
    b2d9:	48 8b bc 24 a0 00 00 	mov    rdi,QWORD PTR [rsp+0xa0]
    b2e0:	00 
    b2e1:	31 f6                	xor    esi,esi
    b2e3:	48 89 ca             	mov    rdx,rcx
    b2e6:	e8 00 00 00 00       	call   b2eb <try_secant_tail.constprop.0+0xa4b>
    b2eb:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    b2f0:	44 8b 1c 24          	mov    r11d,DWORD PTR [rsp]
    b2f4:	31 d2                	xor    edx,edx
    b2f6:	48 8b 8c 24 c8 00 00 	mov    rcx,QWORD PTR [rsp+0xc8]
    b2fd:	00 
    b2fe:	48 8b b4 24 a0 00 00 	mov    rsi,QWORD PTR [rsp+0xa0]
    b305:	00 
    b306:	44 89 ac 24 c0 01 00 	mov    DWORD PTR [rsp+0x1c0],r13d
    b30d:	00 
    b30e:	c5 fb 10 a4 24 a8 00 	vmovsd xmm4,QWORD PTR [rsp+0xa8]
    b315:	00 00 
    b317:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    b31c:	48 89 bc 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rdi
    b323:	00 
    b324:	48 8d 3d 85 7f ff ff 	lea    rdi,[rip+0xffffffffffff7f85]        # 32b0 <try_secant_tail._omp_fn.0>
    b32b:	48 89 8c 24 78 01 00 	mov    QWORD PTR [rsp+0x178],rcx
    b332:	00 
    b333:	48 8b 0d 00 00 00 00 	mov    rcx,QWORD PTR [rip+0x0]        # b33a <try_secant_tail.constprop.0+0xa9a>
    b33a:	48 89 b4 24 b0 01 00 	mov    QWORD PTR [rsp+0x1b0],rsi
    b341:	00 
    b342:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
    b347:	48 89 8c 24 70 01 00 	mov    QWORD PTR [rsp+0x170],rcx
    b34e:	00 
    b34f:	48 8b 4c 24 30       	mov    rcx,QWORD PTR [rsp+0x30]
    b354:	48 89 b4 24 a0 01 00 	mov    QWORD PTR [rsp+0x1a0],rsi
    b35b:	00 
    b35c:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    b360:	48 89 8c 24 68 01 00 	mov    QWORD PTR [rsp+0x168],rcx
    b367:	00 
    b368:	48 8b 4c 24 28       	mov    rcx,QWORD PTR [rsp+0x28]
    b36d:	c5 fb 11 a4 24 98 01 	vmovsd QWORD PTR [rsp+0x198],xmm4
    b374:	00 00 
    b376:	c5 fb 10 a4 24 d8 00 	vmovsd xmm4,QWORD PTR [rsp+0xd8]
    b37d:	00 00 
    b37f:	89 b4 24 b8 01 00 00 	mov    DWORD PTR [rsp+0x1b8],esi
    b386:	48 8d b4 24 60 01 00 	lea    rsi,[rsp+0x160]
    b38d:	00 
    b38e:	48 89 8c 24 60 01 00 	mov    QWORD PTR [rsp+0x160],rcx
    b395:	00 
    b396:	31 c9                	xor    ecx,ecx
    b398:	44 89 9c 24 bc 01 00 	mov    DWORD PTR [rsp+0x1bc],r11d
    b39f:	00 
    b3a0:	48 89 84 24 a8 01 00 	mov    QWORD PTR [rsp+0x1a8],rax
    b3a7:	00 
    b3a8:	4c 89 b4 24 88 01 00 	mov    QWORD PTR [rsp+0x188],r14
    b3af:	00 
    b3b0:	48 89 74 24 48       	mov    QWORD PTR [rsp+0x48],rsi
    b3b5:	c5 fb 11 a4 24 90 01 	vmovsd QWORD PTR [rsp+0x190],xmm4
    b3bc:	00 00 
    b3be:	e8 00 00 00 00       	call   b3c3 <try_secant_tail.constprop.0+0xb23>
    b3c3:	8b bc 24 d0 00 00 00 	mov    edi,DWORD PTR [rsp+0xd0]
    b3ca:	44 8b 1c 24          	mov    r11d,DWORD PTR [rsp]
    b3ce:	4c 8b 54 24 08       	mov    r10,QWORD PTR [rsp+0x8]
    b3d3:	85 ff                	test   edi,edi
    b3d5:	0f 8e a9 00 00 00    	jle    b484 <try_secant_tail.constprop.0+0xbe4>
    b3db:	c5 fb 10 94 24 d0 01 	vmovsd xmm2,QWORD PTR [rsp+0x1d0]
    b3e2:	00 00 
    b3e4:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    b3e8:	c5 fb 10 8c 24 d8 01 	vmovsd xmm1,QWORD PTR [rsp+0x1d8]
    b3ef:	00 00 
    b3f1:	85 f6                	test   esi,esi
    b3f3:	7e 4d                	jle    b442 <try_secant_tail.constprop.0+0xba2>
    b3f5:	48 8b 54 24 68       	mov    rdx,QWORD PTR [rsp+0x68]
    b3fa:	48 8b b4 24 10 01 00 	mov    rsi,QWORD PTR [rsp+0x110]
    b401:	00 
    b402:	31 c9                	xor    ecx,ecx
    b404:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
    b408:	31 c0                	xor    eax,eax
    b40a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    b411:	00 00 00 00 
    b415:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    b41c:	00 00 00 00 
    b420:	c5 fb 10 04 c3       	vmovsd xmm0,QWORD PTR [rbx+rax*8]
    b425:	c5 fb 58 04 c2       	vaddsd xmm0,xmm0,QWORD PTR [rdx+rax*8]
    b42a:	c5 fb 11 04 c3       	vmovsd QWORD PTR [rbx+rax*8],xmm0
    b42f:	48 83 c0 01          	add    rax,0x1
    b433:	41 39 c4             	cmp    r12d,eax
    b436:	7f e8                	jg     b420 <try_secant_tail.constprop.0+0xb80>
    b438:	83 c1 01             	add    ecx,0x1
    b43b:	48 01 f2             	add    rdx,rsi
    b43e:	39 cf                	cmp    edi,ecx
    b440:	75 c6                	jne    b408 <try_secant_tail.constprop.0+0xb68>
    b442:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    b449:	00 
    b44a:	48 8b 94 24 08 01 00 	mov    rdx,QWORD PTR [rsp+0x108]
    b451:	00 
    b452:	0f 1f 00             	nop    DWORD PTR [rax]
    b455:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    b45c:	00 00 00 00 
    b460:	c5 eb 58 10          	vaddsd xmm2,xmm2,QWORD PTR [rax]
    b464:	c5 f3 58 48 08       	vaddsd xmm1,xmm1,QWORD PTR [rax+0x8]
    b469:	48 83 c0 10          	add    rax,0x10
    b46d:	48 39 c2             	cmp    rdx,rax
    b470:	75 ee                	jne    b460 <try_secant_tail.constprop.0+0xbc0>
    b472:	c5 fb 11 94 24 d0 01 	vmovsd QWORD PTR [rsp+0x1d0],xmm2
    b479:	00 00 
    b47b:	c5 fb 11 8c 24 d8 01 	vmovsd QWORD PTR [rsp+0x1d8],xmm1
    b482:	00 00 
    b484:	45 85 ed             	test   r13d,r13d
    b487:	0f 8e 08 05 00 00    	jle    b995 <try_secant_tail.constprop.0+0x10f5>
    b48d:	48 8b 54 24 58       	mov    rdx,QWORD PTR [rsp+0x58]
    b492:	31 c0                	xor    eax,eax
    b494:	eb 17                	jmp    b4ad <try_secant_tail.constprop.0+0xc0d>
    b496:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
    b49d:	00 00 00 
    b4a0:	48 83 c0 01          	add    rax,0x1
    b4a4:	49 39 c7             	cmp    r15,rax
    b4a7:	0f 84 e8 04 00 00    	je     b995 <try_secant_tail.constprop.0+0x10f5>
    b4ad:	80 3c 02 00          	cmp    BYTE PTR [rdx+rax*1],0x0
    b4b1:	74 ed                	je     b4a0 <try_secant_tail.constprop.0+0xc00>
    b4b3:	8b 94 24 2c 01 00 00 	mov    edx,DWORD PTR [rsp+0x12c]
    b4ba:	8b bc 24 24 01 00 00 	mov    edi,DWORD PTR [rsp+0x124]
    b4c1:	85 d2                	test   edx,edx
    b4c3:	89 7c 24 08          	mov    DWORD PTR [rsp+0x8],edi
    b4c7:	0f 85 9d 0c 00 00    	jne    c16a <try_secant_tail.constprop.0+0x18ca>
    b4cd:	48 8b 74 24 30       	mov    rsi,QWORD PTR [rsp+0x30]
    b4d2:	41 01 c3             	add    r11d,eax
    b4d5:	49 89 e8             	mov    r8,rbp
    b4d8:	49 63 c3             	movsxd rax,r11d
    b4db:	4c 0f af c0          	imul   r8,rax
    b4df:	c5 7b 10 0c c6       	vmovsd xmm9,QWORD PTR [rsi+rax*8]
    b4e4:	4c 03 44 24 28       	add    r8,QWORD PTR [rsp+0x28]
    b4e9:	e9 b2 f8 ff ff       	jmp    ada0 <try_secant_tail.constprop.0+0x500>
    b4ee:	66 90                	xchg   ax,ax
    b4f0:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
    b4f4:	c5 f9 2f c2          	vcomisd xmm0,xmm2
    b4f8:	76 0b                	jbe    b505 <try_secant_tail.constprop.0+0xc65>
    b4fa:	48 c7 80 00 00 00 00 	mov    QWORD PTR [rax+0x0],0x0
    b501:	00 00 00 00 
    b505:	c5 fb 10 25 00 00 00 	vmovsd xmm4,QWORD PTR [rip+0x0]        # b50d <try_secant_tail.constprop.0+0xc6d>
    b50c:	00 
    b50d:	c5 f9 2f dc          	vcomisd xmm3,xmm4
    b511:	0f 86 e8 00 00 00    	jbe    b5ff <try_secant_tail.constprop.0+0xd5f>
    b517:	c5 f9 28 c4          	vmovapd xmm0,xmm4
    b51b:	c5 e3 5c d0          	vsubsd xmm2,xmm3,xmm0
    b51f:	c5 f9 2f 15 00 00 00 	vcomisd xmm2,QWORD PTR [rip+0x0]        # b527 <try_secant_tail.constprop.0+0xc87>
    b526:	00 
    b527:	0f 86 b8 00 00 00    	jbe    b5e5 <try_secant_tail.constprop.0+0xd45>
    b52d:	44 8b 84 24 24 01 00 	mov    r8d,DWORD PTR [rsp+0x124]
    b534:	00 
    b535:	44 39 04 24          	cmp    DWORD PTR [rsp],r8d
    b539:	0f 8e df fc ff ff    	jle    b21e <try_secant_tail.constprop.0+0x97e>
    b53f:	8b 84 24 28 01 00 00 	mov    eax,DWORD PTR [rsp+0x128]
    b546:	41 39 c0             	cmp    r8d,eax
    b549:	0f 8c 99 05 00 00    	jl     bae8 <try_secant_tail.constprop.0+0x1248>
    b54f:	dd d8                	fstp   st(0)
    b551:	83 f8 07             	cmp    eax,0x7
    b554:	8b 94 24 20 01 00 00 	mov    edx,DWORD PTR [rsp+0x120]
    b55b:	0f 8f 96 08 00 00    	jg     bdf7 <try_secant_tail.constprop.0+0x1557>
    b561:	41 bf 08 00 00 00    	mov    r15d,0x8
    b567:	44 39 fa             	cmp    edx,r15d
    b56a:	44 0f 4e fa          	cmovle r15d,edx
    b56e:	44 39 f8             	cmp    eax,r15d
    b571:	7d 1e                	jge    b591 <try_secant_tail.constprop.0+0xcf1>
    b573:	48 b8 ff ff ff ff ff 	movabs rax,0x1fffffffffffffff
    b57a:	ff ff 1f 
    b57d:	48 63 f2             	movsxd rsi,edx
    b580:	31 d2                	xor    edx,edx
    b582:	49 63 cf             	movsxd rcx,r15d
    b585:	48 f7 f6             	div    rsi
    b588:	48 39 c8             	cmp    rax,rcx
    b58b:	0f 83 a0 08 00 00    	jae    be31 <try_secant_tail.constprop.0+0x1591>
    b591:	8b 84 24 2c 01 00 00 	mov    eax,DWORD PTR [rsp+0x12c]
    b598:	85 c0                	test   eax,eax
    b59a:	0f 85 39 0a 00 00    	jne    bfd9 <try_secant_tail.constprop.0+0x1739>
    b5a0:	41 83 c3 01          	add    r11d,0x1
    b5a4:	44 39 5c 24 14       	cmp    DWORD PTR [rsp+0x14],r11d
    b5a9:	0f 8e 29 0c 00 00    	jle    c1d8 <try_secant_tail.constprop.0+0x1938>
    b5af:	83 44 24 18 01       	add    DWORD PTR [rsp+0x18],0x1
    b5b4:	44 89 44 24 08       	mov    DWORD PTR [rsp+0x8],r8d
    b5b9:	e9 81 f6 ff ff       	jmp    ac3f <try_secant_tail.constprop.0+0x39f>
    b5be:	66 90                	xchg   ax,ax
    b5c0:	c5 fb 58 54 24 20    	vaddsd xmm2,xmm0,QWORD PTR [rsp+0x20]
    b5c6:	c5 fb 10 25 00 00 00 	vmovsd xmm4,QWORD PTR [rip+0x0]        # b5ce <try_secant_tail.constprop.0+0xd2e>
    b5cd:	00 
    b5ce:	c5 eb 59 d4          	vmulsd xmm2,xmm2,xmm4
    b5d2:	c4 e2 e9 99 c0       	vfmadd132sd xmm0,xmm2,xmm0
    b5d7:	c5 f9 2f d8          	vcomisd xmm3,xmm0
    b5db:	0f 87 3a ff ff ff    	ja     b51b <try_secant_tail.constprop.0+0xc7b>
    b5e1:	dd d8                	fstp   st(0)
    b5e3:	eb 02                	jmp    b5e7 <try_secant_tail.constprop.0+0xd47>
    b5e5:	dd d8                	fstp   st(0)
    b5e7:	c5 fb 58 c3          	vaddsd xmm0,xmm0,xmm3
    b5eb:	c5 fb 10 15 00 00 00 	vmovsd xmm2,QWORD PTR [rip+0x0]        # b5f3 <try_secant_tail.constprop.0+0xd53>
    b5f2:	00 
    b5f3:	c5 f9 2f d0          	vcomisd xmm2,xmm0
    b5f7:	0f 86 23 fc ff ff    	jbe    b220 <try_secant_tail.constprop.0+0x980>
    b5fd:	eb 02                	jmp    b601 <try_secant_tail.constprop.0+0xd61>
    b5ff:	dd d8                	fstp   st(0)
    b601:	c5 fb 10 6c 24 48    	vmovsd xmm5,QWORD PTR [rsp+0x48]
    b607:	c5 d1 54 05 00 00 00 	vandpd xmm0,xmm5,XMMWORD PTR [rip+0x0]        # b60f <try_secant_tail.constprop.0+0xd6f>
    b60e:	00 
    b60f:	c5 fb 58 44 24 20    	vaddsd xmm0,xmm0,QWORD PTR [rsp+0x20]
    b615:	8b 84 24 24 01 00 00 	mov    eax,DWORD PTR [rsp+0x124]
    b61c:	c5 fb 58 84 24 b8 00 	vaddsd xmm0,xmm0,QWORD PTR [rsp+0xb8]
    b623:	00 00 
    b625:	c5 fb 59 05 00 00 00 	vmulsd xmm0,xmm0,QWORD PTR [rip+0x0]        # b62d <try_secant_tail.constprop.0+0xd8d>
    b62c:	00 
    b62d:	c5 fb 10 ac 24 b0 00 	vmovsd xmm5,QWORD PTR [rsp+0xb0]
    b634:	00 00 
    b636:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    b63a:	c5 d1 54 0d 00 00 00 	vandpd xmm1,xmm5,XMMWORD PTR [rip+0x0]        # b642 <try_secant_tail.constprop.0+0xda2>
    b641:	00 
    b642:	c5 f9 2f c8          	vcomisd xmm1,xmm0
    b646:	0f 86 74 04 00 00    	jbe    bac0 <try_secant_tail.constprop.0+0x1220>
    b64c:	39 04 24             	cmp    DWORD PTR [rsp],eax
    b64f:	4d 89 f9             	mov    r9,r15
    b652:	45 89 df             	mov    r15d,r11d
    b655:	0f 84 19 0b 00 00    	je     c174 <try_secant_tail.constprop.0+0x18d4>
    b65b:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    b660:	4c 89 ce             	mov    rsi,r9
    b663:	e8 18 72 ff ff       	call   2880 <local_dependency_svd>
    b668:	83 f8 01             	cmp    eax,0x1
    b66b:	0f 85 b2 fb ff ff    	jne    b223 <try_secant_tail.constprop.0+0x983>
    b671:	8b 84 24 24 01 00 00 	mov    eax,DWORD PTR [rsp+0x124]
    b678:	c7 84 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],0x1
    b67f:	01 00 00 00 
    b683:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    b687:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    b68c:	e8 00 00 00 00       	call   b691 <try_secant_tail.constprop.0+0xdf1>
    b691:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    b696:	e8 00 00 00 00       	call   b69b <try_secant_tail.constprop.0+0xdfb>
    b69b:	48 8b bc 24 a0 00 00 	mov    rdi,QWORD PTR [rsp+0xa0]
    b6a2:	00 
    b6a3:	e8 00 00 00 00       	call   b6a8 <try_secant_tail.constprop.0+0xe08>
    b6a8:	48 8d b4 24 60 01 00 	lea    rsi,[rsp+0x160]
    b6af:	00 
    b6b0:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    b6b7:	00 
    b6b8:	8b 7c 24 08          	mov    edi,DWORD PTR [rsp+0x8]
    b6bc:	48 c7 84 24 70 01 00 	mov    QWORD PTR [rsp+0x170],0x0
    b6c3:	00 00 00 00 00 
    b6c8:	c7 84 24 78 01 00 00 	mov    DWORD PTR [rsp+0x178],0x0
    b6cf:	00 00 00 00 
    b6d3:	8b 4c 24 14          	mov    ecx,DWORD PTR [rsp+0x14]
    b6d7:	89 78 04             	mov    DWORD PTR [rax+0x4],edi
    b6da:	8b 7c 24 10          	mov    edi,DWORD PTR [rsp+0x10]
    b6de:	c7 00 03 00 00 00    	mov    DWORD PTR [rax],0x3
    b6e4:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
    b6eb:	00 
    b6ec:	89 bc 24 9c 01 00 00 	mov    DWORD PTR [rsp+0x19c],edi
    b6f3:	48 89 84 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rax
    b6fa:	00 
    b6fb:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    b700:	89 8c 24 98 01 00 00 	mov    DWORD PTR [rsp+0x198],ecx
    b707:	48 89 84 24 88 01 00 	mov    QWORD PTR [rsp+0x188],rax
    b70e:	00 
    b70f:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    b714:	48 c7 84 24 60 01 00 	mov    QWORD PTR [rsp+0x160],0x0
    b71b:	00 00 00 00 00 
    b720:	48 89 84 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rax
    b727:	00 
    b728:	48 63 c1             	movsxd rax,ecx
    b72b:	48 0f af 44 24 50    	imul   rax,QWORD PTR [rsp+0x50]
    b731:	c7 84 24 68 01 00 00 	mov    DWORD PTR [rsp+0x168],0x0
    b738:	00 00 00 00 
    b73c:	48 3d 3f 42 0f 00    	cmp    rax,0xf423f
    b742:	0f 9f c2             	setg   dl
    b745:	81 ff 7f 01 00 00    	cmp    edi,0x17f
    b74b:	48 8d 3d 1e 4d ff ff 	lea    rdi,[rip+0xffffffffffff4d1e]        # 470 <relres._omp_fn.0>
    b752:	0f 9e c0             	setle  al
    b755:	31 c9                	xor    ecx,ecx
    b757:	21 c2                	and    edx,eax
    b759:	83 f2 01             	xor    edx,0x1
    b75c:	0f b6 d2             	movzx  edx,dl
    b75f:	e8 00 00 00 00       	call   b764 <try_secant_tail.constprop.0+0xec4>
    b764:	db ac 24 70 01 00 00 	fld    TBYTE PTR [rsp+0x170]
    b76b:	db ac 24 60 01 00 00 	fld    TBYTE PTR [rsp+0x160]
    b772:	d9 ee                	fldz
    b774:	df f1                	fcomip st,st(1)
    b776:	0f 84 ee 08 00 00    	je     c06a <try_secant_tail.constprop.0+0x17ca>
    b77c:	d9 fa                	fsqrt
    b77e:	d9 c9                	fxch   st(1)
    b780:	48 8b 8c 24 00 01 00 	mov    rcx,QWORD PTR [rsp+0x100]
    b787:	00 
    b788:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    b78f:	00 
    b790:	48 85 c9             	test   rcx,rcx
    b793:	d9 fa                	fsqrt
    b795:	de f1                	fdivrp st(1),st
    b797:	dd 58 18             	fstp   QWORD PTR [rax+0x18]
    b79a:	0f 84 0f 0a 00 00    	je     c1af <try_secant_tail.constprop.0+0x190f>
    b7a0:	8b 7c 24 10          	mov    edi,DWORD PTR [rsp+0x10]
    b7a4:	85 ff                	test   edi,edi
    b7a6:	0f 8e 10 0a 00 00    	jle    c1bc <try_secant_tail.constprop.0+0x191c>
    b7ac:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
    b7b0:	48 8b 94 24 38 01 00 	mov    rdx,QWORD PTR [rsp+0x138]
    b7b7:	00 
    b7b8:	31 c0                	xor    eax,eax
    b7ba:	c5 f9 28 d3          	vmovapd xmm2,xmm3
    b7be:	c5 fb 10 0c 01       	vmovsd xmm1,QWORD PTR [rcx+rax*1]
    b7c3:	c5 fb 10 04 02       	vmovsd xmm0,QWORD PTR [rdx+rax*1]
    b7c8:	48 83 c0 08          	add    rax,0x8
    b7cc:	48 39 c5             	cmp    rbp,rax
    b7cf:	c5 fb 5c c1          	vsubsd xmm0,xmm0,xmm1
    b7d3:	c4 e2 f1 b9 d9       	vfmadd231sd xmm3,xmm1,xmm1
    b7d8:	c4 e2 f9 b9 d0       	vfmadd231sd xmm2,xmm0,xmm0
    b7dd:	75 df                	jne    b7be <try_secant_tail.constprop.0+0xf1e>
    b7df:	c5 eb 51 d2          	vsqrtsd xmm2,xmm2,xmm2
    b7e3:	c5 e3 51 db          	vsqrtsd xmm3,xmm3,xmm3
    b7e7:	c5 e3 58 1d 00 00 00 	vaddsd xmm3,xmm3,QWORD PTR [rip+0x0]        # b7ef <try_secant_tail.constprop.0+0xf4f>
    b7ee:	00 
    b7ef:	c5 eb 5e d3          	vdivsd xmm2,xmm2,xmm3
    b7f3:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    b7fa:	00 
    b7fb:	c5 fb 11 50 20       	vmovsd QWORD PTR [rax+0x20],xmm2
    b800:	48 8b bc 24 30 01 00 	mov    rdi,QWORD PTR [rsp+0x130]
    b807:	00 
    b808:	e8 00 00 00 00       	call   b80d <try_secant_tail.constprop.0+0xf6d>
    b80d:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    b814:	00 
    b815:	e8 00 00 00 00       	call   b81a <try_secant_tail.constprop.0+0xf7a>
    b81a:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    b821:	00 
    b822:	e8 00 00 00 00       	call   b827 <try_secant_tail.constprop.0+0xf87>
    b827:	4c 89 f7             	mov    rdi,r14
    b82a:	e8 00 00 00 00       	call   b82f <try_secant_tail.constprop.0+0xf8f>
    b82f:	48 89 df             	mov    rdi,rbx
    b832:	e8 00 00 00 00       	call   b837 <try_secant_tail.constprop.0+0xf97>
    b837:	41 ba 01 00 00 00    	mov    r10d,0x1
    b83d:	e9 d7 f0 ff ff       	jmp    a919 <try_secant_tail.constprop.0+0x79>
    b842:	41 8d 43 01          	lea    eax,[r11+0x1]
    b846:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
    b84a:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # b852 <try_secant_tail.constprop.0+0xfb2>
    b851:	00 
    b852:	48 be eb 11 31 13 bb 	movabs rsi,0x94d049bb133111eb
    b859:	49 d0 94 
    b85c:	c5 7b 10 a4 24 d8 00 	vmovsd xmm12,QWORD PTR [rsp+0xd8]
    b863:	00 00 
    b865:	48 63 d0             	movsxd rdx,eax
    b868:	89 44 24 38          	mov    DWORD PTR [rsp+0x38],eax
    b86c:	48 b9 15 7c 4a 7f b9 	movabs rcx,0x9e3779b97f4a7c15
    b873:	79 37 9e 
    b876:	48 89 d0             	mov    rax,rdx
    b879:	48 03 8c 24 c8 00 00 	add    rcx,QWORD PTR [rsp+0xc8]
    b880:	00 
    b881:	48 0f af c6          	imul   rax,rsi
    b885:	48 01 c8             	add    rax,rcx
    b888:	48 89 c7             	mov    rdi,rax
    b88b:	48 c1 ef 1e          	shr    rdi,0x1e
    b88f:	48 31 f8             	xor    rax,rdi
    b892:	48 bf b9 e5 e4 1c 6d 	movabs rdi,0xbf58476d1ce4e5b9
    b899:	47 58 bf 
    b89c:	48 0f af c7          	imul   rax,rdi
    b8a0:	48 0f af d7          	imul   rdx,rdi
    b8a4:	49 89 c1             	mov    r9,rax
    b8a7:	49 c1 e9 1b          	shr    r9,0x1b
    b8ab:	4c 31 c8             	xor    rax,r9
    b8ae:	48 0f af c6          	imul   rax,rsi
    b8b2:	49 89 c1             	mov    r9,rax
    b8b5:	49 c1 e9 1f          	shr    r9,0x1f
    b8b9:	4c 31 c8             	xor    rax,r9
    b8bc:	48 c1 e8 0b          	shr    rax,0xb
    b8c0:	c4 e1 db 2a c0       	vcvtsi2sd xmm0,xmm4,rax
    b8c5:	48 8d 04 0a          	lea    rax,[rdx+rcx*1]
    b8c9:	c5 f9 28 d8          	vmovapd xmm3,xmm0
    b8cd:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # b8d5 <try_secant_tail.constprop.0+0x1035>
    b8d4:	00 
    b8d5:	48 89 c2             	mov    rdx,rax
    b8d8:	48 c1 ea 1e          	shr    rdx,0x1e
    b8dc:	c4 e2 f9 99 dd       	vfmadd132sd xmm3,xmm0,xmm5
    b8e1:	48 31 d0             	xor    rax,rdx
    b8e4:	48 0f af c7          	imul   rax,rdi
    b8e8:	c4 c1 63 59 dc       	vmulsd xmm3,xmm3,xmm12
    b8ed:	48 89 c2             	mov    rdx,rax
    b8f0:	48 c1 ea 1b          	shr    rdx,0x1b
    b8f4:	48 31 c2             	xor    rdx,rax
    b8f7:	48 0f af d6          	imul   rdx,rsi
    b8fb:	48 89 d0             	mov    rax,rdx
    b8fe:	48 c1 e8 1f          	shr    rax,0x1f
    b902:	48 31 d0             	xor    rax,rdx
    b905:	8b 54 24 10          	mov    edx,DWORD PTR [rsp+0x10]
    b909:	48 c1 e8 0b          	shr    rax,0xb
    b90d:	c4 e1 db 2a e0       	vcvtsi2sd xmm4,xmm4,rax
    b912:	c4 e2 f9 99 e5       	vfmadd132sd xmm4,xmm0,xmm5
    b917:	85 d2                	test   edx,edx
    b919:	c4 c1 5b 59 e4       	vmulsd xmm4,xmm4,xmm12
    b91e:	7e 4a                	jle    b96a <try_secant_tail.constprop.0+0x10ca>
    b920:	c5 73 59 d3          	vmulsd xmm10,xmm1,xmm3
    b924:	48 8b 94 24 18 01 00 	mov    rdx,QWORD PTR [rsp+0x118]
    b92b:	00 
    b92c:	31 c0                	xor    eax,eax
    b92e:	c5 f3 59 ec          	vmulsd xmm5,xmm1,xmm4
    b932:	0f 1f 00             	nop    DWORD PTR [rax]
    b935:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    b93c:	00 00 00 00 
    b940:	c4 c1 7b 10 04 00    	vmovsd xmm0,QWORD PTR [r8+rax*1]
    b946:	c4 41 79 28 da       	vmovapd xmm11,xmm10
    b94b:	c4 62 f9 a9 1c 03    	vfmadd213sd xmm11,xmm0,QWORD PTR [rbx+rax*1]
    b951:	c5 7b 11 1c 03       	vmovsd QWORD PTR [rbx+rax*1],xmm11
    b956:	c4 e2 d1 a9 04 02    	vfmadd213sd xmm0,xmm5,QWORD PTR [rdx+rax*1]
    b95c:	c5 fb 11 04 02       	vmovsd QWORD PTR [rdx+rax*1],xmm0
    b961:	48 83 c0 08          	add    rax,0x8
    b965:	48 39 c5             	cmp    rbp,rax
    b968:	75 d6                	jne    b940 <try_secant_tail.constprop.0+0x10a0>
    b96a:	c4 e2 e9 a9 9c 24 d0 	vfmadd213sd xmm3,xmm2,QWORD PTR [rsp+0x1d0]
    b971:	01 00 00 
    b974:	c4 e2 e9 a9 a4 24 d8 	vfmadd213sd xmm4,xmm2,QWORD PTR [rsp+0x1d8]
    b97b:	01 00 00 
    b97e:	c5 fb 11 9c 24 d0 01 	vmovsd QWORD PTR [rsp+0x1d0],xmm3
    b985:	00 00 
    b987:	c5 fb 11 a4 24 d8 01 	vmovsd QWORD PTR [rsp+0x1d8],xmm4
    b98e:	00 00 
    b990:	e9 a2 f3 ff ff       	jmp    ad37 <try_secant_tail.constprop.0+0x497>
    b995:	8b 84 24 24 01 00 00 	mov    eax,DWORD PTR [rsp+0x124]
    b99c:	44 01 6c 24 18       	add    DWORD PTR [rsp+0x18],r13d
    b9a1:	8b bc 24 2c 01 00 00 	mov    edi,DWORD PTR [rsp+0x12c]
    b9a8:	44 8b 7c 24 38       	mov    r15d,DWORD PTR [rsp+0x38]
    b9ad:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    b9b1:	e9 35 f4 ff ff       	jmp    adeb <try_secant_tail.constprop.0+0x54b>
    b9b6:	83 fd 40             	cmp    ebp,0x40
    b9b9:	74 1d                	je     b9d8 <try_secant_tail.constprop.0+0x1138>
    b9bb:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # b9c2 <try_secant_tail.constprop.0+0x1122>
    b9c2:	e8 00 00 00 00       	call   b9c7 <try_secant_tail.constprop.0+0x1127>
    b9c7:	83 c5 01             	add    ebp,0x1
    b9ca:	89 a8 00 00 00 00    	mov    DWORD PTR [rax+0x0],ebp
    b9d0:	46 89 bc a0 00 00 00 	mov    DWORD PTR [rax+r12*4+0x0],r15d
    b9d7:	00 
    b9d8:	48 8b bc 24 30 01 00 	mov    rdi,QWORD PTR [rsp+0x130]
    b9df:	00 
    b9e0:	e8 00 00 00 00       	call   b9e5 <try_secant_tail.constprop.0+0x1145>
    b9e5:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    b9ec:	00 
    b9ed:	e8 00 00 00 00       	call   b9f2 <try_secant_tail.constprop.0+0x1152>
    b9f2:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    b9f9:	00 
    b9fa:	e8 00 00 00 00       	call   b9ff <try_secant_tail.constprop.0+0x115f>
    b9ff:	4c 89 f7             	mov    rdi,r14
    ba02:	e8 00 00 00 00       	call   ba07 <try_secant_tail.constprop.0+0x1167>
    ba07:	48 89 df             	mov    rdi,rbx
    ba0a:	e8 00 00 00 00       	call   ba0f <try_secant_tail.constprop.0+0x116f>
    ba0f:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    ba14:	e8 00 00 00 00       	call   ba19 <try_secant_tail.constprop.0+0x1179>
    ba19:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    ba1e:	e8 00 00 00 00       	call   ba23 <try_secant_tail.constprop.0+0x1183>
    ba23:	48 8b bc 24 a0 00 00 	mov    rdi,QWORD PTR [rsp+0xa0]
    ba2a:	00 
    ba2b:	e8 00 00 00 00       	call   ba30 <try_secant_tail.constprop.0+0x1190>
    ba30:	45 31 d2             	xor    r10d,r10d
    ba33:	e9 e1 ee ff ff       	jmp    a919 <try_secant_tail.constprop.0+0x79>
    ba38:	41 83 c3 01          	add    r11d,0x1
    ba3c:	44 39 5c 24 14       	cmp    DWORD PTR [rsp+0x14],r11d
    ba41:	0f 8e 3d 07 00 00    	jle    c184 <try_secant_tail.constprop.0+0x18e4>
    ba47:	83 44 24 18 01       	add    DWORD PTR [rsp+0x18],0x1
    ba4c:	e9 ee f1 ff ff       	jmp    ac3f <try_secant_tail.constprop.0+0x39f>
    ba51:	49 89 d0             	mov    r8,rdx
    ba54:	8b 54 24 08          	mov    edx,DWORD PTR [rsp+0x8]
    ba58:	4c 89 cf             	mov    rdi,r9
    ba5b:	89 c1                	mov    ecx,eax
    ba5d:	4c 89 94 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r10
    ba64:	00 
    ba65:	44 89 9c 24 80 00 00 	mov    DWORD PTR [rsp+0x80],r11d
    ba6c:	00 
    ba6d:	4c 89 4c 24 70       	mov    QWORD PTR [rsp+0x70],r9
    ba72:	e8 89 69 ff ff       	call   2400 <project_cgs2>
    ba77:	4c 8b 4c 24 70       	mov    r9,QWORD PTR [rsp+0x70]
    ba7c:	8b 34 24             	mov    esi,DWORD PTR [rsp]
    ba7f:	c5 fb 11 84 24 c0 00 	vmovsd QWORD PTR [rsp+0xc0],xmm0
    ba86:	00 00 
    ba88:	4c 89 cf             	mov    rdi,r9
    ba8b:	e8 60 46 ff ff       	call   f0 <norm2>
    ba90:	c5 fb 10 64 24 48    	vmovsd xmm4,QWORD PTR [rsp+0x48]
    ba96:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    ba9d:	00 
    ba9e:	44 8b 9c 24 80 00 00 	mov    r11d,DWORD PTR [rsp+0x80]
    baa5:	00 
    baa6:	4c 8b 94 24 88 00 00 	mov    r10,QWORD PTR [rsp+0x88]
    baad:	00 
    baae:	c5 f9 28 d8          	vmovapd xmm3,xmm0
    bab2:	c5 fb 11 a4 24 b0 00 	vmovsd QWORD PTR [rsp+0xb0],xmm4
    bab9:	00 00 
    babb:	e9 ab f6 ff ff       	jmp    b16b <try_secant_tail.constprop.0+0x8cb>
    bac0:	8b 84 24 2c 01 00 00 	mov    eax,DWORD PTR [rsp+0x12c]
    bac7:	85 c0                	test   eax,eax
    bac9:	0f 85 0f 05 00 00    	jne    bfde <try_secant_tail.constprop.0+0x173e>
    bacf:	41 83 c3 01          	add    r11d,0x1
    bad3:	44 39 5c 24 14       	cmp    DWORD PTR [rsp+0x14],r11d
    bad8:	0f 8f 69 ff ff ff    	jg     ba47 <try_secant_tail.constprop.0+0x11a7>
    bade:	e9 66 f5 ff ff       	jmp    b049 <try_secant_tail.constprop.0+0x7a9>
    bae3:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    bae8:	c5 fb 10 8c 24 b0 00 	vmovsd xmm1,QWORD PTR [rsp+0xb0]
    baef:	00 00 
    baf1:	8b 7c 24 40          	mov    edi,DWORD PTR [rsp+0x40]
    baf5:	45 89 df             	mov    r15d,r11d
    baf8:	4d 89 eb             	mov    r11,r13
    bafb:	48 8b 8c 24 30 01 00 	mov    rcx,QWORD PTR [rsp+0x130]
    bb02:	00 
    bb03:	49 63 d0             	movsxd rdx,r8d
    bb06:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    bb09:	49 0f af d3          	imul   rdx,r11
    bb0d:	48 01 ca             	add    rdx,rcx
    bb10:	85 c0                	test   eax,eax
    bb12:	7e 20                	jle    bb34 <try_secant_tail.constprop.0+0x1294>
    bb14:	c5 fb 10 6c 24 20    	vmovsd xmm5,QWORD PTR [rsp+0x20]
    bb1a:	31 c0                	xor    eax,eax
    bb1c:	c5 d3 5e d3          	vdivsd xmm2,xmm5,xmm3
    bb20:	c4 c1 6b 59 04 01    	vmulsd xmm0,xmm2,QWORD PTR [r9+rax*1]
    bb26:	c5 fb 11 04 02       	vmovsd QWORD PTR [rdx+rax*1],xmm0
    bb2b:	48 83 c0 08          	add    rax,0x8
    bb2f:	49 39 c3             	cmp    r11,rax
    bb32:	75 ec                	jne    bb20 <try_secant_tail.constprop.0+0x1280>
    bb34:	41 83 f8 5f          	cmp    r8d,0x5f
    bb38:	48 63 84 24 20 01 00 	movsxd rax,DWORD PTR [rsp+0x120]
    bb3f:	00 
    bb40:	0f 8e c7 03 00 00    	jle    bf0d <try_secant_tail.constprop.0+0x166d>
    bb46:	d9 ee                	fldz
    bb48:	d9 c9                	fxch   st(1)
    bb4a:	db f1                	fcomi  st,st(1)
    bb4c:	dd d9                	fstp   st(1)
    bb4e:	0f 86 ae 03 00 00    	jbe    bf02 <try_secant_tail.constprop.0+0x1662>
    bb54:	d9 c0                	fld    st(0)
    bb56:	c5 e3 58 15 00 00 00 	vaddsd xmm2,xmm3,QWORD PTR [rip+0x0]        # bb5e <try_secant_tail.constprop.0+0x12be>
    bb5d:	00 
    bb5e:	c5 fb 10 ac 24 c0 00 	vmovsd xmm5,QWORD PTR [rsp+0xc0]
    bb65:	00 00 
    bb67:	d9 fa                	fsqrt
    bb69:	c5 d3 5e d2          	vdivsd xmm2,xmm5,xmm2
    bb6d:	dd 5c 24 18          	fstp   QWORD PTR [rsp+0x18]
    bb71:	c5 fb 10 44 24 18    	vmovsd xmm0,QWORD PTR [rsp+0x18]
    bb77:	c4 e2 d9 99 c2       	vfmadd132sd xmm0,xmm4,xmm2
    bb7c:	c5 fb 11 44 24 18    	vmovsd QWORD PTR [rsp+0x18],xmm0
    bb82:	dd 44 24 18          	fld    QWORD PTR [rsp+0x18]
    bb86:	d8 c8                	fmul   st,st(0)
    bb88:	d8 c0                	fadd   st,st(0)
    bb8a:	85 c0                	test   eax,eax
    bb8c:	0f 8e be 04 00 00    	jle    c050 <try_secant_tail.constprop.0+0x17b0>
    bb92:	48 89 d6             	mov    rsi,rdx
    bb95:	48 8d 04 c2          	lea    rax,[rdx+rax*8]
    bb99:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    bb9d:	0f 1f 00             	nop    DWORD PTR [rax]
    bba0:	c5 fb 10 06          	vmovsd xmm0,QWORD PTR [rsi]
    bba4:	48 83 c6 08          	add    rsi,0x8
    bba8:	48 39 f0             	cmp    rax,rsi
    bbab:	c5 fb 59 c0          	vmulsd xmm0,xmm0,xmm0
    bbaf:	c5 eb 58 d0          	vaddsd xmm2,xmm2,xmm0
    bbb3:	75 eb                	jne    bba0 <try_secant_tail.constprop.0+0x1300>
    bbb5:	c5 eb 5c 44 24 20    	vsubsd xmm0,xmm2,QWORD PTR [rsp+0x20]
    bbbb:	c5 f9 54 05 00 00 00 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x0]        # bbc3 <try_secant_tail.constprop.0+0x1323>
    bbc2:	00 
    bbc3:	c5 fb 58 e4          	vaddsd xmm4,xmm0,xmm4
    bbc7:	c5 fb 11 64 24 18    	vmovsd QWORD PTR [rsp+0x18],xmm4
    bbcd:	dd 44 24 18          	fld    QWORD PTR [rsp+0x18]
    bbd1:	d8 c8                	fmul   st,st(0)
    bbd3:	d9 ca                	fxch   st(2)
    bbd5:	de c1                	faddp  st(1),st
    bbd7:	de c1                	faddp  st(1),st
    bbd9:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    bbdc:	db bc 24 50 01 00 00 	fstp   TBYTE PTR [rsp+0x150]
    bbe3:	85 c0                	test   eax,eax
    bbe5:	7e 32                	jle    bc19 <try_secant_tail.constprop.0+0x1379>
    bbe7:	c5 f3 5e db          	vdivsd xmm3,xmm1,xmm3
    bbeb:	48 8b b4 24 38 01 00 	mov    rsi,QWORD PTR [rsp+0x138]
    bbf2:	00 
    bbf3:	31 c0                	xor    eax,eax
    bbf5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    bbfc:	00 00 00 00 
    bc00:	c5 fb 10 04 02       	vmovsd xmm0,QWORD PTR [rdx+rax*1]
    bc05:	c4 e2 e1 a9 04 06    	vfmadd213sd xmm0,xmm3,QWORD PTR [rsi+rax*1]
    bc0b:	c5 fb 11 04 06       	vmovsd QWORD PTR [rsi+rax*1],xmm0
    bc10:	48 83 c0 08          	add    rax,0x8
    bc14:	49 39 c3             	cmp    r11,rax
    bc17:	75 e7                	jne    bc00 <try_secant_tail.constprop.0+0x1360>
    bc19:	8b b4 24 2c 01 00 00 	mov    esi,DWORD PTR [rsp+0x12c]
    bc20:	41 8d 40 01          	lea    eax,[r8+0x1]
    bc24:	89 84 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],eax
    bc2b:	85 f6                	test   esi,esi
    bc2d:	89 74 24 18          	mov    DWORD PTR [rsp+0x18],esi
    bc31:	0f 85 60 05 00 00    	jne    c197 <try_secant_tail.constprop.0+0x18f7>
    bc37:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    bc3b:	39 c6                	cmp    esi,eax
    bc3d:	0f 84 32 04 00 00    	je     c075 <try_secant_tail.constprop.0+0x17d5>
    bc43:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    bc4a:	48 89 4c 24 40       	mov    QWORD PTR [rsp+0x40],rcx
    bc4f:	49 89 d9             	mov    r9,rbx
    bc52:	4d 89 f3             	mov    r11,r14
    bc55:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    bc5c:	00 
    bc5d:	41 bd 02 00 00 00    	mov    r13d,0x2
    bc63:	83 c0 01             	add    eax,0x1
    bc66:	89 04 24             	mov    DWORD PTR [rsp],eax
    bc69:	e8 82 44 ff ff       	call   f0 <norm2>
    bc6e:	4c 63 44 24 08       	movsxd r8,DWORD PTR [rsp+0x8]
    bc73:	c5 fb 10 35 00 00 00 	vmovsd xmm6,QWORD PTR [rip+0x0]        # bc7b <try_secant_tail.constprop.0+0x13db>
    bc7a:	00 
    bc7b:	c5 fb 11 84 24 a8 00 	vmovsd QWORD PTR [rsp+0xa8],xmm0
    bc82:	00 00 
    bc84:	4c 0f af c5          	imul   r8,rbp
    bc88:	4c 03 44 24 40       	add    r8,QWORD PTR [rsp+0x40]
    bc8d:	4c 89 c3             	mov    rbx,r8
    bc90:	45 89 e0             	mov    r8d,r12d
    bc93:	4d 89 d4             	mov    r12,r10
    bc96:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    bc9a:	85 c0                	test   eax,eax
    bc9c:	0f 8e 3f 02 00 00    	jle    bee1 <try_secant_tail.constprop.0+0x1641>
    bca2:	31 c0                	xor    eax,eax
    bca4:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
    bca8:	66 90                	xchg   ax,ax
    bcaa:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    bcb1:	00 00 00 00 
    bcb5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    bcbc:	00 00 00 00 
    bcc0:	c4 c1 7b 10 04 06    	vmovsd xmm0,QWORD PTR [r14+rax*1]
    bcc6:	c5 fb 59 04 03       	vmulsd xmm0,xmm0,QWORD PTR [rbx+rax*1]
    bccb:	48 83 c0 08          	add    rax,0x8
    bccf:	48 39 c5             	cmp    rbp,rax
    bcd2:	c5 f3 58 c8          	vaddsd xmm1,xmm1,xmm0
    bcd6:	75 e8                	jne    bcc0 <try_secant_tail.constprop.0+0x1420>
    bcd8:	31 c0                	xor    eax,eax
    bcda:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    bce0:	c5 fb 10 04 03       	vmovsd xmm0,QWORD PTR [rbx+rax*1]
    bce5:	c4 c2 f1 ad 04 06    	vfnmadd213sd xmm0,xmm1,QWORD PTR [r14+rax*1]
    bceb:	c4 c1 7b 11 04 06    	vmovsd QWORD PTR [r14+rax*1],xmm0
    bcf1:	48 83 c0 08          	add    rax,0x8
    bcf5:	48 39 c5             	cmp    rbp,rax
    bcf8:	75 e6                	jne    bce0 <try_secant_tail.constprop.0+0x1440>
    bcfa:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    bcfe:	4c 89 f7             	mov    rdi,r14
    bd01:	e8 ea 43 ff ff       	call   f0 <norm2>
    bd06:	c5 f9 2f f0          	vcomisd xmm6,xmm0
    bd0a:	77 3b                	ja     bd47 <try_secant_tail.constprop.0+0x14a7>
    bd0c:	c5 fb 10 6c 24 20    	vmovsd xmm5,QWORD PTR [rsp+0x20]
    bd12:	4c 89 f0             	mov    rax,r14
    bd15:	c5 d3 5e c0          	vdivsd xmm0,xmm5,xmm0
    bd19:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    bd20:	c5 fb 59 08          	vmulsd xmm1,xmm0,QWORD PTR [rax]
    bd24:	48 83 c0 08          	add    rax,0x8
    bd28:	c5 fb 11 48 f8       	vmovsd QWORD PTR [rax-0x8],xmm1
    bd2d:	49 39 c4             	cmp    r12,rax
    bd30:	75 ee                	jne    bd20 <try_secant_tail.constprop.0+0x1480>
    bd32:	41 83 ed 01          	sub    r13d,0x1
    bd36:	0f 84 91 00 00 00    	je     bdcd <try_secant_tail.constprop.0+0x152d>
    bd3c:	49 01 ee             	add    r14,rbp
    bd3f:	49 01 ec             	add    r12,rbp
    bd42:	e9 5b ff ff ff       	jmp    bca2 <try_secant_tail.constprop.0+0x1402>
    bd47:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    bd4c:	4c 89 f7             	mov    rdi,r14
    bd4f:	4c 89 5c 24 70       	mov    QWORD PTR [rsp+0x70],r11
    bd54:	49 01 ee             	add    r14,rbp
    bd57:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    bd5e:	4c 89 8c 24 80 00 00 	mov    QWORD PTR [rsp+0x80],r9
    bd65:	00 
    bd66:	49 01 ec             	add    r12,rbp
    bd69:	4c 89 54 24 48       	mov    QWORD PTR [rsp+0x48],r10
    bd6e:	8d 14 c5 00 00 00 00 	lea    edx,[rax*8+0x0]
    bd75:	44 89 44 24 40       	mov    DWORD PTR [rsp+0x40],r8d
    bd7a:	29 c2                	sub    edx,eax
    bd7c:	c5 fb 11 74 24 08    	vmovsd QWORD PTR [rsp+0x8],xmm6
    bd82:	48 b8 03 ed 92 d1 32 	movabs rax,0xd1b54a32d192ed03
    bd89:	4a b5 d1 
    bd8c:	83 c2 0a             	add    edx,0xa
    bd8f:	44 29 ea             	sub    edx,r13d
    bd92:	48 63 d2             	movsxd rdx,edx
    bd95:	48 0f af d0          	imul   rdx,rax
    bd99:	48 03 94 24 e0 00 00 	add    rdx,QWORD PTR [rsp+0xe0]
    bda0:	00 
    bda1:	e8 9a 69 ff ff       	call   2740 <secant_refresh>
    bda6:	41 83 ed 01          	sub    r13d,0x1
    bdaa:	c5 fb 10 74 24 08    	vmovsd xmm6,QWORD PTR [rsp+0x8]
    bdb0:	44 8b 44 24 40       	mov    r8d,DWORD PTR [rsp+0x40]
    bdb5:	4c 8b 54 24 48       	mov    r10,QWORD PTR [rsp+0x48]
    bdba:	4c 8b 5c 24 70       	mov    r11,QWORD PTR [rsp+0x70]
    bdbf:	4c 8b 8c 24 80 00 00 	mov    r9,QWORD PTR [rsp+0x80]
    bdc6:	00 
    bdc7:	0f 85 c9 fe ff ff    	jne    bc96 <try_secant_tail.constprop.0+0x13f6>
    bdcd:	8b 84 24 24 01 00 00 	mov    eax,DWORD PTR [rsp+0x124]
    bdd4:	45 89 c4             	mov    r12d,r8d
    bdd7:	4d 89 de             	mov    r14,r11
    bdda:	4c 89 cb             	mov    rbx,r9
    bddd:	8b bc 24 2c 01 00 00 	mov    edi,DWORD PTR [rsp+0x12c]
    bde4:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    bde8:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    bdeb:	89 84 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],eax
    bdf2:	e9 f0 ef ff ff       	jmp    ade7 <try_secant_tail.constprop.0+0x547>
    bdf7:	85 d2                	test   edx,edx
    bdf9:	8d 4a 03             	lea    ecx,[rdx+0x3]
    bdfc:	44 8d 3c 85 00 00 00 	lea    r15d,[rax*4+0x0]
    be03:	00 
    be04:	0f 49 ca             	cmovns ecx,edx
    be07:	c1 f9 02             	sar    ecx,0x2
    be0a:	39 c8                	cmp    eax,ecx
    be0c:	44 0f 4f fa          	cmovg  r15d,edx
    be10:	e9 59 f7 ff ff       	jmp    b56e <try_secant_tail.constprop.0+0xcce>
    be15:	c5 fb 10 1d 00 00 00 	vmovsd xmm3,QWORD PTR [rip+0x0]        # be1d <try_secant_tail.constprop.0+0x157d>
    be1c:	00 
    be1d:	c5 fb 11 5c 24 20    	vmovsd QWORD PTR [rsp+0x20],xmm3
    be23:	c5 fb 11 9c 24 d8 00 	vmovsd QWORD PTR [rsp+0xd8],xmm3
    be2a:	00 00 
    be2c:	e9 66 ec ff ff       	jmp    aa97 <try_secant_tail.constprop.0+0x1f7>
    be31:	48 0f af ce          	imul   rcx,rsi
    be35:	48 8b bc 24 30 01 00 	mov    rdi,QWORD PTR [rsp+0x130]
    be3c:	00 
    be3d:	4c 89 54 24 70       	mov    QWORD PTR [rsp+0x70],r10
    be42:	44 89 5c 24 48       	mov    DWORD PTR [rsp+0x48],r11d
    be47:	4c 89 8c 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r9
    be4e:	00 
    be4f:	48 8d 34 cd 00 00 00 	lea    rsi,[rcx*8+0x0]
    be56:	00 
    be57:	c5 fb 11 9c 24 80 00 	vmovsd QWORD PTR [rsp+0x80],xmm3
    be5e:	00 00 
    be60:	c5 fb 11 a4 24 88 00 	vmovsd QWORD PTR [rsp+0x88],xmm4
    be67:	00 00 
    be69:	e8 00 00 00 00       	call   be6e <try_secant_tail.constprop.0+0x15ce>
    be6e:	44 8b 5c 24 48       	mov    r11d,DWORD PTR [rsp+0x48]
    be73:	4c 8b 54 24 70       	mov    r10,QWORD PTR [rsp+0x70]
    be78:	48 85 c0             	test   rax,rax
    be7b:	44 8b 84 24 24 01 00 	mov    r8d,DWORD PTR [rsp+0x124]
    be82:	00 
    be83:	48 89 c1             	mov    rcx,rax
    be86:	0f 84 05 f7 ff ff    	je     b591 <try_secant_tail.constprop.0+0xcf1>
    be8c:	44 89 d8             	mov    eax,r11d
    be8f:	4d 89 eb             	mov    r11,r13
    be92:	45 89 fd             	mov    r13d,r15d
    be95:	48 89 8c 24 30 01 00 	mov    QWORD PTR [rsp+0x130],rcx
    be9c:	00 
    be9d:	44 89 ac 24 28 01 00 	mov    DWORD PTR [rsp+0x128],r13d
    bea4:	00 
    bea5:	8b 7c 24 40          	mov    edi,DWORD PTR [rsp+0x40]
    bea9:	41 89 c7             	mov    r15d,eax
    beac:	db ac 24 50 01 00 00 	fld    TBYTE PTR [rsp+0x150]
    beb3:	4c 8b 8c 24 90 00 00 	mov    r9,QWORD PTR [rsp+0x90]
    beba:	00 
    bebb:	c5 fb 10 8c 24 b0 00 	vmovsd xmm1,QWORD PTR [rsp+0xb0]
    bec2:	00 00 
    bec4:	c5 fb 10 a4 24 88 00 	vmovsd xmm4,QWORD PTR [rsp+0x88]
    becb:	00 00 
    becd:	c5 fb 10 9c 24 80 00 	vmovsd xmm3,QWORD PTR [rsp+0x80]
    bed4:	00 00 
    bed6:	e9 28 fc ff ff       	jmp    bb03 <try_secant_tail.constprop.0+0x1263>
    bedb:	49 01 ee             	add    r14,rbp
    bede:	49 01 ec             	add    r12,rbp
    bee1:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    bee5:	4c 89 f7             	mov    rdi,r14
    bee8:	e8 03 42 ff ff       	call   f0 <norm2>
    beed:	c5 f9 2f f0          	vcomisd xmm6,xmm0
    bef1:	0f 87 50 fe ff ff    	ja     bd47 <try_secant_tail.constprop.0+0x14a7>
    bef7:	41 83 ed 01          	sub    r13d,0x1
    befb:	75 de                	jne    bedb <try_secant_tail.constprop.0+0x163b>
    befd:	e9 cb fe ff ff       	jmp    bdcd <try_secant_tail.constprop.0+0x152d>
    bf02:	d9 05 00 00 00 00    	fld    DWORD PTR [rip+0x0]        # bf08 <try_secant_tail.constprop.0+0x1668>
    bf08:	e9 7d fc ff ff       	jmp    bb8a <try_secant_tail.constprop.0+0x12ea>
    bf0d:	85 c0                	test   eax,eax
    bf0f:	0f 8e 93 02 00 00    	jle    c1a8 <try_secant_tail.constprop.0+0x1908>
    bf15:	4c 63 c8             	movsxd r9,eax
    bf18:	48 89 d6             	mov    rsi,rdx
    bf1b:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    bf1f:	4e 8d 0c ca          	lea    r9,[rdx+r9*8]
    bf23:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    bf2a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    bf31:	00 00 00 00 
    bf35:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    bf3c:	00 00 00 00 
    bf40:	c5 fb 10 06          	vmovsd xmm0,QWORD PTR [rsi]
    bf44:	48 83 c6 08          	add    rsi,0x8
    bf48:	49 39 f1             	cmp    r9,rsi
    bf4b:	c5 fb 59 c0          	vmulsd xmm0,xmm0,xmm0
    bf4f:	c5 eb 58 d0          	vaddsd xmm2,xmm2,xmm0
    bf53:	75 eb                	jne    bf40 <try_secant_tail.constprop.0+0x16a0>
    bf55:	c5 eb 5c 64 24 20    	vsubsd xmm4,xmm2,QWORD PTR [rsp+0x20]
    bf5b:	c5 fb 11 64 24 18    	vmovsd QWORD PTR [rsp+0x18],xmm4
    bf61:	dd 44 24 18          	fld    QWORD PTR [rsp+0x18]
    bf65:	d8 c8                	fmul   st,st(0)
    bf67:	45 85 c0             	test   r8d,r8d
    bf6a:	7e 66                	jle    bfd2 <try_secant_tail.constprop.0+0x1732>
    bf6c:	85 c0                	test   eax,eax
    bf6e:	7e 62                	jle    bfd2 <try_secant_tail.constprop.0+0x1732>
    bf70:	4c 8d 0c c5 00 00 00 	lea    r9,[rax*8+0x0]
    bf77:	00 
    bf78:	48 89 ce             	mov    rsi,rcx
    bf7b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    bf80:	31 c0                	xor    eax,eax
    bf82:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    bf86:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
    bf8a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    bf91:	00 00 00 00 
    bf95:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    bf9c:	00 00 00 00 
    bfa0:	c5 fb 10 04 02       	vmovsd xmm0,QWORD PTR [rdx+rax*1]
    bfa5:	c5 fb 59 04 06       	vmulsd xmm0,xmm0,QWORD PTR [rsi+rax*1]
    bfaa:	48 83 c0 08          	add    rax,0x8
    bfae:	49 39 c1             	cmp    r9,rax
    bfb1:	c5 eb 58 d0          	vaddsd xmm2,xmm2,xmm0
    bfb5:	75 e9                	jne    bfa0 <try_secant_tail.constprop.0+0x1700>
    bfb7:	c5 fb 11 54 24 18    	vmovsd QWORD PTR [rsp+0x18],xmm2
    bfbd:	dd 44 24 18          	fld    QWORD PTR [rsp+0x18]
    bfc1:	83 c7 01             	add    edi,0x1
    bfc4:	4c 01 ce             	add    rsi,r9
    bfc7:	44 39 c7             	cmp    edi,r8d
    bfca:	d8 c8                	fmul   st,st(0)
    bfcc:	d8 c0                	fadd   st,st(0)
    bfce:	de c1                	faddp  st(1),st
    bfd0:	75 ae                	jne    bf80 <try_secant_tail.constprop.0+0x16e0>
    bfd2:	de c1                	faddp  st(1),st
    bfd4:	e9 00 fc ff ff       	jmp    bbd9 <try_secant_tail.constprop.0+0x1339>
    bfd9:	44 89 44 24 08       	mov    DWORD PTR [rsp+0x8],r8d
    bfde:	48 8d b4 24 60 01 00 	lea    rsi,[rsp+0x160]
    bfe5:	00 
    bfe6:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    bfeb:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    bfef:	e8 00 00 00 00       	call   bff4 <try_secant_tail.constprop.0+0x1754>
    bff4:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    bff9:	e8 00 00 00 00       	call   bffe <try_secant_tail.constprop.0+0x175e>
    bffe:	48 8b bc 24 a0 00 00 	mov    rdi,QWORD PTR [rsp+0xa0]
    c005:	00 
    c006:	e8 00 00 00 00       	call   c00b <try_secant_tail.constprop.0+0x176b>
    c00b:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    c00f:	e9 9c f6 ff ff       	jmp    b6b0 <try_secant_tail.constprop.0+0xe10>
    c014:	48 8b bc 24 30 01 00 	mov    rdi,QWORD PTR [rsp+0x130]
    c01b:	00 
    c01c:	e8 00 00 00 00       	call   c021 <try_secant_tail.constprop.0+0x1781>
    c021:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    c028:	00 
    c029:	e8 00 00 00 00       	call   c02e <try_secant_tail.constprop.0+0x178e>
    c02e:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    c035:	00 
    c036:	e8 00 00 00 00       	call   c03b <try_secant_tail.constprop.0+0x179b>
    c03b:	4c 89 f7             	mov    rdi,r14
    c03e:	e8 00 00 00 00       	call   c043 <try_secant_tail.constprop.0+0x17a3>
    c043:	48 89 df             	mov    rdi,rbx
    c046:	e8 00 00 00 00       	call   c04b <try_secant_tail.constprop.0+0x17ab>
    c04b:	e9 e0 f9 ff ff       	jmp    ba30 <try_secant_tail.constprop.0+0x1190>
    c050:	dd 05 00 00 00 00    	fld    QWORD PTR [rip+0x0]        # c056 <try_secant_tail.constprop.0+0x17b6>
    c056:	d9 ca                	fxch   st(2)
    c058:	e9 78 fb ff ff       	jmp    bbd5 <try_secant_tail.constprop.0+0x1335>
    c05d:	c5 fb 10 15 00 00 00 	vmovsd xmm2,QWORD PTR [rip+0x0]        # c065 <try_secant_tail.constprop.0+0x17c5>
    c064:	00 
    c065:	e9 0b ef ff ff       	jmp    af75 <try_secant_tail.constprop.0+0x6d5>
    c06a:	dd d8                	fstp   st(0)
    c06c:	d9 e8                	fld1
    c06e:	d9 c9                	fxch   st(1)
    c070:	e9 0b f7 ff ff       	jmp    b780 <try_secant_tail.constprop.0+0xee0>
    c075:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    c07a:	e8 00 00 00 00       	call   c07f <try_secant_tail.constprop.0+0x17df>
    c07f:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    c084:	e8 00 00 00 00       	call   c089 <try_secant_tail.constprop.0+0x17e9>
    c089:	48 8b bc 24 a0 00 00 	mov    rdi,QWORD PTR [rsp+0xa0]
    c090:	00 
    c091:	e8 00 00 00 00       	call   c096 <try_secant_tail.constprop.0+0x17f6>
    c096:	44 8b 7c 24 10       	mov    r15d,DWORD PTR [rsp+0x10]
    c09b:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # c0a3 <try_secant_tail.constprop.0+0x1803>
    c0a2:	00 
    c0a3:	4c 8d 8c 24 60 01 00 	lea    r9,[rsp+0x160]
    c0aa:	00 
    c0ab:	8b 4c 24 14          	mov    ecx,DWORD PTR [rsp+0x14]
    c0af:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    c0b4:	48 8b 94 24 38 01 00 	mov    rdx,QWORD PTR [rsp+0x138]
    c0bb:	00 
    c0bc:	48 8b 74 24 30       	mov    rsi,QWORD PTR [rsp+0x30]
    c0c1:	45 89 f8             	mov    r8d,r15d
    c0c4:	e8 87 45 ff ff       	call   650 <compat_scan_fused>
    c0c9:	48 8b 8c 24 00 01 00 	mov    rcx,QWORD PTR [rsp+0x100]
    c0d0:	00 
    c0d1:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    c0d8:	00 
    c0d9:	c5 fb 10 84 24 60 01 	vmovsd xmm0,QWORD PTR [rsp+0x160]
    c0e0:	00 00 
    c0e2:	83 f8 01             	cmp    eax,0x1
    c0e5:	19 c0                	sbb    eax,eax
    c0e7:	44 89 7f 04          	mov    DWORD PTR [rdi+0x4],r15d
    c0eb:	83 e0 fe             	and    eax,0xfffffffe
    c0ee:	c5 fb 11 47 18       	vmovsd QWORD PTR [rdi+0x18],xmm0
    c0f3:	83 c0 03             	add    eax,0x3
    c0f6:	48 85 c9             	test   rcx,rcx
    c0f9:	89 07                	mov    DWORD PTR [rdi],eax
    c0fb:	0f 84 ca 00 00 00    	je     c1cb <try_secant_tail.constprop.0+0x192b>
    c101:	45 85 ff             	test   r15d,r15d
    c104:	0f 8e bb 00 00 00    	jle    c1c5 <try_secant_tail.constprop.0+0x1925>
    c10a:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    c10e:	48 8b 94 24 38 01 00 	mov    rdx,QWORD PTR [rsp+0x138]
    c115:	00 
    c116:	31 c0                	xor    eax,eax
    c118:	c5 f9 28 ca          	vmovapd xmm1,xmm2
    c11c:	c5 fb 10 1c 01       	vmovsd xmm3,QWORD PTR [rcx+rax*1]
    c121:	c5 fb 10 04 02       	vmovsd xmm0,QWORD PTR [rdx+rax*1]
    c126:	48 83 c0 08          	add    rax,0x8
    c12a:	48 39 c5             	cmp    rbp,rax
    c12d:	c5 fb 5c c3          	vsubsd xmm0,xmm0,xmm3
    c131:	c4 e2 e1 b9 d3       	vfmadd231sd xmm2,xmm3,xmm3
    c136:	c4 e2 f9 b9 c8       	vfmadd231sd xmm1,xmm0,xmm0
    c13b:	75 df                	jne    c11c <try_secant_tail.constprop.0+0x187c>
    c13d:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
    c141:	c5 eb 51 d2          	vsqrtsd xmm2,xmm2,xmm2
    c145:	c5 eb 58 15 00 00 00 	vaddsd xmm2,xmm2,QWORD PTR [rip+0x0]        # c14d <try_secant_tail.constprop.0+0x18ad>
    c14c:	00 
    c14d:	c5 f3 5e ca          	vdivsd xmm1,xmm1,xmm2
    c151:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    c158:	00 
    c159:	c7 40 0c 00 00 00 00 	mov    DWORD PTR [rax+0xc],0x0
    c160:	c5 fb 11 48 20       	vmovsd QWORD PTR [rax+0x20],xmm1
    c165:	e9 96 f6 ff ff       	jmp    b800 <try_secant_tail.constprop.0+0xf60>
    c16a:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    c16f:	e9 72 fe ff ff       	jmp    bfe6 <try_secant_tail.constprop.0+0x1746>
    c174:	c7 84 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],0x1
    c17b:	01 00 00 00 
    c17f:	e9 03 f5 ff ff       	jmp    b687 <try_secant_tail.constprop.0+0xde7>
    c184:	44 8b 44 24 40       	mov    r8d,DWORD PTR [rsp+0x40]
    c189:	e9 6b ec ff ff       	jmp    adf9 <try_secant_tail.constprop.0+0x559>
    c18e:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    c192:	e9 de ed ff ff       	jmp    af75 <try_secant_tail.constprop.0+0x6d5>
    c197:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    c19b:	48 8d b4 24 60 01 00 	lea    rsi,[rsp+0x160]
    c1a2:	00 
    c1a3:	e9 3e fe ff ff       	jmp    bfe6 <try_secant_tail.constprop.0+0x1746>
    c1a8:	d9 e8                	fld1
    c1aa:	e9 b8 fd ff ff       	jmp    bf67 <try_secant_tail.constprop.0+0x16c7>
    c1af:	c5 fb 10 15 00 00 00 	vmovsd xmm2,QWORD PTR [rip+0x0]        # c1b7 <try_secant_tail.constprop.0+0x1917>
    c1b6:	00 
    c1b7:	e9 37 f6 ff ff       	jmp    b7f3 <try_secant_tail.constprop.0+0xf53>
    c1bc:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    c1c0:	e9 2e f6 ff ff       	jmp    b7f3 <try_secant_tail.constprop.0+0xf53>
    c1c5:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
    c1c9:	eb 86                	jmp    c151 <try_secant_tail.constprop.0+0x18b1>
    c1cb:	c5 fb 10 0d 00 00 00 	vmovsd xmm1,QWORD PTR [rip+0x0]        # c1d3 <try_secant_tail.constprop.0+0x1933>
    c1d2:	00 
    c1d3:	e9 79 ff ff ff       	jmp    c151 <try_secant_tail.constprop.0+0x18b1>
    c1d8:	44 89 44 24 08       	mov    DWORD PTR [rsp+0x8],r8d
    c1dd:	e9 67 ee ff ff       	jmp    b049 <try_secant_tail.constprop.0+0x7a9>
    c1e2:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    c1e7:	e8 00 00 00 00       	call   c1ec <try_secant_tail.constprop.0+0x194c>
    c1ec:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    c1f1:	e8 00 00 00 00       	call   c1f6 <try_secant_tail.constprop.0+0x1956>
    c1f6:	48 8b bc 24 a0 00 00 	mov    rdi,QWORD PTR [rsp+0xa0]
    c1fd:	00 
    c1fe:	e8 00 00 00 00       	call   c203 <try_secant_tail.constprop.0+0x1963>
    c203:	4c 89 f7             	mov    rdi,r14
    c206:	e8 00 00 00 00       	call   c20b <try_secant_tail.constprop.0+0x196b>
    c20b:	48 89 df             	mov    rdi,rbx
    c20e:	e8 00 00 00 00       	call   c213 <try_secant_tail.constprop.0+0x1973>
    c213:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    c218:	e8 b3 3e ff ff       	call   d0 <bs_free>
    c21d:	e9 f1 e6 ff ff       	jmp    a913 <try_secant_tail.constprop.0+0x73>
    c222:	48 8d b4 24 60 01 00 	lea    rsi,[rsp+0x160]
    c229:	00 
    c22a:	e9 81 f4 ff ff       	jmp    b6b0 <try_secant_tail.constprop.0+0xe10>
    c22f:	e8 00 00 00 00       	call   c234 <try_secant_tail.constprop.0+0x1994>
