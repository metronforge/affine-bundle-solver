/tmp/abs-stage2b-measured-control/trace.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000021d80 <abs_tail_replay>:
   21d80:	f3 0f 1e fa          	endbr64
   21d84:	53                   	push   rbx
   21d85:	48 83 ec 38          	sub    rsp,0x38
   21d89:	64 48 8b 1c 25 28 00 	mov    rbx,QWORD PTR fs:0x28
   21d90:	00 00 
   21d92:	48 89 5c 24 30       	mov    QWORD PTR [rsp+0x30],rbx
   21d97:	48 8b 5c 24 50       	mov    rbx,QWORD PTR [rsp+0x50]
   21d9c:	48 8d 44 24 08       	lea    rax,[rsp+0x8]
   21da1:	48 c7 44 24 08 00 00 	mov    QWORD PTR [rsp+0x8],0x0
   21da8:	00 00 
   21daa:	48 c7 44 24 10 00 00 	mov    QWORD PTR [rsp+0x10],0x0
   21db1:	00 00 
   21db3:	48 c7 44 24 18 00 00 	mov    QWORD PTR [rsp+0x18],0x0
   21dba:	00 00 
   21dbc:	48 c7 44 24 20 00 00 	mov    QWORD PTR [rsp+0x20],0x0
   21dc3:	00 00 
   21dc5:	48 c7 44 24 28 00 00 	mov    QWORD PTR [rsp+0x28],0x0
   21dcc:	00 00 
   21dce:	50                   	push   rax
   21dcf:	ff 74 24 50          	push   QWORD PTR [rsp+0x50]
   21dd3:	41 51                	push   r9
   21dd5:	45 89 c1             	mov    r9d,r8d
   21dd8:	41 89 c8             	mov    r8d,ecx
   21ddb:	89 d1                	mov    ecx,edx
   21ddd:	31 d2                	xor    edx,edx
   21ddf:	e8 1c a6 fe ff       	call   c400 <try_secant_tail.constprop.0>
   21de4:	c5 f8 57 c0          	vxorps xmm0,xmm0,xmm0
   21de8:	c5 fb 2a 4c 24 20    	vcvtsi2sd xmm1,xmm0,DWORD PTR [rsp+0x20]
   21dee:	c5 f9 13 0b          	vmovlpd QWORD PTR [rbx],xmm1
   21df2:	c5 fb 2a 4c 24 24    	vcvtsi2sd xmm1,xmm0,DWORD PTR [rsp+0x24]
   21df8:	c5 f9 13 4b 08       	vmovlpd QWORD PTR [rbx+0x8],xmm1
   21dfd:	c5 fb 2a 4c 24 28    	vcvtsi2sd xmm1,xmm0,DWORD PTR [rsp+0x28]
   21e03:	c5 f9 13 4b 10       	vmovlpd QWORD PTR [rbx+0x10],xmm1
   21e08:	c5 fb 2a 4c 24 2c    	vcvtsi2sd xmm1,xmm0,DWORD PTR [rsp+0x2c]
   21e0e:	c5 fb 2a c0          	vcvtsi2sd xmm0,xmm0,eax
   21e12:	c5 f9 13 4b 18       	vmovlpd QWORD PTR [rbx+0x18],xmm1
   21e17:	c5 fb 10 4c 24 30    	vmovsd xmm1,QWORD PTR [rsp+0x30]
   21e1d:	c5 f9 13 43 38       	vmovlpd QWORD PTR [rbx+0x38],xmm0
   21e22:	c5 fb 11 4b 20       	vmovsd QWORD PTR [rbx+0x20],xmm1
   21e27:	c5 fb 10 4c 24 38    	vmovsd xmm1,QWORD PTR [rsp+0x38]
   21e2d:	c5 fb 11 4b 28       	vmovsd QWORD PTR [rbx+0x28],xmm1
   21e32:	c5 fb 10 4c 24 40    	vmovsd xmm1,QWORD PTR [rsp+0x40]
   21e38:	48 83 c4 20          	add    rsp,0x20
   21e3c:	c5 fb 11 4b 30       	vmovsd QWORD PTR [rbx+0x30],xmm1
   21e41:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   21e46:	64 48 2b 04 25 28 00 	sub    rax,QWORD PTR fs:0x28
   21e4d:	00 00 
   21e4f:	75 06                	jne    21e57 <abs_tail_replay+0xd7>
   21e51:	48 83 c4 30          	add    rsp,0x30
   21e55:	5b                   	pop    rbx
   21e56:	c3                   	ret
   21e57:	e8 00 00 00 00       	call   21e5c <abs_tail_replay+0xdc>
