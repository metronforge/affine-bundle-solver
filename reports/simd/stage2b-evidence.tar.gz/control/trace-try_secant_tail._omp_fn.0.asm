/tmp/abs-stage2b-measured-control/trace.o:     file format elf64-x86-64


Disassembly of section .text:

00000000000032b0 <try_secant_tail._omp_fn.0>:
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	41 57                	push   r15
    32b6:	41 56                	push   r14
    32b8:	49 89 fe             	mov    r14,rdi
    32bb:	41 55                	push   r13
    32bd:	41 54                	push   r12
    32bf:	55                   	push   rbp
    32c0:	53                   	push   rbx
    32c1:	48 83 ec 38          	sub    rsp,0x38
    32c5:	e8 00 00 00 00       	call   32ca <try_secant_tail._omp_fn.0+0x1a>
    32ca:	89 c3                	mov    ebx,eax
    32cc:	e8 00 00 00 00       	call   32d1 <try_secant_tail._omp_fn.0+0x21>
    32d1:	89 c1                	mov    ecx,eax
    32d3:	41 8b 46 60          	mov    eax,DWORD PTR [r14+0x60]
    32d7:	99                   	cdq
    32d8:	f7 f9                	idiv   ecx
    32da:	39 d3                	cmp    ebx,edx
    32dc:	8d 48 01             	lea    ecx,[rax+0x1]
    32df:	0f 4c c1             	cmovl  eax,ecx
    32e2:	b9 00 00 00 00       	mov    ecx,0x0
    32e7:	0f 4c d1             	cmovl  edx,ecx
    32ea:	89 c1                	mov    ecx,eax
    32ec:	0f af cb             	imul   ecx,ebx
    32ef:	01 ca                	add    edx,ecx
    32f1:	8d 0c 10             	lea    ecx,[rax+rdx*1]
    32f4:	39 ca                	cmp    edx,ecx
    32f6:	0f 8d 34 03 00 00    	jge    3630 <try_secant_tail._omp_fn.0+0x380>
    32fc:	48 63 f3             	movsxd rsi,ebx
    32ff:	4d 8b 66 40          	mov    r12,QWORD PTR [r14+0x40]
    3303:	4d 63 46 5c          	movsxd r8,DWORD PTR [r14+0x5c]
    3307:	89 c0                	mov    eax,eax
    3309:	48 89 f3             	mov    rbx,rsi
    330c:	48 c1 e6 04          	shl    rsi,0x4
    3310:	49 03 76 50          	add    rsi,QWORD PTR [r14+0x50]
    3314:	4d 63 4e 58          	movsxd r9,DWORD PTR [r14+0x58]
    3318:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    331d:	48 63 f2             	movsxd rsi,edx
    3320:	4c 89 c1             	mov    rcx,r8
    3323:	4d 8b 56 28          	mov    r10,QWORD PTR [r14+0x28]
    3327:	49 01 f4             	add    r12,rsi
    332a:	49 0f af d9          	imul   rbx,r9
    332e:	49 01 f0             	add    r8,rsi
    3331:	c4 41 7b 10 5e 30    	vmovsd xmm11,QWORD PTR [r14+0x30]
    3337:	4c 01 e0             	add    rax,r12
    333a:	49 8b 76 08          	mov    rsi,QWORD PTR [r14+0x8]
    333e:	44 89 4c 24 10       	mov    DWORD PTR [rsp+0x10],r9d
    3343:	49 c1 e1 03          	shl    r9,0x3
    3347:	48 89 04 24          	mov    QWORD PTR [rsp],rax
    334b:	8d 44 11 01          	lea    eax,[rcx+rdx*1+0x1]
    334f:	c5 7b 10 05 00 00 00 	vmovsd xmm8,QWORD PTR [rip+0x0]        # 3357 <try_secant_tail._omp_fn.0+0xa7>
    3356:	00 
    3357:	c4 41 18 57 e4       	vxorps xmm12,xmm12,xmm12
    335c:	44 29 e0             	sub    eax,r12d
    335f:	c4 c1 3b 58 66 38    	vaddsd xmm4,xmm8,QWORD PTR [r14+0x38]
    3365:	48 c1 e3 04          	shl    rbx,0x4
    3369:	c4 c1 7b 10 7e 10    	vmovsd xmm7,QWORD PTR [r14+0x10]
    336f:	89 44 24 14          	mov    DWORD PTR [rsp+0x14],eax
    3373:	49 03 5e 48          	add    rbx,QWORD PTR [r14+0x48]
    3377:	4e 8d 2c c6          	lea    r13,[rsi+r8*8]
    337b:	4f 8d 1c 0a          	lea    r11,[r10+r9*1]
    337f:	c5 7b 10 15 00 00 00 	vmovsd xmm10,QWORD PTR [rip+0x0]        # 3387 <try_secant_tail._omp_fn.0+0xd7>
    3386:	00 
    3387:	c5 7b 10 0d 00 00 00 	vmovsd xmm9,QWORD PTR [rip+0x0]        # 338f <try_secant_tail._omp_fn.0+0xdf>
    338e:	00 
    338f:	4d 0f af c1          	imul   r8,r9
    3393:	48 b8 15 7c 4a 7f b9 	movabs rax,0x9e3779b97f4a7c15
    339a:	79 37 9e 
    339d:	49 03 46 18          	add    rax,QWORD PTR [r14+0x18]
    33a1:	4d 03 06             	add    r8,QWORD PTR [r14]
    33a4:	4a 8d 2c 0b          	lea    rbp,[rbx+r9*1]
    33a8:	c5 fb 11 64 24 28    	vmovsd QWORD PTR [rsp+0x28],xmm4
    33ae:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
    33b3:	c5 7b 11 5c 24 20    	vmovsd QWORD PTR [rsp+0x20],xmm11
    33b9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    33c0:	8b 54 24 10          	mov    edx,DWORD PTR [rsp+0x10]
    33c4:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
    33c8:	c5 79 28 fe          	vmovapd xmm15,xmm6
    33cc:	c5 79 28 ee          	vmovapd xmm13,xmm6
    33d0:	85 d2                	test   edx,edx
    33d2:	0f 8e 70 02 00 00    	jle    3648 <try_secant_tail._omp_fn.0+0x398>
    33d8:	49 8b 46 20          	mov    rax,QWORD PTR [r14+0x20]
    33dc:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
    33e0:	c5 79 28 fe          	vmovapd xmm15,xmm6
    33e4:	c5 79 28 ee          	vmovapd xmm13,xmm6
    33e8:	c5 f9 28 c6          	vmovapd xmm0,xmm6
    33ec:	48 8b 50 18          	mov    rdx,QWORD PTR [rax+0x18]
    33f0:	31 c0                	xor    eax,eax
    33f2:	0f 1f 00             	nop    DWORD PTR [rax]
    33f5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    33fc:	00 00 00 00 
    3400:	c4 c1 7b 10 14 00    	vmovsd xmm2,QWORD PTR [r8+rax*1]
    3406:	c4 62 e9 b9 2c 02    	vfmadd231sd xmm13,xmm2,QWORD PTR [rdx+rax*1]
    340c:	c4 42 e9 b9 3c 02    	vfmadd231sd xmm15,xmm2,QWORD PTR [r10+rax*1]
    3412:	c4 c2 e9 b9 34 03    	vfmadd231sd xmm6,xmm2,QWORD PTR [r11+rax*1]
    3418:	48 83 c0 08          	add    rax,0x8
    341c:	49 39 c1             	cmp    r9,rax
    341f:	c4 e2 e9 b9 c2       	vfmadd231sd xmm0,xmm2,xmm2
    3424:	75 da                	jne    3400 <try_secant_tail._omp_fn.0+0x150>
    3426:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    342a:	c5 f9 2f c2          	vcomisd xmm0,xmm2
    342e:	0f 86 14 02 00 00    	jbe    3648 <try_secant_tail._omp_fn.0+0x398>
    3434:	48 b8 00 00 00 00 00 	movabs rax,0x7ff0000000000000
    343b:	00 f0 7f 
    343e:	c4 e1 f9 7e c7       	vmovq  rdi,xmm0
    3443:	c4 e2 c0 f2 c0       	andn   rax,rdi,rax
    3448:	0f 84 fa 01 00 00    	je     3648 <try_secant_tail._omp_fn.0+0x398>
    344e:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
    3452:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    3456:	c5 bb 5e c0          	vdivsd xmm0,xmm8,xmm0
    345a:	c5 fb 10 6c 24 20    	vmovsd xmm5,QWORD PTR [rsp+0x20]
    3460:	48 be eb 11 31 13 bb 	movabs rsi,0x94d049bb133111eb
    3467:	49 d0 94 
    346a:	48 bf b9 e5 e4 1c 6d 	movabs rdi,0xbf58476d1ce4e5b9
    3471:	47 58 bf 
    3474:	44 01 e0             	add    eax,r12d
    3477:	48 98                	cdqe
    3479:	48 89 c1             	mov    rcx,rax
    347c:	48 0f af ce          	imul   rcx,rsi
    3480:	48 03 4c 24 18       	add    rcx,QWORD PTR [rsp+0x18]
    3485:	49 89 cf             	mov    r15,rcx
    3488:	49 c1 ef 1e          	shr    r15,0x1e
    348c:	49 31 cf             	xor    r15,rcx
    348f:	4c 0f af ff          	imul   r15,rdi
    3493:	4c 89 fa             	mov    rdx,r15
    3496:	48 c1 ea 1b          	shr    rdx,0x1b
    349a:	4c 31 fa             	xor    rdx,r15
    349d:	48 0f af d6          	imul   rdx,rsi
    34a1:	49 89 d7             	mov    r15,rdx
    34a4:	49 c1 ef 1f          	shr    r15,0x1f
    34a8:	49 31 d7             	xor    r15,rdx
    34ab:	48 ba ce d3 b3 09 b2 	movabs rdx,0x2a87fdb209b3d3ce
    34b2:	fd 87 2a 
    34b5:	48 0f af c2          	imul   rax,rdx
    34b9:	49 c1 ef 0b          	shr    r15,0xb
    34bd:	c4 c1 9b 2a df       	vcvtsi2sd xmm3,xmm12,r15
    34c2:	c4 c2 b1 99 da       	vfmadd132sd xmm3,xmm9,xmm10
    34c7:	c4 c1 7b 59 55 00    	vmulsd xmm2,xmm0,QWORD PTR [r13+0x0]
    34cd:	48 01 c8             	add    rax,rcx
    34d0:	48 89 c2             	mov    rdx,rax
    34d3:	48 c1 ea 1e          	shr    rdx,0x1e
    34d7:	c5 e3 59 dd          	vmulsd xmm3,xmm3,xmm5
    34db:	48 31 c2             	xor    rdx,rax
    34de:	48 0f af d7          	imul   rdx,rdi
    34e2:	48 89 d0             	mov    rax,rdx
    34e5:	48 c1 e8 1b          	shr    rax,0x1b
    34e9:	48 31 c2             	xor    rdx,rax
    34ec:	48 0f af d6          	imul   rdx,rsi
    34f0:	48 89 d0             	mov    rax,rdx
    34f3:	48 c1 e8 1f          	shr    rax,0x1f
    34f7:	48 31 c2             	xor    rdx,rax
    34fa:	48 c1 ea 0b          	shr    rdx,0xb
    34fe:	c4 e1 9b 2a e2       	vcvtsi2sd xmm4,xmm12,rdx
    3503:	c4 c2 b1 99 e2       	vfmadd132sd xmm4,xmm9,xmm10
    3508:	48 8b 15 00 00 00 00 	mov    rdx,QWORD PTR [rip+0x0]        # 350f <try_secant_tail._omp_fn.0+0x25f>
    350f:	c5 db 59 e5          	vmulsd xmm4,xmm4,xmm5
    3513:	c4 e1 f9 6e ca       	vmovq  xmm1,rdx
    3518:	48 89 d0             	mov    rax,rdx
    351b:	c5 bb 58 c9          	vaddsd xmm1,xmm8,xmm1
    351f:	c4 e1 f9 7e c9       	vmovq  rcx,xmm1
    3524:	f0 48 0f b1 0d 00 00 	lock cmpxchg QWORD PTR [rip+0x0],rcx        # 352d <try_secant_tail._omp_fn.0+0x27d>
    352b:	00 00 
    352d:	0f 85 4a 01 00 00    	jne    367d <try_secant_tail._omp_fn.0+0x3cd>
    3533:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    3537:	85 c0                	test   eax,eax
    3539:	7e 70                	jle    35ab <try_secant_tail._omp_fn.0+0x2fb>
    353b:	c5 7b 59 db          	vmulsd xmm11,xmm0,xmm3
    353f:	31 c0                	xor    eax,eax
    3541:	c5 7b 59 f4          	vmulsd xmm14,xmm0,xmm4
    3545:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
    3549:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    3550:	00 00 00 00 
    3554:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    355b:	00 00 00 00 
    355f:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    3566:	00 00 00 00 
    356a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    3571:	00 00 00 00 
    3575:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    357c:	00 00 00 00 
    3580:	c4 c1 7b 10 0c 00    	vmovsd xmm1,QWORD PTR [r8+rax*1]
    3586:	c5 79 29 dd          	vmovapd xmm5,xmm11
    358a:	c4 e2 f1 a9 2c 03    	vfmadd213sd xmm5,xmm1,QWORD PTR [rbx+rax*1]
    3590:	c5 fb 11 2c 03       	vmovsd QWORD PTR [rbx+rax*1],xmm5
    3595:	c4 e2 89 a9 4c 05 00 	vfmadd213sd xmm1,xmm14,QWORD PTR [rbp+rax*1+0x0]
    359c:	c5 fb 11 4c 05 00    	vmovsd QWORD PTR [rbp+rax*1+0x0],xmm1
    35a2:	48 83 c0 08          	add    rax,0x8
    35a6:	49 39 c1             	cmp    r9,rax
    35a9:	75 d5                	jne    3580 <try_secant_tail._omp_fn.0+0x2d0>
    35ab:	c5 c9 54 35 00 00 00 	vandpd xmm6,xmm6,XMMWORD PTR [rip+0x0]        # 35b3 <try_secant_tail._omp_fn.0+0x303>
    35b2:	00 
    35b3:	c5 01 54 3d 00 00 00 	vandpd xmm15,xmm15,XMMWORD PTR [rip+0x0]        # 35bb <try_secant_tail._omp_fn.0+0x30b>
    35ba:	00 
    35bb:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    35c0:	c4 c1 4b 5f f7       	vmaxsd xmm6,xmm6,xmm15
    35c5:	c4 e2 e9 a9 18       	vfmadd213sd xmm3,xmm2,QWORD PTR [rax]
    35ca:	c4 e2 e9 a9 60 08    	vfmadd213sd xmm4,xmm2,QWORD PTR [rax+0x8]
    35d0:	c5 cb 59 f0          	vmulsd xmm6,xmm6,xmm0
    35d4:	c5 f9 2f 35 00 00 00 	vcomisd xmm6,QWORD PTR [rip+0x0]        # 35dc <try_secant_tail._omp_fn.0+0x32c>
    35db:	00 
    35dc:	c5 fb 11 18          	vmovsd QWORD PTR [rax],xmm3
    35e0:	c5 fb 11 60 08       	vmovsd QWORD PTR [rax+0x8],xmm4
    35e5:	77 2f                	ja     3616 <try_secant_tail._omp_fn.0+0x366>
    35e7:	c5 e9 54 1d 00 00 00 	vandpd xmm3,xmm2,XMMWORD PTR [rip+0x0]        # 35ef <try_secant_tail._omp_fn.0+0x33f>
    35ee:	00 
    35ef:	c4 c1 7b 10 55 00    	vmovsd xmm2,QWORD PTR [r13+0x0]
    35f5:	c5 e3 58 5c 24 28    	vaddsd xmm3,xmm3,QWORD PTR [rsp+0x28]
    35fb:	c4 c1 6b 5c cd       	vsubsd xmm1,xmm2,xmm13
    3600:	c5 e3 59 df          	vmulsd xmm3,xmm3,xmm7
    3604:	c5 f3 59 c0          	vmulsd xmm0,xmm1,xmm0
    3608:	c5 f9 54 05 00 00 00 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x0]        # 3610 <try_secant_tail._omp_fn.0+0x360>
    360f:	00 
    3610:	c5 f9 2f c3          	vcomisd xmm0,xmm3
    3614:	76 05                	jbe    361b <try_secant_tail._omp_fn.0+0x36b>
    3616:	41 c6 04 24 01       	mov    BYTE PTR [r12],0x1
    361b:	49 83 c4 01          	add    r12,0x1
    361f:	49 83 c5 08          	add    r13,0x8
    3623:	4d 01 c8             	add    r8,r9
    3626:	4c 39 24 24          	cmp    QWORD PTR [rsp],r12
    362a:	0f 85 90 fd ff ff    	jne    33c0 <try_secant_tail._omp_fn.0+0x110>
    3630:	48 83 c4 38          	add    rsp,0x38
    3634:	5b                   	pop    rbx
    3635:	5d                   	pop    rbp
    3636:	41 5c                	pop    r12
    3638:	41 5d                	pop    r13
    363a:	41 5e                	pop    r14
    363c:	41 5f                	pop    r15
    363e:	e9 00 00 00 00       	jmp    3643 <try_secant_tail._omp_fn.0+0x393>
    3643:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    3648:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    364c:	4c 89 c7             	mov    rdi,r8
    364f:	e8 9c ca ff ff       	call   f0 <norm2>
    3654:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    3658:	c5 f9 2f c2          	vcomisd xmm0,xmm2
    365c:	0f 85 f0 fd ff ff    	jne    3452 <try_secant_tail._omp_fn.0+0x1a2>
    3662:	c4 c1 7b 10 45 00    	vmovsd xmm0,QWORD PTR [r13+0x0]
    3668:	c5 f9 54 05 00 00 00 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x0]        # 3670 <try_secant_tail._omp_fn.0+0x3c0>
    366f:	00 
    3670:	c5 f9 2f c7          	vcomisd xmm0,xmm7
    3674:	76 a5                	jbe    361b <try_secant_tail._omp_fn.0+0x36b>
    3676:	41 c6 04 24 01       	mov    BYTE PTR [r12],0x1
    367b:	eb 9e                	jmp    361b <try_secant_tail._omp_fn.0+0x36b>
    367d:	48 89 c2             	mov    rdx,rax
    3680:	e9 8e fe ff ff       	jmp    3513 <try_secant_tail._omp_fn.0+0x263>
