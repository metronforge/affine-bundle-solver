/tmp/abs-stage2b-measured-control/trace.o:     file format elf64-x86-64


Disassembly of section .text:

000000000000c400 <try_secant_tail.constprop.0>:
    c400:	41 57                	push   r15
    c402:	41 56                	push   r14
    c404:	41 55                	push   r13
    c406:	41 54                	push   r12
    c408:	55                   	push   rbp
    c409:	53                   	push   rbx
    c40a:	48 81 ec f8 01 00 00 	sub    rsp,0x1f8
    c411:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # c419 <try_secant_tail.constprop.0+0x19>
    c418:	00 
    c419:	c5 d3 58 05 00 00 00 	vaddsd xmm0,xmm5,QWORD PTR [rip+0x0]        # c421 <try_secant_tail.constprop.0+0x21>
    c420:	00 
    c421:	48 8b 84 24 40 02 00 	mov    rax,QWORD PTR [rsp+0x240]
    c428:	00 
    c429:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    c42e:	48 89 74 24 30       	mov    QWORD PTR [rsp+0x30],rsi
    c433:	48 8b ac 24 30 02 00 	mov    rbp,QWORD PTR [rsp+0x230]
    c43a:	00 
    c43b:	48 89 94 24 08 01 00 	mov    QWORD PTR [rsp+0x108],rdx
    c442:	00 
    c443:	89 4c 24 20          	mov    DWORD PTR [rsp+0x20],ecx
    c447:	44 89 44 24 0c       	mov    DWORD PTR [rsp+0xc],r8d
    c44c:	44 89 4c 24 10       	mov    DWORD PTR [rsp+0x10],r9d
    c451:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
    c458:	00 
    c459:	64 48 8b 04 25 28 00 	mov    rax,QWORD PTR fs:0x28
    c460:	00 00 
    c462:	48 89 84 24 e8 01 00 	mov    QWORD PTR [rsp+0x1e8],rax
    c469:	00 
    c46a:	31 c0                	xor    eax,eax
    c46c:	8b 05 00 00 00 00    	mov    eax,DWORD PTR [rip+0x0]        # c472 <try_secant_tail.constprop.0+0x72>
    c472:	c5 fb 11 05 00 00 00 	vmovsd QWORD PTR [rip+0x0],xmm0        # c47a <try_secant_tail.constprop.0+0x7a>
    c479:	00 
    c47a:	85 c0                	test   eax,eax
    c47c:	0f 85 64 15 00 00    	jne    d9e6 <try_secant_tail.constprop.0+0x15e6>
    c482:	48 89 ee             	mov    rsi,rbp
    c485:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # c48c <try_secant_tail.constprop.0+0x8c>
    c48c:	e8 cf aa ff ff       	call   6f60 <bs_copy>
    c491:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
    c495:	48 89 ee             	mov    rsi,rbp
    c498:	48 8d bc 24 20 01 00 	lea    rdi,[rsp+0x120]
    c49f:	00 
    c4a0:	83 f0 01             	xor    eax,0x1
    c4a3:	c5 db 2a 45 04       	vcvtsi2sd xmm0,xmm4,DWORD PTR [rbp+0x4]
    c4a8:	48 89 7c 24 58       	mov    QWORD PTR [rsp+0x58],rdi
    c4ad:	89 05 00 00 00 00    	mov    DWORD PTR [rip+0x0],eax        # c4b3 <try_secant_tail.constprop.0+0xb3>
    c4b3:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    c4b7:	c5 f9 13 05 00 00 00 	vmovlpd QWORD PTR [rip+0x0],xmm0        # c4bf <try_secant_tail.constprop.0+0xbf>
    c4be:	00 
    c4bf:	89 05 00 00 00 00    	mov    DWORD PTR [rip+0x0],eax        # c4c5 <try_secant_tail.constprop.0+0xc5>
    c4c5:	c5 db 2a c0          	vcvtsi2sd xmm0,xmm4,eax
    c4c9:	c5 f9 13 05 00 00 00 	vmovlpd QWORD PTR [rip+0x0],xmm0        # c4d1 <try_secant_tail.constprop.0+0xd1>
    c4d0:	00 
    c4d1:	e8 8a aa ff ff       	call   6f60 <bs_copy>
    c4d6:	85 c0                	test   eax,eax
    c4d8:	74 32                	je     c50c <try_secant_tail.constprop.0+0x10c>
    c4da:	41 bd ff ff ff ff    	mov    r13d,0xffffffff
    c4e0:	48 8b 84 24 e8 01 00 	mov    rax,QWORD PTR [rsp+0x1e8]
    c4e7:	00 
    c4e8:	64 48 2b 04 25 28 00 	sub    rax,QWORD PTR fs:0x28
    c4ef:	00 00 
    c4f1:	0f 85 c6 19 00 00    	jne    debd <try_secant_tail.constprop.0+0x1abd>
    c4f7:	48 81 c4 f8 01 00 00 	add    rsp,0x1f8
    c4fe:	44 89 e8             	mov    eax,r13d
    c501:	5b                   	pop    rbx
    c502:	5d                   	pop    rbp
    c503:	41 5c                	pop    r12
    c505:	41 5d                	pop    r13
    c507:	41 5e                	pop    r14
    c509:	41 5f                	pop    r15
    c50b:	c3                   	ret
    c50c:	48 63 5c 24 0c       	movsxd rbx,DWORD PTR [rsp+0xc]
    c511:	48 89 d8             	mov    rax,rbx
    c514:	48 89 5c 24 38       	mov    QWORD PTR [rsp+0x38],rbx
    c519:	48 c1 e0 04          	shl    rax,0x4
    c51d:	48 89 c7             	mov    rdi,rax
    c520:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
    c527:	00 
    c528:	e8 00 00 00 00       	call   c52d <try_secant_tail.constprop.0+0x12d>
    c52d:	48 8d 3c 1b          	lea    rdi,[rbx+rbx*1]
    c531:	be 08 00 00 00       	mov    esi,0x8
    c536:	49 89 c7             	mov    r15,rax
    c539:	e8 00 00 00 00       	call   c53e <try_secant_tail.constprop.0+0x13e>
    c53e:	4d 85 ff             	test   r15,r15
    c541:	48 89 c3             	mov    rbx,rax
    c544:	0f 84 2c 19 00 00    	je     de76 <try_secant_tail.constprop.0+0x1a76>
    c54a:	48 85 c0             	test   rax,rax
    c54d:	0f 84 23 19 00 00    	je     de76 <try_secant_tail.constprop.0+0x1a76>
    c553:	48 ba 15 7c 4a 7f b9 	movabs rdx,0x9e3779b97f4a7c15
    c55a:	79 37 9e 
    c55d:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
    c562:	4c 89 ff             	mov    rdi,r15
    c565:	48 b8 d0 31 9f 29 22 	movabs rax,0xa4093822299f31d0
    c56c:	38 09 a4 
    c56f:	48 33 84 24 38 02 00 	xor    rax,QWORD PTR [rsp+0x238]
    c576:	00 
    c577:	48 c7 84 24 d0 01 00 	mov    QWORD PTR [rsp+0x1d0],0x0
    c57e:	00 00 00 00 00 
    c583:	48 c7 84 24 d8 01 00 	mov    QWORD PTR [rsp+0x1d8],0x0
    c58a:	00 00 00 00 00 
    c58f:	48 01 d0             	add    rax,rdx
    c592:	48 89 c2             	mov    rdx,rax
    c595:	48 c1 ea 1e          	shr    rdx,0x1e
    c599:	48 31 c2             	xor    rdx,rax
    c59c:	48 b8 b9 e5 e4 1c 6d 	movabs rax,0xbf58476d1ce4e5b9
    c5a3:	47 58 bf 
    c5a6:	48 0f af d0          	imul   rdx,rax
    c5aa:	48 89 d0             	mov    rax,rdx
    c5ad:	48 c1 e8 1b          	shr    rax,0x1b
    c5b1:	48 31 d0             	xor    rax,rdx
    c5b4:	48 ba eb 11 31 13 bb 	movabs rdx,0x94d049bb133111eb
    c5bb:	49 d0 94 
    c5be:	48 0f af c2          	imul   rax,rdx
    c5c2:	48 89 c2             	mov    rdx,rax
    c5c5:	48 c1 ea 1f          	shr    rdx,0x1f
    c5c9:	48 31 c2             	xor    rdx,rax
    c5cc:	49 89 d5             	mov    r13,rdx
    c5cf:	48 89 94 24 18 01 00 	mov    QWORD PTR [rsp+0x118],rdx
    c5d6:	00 
    c5d7:	48 ba 03 ed 92 d1 32 	movabs rdx,0xd1b54a32d192ed03
    c5de:	4a b5 d1 
    c5e1:	4c 01 ea             	add    rdx,r13
    c5e4:	e8 57 61 ff ff       	call   2740 <secant_refresh>
    c5e9:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    c5ee:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
    c5f3:	48 ba 06 da 25 a3 65 	movabs rdx,0xa36a9465a325da06
    c5fa:	94 6a a3 
    c5fd:	4c 01 ea             	add    rdx,r13
    c600:	4c 8d 24 c5 00 00 00 	lea    r12,[rax*8+0x0]
    c607:	00 
    c608:	4f 8d 34 27          	lea    r14,[r15+r12*1]
    c60c:	4c 89 f7             	mov    rdi,r14
    c60f:	e8 2c 61 ff ff       	call   2740 <secant_refresh>
    c614:	e8 00 00 00 00       	call   c619 <try_secant_tail.constprop.0+0x219>
    c619:	48 8b 3d 00 00 00 00 	mov    rdi,QWORD PTR [rip+0x0]        # c620 <try_secant_tail.constprop.0+0x220>
    c620:	89 84 24 10 01 00 00 	mov    DWORD PTR [rsp+0x110],eax
    c627:	8b 45 04             	mov    eax,DWORD PTR [rbp+0x4]
    c62a:	48 89 bc 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rdi
    c631:	00 
    c632:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    c636:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    c63a:	2b 44 24 10          	sub    eax,DWORD PTR [rsp+0x10]
    c63e:	85 c0                	test   eax,eax
    c640:	7e 1e                	jle    c660 <try_secant_tail.constprop.0+0x260>
    c642:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
    c646:	c5 e3 2a c0          	vcvtsi2sd xmm0,xmm3,eax
    c64a:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
    c64e:	c4 e1 f9 6e df       	vmovq  xmm3,rdi
    c653:	c5 e3 5e e8          	vdivsd xmm5,xmm3,xmm0
    c657:	c5 fb 11 ac 24 b8 00 	vmovsd QWORD PTR [rsp+0xb8],xmm5
    c65e:	00 00 
    c660:	8b 74 24 0c          	mov    esi,DWORD PTR [rsp+0xc]
    c664:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    c66b:	00 
    c66c:	e8 7f 3a ff ff       	call   f0 <norm2>
    c671:	be 01 00 00 00       	mov    esi,0x1
    c676:	bf 00 08 00 00       	mov    edi,0x800
    c67b:	c5 fb 11 44 24 60    	vmovsd QWORD PTR [rsp+0x60],xmm0
    c681:	e8 00 00 00 00       	call   c686 <try_secant_tail.constprop.0+0x286>
    c686:	4c 8b 6c 24 38       	mov    r13,QWORD PTR [rsp+0x38]
    c68b:	be 08 00 00 00       	mov    esi,0x8
    c690:	48 63 ac 24 10 01 00 	movsxd rbp,DWORD PTR [rsp+0x110]
    c697:	00 
    c698:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
    c69d:	4c 0f af ed          	imul   r13,rbp
    c6a1:	4b 8d 7c 2d 00       	lea    rdi,[r13+r13*1+0x0]
    c6a6:	e8 00 00 00 00       	call   c6ab <try_secant_tail.constprop.0+0x2ab>
    c6ab:	48 8d 7c 2d 00       	lea    rdi,[rbp+rbp*1+0x0]
    c6b0:	be 08 00 00 00       	mov    esi,0x8
    c6b5:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    c6ba:	e8 00 00 00 00       	call   c6bf <try_secant_tail.constprop.0+0x2bf>
    c6bf:	48 83 7c 24 40 00    	cmp    QWORD PTR [rsp+0x40],0x0
    c6c5:	48 89 44 24 48       	mov    QWORD PTR [rsp+0x48],rax
    c6ca:	48 89 c1             	mov    rcx,rax
    c6cd:	0f 94 c0             	sete   al
    c6d0:	48 83 7c 24 50 00    	cmp    QWORD PTR [rsp+0x50],0x0
    c6d6:	0f 94 c2             	sete   dl
    c6d9:	08 d0                	or     al,dl
    c6db:	0f 85 77 17 00 00    	jne    de58 <try_secant_tail.constprop.0+0x1a58>
    c6e1:	48 85 c9             	test   rcx,rcx
    c6e4:	0f 84 6e 17 00 00    	je     de58 <try_secant_tail.constprop.0+0x1a58>
    c6ea:	48 8d 84 24 60 01 00 	lea    rax,[rsp+0x160]
    c6f1:	00 
    c6f2:	bf 01 00 00 00       	mov    edi,0x1
    c6f7:	48 89 c6             	mov    rsi,rax
    c6fa:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
    c701:	00 
    c702:	e8 00 00 00 00       	call   c707 <try_secant_tail.constprop.0+0x307>
    c707:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
    c70b:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    c70f:	c4 e1 e3 2a 8c 24 68 	vcvtsi2sd xmm1,xmm3,QWORD PTR [rsp+0x168]
    c716:	01 00 00 
    c719:	c4 e1 e3 2a 84 24 60 	vcvtsi2sd xmm0,xmm3,QWORD PTR [rsp+0x160]
    c720:	01 00 00 
    c723:	3b 74 24 20          	cmp    esi,DWORD PTR [rsp+0x20]
    c727:	c4 e2 f9 99 0d 00 00 	vfmadd132sd xmm1,xmm0,QWORD PTR [rip+0x0]        # c730 <try_secant_tail.constprop.0+0x330>
    c72e:	00 00 
    c730:	c5 fb 11 0d 00 00 00 	vmovsd QWORD PTR [rip+0x0],xmm1        # c738 <try_secant_tail.constprop.0+0x338>
    c737:	00 
    c738:	0f 8d c5 02 00 00    	jge    ca03 <try_secant_tail.constprop.0+0x603>
    c73e:	48 ba 15 7c 4a 7f b9 	movabs rdx,0x9e3779b97f4a7c15
    c745:	79 37 9e 
    c748:	8b 7c 24 0c          	mov    edi,DWORD PTR [rsp+0xc]
    c74c:	48 b8 89 6c 4e ec 98 	movabs rax,0x82efa98ec4e6c89
    c753:	fa 2e 08 
    c756:	48 33 84 24 38 02 00 	xor    rax,QWORD PTR [rsp+0x238]
    c75d:	00 
    c75e:	48 01 d0             	add    rax,rdx
    c761:	4d 89 f1             	mov    r9,r14
    c764:	c7 84 24 14 01 00 00 	mov    DWORD PTR [rsp+0x114],0x0
    c76b:	00 00 00 00 
    c76f:	48 89 c2             	mov    rdx,rax
    c772:	48 c1 ea 1e          	shr    rdx,0x1e
    c776:	48 31 c2             	xor    rdx,rax
    c779:	48 b8 b9 e5 e4 1c 6d 	movabs rax,0xbf58476d1ce4e5b9
    c780:	47 58 bf 
    c783:	48 0f af d0          	imul   rdx,rax
    c787:	48 89 d0             	mov    rax,rdx
    c78a:	48 c1 e8 1b          	shr    rax,0x1b
    c78e:	48 31 d0             	xor    rax,rdx
    c791:	48 ba eb 11 31 13 bb 	movabs rdx,0x94d049bb133111eb
    c798:	49 d0 94 
    c79b:	48 0f af c2          	imul   rax,rdx
    c79f:	48 89 c2             	mov    rdx,rax
    c7a2:	48 c1 ea 1f          	shr    rdx,0x1f
    c7a6:	48 31 c2             	xor    rdx,rax
    c7a9:	89 f8                	mov    eax,edi
    c7ab:	c1 e8 1f             	shr    eax,0x1f
    c7ae:	48 89 94 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rdx
    c7b5:	00 
    c7b6:	01 f8                	add    eax,edi
    c7b8:	d1 f8                	sar    eax,1
    c7ba:	39 44 24 18          	cmp    DWORD PTR [rsp+0x18],eax
    c7be:	c7 44 24 18 00 00 00 	mov    DWORD PTR [rsp+0x18],0x0
    c7c5:	00 
    c7c6:	0f 9d c2             	setge  dl
    c7c9:	83 bc 24 10 01 00 00 	cmp    DWORD PTR [rsp+0x110],0x1
    c7d0:	01 
    c7d1:	0f 9f c0             	setg   al
    c7d4:	49 c1 e5 04          	shl    r13,0x4
    c7d8:	21 c2                	and    edx,eax
    c7da:	48 89 e8             	mov    rax,rbp
    c7dd:	8d 2c 3f             	lea    ebp,[rdi+rdi*1]
    c7e0:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    c7e5:	48 c1 e0 04          	shl    rax,0x4
    c7e9:	88 54 24 7b          	mov    BYTE PTR [rsp+0x7b],dl
    c7ed:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
    c7f4:	00 
    c7f5:	48 01 f8             	add    rax,rdi
    c7f8:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
    c7ff:	00 
    c800:	4c 89 ac 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],r13
    c807:	00 
    c808:	41 89 f5             	mov    r13d,esi
    c80b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    c810:	44 8b b4 24 2c 01 00 	mov    r14d,DWORD PTR [rsp+0x12c]
    c817:	00 
    c818:	45 85 f6             	test   r14d,r14d
    c81b:	0f 85 da 01 00 00    	jne    c9fb <try_secant_tail.constprop.0+0x5fb>
    c821:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    c825:	3b 84 24 24 01 00 00 	cmp    eax,DWORD PTR [rsp+0x124]
    c82c:	0f 8e c9 01 00 00    	jle    c9fb <try_secant_tail.constprop.0+0x5fb>
    c832:	83 7c 24 18 1f       	cmp    DWORD PTR [rsp+0x18],0x1f
    c837:	0f 9f c0             	setg   al
    c83a:	84 44 24 7b          	test   BYTE PTR [rsp+0x7b],al
    c83e:	74 22                	je     c862 <try_secant_tail.constprop.0+0x462>
    c840:	44 39 6c 24 10       	cmp    DWORD PTR [rsp+0x10],r13d
    c845:	7f 1b                	jg     c862 <try_secant_tail.constprop.0+0x462>
    c847:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    c84b:	44 29 e8             	sub    eax,r13d
    c84e:	48 98                	cdqe
    c850:	48 0f af 44 24 38    	imul   rax,QWORD PTR [rsp+0x38]
    c856:	48 3d 3f 42 0f 00    	cmp    rax,0xf423f
    c85c:	0f 8f 9e 03 00 00    	jg     cc00 <try_secant_tail.constprop.0+0x800>
    c862:	48 8b 15 00 00 00 00 	mov    rdx,QWORD PTR [rip+0x0]        # c869 <try_secant_tail.constprop.0+0x469>
    c869:	c4 e1 f9 6e ea       	vmovq  xmm5,rdx
    c86e:	c5 d3 58 25 00 00 00 	vaddsd xmm4,xmm5,QWORD PTR [rip+0x0]        # c876 <try_secant_tail.constprop.0+0x476>
    c875:	00 
    c876:	48 89 d0             	mov    rax,rdx
    c879:	c4 e1 f9 7e e1       	vmovq  rcx,xmm4
    c87e:	f0 48 0f b1 0d 00 00 	lock cmpxchg QWORD PTR [rip+0x0],rcx        # c887 <try_secant_tail.constprop.0+0x487>
    c885:	00 00 
    c887:	0f 85 20 16 00 00    	jne    dead <try_secant_tail.constprop.0+0x1aad>
    c88d:	44 8b 74 24 0c       	mov    r14d,DWORD PTR [rsp+0xc]
    c892:	4d 63 d5             	movsxd r10,r13d
    c895:	4d 89 e0             	mov    r8,r12
    c898:	4d 0f af c2          	imul   r8,r10
    c89c:	4c 03 44 24 28       	add    r8,QWORD PTR [rsp+0x28]
    c8a1:	45 85 f6             	test   r14d,r14d
    c8a4:	0f 8e 8d 06 00 00    	jle    cf37 <try_secant_tail.constprop.0+0xb37>
    c8aa:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
    c8ae:	48 8b 94 24 38 01 00 	mov    rdx,QWORD PTR [rsp+0x138]
    c8b5:	00 
    c8b6:	31 c0                	xor    eax,eax
    c8b8:	c5 f9 28 fe          	vmovapd xmm7,xmm6
    c8bc:	c5 79 28 c6          	vmovapd xmm8,xmm6
    c8c0:	c5 f9 28 ce          	vmovapd xmm1,xmm6
    c8c4:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    c8c9:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    c8d0:	00 00 00 00 
    c8d4:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    c8db:	00 00 00 00 
    c8df:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    c8e6:	00 00 00 00 
    c8ea:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    c8f1:	00 00 00 00 
    c8f5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    c8fc:	00 00 00 00 
    c900:	c4 c1 7b 10 04 00    	vmovsd xmm0,QWORD PTR [r8+rax*1]
    c906:	c4 62 f9 b9 04 02    	vfmadd231sd xmm8,xmm0,QWORD PTR [rdx+rax*1]
    c90c:	c4 c2 f9 b9 3c 07    	vfmadd231sd xmm7,xmm0,QWORD PTR [r15+rax*1]
    c912:	c4 c2 f9 b9 34 01    	vfmadd231sd xmm6,xmm0,QWORD PTR [r9+rax*1]
    c918:	48 83 c0 08          	add    rax,0x8
    c91c:	49 39 c4             	cmp    r12,rax
    c91f:	c4 e2 f9 b9 c8       	vfmadd231sd xmm1,xmm0,xmm0
    c924:	75 da                	jne    c900 <try_secant_tail.constprop.0+0x500>
    c926:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
    c92a:	c5 f9 2f c8          	vcomisd xmm1,xmm0
    c92e:	0f 86 14 06 00 00    	jbe    cf48 <try_secant_tail.constprop.0+0xb48>
    c934:	48 b8 00 00 00 00 00 	movabs rax,0x7ff0000000000000
    c93b:	00 f0 7f 
    c93e:	c4 e1 f9 7e cf       	vmovq  rdi,xmm1
    c943:	c4 e2 c0 f2 c0       	andn   rax,rdi,rax
    c948:	0f 84 fa 05 00 00    	je     cf48 <try_secant_tail.constprop.0+0xb48>
    c94e:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
    c952:	c5 fb 10 1d 00 00 00 	vmovsd xmm3,QWORD PTR [rip+0x0]        # c95a <try_secant_tail.constprop.0+0x55a>
    c959:	00 
    c95a:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    c95f:	44 39 6c 24 10       	cmp    DWORD PTR [rsp+0x10],r13d
    c964:	c5 e3 5e c9          	vdivsd xmm1,xmm3,xmm1
    c968:	4a 8d 14 d0          	lea    rdx,[rax+r10*8]
    c96c:	c5 fb 10 02          	vmovsd xmm0,QWORD PTR [rdx]
    c970:	c5 f3 59 d0          	vmulsd xmm2,xmm1,xmm0
    c974:	0f 8e 06 0e 00 00    	jle    d780 <try_secant_tail.constprop.0+0x1380>
    c97a:	c5 c1 54 3d 00 00 00 	vandpd xmm7,xmm7,XMMWORD PTR [rip+0x0]        # c982 <try_secant_tail.constprop.0+0x582>
    c981:	00 
    c982:	c5 c9 54 35 00 00 00 	vandpd xmm6,xmm6,XMMWORD PTR [rip+0x0]        # c98a <try_secant_tail.constprop.0+0x58a>
    c989:	00 
    c98a:	c5 cb 5f f7          	vmaxsd xmm6,xmm6,xmm7
    c98e:	c5 fb 10 3d 00 00 00 	vmovsd xmm7,QWORD PTR [rip+0x0]        # c996 <try_secant_tail.constprop.0+0x596>
    c995:	00 
    c996:	c5 cb 59 f1          	vmulsd xmm6,xmm6,xmm1
    c99a:	c5 f9 2f f7          	vcomisd xmm6,xmm7
    c99e:	0f 87 0a 05 00 00    	ja     ceae <try_secant_tail.constprop.0+0xaae>
    c9a4:	c5 fb 10 25 00 00 00 	vmovsd xmm4,QWORD PTR [rip+0x0]        # c9ac <try_secant_tail.constprop.0+0x5ac>
    c9ab:	00 
    c9ac:	c5 db 58 5c 24 60    	vaddsd xmm3,xmm4,QWORD PTR [rsp+0x60]
    c9b2:	c4 c1 7b 5c c0       	vsubsd xmm0,xmm0,xmm8
    c9b7:	c5 e9 54 15 00 00 00 	vandpd xmm2,xmm2,XMMWORD PTR [rip+0x0]        # c9bf <try_secant_tail.constprop.0+0x5bf>
    c9be:	00 
    c9bf:	c5 eb 58 d3          	vaddsd xmm2,xmm2,xmm3
    c9c3:	c5 eb 59 15 00 00 00 	vmulsd xmm2,xmm2,QWORD PTR [rip+0x0]        # c9cb <try_secant_tail.constprop.0+0x5cb>
    c9ca:	00 
    c9cb:	c5 fb 59 c1          	vmulsd xmm0,xmm0,xmm1
    c9cf:	c5 f9 54 05 00 00 00 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x0]        # c9d7 <try_secant_tail.constprop.0+0x5d7>
    c9d6:	00 
    c9d7:	c5 f9 2f c2          	vcomisd xmm0,xmm2
    c9db:	0f 87 cd 04 00 00    	ja     ceae <try_secant_tail.constprop.0+0xaae>
    c9e1:	83 44 24 18 01       	add    DWORD PTR [rsp+0x18],0x1
    c9e6:	41 83 c5 01          	add    r13d,0x1
    c9ea:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    c9f0:	44 39 6c 24 20       	cmp    DWORD PTR [rsp+0x20],r13d
    c9f5:	0f 8f 15 fe ff ff    	jg     c810 <try_secant_tail.constprop.0+0x410>
    c9fb:	c5 fb 10 0d 00 00 00 	vmovsd xmm1,QWORD PTR [rip+0x0]        # ca03 <try_secant_tail.constprop.0+0x603>
    ca02:	00 
    ca03:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
    ca0a:	00 
    ca0b:	bf 01 00 00 00       	mov    edi,0x1
    ca10:	c5 fb 11 4c 24 10    	vmovsd QWORD PTR [rsp+0x10],xmm1
    ca16:	e8 00 00 00 00       	call   ca1b <try_secant_tail.constprop.0+0x61b>
    ca1b:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
    ca1f:	c5 fb 10 4c 24 10    	vmovsd xmm1,QWORD PTR [rsp+0x10]
    ca25:	c4 e1 d3 2a 84 24 60 	vcvtsi2sd xmm0,xmm5,QWORD PTR [rsp+0x160]
    ca2c:	01 00 00 
    ca2f:	c5 f9 28 d0          	vmovapd xmm2,xmm0
    ca33:	c5 eb 58 15 00 00 00 	vaddsd xmm2,xmm2,QWORD PTR [rip+0x0]        # ca3b <try_secant_tail.constprop.0+0x63b>
    ca3a:	00 
    ca3b:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    ca40:	c4 e1 d3 2a 84 24 68 	vcvtsi2sd xmm0,xmm5,QWORD PTR [rsp+0x168]
    ca47:	01 00 00 
    ca4a:	c4 e2 f1 9b 05 00 00 	vfmsub132sd xmm0,xmm1,QWORD PTR [rip+0x0]        # ca53 <try_secant_tail.constprop.0+0x653>
    ca51:	00 00 
    ca53:	c5 eb 58 d0          	vaddsd xmm2,xmm2,xmm0
    ca57:	c5 fb 11 15 00 00 00 	vmovsd QWORD PTR [rip+0x0],xmm2        # ca5f <try_secant_tail.constprop.0+0x65f>
    ca5e:	00 
    ca5f:	e8 00 00 00 00       	call   ca64 <try_secant_tail.constprop.0+0x664>
    ca64:	48 8b 7c 24 50       	mov    rdi,QWORD PTR [rsp+0x50]
    ca69:	e8 00 00 00 00       	call   ca6e <try_secant_tail.constprop.0+0x66e>
    ca6e:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    ca73:	e8 00 00 00 00       	call   ca78 <try_secant_tail.constprop.0+0x678>
    ca78:	8b 8c 24 2c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x12c]
    ca7f:	8b 84 24 24 01 00 00 	mov    eax,DWORD PTR [rsp+0x124]
    ca86:	85 c9                	test   ecx,ecx
    ca88:	0f 85 ed 10 00 00    	jne    db7b <try_secant_tail.constprop.0+0x177b>
    ca8e:	39 44 24 0c          	cmp    DWORD PTR [rsp+0xc],eax
    ca92:	4c 8d b4 24 e0 01 00 	lea    r14,[rsp+0x1e0]
    ca99:	00 
    ca9a:	0f 84 96 12 00 00    	je     dd36 <try_secant_tail.constprop.0+0x1936>
    caa0:	48 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],rbx
    caa5:	48 8d ac 24 d0 01 00 	lea    rbp,[rsp+0x1d0]
    caac:	00 
    caad:	c5 fb 10 45 00       	vmovsd xmm0,QWORD PTR [rbp+0x0]
    cab2:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    cab7:	48 89 de             	mov    rsi,rbx
    caba:	e8 81 9a ff ff       	call   6540 <bs_check_certified.constprop.0>
    cabf:	83 f8 01             	cmp    eax,0x1
    cac2:	41 89 c5             	mov    r13d,eax
    cac5:	0f 85 6f 10 00 00    	jne    db3a <try_secant_tail.constprop.0+0x173a>
    cacb:	48 83 c5 08          	add    rbp,0x8
    cacf:	4c 01 e3             	add    rbx,r12
    cad2:	49 39 ee             	cmp    r14,rbp
    cad5:	75 d6                	jne    caad <try_secant_tail.constprop.0+0x6ad>
    cad7:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    cadc:	4c 8b 8c 24 b0 00 00 	mov    r9,QWORD PTR [rsp+0xb0]
    cae3:	00 
    cae4:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # caec <try_secant_tail.constprop.0+0x6ec>
    caeb:	00 
    caec:	44 8b 44 24 0c       	mov    r8d,DWORD PTR [rsp+0xc]
    caf1:	8b 4c 24 20          	mov    ecx,DWORD PTR [rsp+0x20]
    caf5:	48 8b 94 24 38 01 00 	mov    rdx,QWORD PTR [rsp+0x138]
    cafc:	00 
    cafd:	48 8b 74 24 30       	mov    rsi,QWORD PTR [rsp+0x30]
    cb02:	48 8b 5c 24 10       	mov    rbx,QWORD PTR [rsp+0x10]
    cb07:	e8 44 3b ff ff       	call   650 <compat_scan_fused>
    cb0c:	48 8b bc 24 30 01 00 	mov    rdi,QWORD PTR [rsp+0x130]
    cb13:	00 
    cb14:	85 c0                	test   eax,eax
    cb16:	0f 85 2b 10 00 00    	jne    db47 <try_secant_tail.constprop.0+0x1747>
    cb1c:	48 8b 8c 24 08 01 00 	mov    rcx,QWORD PTR [rsp+0x108]
    cb23:	00 
    cb24:	8b 84 24 24 01 00 00 	mov    eax,DWORD PTR [rsp+0x124]
    cb2b:	48 8b b4 24 d8 00 00 	mov    rsi,QWORD PTR [rsp+0xd8]
    cb32:	00 
    cb33:	c5 fb 10 84 24 60 01 	vmovsd xmm0,QWORD PTR [rsp+0x160]
    cb3a:	00 00 
    cb3c:	48 85 c9             	test   rcx,rcx
    cb3f:	c7 06 02 00 00 00    	mov    DWORD PTR [rsi],0x2
    cb45:	89 46 04             	mov    DWORD PTR [rsi+0x4],eax
    cb48:	c5 fb 11 46 18       	vmovsd QWORD PTR [rsi+0x18],xmm0
    cb4d:	0f 84 c9 11 00 00    	je     dd1c <try_secant_tail.constprop.0+0x191c>
    cb53:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    cb57:	85 c0                	test   eax,eax
    cb59:	0f 8e c3 12 00 00    	jle    de22 <try_secant_tail.constprop.0+0x1a22>
    cb5f:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
    cb63:	48 8b 94 24 38 01 00 	mov    rdx,QWORD PTR [rsp+0x138]
    cb6a:	00 
    cb6b:	31 c0                	xor    eax,eax
    cb6d:	c5 f9 28 d3          	vmovapd xmm2,xmm3
    cb71:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
    cb75:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    cb7c:	00 00 00 00 
    cb80:	c5 fb 10 0c 01       	vmovsd xmm1,QWORD PTR [rcx+rax*1]
    cb85:	c5 fb 10 04 02       	vmovsd xmm0,QWORD PTR [rdx+rax*1]
    cb8a:	48 83 c0 08          	add    rax,0x8
    cb8e:	49 39 c4             	cmp    r12,rax
    cb91:	c5 fb 5c c1          	vsubsd xmm0,xmm0,xmm1
    cb95:	c4 e2 f1 b9 d9       	vfmadd231sd xmm3,xmm1,xmm1
    cb9a:	c4 e2 f9 b9 d0       	vfmadd231sd xmm2,xmm0,xmm0
    cb9f:	75 df                	jne    cb80 <try_secant_tail.constprop.0+0x780>
    cba1:	c5 eb 51 d2          	vsqrtsd xmm2,xmm2,xmm2
    cba5:	c5 e3 51 db          	vsqrtsd xmm3,xmm3,xmm3
    cba9:	c5 e3 58 1d 00 00 00 	vaddsd xmm3,xmm3,QWORD PTR [rip+0x0]        # cbb1 <try_secant_tail.constprop.0+0x7b1>
    cbb0:	00 
    cbb1:	c5 eb 5e d3          	vdivsd xmm2,xmm2,xmm3
    cbb5:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    cbbc:	00 
    cbbd:	c7 40 0c 01 00 00 00 	mov    DWORD PTR [rax+0xc],0x1
    cbc4:	c5 fb 11 50 20       	vmovsd QWORD PTR [rax+0x20],xmm2
    cbc9:	e8 00 00 00 00       	call   cbce <try_secant_tail.constprop.0+0x7ce>
    cbce:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    cbd5:	00 
    cbd6:	e8 00 00 00 00       	call   cbdb <try_secant_tail.constprop.0+0x7db>
    cbdb:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    cbe2:	00 
    cbe3:	e8 00 00 00 00       	call   cbe8 <try_secant_tail.constprop.0+0x7e8>
    cbe8:	4c 89 ff             	mov    rdi,r15
    cbeb:	e8 00 00 00 00       	call   cbf0 <try_secant_tail.constprop.0+0x7f0>
    cbf0:	48 89 df             	mov    rdi,rbx
    cbf3:	e8 00 00 00 00       	call   cbf8 <try_secant_tail.constprop.0+0x7f8>
    cbf8:	e9 e3 f8 ff ff       	jmp    c4e0 <try_secant_tail.constprop.0+0xe0>
    cbfd:	0f 1f 00             	nop    DWORD PTR [rax]
    cc00:	8b 74 24 20          	mov    esi,DWORD PTR [rsp+0x20]
    cc04:	41 8d 85 00 08 00 00 	lea    eax,[r13+0x800]
    cc0b:	39 f0                	cmp    eax,esi
    cc0d:	0f 4f c6             	cmovg  eax,esi
    cc10:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    cc14:	41 89 c2             	mov    r10d,eax
    cc17:	48 8b 15 00 00 00 00 	mov    rdx,QWORD PTR [rip+0x0]        # cc1e <try_secant_tail.constprop.0+0x81e>
    cc1e:	45 29 ea             	sub    r10d,r13d
    cc21:	c4 e1 f9 6e ea       	vmovq  xmm5,rdx
    cc26:	c5 d3 58 1d 00 00 00 	vaddsd xmm3,xmm5,QWORD PTR [rip+0x0]        # cc2e <try_secant_tail.constprop.0+0x82e>
    cc2d:	00 
    cc2e:	48 89 d0             	mov    rax,rdx
    cc31:	c4 e1 f9 7e d9       	vmovq  rcx,xmm3
    cc36:	f0 48 0f b1 0d 00 00 	lock cmpxchg QWORD PTR [rip+0x0],rcx        # cc3f <try_secant_tail.constprop.0+0x83f>
    cc3d:	00 00 
    cc3f:	0f 85 58 12 00 00    	jne    de9d <try_secant_tail.constprop.0+0x1a9d>
    cc45:	48 8b 15 00 00 00 00 	mov    rdx,QWORD PTR [rip+0x0]        # cc4c <try_secant_tail.constprop.0+0x84c>
    cc4c:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
    cc50:	c4 c1 63 2a c2       	vcvtsi2sd xmm0,xmm3,r10d
    cc55:	c4 e1 f9 6e ea       	vmovq  xmm5,rdx
    cc5a:	48 89 d0             	mov    rax,rdx
    cc5d:	c5 fb 58 e5          	vaddsd xmm4,xmm0,xmm5
    cc61:	c4 e1 f9 7e e1       	vmovq  rcx,xmm4
    cc66:	f0 48 0f b1 0d 00 00 	lock cmpxchg QWORD PTR [rip+0x0],rcx        # cc6f <try_secant_tail.constprop.0+0x86f>
    cc6d:	00 00 
    cc6f:	0f 85 30 12 00 00    	jne    dea5 <try_secant_tail.constprop.0+0x1aa5>
    cc75:	4d 63 c2             	movsxd r8,r10d
    cc78:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    cc7d:	31 f6                	xor    esi,esi
    cc7f:	b9 00 08 00 00       	mov    ecx,0x800
    cc84:	4c 89 c2             	mov    rdx,r8
    cc87:	4c 89 4c 24 70       	mov    QWORD PTR [rsp+0x70],r9
    cc8c:	4c 89 44 24 68       	mov    QWORD PTR [rsp+0x68],r8
    cc91:	44 89 54 24 24       	mov    DWORD PTR [rsp+0x24],r10d
    cc96:	e8 00 00 00 00       	call   cc9b <try_secant_tail.constprop.0+0x89b>
    cc9b:	48 8b 8c 24 f0 00 00 	mov    rcx,QWORD PTR [rsp+0xf0]
    cca2:	00 
    cca3:	48 8b 7c 24 50       	mov    rdi,QWORD PTR [rsp+0x50]
    cca8:	31 f6                	xor    esi,esi
    ccaa:	48 89 ca             	mov    rdx,rcx
    ccad:	e8 00 00 00 00       	call   ccb2 <try_secant_tail.constprop.0+0x8b2>
    ccb2:	48 8b 8c 24 e8 00 00 	mov    rcx,QWORD PTR [rsp+0xe8]
    ccb9:	00 
    ccba:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    ccbf:	31 f6                	xor    esi,esi
    ccc1:	48 89 ca             	mov    rdx,rcx
    ccc4:	e8 00 00 00 00       	call   ccc9 <try_secant_tail.constprop.0+0x8c9>
    ccc9:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    ccce:	48 8b 74 24 30       	mov    rsi,QWORD PTR [rsp+0x30]
    ccd3:	31 d2                	xor    edx,edx
    ccd5:	48 8b 4c 24 48       	mov    rcx,QWORD PTR [rsp+0x48]
    ccda:	44 8b 54 24 24       	mov    r10d,DWORD PTR [rsp+0x24]
    ccdf:	44 89 ac 24 bc 01 00 	mov    DWORD PTR [rsp+0x1bc],r13d
    cce6:	00 
    cce7:	48 89 bc 24 a0 01 00 	mov    QWORD PTR [rsp+0x1a0],rdi
    ccee:	00 
    ccef:	48 8b bc 24 c8 00 00 	mov    rdi,QWORD PTR [rsp+0xc8]
    ccf6:	00 
    ccf7:	48 89 b4 24 68 01 00 	mov    QWORD PTR [rsp+0x168],rsi
    ccfe:	00 
    ccff:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    cd04:	48 89 bc 24 78 01 00 	mov    QWORD PTR [rsp+0x178],rdi
    cd0b:	00 
    cd0c:	48 8b 3d 00 00 00 00 	mov    rdi,QWORD PTR [rip+0x0]        # cd13 <try_secant_tail.constprop.0+0x913>
    cd13:	48 89 8c 24 b0 01 00 	mov    QWORD PTR [rsp+0x1b0],rcx
    cd1a:	00 
    cd1b:	48 8b 4c 24 58       	mov    rcx,QWORD PTR [rsp+0x58]
    cd20:	48 89 bc 24 70 01 00 	mov    QWORD PTR [rsp+0x170],rdi
    cd27:	00 
    cd28:	8b 7c 24 0c          	mov    edi,DWORD PTR [rsp+0xc]
    cd2c:	48 89 b4 24 60 01 00 	mov    QWORD PTR [rsp+0x160],rsi
    cd33:	00 
    cd34:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    cd39:	c5 fb 10 5c 24 60    	vmovsd xmm3,QWORD PTR [rsp+0x60]
    cd3f:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
    cd46:	00 
    cd47:	89 bc 24 b8 01 00 00 	mov    DWORD PTR [rsp+0x1b8],edi
    cd4e:	48 8d 3d 5b 65 ff ff 	lea    rdi,[rip+0xffffffffffff655b]        # 32b0 <try_secant_tail._omp_fn.0>
    cd55:	c5 fb 10 a4 24 b8 00 	vmovsd xmm4,QWORD PTR [rsp+0xb8]
    cd5c:	00 00 
    cd5e:	48 89 8c 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rcx
    cd65:	00 
    cd66:	31 c9                	xor    ecx,ecx
    cd68:	44 89 94 24 c0 01 00 	mov    DWORD PTR [rsp+0x1c0],r10d
    cd6f:	00 
    cd70:	48 89 84 24 a8 01 00 	mov    QWORD PTR [rsp+0x1a8],rax
    cd77:	00 
    cd78:	4c 89 bc 24 88 01 00 	mov    QWORD PTR [rsp+0x188],r15
    cd7f:	00 
    cd80:	c5 fb 11 9c 24 98 01 	vmovsd QWORD PTR [rsp+0x198],xmm3
    cd87:	00 00 
    cd89:	c5 fb 11 a4 24 90 01 	vmovsd QWORD PTR [rsp+0x190],xmm4
    cd90:	00 00 
    cd92:	e8 00 00 00 00       	call   cd97 <try_secant_tail.constprop.0+0x997>
    cd97:	44 8b 54 24 24       	mov    r10d,DWORD PTR [rsp+0x24]
    cd9c:	4c 8b 44 24 68       	mov    r8,QWORD PTR [rsp+0x68]
    cda1:	8b b4 24 10 01 00 00 	mov    esi,DWORD PTR [rsp+0x110]
    cda8:	4c 8b 4c 24 70       	mov    r9,QWORD PTR [rsp+0x70]
    cdad:	85 f6                	test   esi,esi
    cdaf:	0f 8e af 00 00 00    	jle    ce64 <try_secant_tail.constprop.0+0xa64>
    cdb5:	c5 fb 10 94 24 d0 01 	vmovsd xmm2,QWORD PTR [rsp+0x1d0]
    cdbc:	00 00 
    cdbe:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    cdc2:	c5 fb 10 8c 24 d8 01 	vmovsd xmm1,QWORD PTR [rsp+0x1d8]
    cdc9:	00 00 
    cdcb:	85 c0                	test   eax,eax
    cdcd:	7e 54                	jle    ce23 <try_secant_tail.constprop.0+0xa23>
    cdcf:	48 8b 54 24 50       	mov    rdx,QWORD PTR [rsp+0x50]
    cdd4:	48 8b 8c 24 00 01 00 	mov    rcx,QWORD PTR [rsp+0x100]
    cddb:	00 
    cddc:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
    cde0:	31 c0                	xor    eax,eax
    cde2:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
    cde9:	00 
    cdea:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    cdf1:	00 00 00 00 
    cdf5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    cdfc:	00 00 00 00 
    ce00:	c5 fb 10 04 c3       	vmovsd xmm0,QWORD PTR [rbx+rax*8]
    ce05:	c5 fb 58 04 c2       	vaddsd xmm0,xmm0,QWORD PTR [rdx+rax*8]
    ce0a:	c5 fb 11 04 c3       	vmovsd QWORD PTR [rbx+rax*8],xmm0
    ce0f:	48 83 c0 01          	add    rax,0x1
    ce13:	39 c5                	cmp    ebp,eax
    ce15:	7f e9                	jg     ce00 <try_secant_tail.constprop.0+0xa00>
    ce17:	41 83 c6 01          	add    r14d,0x1
    ce1b:	48 01 ca             	add    rdx,rcx
    ce1e:	41 39 f6             	cmp    r14d,esi
    ce21:	75 bd                	jne    cde0 <try_secant_tail.constprop.0+0x9e0>
    ce23:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
    ce28:	48 8b 94 24 f8 00 00 	mov    rdx,QWORD PTR [rsp+0xf8]
    ce2f:	00 
    ce30:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    ce35:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    ce3c:	00 00 00 00 
    ce40:	c5 eb 58 10          	vaddsd xmm2,xmm2,QWORD PTR [rax]
    ce44:	c5 f3 58 48 08       	vaddsd xmm1,xmm1,QWORD PTR [rax+0x8]
    ce49:	48 83 c0 10          	add    rax,0x10
    ce4d:	48 39 c2             	cmp    rdx,rax
    ce50:	75 ee                	jne    ce40 <try_secant_tail.constprop.0+0xa40>
    ce52:	c5 fb 11 94 24 d0 01 	vmovsd QWORD PTR [rsp+0x1d0],xmm2
    ce59:	00 00 
    ce5b:	c5 fb 11 8c 24 d8 01 	vmovsd QWORD PTR [rsp+0x1d8],xmm1
    ce62:	00 00 
    ce64:	45 85 d2             	test   r10d,r10d
    ce67:	0f 8e 23 08 00 00    	jle    d690 <try_secant_tail.constprop.0+0x1290>
    ce6d:	48 8b 54 24 40       	mov    rdx,QWORD PTR [rsp+0x40]
    ce72:	31 c0                	xor    eax,eax
    ce74:	eb 17                	jmp    ce8d <try_secant_tail.constprop.0+0xa8d>
    ce76:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
    ce7d:	00 00 00 
    ce80:	48 83 c0 01          	add    rax,0x1
    ce84:	49 39 c0             	cmp    r8,rax
    ce87:	0f 84 03 08 00 00    	je     d690 <try_secant_tail.constprop.0+0x1290>
    ce8d:	80 3c 02 00          	cmp    BYTE PTR [rdx+rax*1],0x0
    ce91:	74 ed                	je     ce80 <try_secant_tail.constprop.0+0xa80>
    ce93:	48 8b 4c 24 30       	mov    rcx,QWORD PTR [rsp+0x30]
    ce98:	41 01 c5             	add    r13d,eax
    ce9b:	4d 89 e0             	mov    r8,r12
    ce9e:	49 63 c5             	movsxd rax,r13d
    cea1:	4c 0f af c0          	imul   r8,rax
    cea5:	48 8d 14 c1          	lea    rdx,[rcx+rax*8]
    cea9:	4c 03 44 24 28       	add    r8,QWORD PTR [rsp+0x28]
    ceae:	48 8b 0d 00 00 00 00 	mov    rcx,QWORD PTR [rip+0x0]        # ceb5 <try_secant_tail.constprop.0+0xab5>
    ceb5:	c4 e1 f9 6e e1       	vmovq  xmm4,rcx
    ceba:	c5 db 58 1d 00 00 00 	vaddsd xmm3,xmm4,QWORD PTR [rip+0x0]        # cec2 <try_secant_tail.constprop.0+0xac2>
    cec1:	00 
    cec2:	48 89 c8             	mov    rax,rcx
    cec5:	c4 e1 f9 7e de       	vmovq  rsi,xmm3
    ceca:	f0 48 0f b1 35 00 00 	lock cmpxchg QWORD PTR [rip+0x0],rsi        # ced3 <try_secant_tail.constprop.0+0xad3>
    ced1:	00 00 
    ced3:	0f 85 e9 0f 00 00    	jne    dec2 <try_secant_tail.constprop.0+0x1ac2>
    ced9:	8b 84 24 2c 01 00 00 	mov    eax,DWORD PTR [rsp+0x12c]
    cee0:	85 c0                	test   eax,eax
    cee2:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    cee6:	0f 85 0f fb ff ff    	jne    c9fb <try_secant_tail.constprop.0+0x5fb>
    ceec:	8b 84 24 20 01 00 00 	mov    eax,DWORD PTR [rsp+0x120]
    cef3:	4c 89 c7             	mov    rdi,r8
    cef6:	c5 fb 10 32          	vmovsd xmm6,QWORD PTR [rdx]
    cefa:	89 c6                	mov    esi,eax
    cefc:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    cf00:	e8 eb 31 ff ff       	call   f0 <norm2>
    cf05:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
    cf09:	c5 f9 2f c1          	vcomisd xmm0,xmm1
    cf0d:	0f 85 9d 00 00 00    	jne    cfb0 <try_secant_tail.constprop.0+0xbb0>
    cf13:	c5 c9 54 35 00 00 00 	vandpd xmm6,xmm6,XMMWORD PTR [rip+0x0]        # cf1b <try_secant_tail.constprop.0+0xb1b>
    cf1a:	00 
    cf1b:	c5 f9 2f 35 00 00 00 	vcomisd xmm6,QWORD PTR [rip+0x0]        # cf23 <try_secant_tail.constprop.0+0xb23>
    cf22:	00 
    cf23:	0f 87 e1 0e 00 00    	ja     de0a <try_secant_tail.constprop.0+0x1a0a>
    cf29:	83 44 24 18 01       	add    DWORD PTR [rsp+0x18],0x1
    cf2e:	41 83 c5 01          	add    r13d,0x1
    cf32:	e9 b9 fa ff ff       	jmp    c9f0 <try_secant_tail.constprop.0+0x5f0>
    cf37:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
    cf3b:	c5 f9 28 fe          	vmovapd xmm7,xmm6
    cf3f:	c5 79 28 c6          	vmovapd xmm8,xmm6
    cf43:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    cf48:	8b 74 24 0c          	mov    esi,DWORD PTR [rsp+0xc]
    cf4c:	4c 89 c7             	mov    rdi,r8
    cf4f:	e8 9c 31 ff ff       	call   f0 <norm2>
    cf54:	c5 f9 28 c8          	vmovapd xmm1,xmm0
    cf58:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
    cf5c:	c5 f9 2f c8          	vcomisd xmm1,xmm0
    cf60:	0f 85 ec f9 ff ff    	jne    c952 <try_secant_tail.constprop.0+0x552>
    cf66:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    cf6b:	4a 8d 14 d0          	lea    rdx,[rax+r10*8]
    cf6f:	c5 fb 10 02          	vmovsd xmm0,QWORD PTR [rdx]
    cf73:	c5 f9 54 05 00 00 00 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x0]        # cf7b <try_secant_tail.constprop.0+0xb7b>
    cf7a:	00 
    cf7b:	c5 f9 2f 05 00 00 00 	vcomisd xmm0,QWORD PTR [rip+0x0]        # cf83 <try_secant_tail.constprop.0+0xb83>
    cf82:	00 
    cf83:	0f 87 25 ff ff ff    	ja     ceae <try_secant_tail.constprop.0+0xaae>
    cf89:	8b 7c 24 10          	mov    edi,DWORD PTR [rsp+0x10]
    cf8d:	41 8d 45 01          	lea    eax,[r13+0x1]
    cf91:	44 39 ef             	cmp    edi,r13d
    cf94:	41 89 c5             	mov    r13d,eax
    cf97:	0f 4e f8             	cmovle edi,eax
    cf9a:	83 44 24 18 01       	add    DWORD PTR [rsp+0x18],0x1
    cf9f:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    cfa3:	e9 48 fa ff ff       	jmp    c9f0 <try_secant_tail.constprop.0+0x5f0>
    cfa8:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
    cfaf:	00 
    cfb0:	c5 fb 10 25 00 00 00 	vmovsd xmm4,QWORD PTR [rip+0x0]        # cfb8 <try_secant_tail.constprop.0+0xbb8>
    cfb7:	00 
    cfb8:	8b 84 24 24 01 00 00 	mov    eax,DWORD PTR [rsp+0x124]
    cfbf:	4c 63 74 24 24       	movsxd r14,DWORD PTR [rsp+0x24]
    cfc4:	4c 8b 94 24 40 01 00 	mov    r10,QWORD PTR [rsp+0x140]
    cfcb:	00 
    cfcc:	c5 db 5e c8          	vdivsd xmm1,xmm4,xmm0
    cfd0:	89 44 24 70          	mov    DWORD PTR [rsp+0x70],eax
    cfd4:	48 8b b4 24 30 01 00 	mov    rsi,QWORD PTR [rsp+0x130]
    cfdb:	00 
    cfdc:	4c 89 f0             	mov    rax,r14
    cfdf:	49 c1 e6 03          	shl    r14,0x3
    cfe3:	4f 8d 1c 32          	lea    r11,[r10+r14*1]
    cfe7:	85 c0                	test   eax,eax
    cfe9:	4b 8d 14 33          	lea    rdx,[r11+r14*1]
    cfed:	c5 cb 59 e9          	vmulsd xmm5,xmm6,xmm1
    cff1:	c5 fb 11 6c 24 68    	vmovsd QWORD PTR [rsp+0x68],xmm5
    cff7:	0f 8e 21 0a 00 00    	jle    da1e <try_secant_tail.constprop.0+0x161e>
    cffd:	31 c0                	xor    eax,eax
    cfff:	90                   	nop
    d000:	c4 c1 73 59 04 00    	vmulsd xmm0,xmm1,QWORD PTR [r8+rax*1]
    d006:	c4 c1 7b 11 04 02    	vmovsd QWORD PTR [r10+rax*1],xmm0
    d00c:	c4 c1 7b 11 04 03    	vmovsd QWORD PTR [r11+rax*1],xmm0
    d012:	48 83 c0 08          	add    rax,0x8
    d016:	49 39 c6             	cmp    r14,rax
    d019:	75 e5                	jne    d000 <try_secant_tail.constprop.0+0xc00>
    d01b:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    d01f:	49 89 d0             	mov    r8,rdx
    d022:	8b 54 24 70          	mov    edx,DWORD PTR [rsp+0x70]
    d026:	4c 89 df             	mov    rdi,r11
    d029:	4c 89 94 24 98 00 00 	mov    QWORD PTR [rsp+0x98],r10
    d030:	00 
    d031:	4c 89 8c 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r9
    d038:	00 
    d039:	4c 89 9c 24 80 00 00 	mov    QWORD PTR [rsp+0x80],r11
    d040:	00 
    d041:	e8 ba 53 ff ff       	call   2400 <project_cgs2>
    d046:	4c 8b 9c 24 80 00 00 	mov    r11,QWORD PTR [rsp+0x80]
    d04d:	00 
    d04e:	8b 74 24 24          	mov    esi,DWORD PTR [rsp+0x24]
    d052:	c5 fb 11 84 24 e0 00 	vmovsd QWORD PTR [rsp+0xe0],xmm0
    d059:	00 00 
    d05b:	4c 89 df             	mov    rdi,r11
    d05e:	e8 8d 30 ff ff       	call   f0 <norm2>
    d063:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    d06a:	00 
    d06b:	31 c0                	xor    eax,eax
    d06d:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
    d071:	4c 8b 94 24 98 00 00 	mov    r10,QWORD PTR [rsp+0x98]
    d078:	00 
    d079:	4c 8b 8c 24 90 00 00 	mov    r9,QWORD PTR [rsp+0x90]
    d080:	00 
    d081:	c5 f9 28 d0          	vmovapd xmm2,xmm0
    d085:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    d08a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    d091:	00 00 00 00 
    d095:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    d09c:	00 00 00 00 
    d0a0:	c4 c1 7b 10 04 02    	vmovsd xmm0,QWORD PTR [r10+rax*1]
    d0a6:	c5 fb 59 04 07       	vmulsd xmm0,xmm0,QWORD PTR [rdi+rax*1]
    d0ab:	48 83 c0 08          	add    rax,0x8
    d0af:	49 39 c6             	cmp    r14,rax
    d0b2:	c5 f3 58 c8          	vaddsd xmm1,xmm1,xmm0
    d0b6:	75 e8                	jne    d0a0 <try_secant_tail.constprop.0+0xca0>
    d0b8:	c5 fb 10 6c 24 68    	vmovsd xmm5,QWORD PTR [rsp+0x68]
    d0be:	c5 d3 5c d9          	vsubsd xmm3,xmm5,xmm1
    d0c2:	c5 fb 11 9c 24 c0 00 	vmovsd QWORD PTR [rsp+0xc0],xmm3
    d0c9:	00 00 
    d0cb:	8b 74 24 24          	mov    esi,DWORD PTR [rsp+0x24]
    d0cf:	4c 89 94 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],r10
    d0d6:	00 
    d0d7:	c5 fb 11 94 24 90 00 	vmovsd QWORD PTR [rsp+0x90],xmm2
    d0de:	00 00 
    d0e0:	4c 89 8c 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],r9
    d0e7:	00 
    d0e8:	4c 89 9c 24 98 00 00 	mov    QWORD PTR [rsp+0x98],r11
    d0ef:	00 
    d0f0:	e8 fb 2f ff ff       	call   f0 <norm2>
    d0f5:	db ac 24 50 01 00 00 	fld    TBYTE PTR [rsp+0x150]
    d0fc:	c5 fb 11 84 24 d0 00 	vmovsd QWORD PTR [rsp+0xd0],xmm0
    d103:	00 00 
    d105:	db bc 24 80 00 00 00 	fstp   TBYTE PTR [rsp+0x80]
    d10c:	c5 f8 77             	vzeroupper
    d10f:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # d116 <try_secant_tail.constprop.0+0xd16>
    d116:	e8 00 00 00 00       	call   d11b <try_secant_tail.constprop.0+0xd1b>
    d11b:	4c 8b 9c 24 98 00 00 	mov    r11,QWORD PTR [rsp+0x98]
    d122:	00 
    d123:	c5 fb 10 94 24 90 00 	vmovsd xmm2,QWORD PTR [rsp+0x90]
    d12a:	00 00 
    d12c:	4c 8b 8c 24 a0 00 00 	mov    r9,QWORD PTR [rsp+0xa0]
    d133:	00 
    d134:	4c 8b 94 24 a8 00 00 	mov    r10,QWORD PTR [rsp+0xa8]
    d13b:	00 
    d13c:	d9 ee                	fldz
    d13e:	c5 fb 10 88 00 00 00 	vmovsd xmm1,QWORD PTR [rax+0x0]
    d145:	00 
    d146:	db ac 24 80 00 00 00 	fld    TBYTE PTR [rsp+0x80]
    d14d:	db f1                	fcomi  st,st(1)
    d14f:	dd d9                	fstp   st(1)
    d151:	0f 86 90 00 00 00    	jbe    d1e7 <try_secant_tail.constprop.0+0xde7>
    d157:	d9 c0                	fld    st(0)
    d159:	d9 fa                	fsqrt
    d15b:	dd 9c 24 80 00 00 00 	fstp   QWORD PTR [rsp+0x80]
    d162:	c5 fb 10 84 24 80 00 	vmovsd xmm0,QWORD PTR [rsp+0x80]
    d169:	00 00 
    d16b:	c5 f9 2f c1          	vcomisd xmm0,xmm1
    d16f:	76 08                	jbe    d179 <try_secant_tail.constprop.0+0xd79>
    d171:	c5 fb 11 80 00 00 00 	vmovsd QWORD PTR [rax+0x0],xmm0
    d178:	00 
    d179:	c5 f9 2f 05 00 00 00 	vcomisd xmm0,QWORD PTR [rip+0x0]        # d181 <try_secant_tail.constprop.0+0xd81>
    d180:	00 
    d181:	0f 82 40 04 00 00    	jb     d5c7 <try_secant_tail.constprop.0+0x11c7>
    d187:	dd d8                	fstp   st(0)
    d189:	eb 02                	jmp    d18d <try_secant_tail.constprop.0+0xd8d>
    d18b:	dd d8                	fstp   st(0)
    d18d:	45 85 ed             	test   r13d,r13d
    d190:	0f 88 a4 07 00 00    	js     d93a <try_secant_tail.constprop.0+0x153a>
    d196:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # d19d <try_secant_tail.constprop.0+0xd9d>
    d19d:	e8 00 00 00 00       	call   d1a2 <try_secant_tail.constprop.0+0xda2>
    d1a2:	8b a8 00 00 00 00    	mov    ebp,DWORD PTR [rax+0x0]
    d1a8:	83 80 00 00 00 00 01 	add    DWORD PTR [rax+0x0],0x1
    d1af:	85 ed                	test   ebp,ebp
    d1b1:	4c 63 e5             	movsxd r12,ebp
    d1b4:	0f 8e 63 07 00 00    	jle    d91d <try_secant_tail.constprop.0+0x151d>
    d1ba:	48 05 00 00 00 00    	add    rax,0x0
    d1c0:	4c 63 e5             	movsxd r12,ebp
    d1c3:	4a 8d 14 a0          	lea    rdx,[rax+r12*4]
    d1c7:	eb 14                	jmp    d1dd <try_secant_tail.constprop.0+0xddd>
    d1c9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    d1d0:	48 83 c0 04          	add    rax,0x4
    d1d4:	48 39 c2             	cmp    rdx,rax
    d1d7:	0f 84 3b 07 00 00    	je     d918 <try_secant_tail.constprop.0+0x1518>
    d1dd:	44 3b 28             	cmp    r13d,DWORD PTR [rax]
    d1e0:	75 ee                	jne    d1d0 <try_secant_tail.constprop.0+0xdd0>
    d1e2:	e9 53 07 00 00       	jmp    d93a <try_secant_tail.constprop.0+0x153a>
    d1e7:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
    d1eb:	c5 f9 2f c1          	vcomisd xmm0,xmm1
    d1ef:	76 0b                	jbe    d1fc <try_secant_tail.constprop.0+0xdfc>
    d1f1:	48 c7 80 00 00 00 00 	mov    QWORD PTR [rax+0x0],0x0
    d1f8:	00 00 00 00 
    d1fc:	c5 fb 10 1d 00 00 00 	vmovsd xmm3,QWORD PTR [rip+0x0]        # d204 <try_secant_tail.constprop.0+0xe04>
    d203:	00 
    d204:	c5 f9 2f d3          	vcomisd xmm2,xmm3
    d208:	0f 86 fa 03 00 00    	jbe    d608 <try_secant_tail.constprop.0+0x1208>
    d20e:	c5 f9 28 c3          	vmovapd xmm0,xmm3
    d212:	c5 eb 5c c8          	vsubsd xmm1,xmm2,xmm0
    d216:	c5 f9 2f 0d 00 00 00 	vcomisd xmm1,QWORD PTR [rip+0x0]        # d21e <try_secant_tail.constprop.0+0xe1e>
    d21d:	00 
    d21e:	0f 86 ca 03 00 00    	jbe    d5ee <try_secant_tail.constprop.0+0x11ee>
    d224:	8b 8c 24 24 01 00 00 	mov    ecx,DWORD PTR [rsp+0x124]
    d22b:	39 4c 24 24          	cmp    DWORD PTR [rsp+0x24],ecx
    d22f:	0f 8e 56 ff ff ff    	jle    d18b <try_secant_tail.constprop.0+0xd8b>
    d235:	8b 84 24 28 01 00 00 	mov    eax,DWORD PTR [rsp+0x128]
    d23c:	48 8b b4 24 30 01 00 	mov    rsi,QWORD PTR [rsp+0x130]
    d243:	00 
    d244:	39 c1                	cmp    ecx,eax
    d246:	0f 8c d9 00 00 00    	jl     d325 <try_secant_tail.constprop.0+0xf25>
    d24c:	dd d8                	fstp   st(0)
    d24e:	83 f8 07             	cmp    eax,0x7
    d251:	8b 94 24 20 01 00 00 	mov    edx,DWORD PTR [rsp+0x120]
    d258:	0f 8e b1 07 00 00    	jle    da0f <try_secant_tail.constprop.0+0x160f>
    d25e:	85 d2                	test   edx,edx
    d260:	8d 72 03             	lea    esi,[rdx+0x3]
    d263:	8d 0c 85 00 00 00 00 	lea    ecx,[rax*4+0x0]
    d26a:	0f 49 f2             	cmovns esi,edx
    d26d:	c1 fe 02             	sar    esi,0x2
    d270:	39 f0                	cmp    eax,esi
    d272:	0f 4f ca             	cmovg  ecx,edx
    d275:	39 c8                	cmp    eax,ecx
    d277:	0f 8d e9 04 00 00    	jge    d766 <try_secant_tail.constprop.0+0x1366>
    d27d:	48 b8 ff ff ff ff ff 	movabs rax,0x1fffffffffffffff
    d284:	ff ff 1f 
    d287:	48 63 f2             	movsxd rsi,edx
    d28a:	31 d2                	xor    edx,edx
    d28c:	48 63 f9             	movsxd rdi,ecx
    d28f:	48 f7 f6             	div    rsi
    d292:	48 39 f8             	cmp    rax,rdi
    d295:	0f 82 cb 04 00 00    	jb     d766 <try_secant_tail.constprop.0+0x1366>
    d29b:	48 0f af f7          	imul   rsi,rdi
    d29f:	48 8b bc 24 30 01 00 	mov    rdi,QWORD PTR [rsp+0x130]
    d2a6:	00 
    d2a7:	4c 89 4c 24 68       	mov    QWORD PTR [rsp+0x68],r9
    d2ac:	89 8c 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],ecx
    d2b3:	4c 89 9c 24 98 00 00 	mov    QWORD PTR [rsp+0x98],r11
    d2ba:	00 
    d2bb:	c5 fb 11 94 24 90 00 	vmovsd QWORD PTR [rsp+0x90],xmm2
    d2c2:	00 00 
    d2c4:	48 c1 e6 03          	shl    rsi,0x3
    d2c8:	c5 fb 11 9c 24 a0 00 	vmovsd QWORD PTR [rsp+0xa0],xmm3
    d2cf:	00 00 
    d2d1:	e8 00 00 00 00       	call   d2d6 <try_secant_tail.constprop.0+0xed6>
    d2d6:	4c 8b 4c 24 68       	mov    r9,QWORD PTR [rsp+0x68]
    d2db:	48 85 c0             	test   rax,rax
    d2de:	48 89 c6             	mov    rsi,rax
    d2e1:	0f 84 7f 04 00 00    	je     d766 <try_secant_tail.constprop.0+0x1366>
    d2e7:	8b 8c 24 80 00 00 00 	mov    ecx,DWORD PTR [rsp+0x80]
    d2ee:	db ac 24 50 01 00 00 	fld    TBYTE PTR [rsp+0x150]
    d2f5:	48 89 84 24 30 01 00 	mov    QWORD PTR [rsp+0x130],rax
    d2fc:	00 
    d2fd:	c5 fb 10 9c 24 a0 00 	vmovsd xmm3,QWORD PTR [rsp+0xa0]
    d304:	00 00 
    d306:	89 8c 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],ecx
    d30d:	8b 8c 24 24 01 00 00 	mov    ecx,DWORD PTR [rsp+0x124]
    d314:	4c 8b 9c 24 98 00 00 	mov    r11,QWORD PTR [rsp+0x98]
    d31b:	00 
    d31c:	c5 fb 10 94 24 90 00 	vmovsd xmm2,QWORD PTR [rsp+0x90]
    d323:	00 00 
    d325:	48 63 d1             	movsxd rdx,ecx
    d328:	44 8b 54 24 24       	mov    r10d,DWORD PTR [rsp+0x24]
    d32d:	49 0f af d6          	imul   rdx,r14
    d331:	48 01 f2             	add    rdx,rsi
    d334:	45 85 d2             	test   r10d,r10d
    d337:	7e 3b                	jle    d374 <try_secant_tail.constprop.0+0xf74>
    d339:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # d341 <try_secant_tail.constprop.0+0xf41>
    d340:	00 
    d341:	31 c0                	xor    eax,eax
    d343:	c5 d3 5e ca          	vdivsd xmm1,xmm5,xmm2
    d347:	0f 1f 00             	nop    DWORD PTR [rax]
    d34a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    d351:	00 00 00 00 
    d355:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    d35c:	00 00 00 00 
    d360:	c4 c1 73 59 04 03    	vmulsd xmm0,xmm1,QWORD PTR [r11+rax*1]
    d366:	c5 fb 11 04 02       	vmovsd QWORD PTR [rdx+rax*1],xmm0
    d36b:	48 83 c0 08          	add    rax,0x8
    d36f:	49 39 c6             	cmp    r14,rax
    d372:	75 ec                	jne    d360 <try_secant_tail.constprop.0+0xf60>
    d374:	83 f9 5f             	cmp    ecx,0x5f
    d377:	48 63 bc 24 20 01 00 	movsxd rdi,DWORD PTR [rsp+0x120]
    d37e:	00 
    d37f:	0f 8e 1a 07 00 00    	jle    da9f <try_secant_tail.constprop.0+0x169f>
    d385:	d9 ee                	fldz
    d387:	d9 c9                	fxch   st(1)
    d389:	db f1                	fcomi  st,st(1)
    d38b:	dd d9                	fstp   st(1)
    d38d:	0f 86 01 07 00 00    	jbe    da94 <try_secant_tail.constprop.0+0x1694>
    d393:	d9 c0                	fld    st(0)
    d395:	c5 eb 58 0d 00 00 00 	vaddsd xmm1,xmm2,QWORD PTR [rip+0x0]        # d39d <try_secant_tail.constprop.0+0xf9d>
    d39c:	00 
    d39d:	c5 fb 10 a4 24 e0 00 	vmovsd xmm4,QWORD PTR [rsp+0xe0]
    d3a4:	00 00 
    d3a6:	d9 fa                	fsqrt
    d3a8:	c5 db 5e c9          	vdivsd xmm1,xmm4,xmm1
    d3ac:	dd 5c 24 18          	fstp   QWORD PTR [rsp+0x18]
    d3b0:	c5 fb 10 44 24 18    	vmovsd xmm0,QWORD PTR [rsp+0x18]
    d3b6:	c4 e2 e1 99 c1       	vfmadd132sd xmm0,xmm3,xmm1
    d3bb:	c5 fb 11 44 24 18    	vmovsd QWORD PTR [rsp+0x18],xmm0
    d3c1:	dd 44 24 18          	fld    QWORD PTR [rsp+0x18]
    d3c5:	d8 c8                	fmul   st,st(0)
    d3c7:	d8 c0                	fadd   st,st(0)
    d3c9:	85 ff                	test   edi,edi
    d3cb:	0f 8e 58 09 00 00    	jle    dd29 <try_secant_tail.constprop.0+0x1929>
    d3d1:	48 89 d0             	mov    rax,rdx
    d3d4:	48 8d 34 fa          	lea    rsi,[rdx+rdi*8]
    d3d8:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
    d3dc:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
    d3e0:	c5 fb 10 00          	vmovsd xmm0,QWORD PTR [rax]
    d3e4:	48 83 c0 08          	add    rax,0x8
    d3e8:	48 39 c6             	cmp    rsi,rax
    d3eb:	c5 fb 59 c0          	vmulsd xmm0,xmm0,xmm0
    d3ef:	c5 f3 58 c8          	vaddsd xmm1,xmm1,xmm0
    d3f3:	75 eb                	jne    d3e0 <try_secant_tail.constprop.0+0xfe0>
    d3f5:	c5 f3 5c 05 00 00 00 	vsubsd xmm0,xmm1,QWORD PTR [rip+0x0]        # d3fd <try_secant_tail.constprop.0+0xffd>
    d3fc:	00 
    d3fd:	c5 f9 54 05 00 00 00 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x0]        # d405 <try_secant_tail.constprop.0+0x1005>
    d404:	00 
    d405:	c5 fb 58 e3          	vaddsd xmm4,xmm0,xmm3
    d409:	c5 fb 11 64 24 18    	vmovsd QWORD PTR [rsp+0x18],xmm4
    d40f:	dd 44 24 18          	fld    QWORD PTR [rsp+0x18]
    d413:	d8 c8                	fmul   st,st(0)
    d415:	d9 ca                	fxch   st(2)
    d417:	de c1                	faddp  st(1),st
    d419:	de c1                	faddp  st(1),st
    d41b:	44 8b 44 24 24       	mov    r8d,DWORD PTR [rsp+0x24]
    d420:	db bc 24 50 01 00 00 	fstp   TBYTE PTR [rsp+0x150]
    d427:	45 85 c0             	test   r8d,r8d
    d42a:	7e 4d                	jle    d479 <try_secant_tail.constprop.0+0x1079>
    d42c:	c5 fb 10 a4 24 c0 00 	vmovsd xmm4,QWORD PTR [rsp+0xc0]
    d433:	00 00 
    d435:	48 8b b4 24 38 01 00 	mov    rsi,QWORD PTR [rsp+0x138]
    d43c:	00 
    d43d:	31 c0                	xor    eax,eax
    d43f:	c5 db 5e d2          	vdivsd xmm2,xmm4,xmm2
    d443:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    d44a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    d451:	00 00 00 00 
    d455:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    d45c:	00 00 00 00 
    d460:	c5 fb 10 04 02       	vmovsd xmm0,QWORD PTR [rdx+rax*1]
    d465:	c4 e2 e9 a9 04 06    	vfmadd213sd xmm0,xmm2,QWORD PTR [rsi+rax*1]
    d46b:	c5 fb 11 04 06       	vmovsd QWORD PTR [rsi+rax*1],xmm0
    d470:	48 83 c0 08          	add    rax,0x8
    d474:	49 39 c6             	cmp    r14,rax
    d477:	75 e7                	jne    d460 <try_secant_tail.constprop.0+0x1060>
    d479:	8b 84 24 2c 01 00 00 	mov    eax,DWORD PTR [rsp+0x12c]
    d480:	83 c1 01             	add    ecx,0x1
    d483:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    d48a:	85 c0                	test   eax,eax
    d48c:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    d490:	0f 85 65 f5 ff ff    	jne    c9fb <try_secant_tail.constprop.0+0x5fb>
    d496:	48 8b 15 00 00 00 00 	mov    rdx,QWORD PTR [rip+0x0]        # d49d <try_secant_tail.constprop.0+0x109d>
    d49d:	c4 e1 f9 6e ea       	vmovq  xmm5,rdx
    d4a2:	c5 d3 58 1d 00 00 00 	vaddsd xmm3,xmm5,QWORD PTR [rip+0x0]        # d4aa <try_secant_tail.constprop.0+0x10aa>
    d4a9:	00 
    d4aa:	48 89 d0             	mov    rax,rdx
    d4ad:	c4 e1 f9 7e d9       	vmovq  rcx,xmm3
    d4b2:	f0 48 0f b1 0d 00 00 	lock cmpxchg QWORD PTR [rip+0x0],rcx        # d4bb <try_secant_tail.constprop.0+0x10bb>
    d4b9:	00 00 
    d4bb:	0f 85 d4 09 00 00    	jne    de95 <try_secant_tail.constprop.0+0x1a95>
    d4c1:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    d4c5:	3b 84 24 24 01 00 00 	cmp    eax,DWORD PTR [rsp+0x124]
    d4cc:	0f 84 29 f5 ff ff    	je     c9fb <try_secant_tail.constprop.0+0x5fb>
    d4d2:	89 c6                	mov    esi,eax
    d4d4:	8b 84 24 14 01 00 00 	mov    eax,DWORD PTR [rsp+0x114]
    d4db:	45 89 eb             	mov    r11d,r13d
    d4de:	49 89 d8             	mov    r8,rbx
    d4e1:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    d4e8:	00 
    d4e9:	41 89 ea             	mov    r10d,ebp
    d4ec:	4d 89 cd             	mov    r13,r9
    d4ef:	41 be 02 00 00 00    	mov    r14d,0x2
    d4f5:	83 c0 01             	add    eax,0x1
    d4f8:	4c 89 fd             	mov    rbp,r15
    d4fb:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    d4ff:	e8 ec 2b ff ff       	call   f0 <norm2>
    d504:	48 63 44 24 70       	movsxd rax,DWORD PTR [rsp+0x70]
    d509:	48 0f af 44 24 38    	imul   rax,QWORD PTR [rsp+0x38]
    d50f:	48 8b 94 24 30 01 00 	mov    rdx,QWORD PTR [rsp+0x130]
    d516:	00 
    d517:	c5 fb 10 3d 00 00 00 	vmovsd xmm7,QWORD PTR [rip+0x0]        # d51f <try_secant_tail.constprop.0+0x111f>
    d51e:	00 
    d51f:	c5 fb 11 44 24 60    	vmovsd QWORD PTR [rsp+0x60],xmm0
    d525:	48 8d 1c c2          	lea    rbx,[rdx+rax*8]
    d529:	8b 74 24 0c          	mov    esi,DWORD PTR [rsp+0xc]
    d52d:	85 f6                	test   esi,esi
    d52f:	0f 8e 7a 01 00 00    	jle    d6af <try_secant_tail.constprop.0+0x12af>
    d535:	31 c0                	xor    eax,eax
    d537:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
    d53b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    d540:	c5 fb 10 44 05 00    	vmovsd xmm0,QWORD PTR [rbp+rax*1+0x0]
    d546:	c5 fb 59 04 03       	vmulsd xmm0,xmm0,QWORD PTR [rbx+rax*1]
    d54b:	48 83 c0 08          	add    rax,0x8
    d54f:	49 39 c4             	cmp    r12,rax
    d552:	c5 f3 58 c8          	vaddsd xmm1,xmm1,xmm0
    d556:	75 e8                	jne    d540 <try_secant_tail.constprop.0+0x1140>
    d558:	31 c0                	xor    eax,eax
    d55a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    d560:	c5 fb 10 04 03       	vmovsd xmm0,QWORD PTR [rbx+rax*1]
    d565:	c4 e2 f1 ad 44 05 00 	vfnmadd213sd xmm0,xmm1,QWORD PTR [rbp+rax*1+0x0]
    d56c:	c5 fb 11 44 05 00    	vmovsd QWORD PTR [rbp+rax*1+0x0],xmm0
    d572:	48 83 c0 08          	add    rax,0x8
    d576:	49 39 c4             	cmp    r12,rax
    d579:	75 e5                	jne    d560 <try_secant_tail.constprop.0+0x1160>
    d57b:	8b 74 24 0c          	mov    esi,DWORD PTR [rsp+0xc]
    d57f:	48 89 ef             	mov    rdi,rbp
    d582:	e8 69 2b ff ff       	call   f0 <norm2>
    d587:	c5 f9 2f f8          	vcomisd xmm7,xmm0
    d58b:	0f 87 30 01 00 00    	ja     d6c1 <try_secant_tail.constprop.0+0x12c1>
    d591:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # d599 <try_secant_tail.constprop.0+0x1199>
    d598:	00 
    d599:	48 89 e8             	mov    rax,rbp
    d59c:	c5 d3 5e c0          	vdivsd xmm0,xmm5,xmm0
    d5a0:	c5 fb 59 08          	vmulsd xmm1,xmm0,QWORD PTR [rax]
    d5a4:	48 83 c0 08          	add    rax,0x8
    d5a8:	c5 fb 11 48 f8       	vmovsd QWORD PTR [rax-0x8],xmm1
    d5ad:	4c 39 e8             	cmp    rax,r13
    d5b0:	75 ee                	jne    d5a0 <try_secant_tail.constprop.0+0x11a0>
    d5b2:	41 83 ee 01          	sub    r14d,0x1
    d5b6:	0f 84 91 01 00 00    	je     d74d <try_secant_tail.constprop.0+0x134d>
    d5bc:	4c 01 e5             	add    rbp,r12
    d5bf:	4d 01 e5             	add    r13,r12
    d5c2:	e9 6e ff ff ff       	jmp    d535 <try_secant_tail.constprop.0+0x1135>
    d5c7:	c5 fb 58 0d 00 00 00 	vaddsd xmm1,xmm0,QWORD PTR [rip+0x0]        # d5cf <try_secant_tail.constprop.0+0x11cf>
    d5ce:	00 
    d5cf:	c5 fb 10 1d 00 00 00 	vmovsd xmm3,QWORD PTR [rip+0x0]        # d5d7 <try_secant_tail.constprop.0+0x11d7>
    d5d6:	00 
    d5d7:	c5 f3 59 cb          	vmulsd xmm1,xmm1,xmm3
    d5db:	c4 e2 f1 99 c0       	vfmadd132sd xmm0,xmm1,xmm0
    d5e0:	c5 f9 2f d0          	vcomisd xmm2,xmm0
    d5e4:	0f 87 28 fc ff ff    	ja     d212 <try_secant_tail.constprop.0+0xe12>
    d5ea:	dd d8                	fstp   st(0)
    d5ec:	eb 02                	jmp    d5f0 <try_secant_tail.constprop.0+0x11f0>
    d5ee:	dd d8                	fstp   st(0)
    d5f0:	c5 eb 58 c0          	vaddsd xmm0,xmm2,xmm0
    d5f4:	c5 fb 10 0d 00 00 00 	vmovsd xmm1,QWORD PTR [rip+0x0]        # d5fc <try_secant_tail.constprop.0+0x11fc>
    d5fb:	00 
    d5fc:	c5 f9 2f c8          	vcomisd xmm1,xmm0
    d600:	0f 86 87 fb ff ff    	jbe    d18d <try_secant_tail.constprop.0+0xd8d>
    d606:	eb 02                	jmp    d60a <try_secant_tail.constprop.0+0x120a>
    d608:	dd d8                	fstp   st(0)
    d60a:	c5 fb 10 ac 24 c0 00 	vmovsd xmm5,QWORD PTR [rsp+0xc0]
    d611:	00 00 
    d613:	c5 fb 10 64 24 68    	vmovsd xmm4,QWORD PTR [rsp+0x68]
    d619:	c5 d9 54 05 00 00 00 	vandpd xmm0,xmm4,XMMWORD PTR [rip+0x0]        # d621 <try_secant_tail.constprop.0+0x1221>
    d620:	00 
    d621:	c5 fb 58 05 00 00 00 	vaddsd xmm0,xmm0,QWORD PTR [rip+0x0]        # d629 <try_secant_tail.constprop.0+0x1229>
    d628:	00 
    d629:	c5 fb 58 84 24 d0 00 	vaddsd xmm0,xmm0,QWORD PTR [rsp+0xd0]
    d630:	00 00 
    d632:	c5 fb 59 05 00 00 00 	vmulsd xmm0,xmm0,QWORD PTR [rip+0x0]        # d63a <try_secant_tail.constprop.0+0x123a>
    d639:	00 
    d63a:	c5 d1 54 0d 00 00 00 	vandpd xmm1,xmm5,XMMWORD PTR [rip+0x0]        # d642 <try_secant_tail.constprop.0+0x1242>
    d641:	00 
    d642:	c5 f9 2f c8          	vcomisd xmm1,xmm0
    d646:	0f 86 1a 01 00 00    	jbe    d766 <try_secant_tail.constprop.0+0x1366>
    d64c:	8b 44 24 24          	mov    eax,DWORD PTR [rsp+0x24]
    d650:	3b 84 24 24 01 00 00 	cmp    eax,DWORD PTR [rsp+0x124]
    d657:	0f 84 ad 07 00 00    	je     de0a <try_secant_tail.constprop.0+0x1a0a>
    d65d:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    d662:	4c 89 d6             	mov    rsi,r10
    d665:	e8 16 52 ff ff       	call   2880 <local_dependency_svd>
    d66a:	83 f8 01             	cmp    eax,0x1
    d66d:	0f 85 1a fb ff ff    	jne    d18d <try_secant_tail.constprop.0+0xd8d>
    d673:	c7 84 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],0x1
    d67a:	01 00 00 00 
    d67e:	c5 fb 10 0d 00 00 00 	vmovsd xmm1,QWORD PTR [rip+0x0]        # d686 <try_secant_tail.constprop.0+0x1286>
    d685:	00 
    d686:	e9 78 f3 ff ff       	jmp    ca03 <try_secant_tail.constprop.0+0x603>
    d68b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    d690:	44 01 54 24 18       	add    DWORD PTR [rsp+0x18],r10d
    d695:	44 8b 6c 24 10       	mov    r13d,DWORD PTR [rsp+0x10]
    d69a:	e9 51 f3 ff ff       	jmp    c9f0 <try_secant_tail.constprop.0+0x5f0>
    d69f:	41 83 ee 01          	sub    r14d,0x1
    d6a3:	0f 84 a4 00 00 00    	je     d74d <try_secant_tail.constprop.0+0x134d>
    d6a9:	4c 01 e5             	add    rbp,r12
    d6ac:	4d 01 e5             	add    r13,r12
    d6af:	8b 74 24 0c          	mov    esi,DWORD PTR [rsp+0xc]
    d6b3:	48 89 ef             	mov    rdi,rbp
    d6b6:	e8 35 2a ff ff       	call   f0 <norm2>
    d6bb:	c5 f9 2f f8          	vcomisd xmm7,xmm0
    d6bf:	76 de                	jbe    d69f <try_secant_tail.constprop.0+0x129f>
    d6c1:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
    d6c6:	48 89 ef             	mov    rdi,rbp
    d6c9:	44 89 5c 24 7c       	mov    DWORD PTR [rsp+0x7c],r11d
    d6ce:	4c 01 e5             	add    rbp,r12
    d6d1:	8b 84 24 14 01 00 00 	mov    eax,DWORD PTR [rsp+0x114]
    d6d8:	4c 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r8
    d6df:	00 
    d6e0:	4d 01 e5             	add    r13,r12
    d6e3:	4c 89 8c 24 80 00 00 	mov    QWORD PTR [rsp+0x80],r9
    d6ea:	00 
    d6eb:	8d 14 c5 00 00 00 00 	lea    edx,[rax*8+0x0]
    d6f2:	44 89 54 24 70       	mov    DWORD PTR [rsp+0x70],r10d
    d6f7:	29 c2                	sub    edx,eax
    d6f9:	c5 fb 11 7c 24 68    	vmovsd QWORD PTR [rsp+0x68],xmm7
    d6ff:	48 b8 03 ed 92 d1 32 	movabs rax,0xd1b54a32d192ed03
    d706:	4a b5 d1 
    d709:	83 c2 0a             	add    edx,0xa
    d70c:	44 29 f2             	sub    edx,r14d
    d70f:	48 63 d2             	movsxd rdx,edx
    d712:	48 0f af d0          	imul   rdx,rax
    d716:	48 03 94 24 18 01 00 	add    rdx,QWORD PTR [rsp+0x118]
    d71d:	00 
    d71e:	e8 1d 50 ff ff       	call   2740 <secant_refresh>
    d723:	41 83 ee 01          	sub    r14d,0x1
    d727:	c5 fb 10 7c 24 68    	vmovsd xmm7,QWORD PTR [rsp+0x68]
    d72d:	44 8b 54 24 70       	mov    r10d,DWORD PTR [rsp+0x70]
    d732:	44 8b 5c 24 7c       	mov    r11d,DWORD PTR [rsp+0x7c]
    d737:	4c 8b 8c 24 80 00 00 	mov    r9,QWORD PTR [rsp+0x80]
    d73e:	00 
    d73f:	4c 8b 84 24 90 00 00 	mov    r8,QWORD PTR [rsp+0x90]
    d746:	00 
    d747:	0f 85 dc fd ff ff    	jne    d529 <try_secant_tail.constprop.0+0x1129>
    d74d:	8b 44 24 24          	mov    eax,DWORD PTR [rsp+0x24]
    d751:	44 89 d5             	mov    ebp,r10d
    d754:	45 89 dd             	mov    r13d,r11d
    d757:	4c 89 c3             	mov    rbx,r8
    d75a:	89 84 24 14 01 00 00 	mov    DWORD PTR [rsp+0x114],eax
    d761:	e9 c8 f7 ff ff       	jmp    cf2e <try_secant_tail.constprop.0+0xb2e>
    d766:	8b bc 24 2c 01 00 00 	mov    edi,DWORD PTR [rsp+0x12c]
    d76d:	85 ff                	test   edi,edi
    d76f:	0f 84 b4 f7 ff ff    	je     cf29 <try_secant_tail.constprop.0+0xb29>
    d775:	e9 81 f2 ff ff       	jmp    c9fb <try_secant_tail.constprop.0+0x5fb>
    d77a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    d780:	48 8b 0d 00 00 00 00 	mov    rcx,QWORD PTR [rip+0x0]        # d787 <try_secant_tail.constprop.0+0x1387>
    d787:	c4 e1 f9 6e d9       	vmovq  xmm3,rcx
    d78c:	c5 e3 58 25 00 00 00 	vaddsd xmm4,xmm3,QWORD PTR [rip+0x0]        # d794 <try_secant_tail.constprop.0+0x1394>
    d793:	00 
    d794:	48 89 c8             	mov    rax,rcx
    d797:	c4 e1 f9 7e e6       	vmovq  rsi,xmm4
    d79c:	f0 48 0f b1 35 00 00 	lock cmpxchg QWORD PTR [rip+0x0],rsi        # d7a5 <try_secant_tail.constprop.0+0x13a5>
    d7a3:	00 00 
    d7a5:	0f 85 0a 07 00 00    	jne    deb5 <try_secant_tail.constprop.0+0x1ab5>
    d7ab:	41 8d 45 01          	lea    eax,[r13+0x1]
    d7af:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
    d7b3:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # d7bb <try_secant_tail.constprop.0+0x13bb>
    d7ba:	00 
    d7bb:	48 bf eb 11 31 13 bb 	movabs rdi,0x94d049bb133111eb
    d7c2:	49 d0 94 
    d7c5:	48 be 15 7c 4a 7f b9 	movabs rsi,0x9e3779b97f4a7c15
    d7cc:	79 37 9e 
    d7cf:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    d7d3:	48 98                	cdqe
    d7d5:	48 03 b4 24 c8 00 00 	add    rsi,QWORD PTR [rsp+0xc8]
    d7dc:	00 
    d7dd:	c5 7b 10 9c 24 b8 00 	vmovsd xmm11,QWORD PTR [rsp+0xb8]
    d7e4:	00 00 
    d7e6:	48 89 c1             	mov    rcx,rax
    d7e9:	48 0f af cf          	imul   rcx,rdi
    d7ed:	48 01 f1             	add    rcx,rsi
    d7f0:	49 89 ca             	mov    r10,rcx
    d7f3:	49 c1 ea 1e          	shr    r10,0x1e
    d7f7:	4c 31 d1             	xor    rcx,r10
    d7fa:	49 ba b9 e5 e4 1c 6d 	movabs r10,0xbf58476d1ce4e5b9
    d801:	47 58 bf 
    d804:	49 0f af ca          	imul   rcx,r10
    d808:	49 0f af c2          	imul   rax,r10
    d80c:	49 89 cb             	mov    r11,rcx
    d80f:	49 c1 eb 1b          	shr    r11,0x1b
    d813:	48 01 f0             	add    rax,rsi
    d816:	4c 31 d9             	xor    rcx,r11
    d819:	48 0f af cf          	imul   rcx,rdi
    d81d:	49 89 cb             	mov    r11,rcx
    d820:	49 c1 eb 1f          	shr    r11,0x1f
    d824:	49 31 cb             	xor    r11,rcx
    d827:	48 89 c1             	mov    rcx,rax
    d82a:	48 c1 e9 1e          	shr    rcx,0x1e
    d82e:	49 c1 eb 0b          	shr    r11,0xb
    d832:	48 31 c8             	xor    rax,rcx
    d835:	c4 c1 db 2a c3       	vcvtsi2sd xmm0,xmm4,r11
    d83a:	c5 f9 28 d8          	vmovapd xmm3,xmm0
    d83e:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # d846 <try_secant_tail.constprop.0+0x1446>
    d845:	00 
    d846:	49 0f af c2          	imul   rax,r10
    d84a:	44 8b 5c 24 0c       	mov    r11d,DWORD PTR [rsp+0xc]
    d84f:	c4 e2 f9 99 dd       	vfmadd132sd xmm3,xmm0,xmm5
    d854:	48 89 c1             	mov    rcx,rax
    d857:	48 c1 e9 1b          	shr    rcx,0x1b
    d85b:	48 31 c8             	xor    rax,rcx
    d85e:	48 0f af c7          	imul   rax,rdi
    d862:	c4 c1 63 59 db       	vmulsd xmm3,xmm3,xmm11
    d867:	48 89 c1             	mov    rcx,rax
    d86a:	48 c1 e9 1f          	shr    rcx,0x1f
    d86e:	48 31 c1             	xor    rcx,rax
    d871:	48 c1 e9 0b          	shr    rcx,0xb
    d875:	45 85 db             	test   r11d,r11d
    d878:	c4 e1 db 2a e1       	vcvtsi2sd xmm4,xmm4,rcx
    d87d:	c4 e2 f9 99 e5       	vfmadd132sd xmm4,xmm0,xmm5
    d882:	c4 c1 5b 59 e3       	vmulsd xmm4,xmm4,xmm11
    d887:	7e 60                	jle    d8e9 <try_secant_tail.constprop.0+0x14e9>
    d889:	c5 73 59 d3          	vmulsd xmm10,xmm1,xmm3
    d88d:	4a 8d 0c 23          	lea    rcx,[rbx+r12*1]
    d891:	31 c0                	xor    eax,eax
    d893:	c5 73 59 cc          	vmulsd xmm9,xmm1,xmm4
    d897:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
    d89e:	00 
    d89f:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    d8a6:	00 00 00 00 
    d8aa:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    d8b1:	00 00 00 00 
    d8b5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    d8bc:	00 00 00 00 
    d8c0:	c4 c1 7b 10 04 00    	vmovsd xmm0,QWORD PTR [r8+rax*1]
    d8c6:	c5 79 29 d5          	vmovapd xmm5,xmm10
    d8ca:	c4 e2 f9 a9 2c 03    	vfmadd213sd xmm5,xmm0,QWORD PTR [rbx+rax*1]
    d8d0:	c5 fb 11 2c 03       	vmovsd QWORD PTR [rbx+rax*1],xmm5
    d8d5:	c4 e2 b1 a9 04 01    	vfmadd213sd xmm0,xmm9,QWORD PTR [rcx+rax*1]
    d8db:	c5 fb 11 04 01       	vmovsd QWORD PTR [rcx+rax*1],xmm0
    d8e0:	48 83 c0 08          	add    rax,0x8
    d8e4:	49 39 c4             	cmp    r12,rax
    d8e7:	75 d7                	jne    d8c0 <try_secant_tail.constprop.0+0x14c0>
    d8e9:	c4 e2 e9 a9 9c 24 d0 	vfmadd213sd xmm3,xmm2,QWORD PTR [rsp+0x1d0]
    d8f0:	01 00 00 
    d8f3:	c5 fb 10 02          	vmovsd xmm0,QWORD PTR [rdx]
    d8f7:	c4 e2 e9 a9 a4 24 d8 	vfmadd213sd xmm4,xmm2,QWORD PTR [rsp+0x1d8]
    d8fe:	01 00 00 
    d901:	c5 fb 11 9c 24 d0 01 	vmovsd QWORD PTR [rsp+0x1d0],xmm3
    d908:	00 00 
    d90a:	c5 fb 11 a4 24 d8 01 	vmovsd QWORD PTR [rsp+0x1d8],xmm4
    d911:	00 00 
    d913:	e9 62 f0 ff ff       	jmp    c97a <try_secant_tail.constprop.0+0x57a>
    d918:	83 fd 40             	cmp    ebp,0x40
    d91b:	74 1d                	je     d93a <try_secant_tail.constprop.0+0x153a>
    d91d:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # d924 <try_secant_tail.constprop.0+0x1524>
    d924:	e8 00 00 00 00       	call   d929 <try_secant_tail.constprop.0+0x1529>
    d929:	83 c5 01             	add    ebp,0x1
    d92c:	89 a8 00 00 00 00    	mov    DWORD PTR [rax+0x0],ebp
    d932:	46 89 ac a0 00 00 00 	mov    DWORD PTR [rax+r12*4+0x0],r13d
    d939:	00 
    d93a:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
    d941:	00 
    d942:	bf 01 00 00 00       	mov    edi,0x1
    d947:	e8 00 00 00 00       	call   d94c <try_secant_tail.constprop.0+0x154c>
    d94c:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
    d950:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # d958 <try_secant_tail.constprop.0+0x1558>
    d957:	00 
    d958:	c4 e1 e3 2a 84 24 68 	vcvtsi2sd xmm0,xmm3,QWORD PTR [rsp+0x168]
    d95f:	01 00 00 
    d962:	c4 e2 d1 a9 05 00 00 	vfmadd213sd xmm0,xmm5,QWORD PTR [rip+0x0]        # d96b <try_secant_tail.constprop.0+0x156b>
    d969:	00 00 
    d96b:	48 8b bc 24 30 01 00 	mov    rdi,QWORD PTR [rsp+0x130]
    d972:	00 
    d973:	c4 e1 e3 2a 8c 24 60 	vcvtsi2sd xmm1,xmm3,QWORD PTR [rsp+0x160]
    d97a:	01 00 00 
    d97d:	c5 f3 5c 0d 00 00 00 	vsubsd xmm1,xmm1,QWORD PTR [rip+0x0]        # d985 <try_secant_tail.constprop.0+0x1585>
    d984:	00 
    d985:	c5 fb 58 c1          	vaddsd xmm0,xmm0,xmm1
    d989:	c5 fb 11 05 00 00 00 	vmovsd QWORD PTR [rip+0x0],xmm0        # d991 <try_secant_tail.constprop.0+0x1591>
    d990:	00 
    d991:	e8 00 00 00 00       	call   d996 <try_secant_tail.constprop.0+0x1596>
    d996:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    d99d:	00 
    d99e:	e8 00 00 00 00       	call   d9a3 <try_secant_tail.constprop.0+0x15a3>
    d9a3:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    d9aa:	00 
    d9ab:	e8 00 00 00 00       	call   d9b0 <try_secant_tail.constprop.0+0x15b0>
    d9b0:	4c 89 ff             	mov    rdi,r15
    d9b3:	e8 00 00 00 00       	call   d9b8 <try_secant_tail.constprop.0+0x15b8>
    d9b8:	48 89 df             	mov    rdi,rbx
    d9bb:	e8 00 00 00 00       	call   d9c0 <try_secant_tail.constprop.0+0x15c0>
    d9c0:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    d9c5:	e8 00 00 00 00       	call   d9ca <try_secant_tail.constprop.0+0x15ca>
    d9ca:	48 8b 7c 24 50       	mov    rdi,QWORD PTR [rsp+0x50]
    d9cf:	e8 00 00 00 00       	call   d9d4 <try_secant_tail.constprop.0+0x15d4>
    d9d4:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    d9d9:	e8 00 00 00 00       	call   d9de <try_secant_tail.constprop.0+0x15de>
    d9de:	45 31 ed             	xor    r13d,r13d
    d9e1:	e9 fa ea ff ff       	jmp    c4e0 <try_secant_tail.constprop.0+0xe0>
    d9e6:	48 8b 3d 00 00 00 00 	mov    rdi,QWORD PTR [rip+0x0]        # d9ed <try_secant_tail.constprop.0+0x15ed>
    d9ed:	e8 00 00 00 00       	call   d9f2 <try_secant_tail.constprop.0+0x15f2>
    d9f2:	48 8b 3d 00 00 00 00 	mov    rdi,QWORD PTR [rip+0x0]        # d9f9 <try_secant_tail.constprop.0+0x15f9>
    d9f9:	e8 00 00 00 00       	call   d9fe <try_secant_tail.constprop.0+0x15fe>
    d9fe:	48 8b 3d 00 00 00 00 	mov    rdi,QWORD PTR [rip+0x0]        # da05 <try_secant_tail.constprop.0+0x1605>
    da05:	e8 00 00 00 00       	call   da0a <try_secant_tail.constprop.0+0x160a>
    da0a:	e9 73 ea ff ff       	jmp    c482 <try_secant_tail.constprop.0+0x82>
    da0f:	b9 08 00 00 00       	mov    ecx,0x8
    da14:	39 ca                	cmp    edx,ecx
    da16:	0f 4e ca             	cmovle ecx,edx
    da19:	e9 57 f8 ff ff       	jmp    d275 <try_secant_tail.constprop.0+0xe75>
    da1e:	49 89 d0             	mov    r8,rdx
    da21:	8b 54 24 70          	mov    edx,DWORD PTR [rsp+0x70]
    da25:	4c 89 df             	mov    rdi,r11
    da28:	89 c1                	mov    ecx,eax
    da2a:	4c 89 94 24 98 00 00 	mov    QWORD PTR [rsp+0x98],r10
    da31:	00 
    da32:	4c 89 8c 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r9
    da39:	00 
    da3a:	4c 89 9c 24 80 00 00 	mov    QWORD PTR [rsp+0x80],r11
    da41:	00 
    da42:	e8 b9 49 ff ff       	call   2400 <project_cgs2>
    da47:	4c 8b 9c 24 80 00 00 	mov    r11,QWORD PTR [rsp+0x80]
    da4e:	00 
    da4f:	8b 74 24 24          	mov    esi,DWORD PTR [rsp+0x24]
    da53:	c5 fb 11 84 24 e0 00 	vmovsd QWORD PTR [rsp+0xe0],xmm0
    da5a:	00 00 
    da5c:	4c 89 df             	mov    rdi,r11
    da5f:	e8 8c 26 ff ff       	call   f0 <norm2>
    da64:	c5 fb 10 64 24 68    	vmovsd xmm4,QWORD PTR [rsp+0x68]
    da6a:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    da71:	00 
    da72:	4c 8b 8c 24 90 00 00 	mov    r9,QWORD PTR [rsp+0x90]
    da79:	00 
    da7a:	4c 8b 94 24 98 00 00 	mov    r10,QWORD PTR [rsp+0x98]
    da81:	00 
    da82:	c5 f9 28 d0          	vmovapd xmm2,xmm0
    da86:	c5 fb 11 a4 24 c0 00 	vmovsd QWORD PTR [rsp+0xc0],xmm4
    da8d:	00 00 
    da8f:	e9 37 f6 ff ff       	jmp    d0cb <try_secant_tail.constprop.0+0xccb>
    da94:	d9 05 00 00 00 00    	fld    DWORD PTR [rip+0x0]        # da9a <try_secant_tail.constprop.0+0x169a>
    da9a:	e9 2a f9 ff ff       	jmp    d3c9 <try_secant_tail.constprop.0+0xfc9>
    da9f:	85 ff                	test   edi,edi
    daa1:	0f 8e a4 03 00 00    	jle    de4b <try_secant_tail.constprop.0+0x1a4b>
    daa7:	4c 63 c7             	movsxd r8,edi
    daaa:	48 89 d0             	mov    rax,rdx
    daad:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
    dab1:	4e 8d 04 c2          	lea    r8,[rdx+r8*8]
    dab5:	c5 fb 10 00          	vmovsd xmm0,QWORD PTR [rax]
    dab9:	48 83 c0 08          	add    rax,0x8
    dabd:	49 39 c0             	cmp    r8,rax
    dac0:	c5 fb 59 c0          	vmulsd xmm0,xmm0,xmm0
    dac4:	c5 f3 58 c8          	vaddsd xmm1,xmm1,xmm0
    dac8:	75 eb                	jne    dab5 <try_secant_tail.constprop.0+0x16b5>
    daca:	c5 f3 5c 25 00 00 00 	vsubsd xmm4,xmm1,QWORD PTR [rip+0x0]        # dad2 <try_secant_tail.constprop.0+0x16d2>
    dad1:	00 
    dad2:	c5 fb 11 64 24 18    	vmovsd QWORD PTR [rsp+0x18],xmm4
    dad8:	dd 44 24 18          	fld    QWORD PTR [rsp+0x18]
    dadc:	d8 c8                	fmul   st,st(0)
    dade:	85 c9                	test   ecx,ecx
    dae0:	7e 51                	jle    db33 <try_secant_tail.constprop.0+0x1733>
    dae2:	85 ff                	test   edi,edi
    dae4:	7e 4d                	jle    db33 <try_secant_tail.constprop.0+0x1733>
    dae6:	44 8b 44 24 7c       	mov    r8d,DWORD PTR [rsp+0x7c]
    daeb:	48 c1 e7 03          	shl    rdi,0x3
    daef:	31 c0                	xor    eax,eax
    daf1:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
    daf5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    dafc:	00 00 00 00 
    db00:	c5 fb 10 04 02       	vmovsd xmm0,QWORD PTR [rdx+rax*1]
    db05:	c5 fb 59 04 06       	vmulsd xmm0,xmm0,QWORD PTR [rsi+rax*1]
    db0a:	48 83 c0 08          	add    rax,0x8
    db0e:	48 39 c7             	cmp    rdi,rax
    db11:	c5 f3 58 c8          	vaddsd xmm1,xmm1,xmm0
    db15:	75 e9                	jne    db00 <try_secant_tail.constprop.0+0x1700>
    db17:	c5 fb 11 4c 24 18    	vmovsd QWORD PTR [rsp+0x18],xmm1
    db1d:	dd 44 24 18          	fld    QWORD PTR [rsp+0x18]
    db21:	41 83 c0 01          	add    r8d,0x1
    db25:	48 01 fe             	add    rsi,rdi
    db28:	41 39 c8             	cmp    r8d,ecx
    db2b:	d8 c8                	fmul   st,st(0)
    db2d:	d8 c0                	fadd   st,st(0)
    db2f:	de c1                	faddp  st(1),st
    db31:	75 bc                	jne    daef <try_secant_tail.constprop.0+0x16ef>
    db33:	de c1                	faddp  st(1),st
    db35:	e9 e1 f8 ff ff       	jmp    d41b <try_secant_tail.constprop.0+0x101b>
    db3a:	48 8b 5c 24 10       	mov    rbx,QWORD PTR [rsp+0x10]
    db3f:	48 8b bc 24 30 01 00 	mov    rdi,QWORD PTR [rsp+0x130]
    db46:	00 
    db47:	e8 00 00 00 00       	call   db4c <try_secant_tail.constprop.0+0x174c>
    db4c:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    db53:	00 
    db54:	e8 00 00 00 00       	call   db59 <try_secant_tail.constprop.0+0x1759>
    db59:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    db60:	00 
    db61:	e8 00 00 00 00       	call   db66 <try_secant_tail.constprop.0+0x1766>
    db66:	4c 89 ff             	mov    rdi,r15
    db69:	e8 00 00 00 00       	call   db6e <try_secant_tail.constprop.0+0x176e>
    db6e:	48 89 df             	mov    rdi,rbx
    db71:	e8 00 00 00 00       	call   db76 <try_secant_tail.constprop.0+0x1776>
    db76:	e9 63 fe ff ff       	jmp    d9de <try_secant_tail.constprop.0+0x15de>
    db7b:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    db82:	00 
    db83:	8b 74 24 20          	mov    esi,DWORD PTR [rsp+0x20]
    db87:	48 c7 84 24 70 01 00 	mov    QWORD PTR [rsp+0x170],0x0
    db8e:	00 00 00 00 00 
    db93:	c7 84 24 78 01 00 00 	mov    DWORD PTR [rsp+0x178],0x0
    db9a:	00 00 00 00 
    db9e:	89 47 04             	mov    DWORD PTR [rdi+0x4],eax
    dba1:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
    dba8:	00 
    dba9:	c7 07 03 00 00 00    	mov    DWORD PTR [rdi],0x3
    dbaf:	8b 7c 24 0c          	mov    edi,DWORD PTR [rsp+0xc]
    dbb3:	48 89 84 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rax
    dbba:	00 
    dbbb:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    dbc0:	89 b4 24 98 01 00 00 	mov    DWORD PTR [rsp+0x198],esi
    dbc7:	48 89 84 24 88 01 00 	mov    QWORD PTR [rsp+0x188],rax
    dbce:	00 
    dbcf:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    dbd4:	89 bc 24 9c 01 00 00 	mov    DWORD PTR [rsp+0x19c],edi
    dbdb:	48 89 84 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rax
    dbe2:	00 
    dbe3:	48 63 c6             	movsxd rax,esi
    dbe6:	48 0f af 44 24 38    	imul   rax,QWORD PTR [rsp+0x38]
    dbec:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
    dbf3:	00 
    dbf4:	48 c7 84 24 60 01 00 	mov    QWORD PTR [rsp+0x160],0x0
    dbfb:	00 00 00 00 00 
    dc00:	c7 84 24 68 01 00 00 	mov    DWORD PTR [rsp+0x168],0x0
    dc07:	00 00 00 00 
    dc0b:	48 3d 3f 42 0f 00    	cmp    rax,0xf423f
    dc11:	0f 9f c2             	setg   dl
    dc14:	81 ff 7f 01 00 00    	cmp    edi,0x17f
    dc1a:	48 8d 3d 4f 28 ff ff 	lea    rdi,[rip+0xffffffffffff284f]        # 470 <relres._omp_fn.0>
    dc21:	0f 9e c0             	setle  al
    dc24:	31 c9                	xor    ecx,ecx
    dc26:	21 c2                	and    edx,eax
    dc28:	83 f2 01             	xor    edx,0x1
    dc2b:	0f b6 d2             	movzx  edx,dl
    dc2e:	e8 00 00 00 00       	call   dc33 <try_secant_tail.constprop.0+0x1833>
    dc33:	db ac 24 70 01 00 00 	fld    TBYTE PTR [rsp+0x170]
    dc3a:	db ac 24 60 01 00 00 	fld    TBYTE PTR [rsp+0x160]
    dc41:	d9 ee                	fldz
    dc43:	df f1                	fcomip st,st(1)
    dc45:	0f 84 c6 00 00 00    	je     dd11 <try_secant_tail.constprop.0+0x1911>
    dc4b:	d9 fa                	fsqrt
    dc4d:	d9 c9                	fxch   st(1)
    dc4f:	48 8b 8c 24 08 01 00 	mov    rcx,QWORD PTR [rsp+0x108]
    dc56:	00 
    dc57:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    dc5e:	00 
    dc5f:	48 85 c9             	test   rcx,rcx
    dc62:	d9 fa                	fsqrt
    dc64:	de f1                	fdivrp st(1),st
    dc66:	dd 58 18             	fstp   QWORD PTR [rax+0x18]
    dc69:	0f 84 bc 01 00 00    	je     de2b <try_secant_tail.constprop.0+0x1a2b>
    dc6f:	8b 54 24 0c          	mov    edx,DWORD PTR [rsp+0xc]
    dc73:	85 d2                	test   edx,edx
    dc75:	0f 8e bd 01 00 00    	jle    de38 <try_secant_tail.constprop.0+0x1a38>
    dc7b:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
    dc7f:	48 8b 94 24 38 01 00 	mov    rdx,QWORD PTR [rsp+0x138]
    dc86:	00 
    dc87:	31 c0                	xor    eax,eax
    dc89:	c5 f9 28 d3          	vmovapd xmm2,xmm3
    dc8d:	c5 fb 10 0c 01       	vmovsd xmm1,QWORD PTR [rcx+rax*1]
    dc92:	c5 fb 10 04 02       	vmovsd xmm0,QWORD PTR [rdx+rax*1]
    dc97:	48 83 c0 08          	add    rax,0x8
    dc9b:	49 39 c4             	cmp    r12,rax
    dc9e:	c5 fb 5c c1          	vsubsd xmm0,xmm0,xmm1
    dca2:	c4 e2 f1 b9 d9       	vfmadd231sd xmm3,xmm1,xmm1
    dca7:	c4 e2 f9 b9 d0       	vfmadd231sd xmm2,xmm0,xmm0
    dcac:	75 df                	jne    dc8d <try_secant_tail.constprop.0+0x188d>
    dcae:	c5 eb 51 d2          	vsqrtsd xmm2,xmm2,xmm2
    dcb2:	c5 e3 51 db          	vsqrtsd xmm3,xmm3,xmm3
    dcb6:	c5 e3 58 1d 00 00 00 	vaddsd xmm3,xmm3,QWORD PTR [rip+0x0]        # dcbe <try_secant_tail.constprop.0+0x18be>
    dcbd:	00 
    dcbe:	c5 eb 5e d3          	vdivsd xmm2,xmm2,xmm3
    dcc2:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    dcc9:	00 
    dcca:	c5 fb 11 50 20       	vmovsd QWORD PTR [rax+0x20],xmm2
    dccf:	48 8b bc 24 30 01 00 	mov    rdi,QWORD PTR [rsp+0x130]
    dcd6:	00 
    dcd7:	41 bd 01 00 00 00    	mov    r13d,0x1
    dcdd:	e8 00 00 00 00       	call   dce2 <try_secant_tail.constprop.0+0x18e2>
    dce2:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
    dce9:	00 
    dcea:	e8 00 00 00 00       	call   dcef <try_secant_tail.constprop.0+0x18ef>
    dcef:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    dcf6:	00 
    dcf7:	e8 00 00 00 00       	call   dcfc <try_secant_tail.constprop.0+0x18fc>
    dcfc:	4c 89 ff             	mov    rdi,r15
    dcff:	e8 00 00 00 00       	call   dd04 <try_secant_tail.constprop.0+0x1904>
    dd04:	48 89 df             	mov    rdi,rbx
    dd07:	e8 00 00 00 00       	call   dd0c <try_secant_tail.constprop.0+0x190c>
    dd0c:	e9 cf e7 ff ff       	jmp    c4e0 <try_secant_tail.constprop.0+0xe0>
    dd11:	dd d8                	fstp   st(0)
    dd13:	d9 e8                	fld1
    dd15:	d9 c9                	fxch   st(1)
    dd17:	e9 33 ff ff ff       	jmp    dc4f <try_secant_tail.constprop.0+0x184f>
    dd1c:	c5 fb 10 15 00 00 00 	vmovsd xmm2,QWORD PTR [rip+0x0]        # dd24 <try_secant_tail.constprop.0+0x1924>
    dd23:	00 
    dd24:	e9 8c ee ff ff       	jmp    cbb5 <try_secant_tail.constprop.0+0x7b5>
    dd29:	dd 05 00 00 00 00    	fld    QWORD PTR [rip+0x0]        # dd2f <try_secant_tail.constprop.0+0x192f>
    dd2f:	d9 ca                	fxch   st(2)
    dd31:	e9 e1 f6 ff ff       	jmp    d417 <try_secant_tail.constprop.0+0x1017>
    dd36:	44 8b 74 24 0c       	mov    r14d,DWORD PTR [rsp+0xc]
    dd3b:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # dd43 <try_secant_tail.constprop.0+0x1943>
    dd42:	00 
    dd43:	8b 4c 24 20          	mov    ecx,DWORD PTR [rsp+0x20]
    dd47:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    dd4c:	4c 8b 8c 24 b0 00 00 	mov    r9,QWORD PTR [rsp+0xb0]
    dd53:	00 
    dd54:	48 8b 94 24 38 01 00 	mov    rdx,QWORD PTR [rsp+0x138]
    dd5b:	00 
    dd5c:	45 89 f0             	mov    r8d,r14d
    dd5f:	48 8b 74 24 30       	mov    rsi,QWORD PTR [rsp+0x30]
    dd64:	e8 e7 28 ff ff       	call   650 <compat_scan_fused>
    dd69:	48 8b 8c 24 08 01 00 	mov    rcx,QWORD PTR [rsp+0x108]
    dd70:	00 
    dd71:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    dd78:	00 
    dd79:	c5 fb 10 84 24 60 01 	vmovsd xmm0,QWORD PTR [rsp+0x160]
    dd80:	00 00 
    dd82:	83 f8 01             	cmp    eax,0x1
    dd85:	19 c0                	sbb    eax,eax
    dd87:	44 89 77 04          	mov    DWORD PTR [rdi+0x4],r14d
    dd8b:	83 e0 fe             	and    eax,0xfffffffe
    dd8e:	c5 fb 11 47 18       	vmovsd QWORD PTR [rdi+0x18],xmm0
    dd93:	83 c0 03             	add    eax,0x3
    dd96:	48 85 c9             	test   rcx,rcx
    dd99:	89 07                	mov    DWORD PTR [rdi],eax
    dd9b:	0f 84 a0 00 00 00    	je     de41 <try_secant_tail.constprop.0+0x1a41>
    dda1:	45 85 f6             	test   r14d,r14d
    dda4:	0f 8e a8 00 00 00    	jle    de52 <try_secant_tail.constprop.0+0x1a52>
    ddaa:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    ddae:	48 8b 94 24 38 01 00 	mov    rdx,QWORD PTR [rsp+0x138]
    ddb5:	00 
    ddb6:	31 c0                	xor    eax,eax
    ddb8:	c5 f9 28 ca          	vmovapd xmm1,xmm2
    ddbc:	c5 fb 10 1c 01       	vmovsd xmm3,QWORD PTR [rcx+rax*1]
    ddc1:	c5 fb 10 04 02       	vmovsd xmm0,QWORD PTR [rdx+rax*1]
    ddc6:	48 83 c0 08          	add    rax,0x8
    ddca:	49 39 c4             	cmp    r12,rax
    ddcd:	c5 fb 5c c3          	vsubsd xmm0,xmm0,xmm3
    ddd1:	c4 e2 e1 b9 d3       	vfmadd231sd xmm2,xmm3,xmm3
    ddd6:	c4 e2 f9 b9 c8       	vfmadd231sd xmm1,xmm0,xmm0
    dddb:	75 df                	jne    ddbc <try_secant_tail.constprop.0+0x19bc>
    dddd:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
    dde1:	c5 eb 51 d2          	vsqrtsd xmm2,xmm2,xmm2
    dde5:	c5 eb 58 15 00 00 00 	vaddsd xmm2,xmm2,QWORD PTR [rip+0x0]        # dded <try_secant_tail.constprop.0+0x19ed>
    ddec:	00 
    dded:	c5 f3 5e ca          	vdivsd xmm1,xmm1,xmm2
    ddf1:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    ddf8:	00 
    ddf9:	c7 40 0c 00 00 00 00 	mov    DWORD PTR [rax+0xc],0x0
    de00:	c5 fb 11 48 20       	vmovsd QWORD PTR [rax+0x20],xmm1
    de05:	e9 c5 fe ff ff       	jmp    dccf <try_secant_tail.constprop.0+0x18cf>
    de0a:	c7 84 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],0x1
    de11:	01 00 00 00 
    de15:	c5 fb 10 0d 00 00 00 	vmovsd xmm1,QWORD PTR [rip+0x0]        # de1d <try_secant_tail.constprop.0+0x1a1d>
    de1c:	00 
    de1d:	e9 e1 eb ff ff       	jmp    ca03 <try_secant_tail.constprop.0+0x603>
    de22:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    de26:	e9 8a ed ff ff       	jmp    cbb5 <try_secant_tail.constprop.0+0x7b5>
    de2b:	c5 fb 10 15 00 00 00 	vmovsd xmm2,QWORD PTR [rip+0x0]        # de33 <try_secant_tail.constprop.0+0x1a33>
    de32:	00 
    de33:	e9 8a fe ff ff       	jmp    dcc2 <try_secant_tail.constprop.0+0x18c2>
    de38:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    de3c:	e9 81 fe ff ff       	jmp    dcc2 <try_secant_tail.constprop.0+0x18c2>
    de41:	c5 fb 10 0d 00 00 00 	vmovsd xmm1,QWORD PTR [rip+0x0]        # de49 <try_secant_tail.constprop.0+0x1a49>
    de48:	00 
    de49:	eb a6                	jmp    ddf1 <try_secant_tail.constprop.0+0x19f1>
    de4b:	d9 e8                	fld1
    de4d:	e9 8c fc ff ff       	jmp    dade <try_secant_tail.constprop.0+0x16de>
    de52:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
    de56:	eb 99                	jmp    ddf1 <try_secant_tail.constprop.0+0x19f1>
    de58:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    de5d:	e8 00 00 00 00       	call   de62 <try_secant_tail.constprop.0+0x1a62>
    de62:	48 8b 7c 24 50       	mov    rdi,QWORD PTR [rsp+0x50]
    de67:	e8 00 00 00 00       	call   de6c <try_secant_tail.constprop.0+0x1a6c>
    de6c:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    de71:	e8 00 00 00 00       	call   de76 <try_secant_tail.constprop.0+0x1a76>
    de76:	4c 89 ff             	mov    rdi,r15
    de79:	e8 00 00 00 00       	call   de7e <try_secant_tail.constprop.0+0x1a7e>
    de7e:	48 89 df             	mov    rdi,rbx
    de81:	e8 00 00 00 00       	call   de86 <try_secant_tail.constprop.0+0x1a86>
    de86:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
    de8b:	e8 40 22 ff ff       	call   d0 <bs_free>
    de90:	e9 45 e6 ff ff       	jmp    c4da <try_secant_tail.constprop.0+0xda>
    de95:	48 89 c2             	mov    rdx,rax
    de98:	e9 00 f6 ff ff       	jmp    d49d <try_secant_tail.constprop.0+0x109d>
    de9d:	48 89 c2             	mov    rdx,rax
    dea0:	e9 7c ed ff ff       	jmp    cc21 <try_secant_tail.constprop.0+0x821>
    dea5:	48 89 c2             	mov    rdx,rax
    dea8:	e9 a8 ed ff ff       	jmp    cc55 <try_secant_tail.constprop.0+0x855>
    dead:	48 89 c2             	mov    rdx,rax
    deb0:	e9 b4 e9 ff ff       	jmp    c869 <try_secant_tail.constprop.0+0x469>
    deb5:	48 89 c1             	mov    rcx,rax
    deb8:	e9 ca f8 ff ff       	jmp    d787 <try_secant_tail.constprop.0+0x1387>
    debd:	e8 00 00 00 00       	call   dec2 <try_secant_tail.constprop.0+0x1ac2>
    dec2:	48 89 c1             	mov    rcx,rax
    dec5:	e9 eb ef ff ff       	jmp    ceb5 <try_secant_tail.constprop.0+0xab5>
