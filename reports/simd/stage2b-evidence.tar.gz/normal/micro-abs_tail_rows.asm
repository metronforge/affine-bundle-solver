
/tmp/abs-stage2b-measured-normal/tail.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000031c00 <abs_tail_rows>:
   31c00:	f3 0f 1e fa          	endbr64
   31c04:	55                   	push   rbp
   31c05:	48 89 e5             	mov    rbp,rsp
   31c08:	41 57                	push   r15
   31c0a:	41 56                	push   r14
   31c0c:	4d 63 f1             	movsxd r14,r9d
   31c0f:	41 55                	push   r13
   31c11:	41 54                	push   r12
   31c13:	49 89 d4             	mov    r12,rdx
   31c16:	53                   	push   rbx
   31c17:	48 89 cb             	mov    rbx,rcx
   31c1a:	48 83 e4 e0          	and    rsp,0xffffffffffffffe0
   31c1e:	48 83 c4 80          	add    rsp,0xffffffffffffff80
   31c22:	48 8b 4d 20          	mov    rcx,QWORD PTR [rbp+0x20]
   31c26:	48 8b 45 18          	mov    rax,QWORD PTR [rbp+0x18]
   31c2a:	48 89 7c 24 70       	mov    QWORD PTR [rsp+0x70],rdi
   31c2f:	4b 8d 3c 36          	lea    rdi,[r14+r14*1]
   31c33:	44 8b 7d 10          	mov    r15d,DWORD PTR [rbp+0x10]
   31c37:	48 89 74 24 50       	mov    QWORD PTR [rsp+0x50],rsi
   31c3c:	be 08 00 00 00       	mov    esi,0x8
   31c41:	48 89 4c 24 78       	mov    QWORD PTR [rsp+0x78],rcx
   31c46:	44 89 44 24 5c       	mov    DWORD PTR [rsp+0x5c],r8d
   31c4b:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
   31c50:	e8 00 00 00 00       	call   31c55 <abs_tail_rows+0x55>
   31c55:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
   31c5a:	48 85 c0             	test   rax,rax
   31c5d:	0f 84 e8 07 00 00    	je     3244b <abs_tail_rows+0x84b>
   31c63:	8b 7c 24 5c          	mov    edi,DWORD PTR [rsp+0x5c]
   31c67:	4d 89 f5             	mov    r13,r14
   31c6a:	49 89 c2             	mov    r10,rax
   31c6d:	85 ff                	test   edi,edi
   31c6f:	0f 84 9b 03 00 00    	je     32010 <abs_tail_rows+0x410>
   31c75:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
   31c79:	31 c0                	xor    eax,eax
   31c7b:	45 85 ff             	test   r15d,r15d
   31c7e:	44 89 f6             	mov    esi,r14d
   31c81:	c5 cb 2a c7          	vcvtsi2sd xmm0,xmm6,edi
   31c85:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
   31c89:	0f 44 c7             	cmove  eax,edi
   31c8c:	41 89 ff             	mov    r15d,edi
   31c8f:	c5 fb 10 35 00 00 00 	vmovsd xmm6,QWORD PTR [rip+0x0]        # 31c97 <abs_tail_rows+0x97>
   31c96:	00 
   31c97:	4c 89 e7             	mov    rdi,r12
   31c9a:	48 89 4c 24 78       	mov    QWORD PTR [rsp+0x78],rcx
   31c9f:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
   31ca3:	c5 cb 5e f0          	vdivsd xmm6,xmm6,xmm0
   31ca7:	c5 fb 11 74 24 08    	vmovsd QWORD PTR [rsp+0x8],xmm6
   31cad:	e8 8e e5 fc ff       	call   240 <norm2>
   31cb2:	48 8b 54 24 68       	mov    rdx,QWORD PTR [rsp+0x68]
   31cb7:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
   31cbc:	48 b8 89 6c 4e ec 98 	movabs rax,0x82efa98ec4e6c89
   31cc3:	fa 2e 08 
   31cc6:	48 bf b9 e5 e4 1c 6d 	movabs rdi,0xbf58476d1ce4e5b9
   31ccd:	47 58 bf 
   31cd0:	48 31 c2             	xor    rdx,rax
   31cd3:	48 b8 15 7c 4a 7f b9 	movabs rax,0x9e3779b97f4a7c15
   31cda:	79 37 9e 
   31cdd:	48 01 d0             	add    rax,rdx
   31ce0:	48 89 c2             	mov    rdx,rax
   31ce3:	48 c1 ea 1e          	shr    rdx,0x1e
   31ce7:	48 31 d0             	xor    rax,rdx
   31cea:	48 0f af c7          	imul   rax,rdi
   31cee:	48 89 c2             	mov    rdx,rax
   31cf1:	48 c1 ea 1b          	shr    rdx,0x1b
   31cf5:	48 31 c2             	xor    rdx,rax
   31cf8:	48 b8 eb 11 31 13 bb 	movabs rax,0x94d049bb133111eb
   31cff:	49 d0 94 
   31d02:	48 0f af d0          	imul   rdx,rax
   31d06:	48 89 d0             	mov    rax,rdx
   31d09:	48 c1 e8 1f          	shr    rax,0x1f
   31d0d:	48 31 d0             	xor    rax,rdx
   31d10:	45 85 ff             	test   r15d,r15d
   31d13:	0f 8e f7 02 00 00    	jle    32010 <abs_tail_rows+0x410>
   31d19:	48 ba 00 8e 7b 92 74 	movabs rdx,0x3307c374927b8e00
   31d20:	c3 07 33 
   31d23:	45 31 db             	xor    r11d,r11d
   31d26:	45 31 c9             	xor    r9d,r9d
   31d29:	c7 44 24 38 00 00 00 	mov    DWORD PTR [rsp+0x38],0x0
   31d30:	00 
   31d31:	48 8d 3c 10          	lea    rdi,[rax+rdx*1]
   31d35:	48 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],rcx
   31d3a:	48 ba ce 61 2f 9c 26 	movabs rdx,0x5d8fc1269c2f61ce
   31d41:	c1 8f 5d 
   31d44:	c5 fb 58 3d 00 00 00 	vaddsd xmm7,xmm0,QWORD PTR [rip+0x0]        # 31d4c <abs_tail_rows+0x14c>
   31d4b:	00 
   31d4c:	4c 8d 3c 10          	lea    r15,[rax+rdx*1]
   31d50:	41 8d 46 ff          	lea    eax,[r14-0x1]
   31d54:	48 89 7c 24 68       	mov    QWORD PTR [rsp+0x68],rdi
   31d59:	89 44 24 58          	mov    DWORD PTR [rsp+0x58],eax
   31d5d:	4a 8d 04 f5 00 00 00 	lea    rax,[r14*8+0x0]
   31d64:	00 
   31d65:	4c 8d 04 03          	lea    r8,[rbx+rax*1]
   31d69:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
   31d6e:	4c 89 f8             	mov    rax,r15
   31d71:	4d 89 f7             	mov    r15,r14
   31d74:	48 c7 44 24 30 00 00 	mov    QWORD PTR [rsp+0x30],0x0
   31d7b:	00 00 
   31d7d:	49 89 c6             	mov    r14,rax
   31d80:	48 c7 44 24 28 00 00 	mov    QWORD PTR [rsp+0x28],0x0
   31d87:	00 00 
   31d89:	4c 89 44 24 78       	mov    QWORD PTR [rsp+0x78],r8
   31d8e:	c5 fb 11 7c 24 20    	vmovsd QWORD PTR [rsp+0x20],xmm7
   31d94:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   31d98:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   31d9d:	45 85 ed             	test   r13d,r13d
   31da0:	4a 8d 3c d8          	lea    rdi,[rax+r11*8]
   31da4:	0f 8e 76 03 00 00    	jle    32120 <abs_tail_rows+0x520>
   31daa:	83 7c 24 58 02       	cmp    DWORD PTR [rsp+0x58],0x2
   31daf:	0f 86 f3 05 00 00    	jbe    323a8 <abs_tail_rows+0x7a8>
   31db5:	44 89 ea             	mov    edx,r13d
   31db8:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
   31dbc:	4c 8b 44 24 78       	mov    r8,QWORD PTR [rsp+0x78]
   31dc1:	31 c0                	xor    eax,eax
   31dc3:	c5 fd 28 dc          	vmovapd ymm3,ymm4
   31dc7:	c1 ea 02             	shr    edx,0x2
   31dca:	c5 fd 28 cc          	vmovapd ymm1,ymm4
   31dce:	c5 fd 28 d4          	vmovapd ymm2,ymm4
   31dd2:	48 c1 e2 05          	shl    rdx,0x5
   31dd6:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
   31ddd:	00 00 
   31ddf:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   31de6:	00 00 00 00 
   31dea:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   31df1:	00 00 00 00 
   31df5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   31dfc:	00 00 00 00 
   31e00:	c5 fd 10 04 07       	vmovupd ymm0,YMMWORD PTR [rdi+rax*1]
   31e05:	c4 c2 fd b8 1c 04    	vfmadd231pd ymm3,ymm0,YMMWORD PTR [r12+rax*1]
   31e0b:	c4 e2 fd b8 0c 03    	vfmadd231pd ymm1,ymm0,YMMWORD PTR [rbx+rax*1]
   31e11:	c4 c2 fd b8 14 00    	vfmadd231pd ymm2,ymm0,YMMWORD PTR [r8+rax*1]
   31e17:	48 83 c0 20          	add    rax,0x20
   31e1b:	48 39 c2             	cmp    rdx,rax
   31e1e:	c4 e2 fd b8 e0       	vfmadd231pd ymm4,ymm0,ymm0
   31e23:	75 db                	jne    31e00 <abs_tail_rows+0x200>
   31e25:	c4 e3 7d 19 d6 01    	vextractf128 xmm6,ymm2,0x1
   31e2b:	c4 e3 7d 19 e5 01    	vextractf128 xmm5,ymm4,0x1
   31e31:	44 89 e8             	mov    eax,r13d
   31e34:	4c 89 44 24 78       	mov    QWORD PTR [rsp+0x78],r8
   31e39:	c5 c9 58 f2          	vaddpd xmm6,xmm6,xmm2
   31e3d:	c4 e3 7d 19 ca 01    	vextractf128 xmm2,ymm1,0x1
   31e43:	c5 d1 58 ec          	vaddpd xmm5,xmm5,xmm4
   31e47:	83 e0 fc             	and    eax,0xfffffffc
   31e4a:	c5 e9 58 d1          	vaddpd xmm2,xmm2,xmm1
   31e4e:	c4 e3 7d 19 dc 01    	vextractf128 xmm4,ymm3,0x1
   31e54:	41 39 c5             	cmp    r13d,eax
   31e57:	89 c2                	mov    edx,eax
   31e59:	c5 d9 58 db          	vaddpd xmm3,xmm4,xmm3
   31e5d:	c5 49 15 c6          	vunpckhpd xmm8,xmm6,xmm6
   31e61:	c5 d1 15 c5          	vunpckhpd xmm0,xmm5,xmm5
   31e65:	c5 e9 15 fa          	vunpckhpd xmm7,xmm2,xmm2
   31e69:	c5 39 58 c6          	vaddpd xmm8,xmm8,xmm6
   31e6d:	c5 f9 58 c5          	vaddpd xmm0,xmm0,xmm5
   31e71:	c5 c1 58 fa          	vaddpd xmm7,xmm7,xmm2
   31e75:	c5 e1 15 e3          	vunpckhpd xmm4,xmm3,xmm3
   31e79:	c5 d9 58 e3          	vaddpd xmm4,xmm4,xmm3
   31e7d:	c5 b9 14 ff          	vunpcklpd xmm7,xmm8,xmm7
   31e81:	0f 84 97 00 00 00    	je     31f1e <abs_tail_rows+0x31e>
   31e87:	44 89 e9             	mov    ecx,r13d
   31e8a:	29 d1                	sub    ecx,edx
   31e8c:	83 f9 01             	cmp    ecx,0x1
   31e8f:	74 62                	je     31ef3 <abs_tail_rows+0x2f3>
   31e91:	49 8d 34 17          	lea    rsi,[r15+rdx*1]
   31e95:	4c 8b 44 24 70       	mov    r8,QWORD PTR [rsp+0x70]
   31e9a:	f6 c1 01             	test   cl,0x1
   31e9d:	48 89 74 24 60       	mov    QWORD PTR [rsp+0x60],rsi
   31ea2:	49 8d 34 13          	lea    rsi,[r11+rdx*1]
   31ea6:	c4 c1 79 10 04 f0    	vmovupd xmm0,XMMWORD PTR [r8+rsi*8]
   31eac:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
   31eb1:	c4 c2 f9 b8 1c d4    	vfmadd231pd xmm3,xmm0,XMMWORD PTR [r12+rdx*8]
   31eb7:	c4 e2 f9 b8 14 d3    	vfmadd231pd xmm2,xmm0,XMMWORD PTR [rbx+rdx*8]
   31ebd:	c4 e2 f9 b8 34 f3    	vfmadd231pd xmm6,xmm0,XMMWORD PTR [rbx+rsi*8]
   31ec3:	c4 e2 f9 b8 e8       	vfmadd231pd xmm5,xmm0,xmm0
   31ec8:	c5 e1 15 e3          	vunpckhpd xmm4,xmm3,xmm3
   31ecc:	c5 d9 58 e3          	vaddpd xmm4,xmm4,xmm3
   31ed0:	c5 c9 15 ce          	vunpckhpd xmm1,xmm6,xmm6
   31ed4:	c5 e9 15 da          	vunpckhpd xmm3,xmm2,xmm2
   31ed8:	c5 f1 58 ce          	vaddpd xmm1,xmm1,xmm6
   31edc:	c5 e1 58 d2          	vaddpd xmm2,xmm3,xmm2
   31ee0:	c5 d1 15 c5          	vunpckhpd xmm0,xmm5,xmm5
   31ee4:	c5 f9 58 c5          	vaddpd xmm0,xmm0,xmm5
   31ee8:	c5 f1 14 fa          	vunpcklpd xmm7,xmm1,xmm2
   31eec:	74 30                	je     31f1e <abs_tail_rows+0x31e>
   31eee:	83 e1 fe             	and    ecx,0xfffffffe
   31ef1:	01 c8                	add    eax,ecx
   31ef3:	48 63 d0             	movsxd rdx,eax
   31ef6:	44 01 e8             	add    eax,r13d
   31ef9:	c5 fb 10 14 d7       	vmovsd xmm2,QWORD PTR [rdi+rdx*8]
   31efe:	48 98                	cdqe
   31f00:	c4 c2 e9 b9 24 d4    	vfmadd231sd xmm4,xmm2,QWORD PTR [r12+rdx*8]
   31f06:	c5 fb 12 da          	vmovddup xmm3,xmm2
   31f0a:	c4 e2 e9 b9 c2       	vfmadd231sd xmm0,xmm2,xmm2
   31f0f:	c5 fb 10 14 c3       	vmovsd xmm2,QWORD PTR [rbx+rax*8]
   31f14:	c5 e9 16 14 d3       	vmovhpd xmm2,xmm2,QWORD PTR [rbx+rdx*8]
   31f19:	c4 e2 e9 b8 fb       	vfmadd231pd xmm7,xmm2,xmm3
   31f1e:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
   31f22:	c5 f9 2f c2          	vcomisd xmm0,xmm2
   31f26:	0f 86 04 02 00 00    	jbe    32130 <abs_tail_rows+0x530>
   31f2c:	48 b8 00 00 00 00 00 	movabs rax,0x7ff0000000000000
   31f33:	00 f0 7f 
   31f36:	c4 e1 f9 7e c1       	vmovq  rcx,xmm0
   31f3b:	c4 e2 f0 f2 c0       	andn   rax,rcx,rax
   31f40:	0f 84 ea 01 00 00    	je     32130 <abs_tail_rows+0x530>
   31f46:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
   31f4a:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # 31f52 <abs_tail_rows+0x352>
   31f51:	00 
   31f52:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
   31f57:	44 39 4c 24 3c       	cmp    DWORD PTR [rsp+0x3c],r9d
   31f5c:	c5 c1 54 35 00 00 00 	vandpd xmm6,xmm7,XMMWORD PTR [rip+0x0]        # 31f64 <abs_tail_rows+0x364>
   31f63:	00 
   31f64:	c5 d3 5e c0          	vdivsd xmm0,xmm5,xmm0
   31f68:	c4 a1 7b 10 1c c8    	vmovsd xmm3,QWORD PTR [rax+r9*8]
   31f6e:	41 8d 41 01          	lea    eax,[r9+0x1]
   31f72:	c5 e3 59 e8          	vmulsd xmm5,xmm3,xmm0
   31f76:	0f 8e 24 02 00 00    	jle    321a0 <abs_tail_rows+0x5a0>
   31f7c:	c5 c9 15 ce          	vunpckhpd xmm1,xmm6,xmm6
   31f80:	c5 f1 5f ce          	vmaxpd xmm1,xmm1,xmm6
   31f84:	c5 f3 59 c8          	vmulsd xmm1,xmm1,xmm0
   31f88:	c5 f9 2f 0d 00 00 00 	vcomisd xmm1,QWORD PTR [rip+0x0]        # 31f90 <abs_tail_rows+0x390>
   31f8f:	00 
   31f90:	77 2c                	ja     31fbe <abs_tail_rows+0x3be>
   31f92:	c5 e3 5c dc          	vsubsd xmm3,xmm3,xmm4
   31f96:	c5 e3 59 d8          	vmulsd xmm3,xmm3,xmm0
   31f9a:	c5 d1 54 05 00 00 00 	vandpd xmm0,xmm5,XMMWORD PTR [rip+0x0]        # 31fa2 <abs_tail_rows+0x3a2>
   31fa1:	00 
   31fa2:	c5 fb 58 44 24 20    	vaddsd xmm0,xmm0,QWORD PTR [rsp+0x20]
   31fa8:	c5 fb 59 05 00 00 00 	vmulsd xmm0,xmm0,QWORD PTR [rip+0x0]        # 31fb0 <abs_tail_rows+0x3b0>
   31faf:	00 
   31fb0:	c5 e1 54 1d 00 00 00 	vandpd xmm3,xmm3,XMMWORD PTR [rip+0x0]        # 31fb8 <abs_tail_rows+0x3b8>
   31fb7:	00 
   31fb8:	c5 f9 2f d8          	vcomisd xmm3,xmm0
   31fbc:	76 05                	jbe    31fc3 <abs_tail_rows+0x3c3>
   31fbe:	83 44 24 38 01       	add    DWORD PTR [rsp+0x38],0x1
   31fc3:	48 be b9 e5 e4 1c 6d 	movabs rsi,0xbf58476d1ce4e5b9
   31fca:	47 58 bf 
   31fcd:	49 83 c1 01          	add    r9,0x1
   31fd1:	4d 01 fb             	add    r11,r15
   31fd4:	48 b9 eb 11 31 13 bb 	movabs rcx,0x94d049bb133111eb
   31fdb:	49 d0 94 
   31fde:	49 01 f6             	add    r14,rsi
   31fe1:	48 01 4c 24 68       	add    QWORD PTR [rsp+0x68],rcx
   31fe6:	39 44 24 5c          	cmp    DWORD PTR [rsp+0x5c],eax
   31fea:	0f 8f a8 fd ff ff    	jg     31d98 <abs_tail_rows+0x198>
   31ff0:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
   31ff4:	c5 fb 10 6c 24 28    	vmovsd xmm5,QWORD PTR [rsp+0x28]
   31ffa:	c5 c3 2a 44 24 38    	vcvtsi2sd xmm0,xmm7,DWORD PTR [rsp+0x38]
   32000:	4d 89 fe             	mov    r14,r15
   32003:	48 8b 4c 24 10       	mov    rcx,QWORD PTR [rsp+0x10]
   32008:	c5 f9 16 44 24 30    	vmovhpd xmm0,xmm0,QWORD PTR [rsp+0x30]
   3200e:	eb 08                	jmp    32018 <abs_tail_rows+0x418>
   32010:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   32014:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
   32018:	45 85 ed             	test   r13d,r13d
   3201b:	48 c7 41 18 00 00 00 	mov    QWORD PTR [rcx+0x18],0x0
   32022:	00 
   32023:	48 c7 41 20 00 00 00 	mov    QWORD PTR [rcx+0x20],0x0
   3202a:	00 
   3202b:	c5 f9 11 01          	vmovupd XMMWORD PTR [rcx],xmm0
   3202f:	c5 fb 11 69 10       	vmovsd QWORD PTR [rcx+0x10],xmm5
   32034:	0f 8e cb 00 00 00    	jle    32105 <abs_tail_rows+0x505>
   3203a:	41 8d 45 ff          	lea    eax,[r13-0x1]
   3203e:	83 f8 02             	cmp    eax,0x2
   32041:	0f 86 ed 03 00 00    	jbe    32434 <abs_tail_rows+0x834>
   32047:	44 89 ea             	mov    edx,r13d
   3204a:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   3204e:	4b 8d 34 f2          	lea    rsi,[r10+r14*8]
   32052:	31 c0                	xor    eax,eax
   32054:	c1 ea 02             	shr    edx,0x2
   32057:	c5 fd 28 c1          	vmovapd ymm0,ymm1
   3205b:	48 c1 e2 05          	shl    rdx,0x5
   3205f:	90                   	nop
   32060:	c4 c1 75 58 0c 02    	vaddpd ymm1,ymm1,YMMWORD PTR [r10+rax*1]
   32066:	c5 fd 58 04 06       	vaddpd ymm0,ymm0,YMMWORD PTR [rsi+rax*1]
   3206b:	48 83 c0 20          	add    rax,0x20
   3206f:	48 39 c2             	cmp    rdx,rax
   32072:	75 ec                	jne    32060 <abs_tail_rows+0x460>
   32074:	c4 e3 7d 19 ca 01    	vextractf128 xmm2,ymm1,0x1
   3207a:	41 f6 c5 03          	test   r13b,0x3
   3207e:	c5 e9 58 d1          	vaddpd xmm2,xmm2,xmm1
   32082:	c5 e9 15 ca          	vunpckhpd xmm1,xmm2,xmm2
   32086:	c5 f1 58 ca          	vaddpd xmm1,xmm1,xmm2
   3208a:	c4 e3 7d 19 c2 01    	vextractf128 xmm2,ymm0,0x1
   32090:	c5 e9 58 d0          	vaddpd xmm2,xmm2,xmm0
   32094:	c5 e9 15 c2          	vunpckhpd xmm0,xmm2,xmm2
   32098:	c5 f9 58 c2          	vaddpd xmm0,xmm0,xmm2
   3209c:	c5 f1 14 c0          	vunpcklpd xmm0,xmm1,xmm0
   320a0:	74 5e                	je     32100 <abs_tail_rows+0x500>
   320a2:	44 89 e8             	mov    eax,r13d
   320a5:	83 e0 fc             	and    eax,0xfffffffc
   320a8:	41 8d 54 05 00       	lea    edx,[r13+rax*1+0x0]
   320ad:	48 63 f0             	movsxd rsi,eax
   320b0:	48 63 d2             	movsxd rdx,edx
   320b3:	c4 c1 7b 10 0c f2    	vmovsd xmm1,QWORD PTR [r10+rsi*8]
   320b9:	c4 c1 71 16 0c d2    	vmovhpd xmm1,xmm1,QWORD PTR [r10+rdx*8]
   320bf:	8d 50 01             	lea    edx,[rax+0x1]
   320c2:	c5 f9 58 c1          	vaddpd xmm0,xmm0,xmm1
   320c6:	41 39 d5             	cmp    r13d,edx
   320c9:	7e 35                	jle    32100 <abs_tail_rows+0x500>
   320cb:	44 01 ea             	add    edx,r13d
   320ce:	83 c0 02             	add    eax,0x2
   320d1:	c4 c1 7b 10 4c f2 08 	vmovsd xmm1,QWORD PTR [r10+rsi*8+0x8]
   320d8:	48 63 d2             	movsxd rdx,edx
   320db:	44 39 e8             	cmp    eax,r13d
   320de:	c4 c1 71 16 0c d2    	vmovhpd xmm1,xmm1,QWORD PTR [r10+rdx*8]
   320e4:	c5 f9 58 c1          	vaddpd xmm0,xmm0,xmm1
   320e8:	7d 16                	jge    32100 <abs_tail_rows+0x500>
   320ea:	44 01 e8             	add    eax,r13d
   320ed:	c4 c1 7b 10 4c f2 10 	vmovsd xmm1,QWORD PTR [r10+rsi*8+0x10]
   320f4:	48 98                	cdqe
   320f6:	c4 c1 71 16 0c c2    	vmovhpd xmm1,xmm1,QWORD PTR [r10+rax*8]
   320fc:	c5 f9 58 c1          	vaddpd xmm0,xmm0,xmm1
   32100:	c5 f9 11 41 18       	vmovupd XMMWORD PTR [rcx+0x18],xmm0
   32105:	c5 f8 77             	vzeroupper
   32108:	48 8d 65 d8          	lea    rsp,[rbp-0x28]
   3210c:	4c 89 d7             	mov    rdi,r10
   3210f:	5b                   	pop    rbx
   32110:	41 5c                	pop    r12
   32112:	41 5d                	pop    r13
   32114:	41 5e                	pop    r14
   32116:	41 5f                	pop    r15
   32118:	5d                   	pop    rbp
   32119:	e9 00 00 00 00       	jmp    3211e <abs_tail_rows+0x51e>
   3211e:	66 90                	xchg   ax,ax
   32120:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
   32124:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
   32128:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
   3212f:	00 
   32130:	c5 f9 29 7c 24 40    	vmovapd XMMWORD PTR [rsp+0x40],xmm7
   32136:	44 89 ee             	mov    esi,r13d
   32139:	c5 fb 11 64 24 60    	vmovsd QWORD PTR [rsp+0x60],xmm4
   3213f:	c5 f8 77             	vzeroupper
   32142:	e8 f9 e0 fc ff       	call   240 <norm2>
   32147:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
   3214b:	c5 fb 10 64 24 60    	vmovsd xmm4,QWORD PTR [rsp+0x60]
   32151:	c5 f9 2f c2          	vcomisd xmm0,xmm2
   32155:	c5 f9 28 7c 24 40    	vmovapd xmm7,XMMWORD PTR [rsp+0x40]
   3215b:	0f 85 e9 fd ff ff    	jne    31f4a <abs_tail_rows+0x34a>
   32161:	48 8b 7c 24 50       	mov    rdi,QWORD PTR [rsp+0x50]
   32166:	41 8d 41 01          	lea    eax,[r9+0x1]
   3216a:	c4 a1 7b 10 04 cf    	vmovsd xmm0,QWORD PTR [rdi+r9*8]
   32170:	c5 f9 54 05 00 00 00 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x0]        # 32178 <abs_tail_rows+0x578>
   32177:	00 
   32178:	c5 f9 2f 05 00 00 00 	vcomisd xmm0,QWORD PTR [rip+0x0]        # 32180 <abs_tail_rows+0x580>
   3217f:	00 
   32180:	0f 87 38 fe ff ff    	ja     31fbe <abs_tail_rows+0x3be>
   32186:	8b 7c 24 3c          	mov    edi,DWORD PTR [rsp+0x3c]
   3218a:	44 39 cf             	cmp    edi,r9d
   3218d:	0f 4e f8             	cmovle edi,eax
   32190:	89 7c 24 3c          	mov    DWORD PTR [rsp+0x3c],edi
   32194:	e9 2a fe ff ff       	jmp    31fc3 <abs_tail_rows+0x3c3>
   32199:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   321a0:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
   321a5:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
   321a9:	49 b8 eb 11 31 13 bb 	movabs r8,0x94d049bb133111eb
   321b0:	49 d0 94 
   321b3:	c5 fb 10 15 00 00 00 	vmovsd xmm2,QWORD PTR [rip+0x0]        # 321bb <abs_tail_rows+0x5bb>
   321ba:	00 
   321bb:	c5 7b 10 6c 24 08    	vmovsd xmm13,QWORD PTR [rsp+0x8]
   321c1:	48 89 f1             	mov    rcx,rsi
   321c4:	48 c1 e9 1e          	shr    rcx,0x1e
   321c8:	48 31 f1             	xor    rcx,rsi
   321cb:	48 be b9 e5 e4 1c 6d 	movabs rsi,0xbf58476d1ce4e5b9
   321d2:	47 58 bf 
   321d5:	48 0f af ce          	imul   rcx,rsi
   321d9:	48 89 ca             	mov    rdx,rcx
   321dc:	48 c1 ea 1b          	shr    rdx,0x1b
   321e0:	48 31 ca             	xor    rdx,rcx
   321e3:	49 0f af d0          	imul   rdx,r8
   321e7:	48 89 d1             	mov    rcx,rdx
   321ea:	48 c1 e9 1f          	shr    rcx,0x1f
   321ee:	48 31 d1             	xor    rcx,rdx
   321f1:	48 c1 e9 0b          	shr    rcx,0xb
   321f5:	c4 e1 c3 2a c9       	vcvtsi2sd xmm1,xmm7,rcx
   321fa:	4c 89 f1             	mov    rcx,r14
   321fd:	c4 e2 e9 99 0d 00 00 	vfmadd132sd xmm1,xmm2,QWORD PTR [rip+0x0]        # 32206 <abs_tail_rows+0x606>
   32204:	00 00 
   32206:	48 c1 e9 1e          	shr    rcx,0x1e
   3220a:	4c 31 f1             	xor    rcx,r14
   3220d:	48 0f af ce          	imul   rcx,rsi
   32211:	c4 c1 73 59 cd       	vmulsd xmm1,xmm1,xmm13
   32216:	48 89 ca             	mov    rdx,rcx
   32219:	48 c1 ea 1b          	shr    rdx,0x1b
   3221d:	48 31 ca             	xor    rdx,rcx
   32220:	49 0f af d0          	imul   rdx,r8
   32224:	48 89 d1             	mov    rcx,rdx
   32227:	48 c1 e9 1f          	shr    rcx,0x1f
   3222b:	48 31 d1             	xor    rcx,rdx
   3222e:	48 c1 e9 0b          	shr    rcx,0xb
   32232:	45 85 ed             	test   r13d,r13d
   32235:	c4 e1 c3 2a d1       	vcvtsi2sd xmm2,xmm7,rcx
   3223a:	c5 f9 28 fa          	vmovapd xmm7,xmm2
   3223e:	c5 fb 10 15 00 00 00 	vmovsd xmm2,QWORD PTR [rip+0x0]        # 32246 <abs_tail_rows+0x646>
   32245:	00 
   32246:	c4 e2 e9 99 3d 00 00 	vfmadd132sd xmm7,xmm2,QWORD PTR [rip+0x0]        # 3224f <abs_tail_rows+0x64f>
   3224d:	00 00 
   3224f:	c4 c1 43 59 fd       	vmulsd xmm7,xmm7,xmm13
   32254:	0f 8e 2b 01 00 00    	jle    32385 <abs_tail_rows+0x785>
   3225a:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
   3225f:	c5 7b 59 d1          	vmulsd xmm10,xmm0,xmm1
   32263:	41 83 fd 01          	cmp    r13d,0x1
   32267:	c5 7b 59 df          	vmulsd xmm11,xmm0,xmm7
   3226b:	49 8d 0c 32          	lea    rcx,[r10+rsi*1]
   3226f:	0f 84 58 01 00 00    	je     323cd <abs_tail_rows+0x7cd>
   32275:	49 8d 52 20          	lea    rdx,[r10+0x20]
   32279:	48 39 d1             	cmp    rcx,rdx
   3227c:	0f 82 4b 01 00 00    	jb     323cd <abs_tail_rows+0x7cd>
   32282:	83 7c 24 58 02       	cmp    DWORD PTR [rsp+0x58],0x2
   32287:	0f 86 b2 01 00 00    	jbe    3243f <abs_tail_rows+0x83f>
   3228d:	44 89 ee             	mov    esi,r13d
   32290:	4c 8b 44 24 78       	mov    r8,QWORD PTR [rsp+0x78]
   32295:	c4 42 7d 19 ca       	vbroadcastsd ymm9,xmm10
   3229a:	31 d2                	xor    edx,edx
   3229c:	c1 ee 02             	shr    esi,0x2
   3229f:	c4 42 7d 19 c3       	vbroadcastsd ymm8,xmm11
   322a4:	48 c1 e6 05          	shl    rsi,0x5
   322a8:	66 90                	xchg   ax,ax
   322aa:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   322b1:	00 00 00 00 
   322b5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   322bc:	00 00 00 00 
   322c0:	c5 fd 10 14 17       	vmovupd ymm2,YMMWORD PTR [rdi+rdx*1]
   322c5:	c5 7d 28 e2          	vmovapd ymm12,ymm2
   322c9:	c4 42 b5 a8 24 12    	vfmadd213pd ymm12,ymm9,YMMWORD PTR [r10+rdx*1]
   322cf:	c4 41 7d 11 24 12    	vmovupd YMMWORD PTR [r10+rdx*1],ymm12
   322d5:	c4 e2 bd a8 14 11    	vfmadd213pd ymm2,ymm8,YMMWORD PTR [rcx+rdx*1]
   322db:	c5 fd 11 14 11       	vmovupd YMMWORD PTR [rcx+rdx*1],ymm2
   322e0:	48 83 c2 20          	add    rdx,0x20
   322e4:	48 39 d6             	cmp    rsi,rdx
   322e7:	75 d7                	jne    322c0 <abs_tail_rows+0x6c0>
   322e9:	44 89 ea             	mov    edx,r13d
   322ec:	4c 89 44 24 78       	mov    QWORD PTR [rsp+0x78],r8
   322f1:	83 e2 fc             	and    edx,0xfffffffc
   322f4:	44 39 ea             	cmp    edx,r13d
   322f7:	89 d1                	mov    ecx,edx
   322f9:	0f 84 86 00 00 00    	je     32385 <abs_tail_rows+0x785>
   322ff:	44 89 ee             	mov    esi,r13d
   32302:	29 d6                	sub    esi,edx
   32304:	83 fe 01             	cmp    esi,0x1
   32307:	74 56                	je     3235f <abs_tail_rows+0x75f>
   32309:	4d 8d 04 ca          	lea    r8,[r10+rcx*8]
   3230d:	c4 41 7b 12 ca       	vmovddup xmm9,xmm10
   32312:	c4 41 7b 12 c3       	vmovddup xmm8,xmm11
   32317:	4c 89 44 24 60       	mov    QWORD PTR [rsp+0x60],r8
   3231c:	4d 8d 04 0f          	lea    r8,[r15+rcx*1]
   32320:	4c 01 d9             	add    rcx,r11
   32323:	40 f6 c6 01          	test   sil,0x1
   32327:	4f 8d 04 c2          	lea    r8,[r10+r8*8]
   3232b:	4c 89 44 24 40       	mov    QWORD PTR [rsp+0x40],r8
   32330:	4c 8b 44 24 70       	mov    r8,QWORD PTR [rsp+0x70]
   32335:	c4 c1 79 10 14 c8    	vmovupd xmm2,XMMWORD PTR [r8+rcx*8]
   3233b:	4c 8b 44 24 60       	mov    r8,QWORD PTR [rsp+0x60]
   32340:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
   32345:	c4 42 e9 a8 08       	vfmadd213pd xmm9,xmm2,XMMWORD PTR [r8]
   3234a:	c4 41 79 11 08       	vmovupd XMMWORD PTR [r8],xmm9
   3234f:	c4 e2 b9 a8 11       	vfmadd213pd xmm2,xmm8,XMMWORD PTR [rcx]
   32354:	c5 f9 11 11          	vmovupd XMMWORD PTR [rcx],xmm2
   32358:	74 2b                	je     32385 <abs_tail_rows+0x785>
   3235a:	83 e6 fe             	and    esi,0xfffffffe
   3235d:	01 f2                	add    edx,esi
   3235f:	48 63 ca             	movsxd rcx,edx
   32362:	44 01 ea             	add    edx,r13d
   32365:	c5 fb 10 14 cf       	vmovsd xmm2,QWORD PTR [rdi+rcx*8]
   3236a:	c4 42 e9 a9 14 ca    	vfmadd213sd xmm10,xmm2,QWORD PTR [r10+rcx*8]
   32370:	48 63 d2             	movsxd rdx,edx
   32373:	c4 41 7b 11 14 ca    	vmovsd QWORD PTR [r10+rcx*8],xmm10
   32379:	c4 c2 a1 a9 14 d2    	vfmadd213sd xmm2,xmm11,QWORD PTR [r10+rdx*8]
   3237f:	c4 c1 7b 11 14 d2    	vmovsd QWORD PTR [r10+rdx*8],xmm2
   32385:	c4 e2 d1 a9 4c 24 30 	vfmadd213sd xmm1,xmm5,QWORD PTR [rsp+0x30]
   3238c:	c4 e2 d1 a9 7c 24 28 	vfmadd213sd xmm7,xmm5,QWORD PTR [rsp+0x28]
   32393:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
   32397:	c5 fb 11 4c 24 30    	vmovsd QWORD PTR [rsp+0x30],xmm1
   3239d:	c5 fb 11 7c 24 28    	vmovsd QWORD PTR [rsp+0x28],xmm7
   323a3:	e9 d4 fb ff ff       	jmp    31f7c <abs_tail_rows+0x37c>
   323a8:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
   323ac:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
   323b0:	31 d2                	xor    edx,edx
   323b2:	31 c0                	xor    eax,eax
   323b4:	c5 f9 28 ef          	vmovapd xmm5,xmm7
   323b8:	c5 f9 28 df          	vmovapd xmm3,xmm7
   323bc:	c5 f9 28 d7          	vmovapd xmm2,xmm7
   323c0:	c5 f9 28 f7          	vmovapd xmm6,xmm7
   323c4:	c5 f9 28 c4          	vmovapd xmm0,xmm4
   323c8:	e9 ba fa ff ff       	jmp    31e87 <abs_tail_rows+0x287>
   323cd:	4c 8b 44 24 78       	mov    r8,QWORD PTR [rsp+0x78]
   323d2:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
   323d7:	31 d2                	xor    edx,edx
   323d9:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   323df:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   323e6:	00 00 00 00 
   323ea:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   323f1:	00 00 00 00 
   323f5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   323fc:	00 00 00 00 
   32400:	c5 fb 10 14 17       	vmovsd xmm2,QWORD PTR [rdi+rdx*1]
   32405:	c4 41 79 28 c2       	vmovapd xmm8,xmm10
   3240a:	c4 42 e9 a9 04 12    	vfmadd213sd xmm8,xmm2,QWORD PTR [r10+rdx*1]
   32410:	c4 41 7b 11 04 12    	vmovsd QWORD PTR [r10+rdx*1],xmm8
   32416:	c4 e2 a1 a9 14 11    	vfmadd213sd xmm2,xmm11,QWORD PTR [rcx+rdx*1]
   3241c:	c5 fb 11 14 11       	vmovsd QWORD PTR [rcx+rdx*1],xmm2
   32421:	48 83 c2 08          	add    rdx,0x8
   32425:	48 39 d6             	cmp    rsi,rdx
   32428:	75 d6                	jne    32400 <abs_tail_rows+0x800>
   3242a:	4c 89 44 24 78       	mov    QWORD PTR [rsp+0x78],r8
   3242f:	e9 51 ff ff ff       	jmp    32385 <abs_tail_rows+0x785>
   32434:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   32438:	31 c0                	xor    eax,eax
   3243a:	e9 69 fc ff ff       	jmp    320a8 <abs_tail_rows+0x4a8>
   3243f:	44 89 ee             	mov    esi,r13d
   32442:	31 d2                	xor    edx,edx
   32444:	31 c9                	xor    ecx,ecx
   32446:	e9 be fe ff ff       	jmp    32309 <abs_tail_rows+0x709>
   3244b:	48 8b 05 00 00 00 00 	mov    rax,QWORD PTR [rip+0x0]        # 32452 <abs_tail_rows+0x852>
   32452:	48 89 01             	mov    QWORD PTR [rcx],rax
   32455:	48 8d 65 d8          	lea    rsp,[rbp-0x28]
   32459:	5b                   	pop    rbx
   3245a:	41 5c                	pop    r12
   3245c:	41 5d                	pop    r13
   3245e:	41 5e                	pop    r14
   32460:	41 5f                	pop    r15
   32462:	5d                   	pop    rbp
   32463:	c3                   	ret
