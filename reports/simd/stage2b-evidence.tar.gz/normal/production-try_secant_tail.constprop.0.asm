/tmp/abs-stage2b-measured-normal/CMakeFiles/abs_router_obj.dir/src/bsolver.c.o:     file format elf64-x86-64


Disassembly of section .text:

000000000000fc30 <try_secant_tail.constprop.0>:
    fc30:	4c 8d 54 24 08       	lea    r10,[rsp+0x8]
    fc35:	48 83 e4 e0          	and    rsp,0xffffffffffffffe0
    fc39:	41 ff 72 f8          	push   QWORD PTR [r10-0x8]
    fc3d:	55                   	push   rbp
    fc3e:	48 89 e5             	mov    rbp,rsp
    fc41:	41 57                	push   r15
    fc43:	41 56                	push   r14
    fc45:	45 89 c6             	mov    r14d,r8d
    fc48:	41 55                	push   r13
    fc4a:	41 54                	push   r12
    fc4c:	41 52                	push   r10
    fc4e:	53                   	push   rbx
    fc4f:	48 81 ec 80 02 00 00 	sub    rsp,0x280
    fc56:	49 8b 42 10          	mov    rax,QWORD PTR [r10+0x10]
    fc5a:	48 89 bd b8 fe ff ff 	mov    QWORD PTR [rbp-0x148],rdi
    fc61:	48 89 b5 98 fe ff ff 	mov    QWORD PTR [rbp-0x168],rsi
    fc68:	49 8b 1a             	mov    rbx,QWORD PTR [r10]
    fc6b:	48 89 95 c8 fd ff ff 	mov    QWORD PTR [rbp-0x238],rdx
    fc72:	4d 8b 6a 08          	mov    r13,QWORD PTR [r10+0x8]
    fc76:	89 8d cc fe ff ff    	mov    DWORD PTR [rbp-0x134],ecx
    fc7c:	48 89 de             	mov    rsi,rbx
    fc7f:	44 89 85 48 fe ff ff 	mov    DWORD PTR [rbp-0x1b8],r8d
    fc86:	44 89 8d f8 fe ff ff 	mov    DWORD PTR [rbp-0x108],r9d
    fc8d:	48 89 85 d0 fd ff ff 	mov    QWORD PTR [rbp-0x230],rax
    fc94:	64 48 8b 04 25 28 00 	mov    rax,QWORD PTR fs:0x28
    fc9b:	00 00 
    fc9d:	48 89 45 c8          	mov    QWORD PTR [rbp-0x38],rax
    fca1:	48 8d 85 00 ff ff ff 	lea    rax,[rbp-0x100]
    fca8:	48 89 c7             	mov    rdi,rax
    fcab:	48 89 85 18 fe ff ff 	mov    QWORD PTR [rbp-0x1e8],rax
    fcb2:	e8 79 bb ff ff       	call   b830 <bs_copy>
    fcb7:	85 c0                	test   eax,eax
    fcb9:	89 85 c4 fd ff ff    	mov    DWORD PTR [rbp-0x23c],eax
    fcbf:	74 34                	je     fcf5 <try_secant_tail.constprop.0+0xc5>
    fcc1:	41 bc ff ff ff ff    	mov    r12d,0xffffffff
    fcc7:	48 8b 45 c8          	mov    rax,QWORD PTR [rbp-0x38]
    fccb:	64 48 2b 04 25 28 00 	sub    rax,QWORD PTR fs:0x28
    fcd2:	00 00 
    fcd4:	0f 85 90 2d 00 00    	jne    12a6a <try_secant_tail.constprop.0+0x2e3a>
    fcda:	48 81 c4 80 02 00 00 	add    rsp,0x280
    fce1:	44 89 e0             	mov    eax,r12d
    fce4:	5b                   	pop    rbx
    fce5:	41 5a                	pop    r10
    fce7:	41 5c                	pop    r12
    fce9:	41 5d                	pop    r13
    fceb:	41 5e                	pop    r14
    fced:	41 5f                	pop    r15
    fcef:	5d                   	pop    rbp
    fcf0:	49 8d 62 f8          	lea    rsp,[r10-0x8]
    fcf4:	c3                   	ret
    fcf5:	4d 63 fe             	movsxd r15,r14d
    fcf8:	4c 89 ff             	mov    rdi,r15
    fcfb:	4c 89 bd f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],r15
    fd02:	48 c1 e7 04          	shl    rdi,0x4
    fd06:	e8 00 00 00 00       	call   fd0b <try_secant_tail.constprop.0+0xdb>
    fd0b:	be 08 00 00 00       	mov    esi,0x8
    fd10:	49 89 c6             	mov    r14,rax
    fd13:	4b 8d 04 3f          	lea    rax,[r15+r15*1]
    fd17:	48 89 c7             	mov    rdi,rax
    fd1a:	48 89 85 88 fd ff ff 	mov    QWORD PTR [rbp-0x278],rax
    fd21:	e8 00 00 00 00       	call   fd26 <try_secant_tail.constprop.0+0xf6>
    fd26:	4d 85 f6             	test   r14,r14
    fd29:	49 89 c2             	mov    r10,rax
    fd2c:	0f 84 49 2d 00 00    	je     12a7b <try_secant_tail.constprop.0+0x2e4b>
    fd32:	48 85 c0             	test   rax,rax
    fd35:	0f 84 40 2d 00 00    	je     12a7b <try_secant_tail.constprop.0+0x2e4b>
    fd3b:	48 89 85 d0 fe ff ff 	mov    QWORD PTR [rbp-0x130],rax
    fd42:	4c 8b a5 18 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1e8]
    fd49:	4c 89 f7             	mov    rdi,r14
    fd4c:	48 b8 d0 31 9f 29 22 	movabs rax,0xa4093822299f31d0
    fd53:	38 09 a4 
    fd56:	4c 31 e8             	xor    rax,r13
    fd59:	48 c7 45 b0 00 00 00 	mov    QWORD PTR [rbp-0x50],0x0
    fd60:	00 
    fd61:	48 ba 15 7c 4a 7f b9 	movabs rdx,0x9e3779b97f4a7c15
    fd68:	79 37 9e 
    fd6b:	48 01 d0             	add    rax,rdx
    fd6e:	4c 89 e6             	mov    rsi,r12
    fd71:	48 c7 45 b8 00 00 00 	mov    QWORD PTR [rbp-0x48],0x0
    fd78:	00 
    fd79:	48 89 c2             	mov    rdx,rax
    fd7c:	48 c1 ea 1e          	shr    rdx,0x1e
    fd80:	48 31 c2             	xor    rdx,rax
    fd83:	48 b8 b9 e5 e4 1c 6d 	movabs rax,0xbf58476d1ce4e5b9
    fd8a:	47 58 bf 
    fd8d:	48 0f af d0          	imul   rdx,rax
    fd91:	48 89 d0             	mov    rax,rdx
    fd94:	48 c1 e8 1b          	shr    rax,0x1b
    fd98:	48 31 d0             	xor    rax,rdx
    fd9b:	48 ba eb 11 31 13 bb 	movabs rdx,0x94d049bb133111eb
    fda2:	49 d0 94 
    fda5:	48 0f af c2          	imul   rax,rdx
    fda9:	48 89 c2             	mov    rdx,rax
    fdac:	48 c1 ea 1f          	shr    rdx,0x1f
    fdb0:	48 31 c2             	xor    rdx,rax
    fdb3:	49 89 d7             	mov    r15,rdx
    fdb6:	48 89 95 68 fd ff ff 	mov    QWORD PTR [rbp-0x298],rdx
    fdbd:	48 ba 03 ed 92 d1 32 	movabs rdx,0xd1b54a32d192ed03
    fdc4:	4a b5 d1 
    fdc7:	4c 01 fa             	add    rdx,r15
    fdca:	e8 d1 3c ff ff       	call   3aa0 <secant_refresh>
    fdcf:	48 8b 85 f0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x110]
    fdd6:	4c 89 e6             	mov    rsi,r12
    fdd9:	48 ba 06 da 25 a3 65 	movabs rdx,0xa36a9465a325da06
    fde0:	94 6a a3 
    fde3:	4c 01 fa             	add    rdx,r15
    fde6:	48 c1 e0 03          	shl    rax,0x3
    fdea:	49 8d 3c 06          	lea    rdi,[r14+rax*1]
    fdee:	48 89 85 f0 fd ff ff 	mov    QWORD PTR [rbp-0x210],rax
    fdf5:	48 89 bd a8 fe ff ff 	mov    QWORD PTR [rbp-0x158],rdi
    fdfc:	e8 9f 3c ff ff       	call   3aa0 <secant_refresh>
    fe01:	e8 00 00 00 00       	call   fe06 <try_secant_tail.constprop.0+0x1d6>
    fe06:	44 8b 63 04          	mov    r12d,DWORD PTR [rbx+0x4]
    fe0a:	4c 8b 95 d0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x130]
    fe11:	89 85 4c fe ff ff    	mov    DWORD PTR [rbp-0x1b4],eax
    fe17:	8b 85 cc fe ff ff    	mov    eax,DWORD PTR [rbp-0x134]
    fe1d:	2b 85 f8 fe ff ff    	sub    eax,DWORD PTR [rbp-0x108]
    fe23:	85 c0                	test   eax,eax
    fe25:	0f 8e 12 22 00 00    	jle    1203d <try_secant_tail.constprop.0+0x240d>
    fe2b:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
    fe2f:	c5 d3 2a c0          	vcvtsi2sd xmm0,xmm5,eax
    fe33:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
    fe37:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # fe3f <try_secant_tail.constprop.0+0x20f>
    fe3e:	00 
    fe3f:	c5 fb 11 ad b0 fe ff 	vmovsd QWORD PTR [rbp-0x150],xmm5
    fe46:	ff 
    fe47:	c5 d3 5e f0          	vdivsd xmm6,xmm5,xmm0
    fe4b:	c5 fb 11 b5 80 fe ff 	vmovsd QWORD PTR [rbp-0x180],xmm6
    fe52:	ff 
    fe53:	8b b5 48 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b8]
    fe59:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
    fe60:	4c 89 95 d0 fe ff ff 	mov    QWORD PTR [rbp-0x130],r10
    fe67:	e8 d4 03 ff ff       	call   240 <norm2>
    fe6c:	be 01 00 00 00       	mov    esi,0x1
    fe71:	bf 00 08 00 00       	mov    edi,0x800
    fe76:	c5 fb 11 85 90 fe ff 	vmovsd QWORD PTR [rbp-0x170],xmm0
    fe7d:	ff 
    fe7e:	e8 00 00 00 00       	call   fe83 <try_secant_tail.constprop.0+0x253>
    fe83:	48 63 9d 4c fe ff ff 	movsxd rbx,DWORD PTR [rbp-0x1b4]
    fe8a:	be 08 00 00 00       	mov    esi,0x8
    fe8f:	4c 8b bd f0 fe ff ff 	mov    r15,QWORD PTR [rbp-0x110]
    fe96:	48 89 85 58 fe ff ff 	mov    QWORD PTR [rbp-0x1a8],rax
    fe9d:	4c 0f af fb          	imul   r15,rbx
    fea1:	4b 8d 3c 3f          	lea    rdi,[r15+r15*1]
    fea5:	e8 00 00 00 00       	call   feaa <try_secant_tail.constprop.0+0x27a>
    feaa:	48 8d 3c 1b          	lea    rdi,[rbx+rbx*1]
    feae:	be 08 00 00 00       	mov    esi,0x8
    feb3:	48 89 85 10 fe ff ff 	mov    QWORD PTR [rbp-0x1f0],rax
    feba:	e8 00 00 00 00       	call   febf <try_secant_tail.constprop.0+0x28f>
    febf:	48 8b bd 58 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1a8]
    fec6:	48 8b 95 10 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1f0]
    fecd:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
    fed4:	49 89 c3             	mov    r11,rax
    fed7:	4c 8b 95 d0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x130]
    fede:	48 85 ff             	test   rdi,rdi
    fee1:	0f 94 c0             	sete   al
    fee4:	48 85 d2             	test   rdx,rdx
    fee7:	0f 94 c1             	sete   cl
    feea:	08 c8                	or     al,cl
    feec:	0f 85 b5 2b 00 00    	jne    12aa7 <try_secant_tail.constprop.0+0x2e77>
    fef2:	4d 85 db             	test   r11,r11
    fef5:	0f 84 ac 2b 00 00    	je     12aa7 <try_secant_tail.constprop.0+0x2e77>
    fefb:	c5 fa 7e ad b8 fe ff 	vmovq  xmm5,QWORD PTR [rbp-0x148]
    ff02:	ff 
    ff03:	44 8b 9d 0c ff ff ff 	mov    r11d,DWORD PTR [rbp-0xf4]
    ff0a:	c4 e3 d1 22 b5 98 fe 	vpinsrq xmm6,xmm5,QWORD PTR [rbp-0x168],0x1
    ff11:	ff ff 01 
    ff14:	8b 8d 04 ff ff ff    	mov    ecx,DWORD PTR [rbp-0xfc]
    ff1a:	44 8b 85 f8 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x108]
    ff21:	44 39 85 cc fe ff ff 	cmp    DWORD PTR [rbp-0x134],r8d
    ff28:	44 89 9d c0 fe ff ff 	mov    DWORD PTR [rbp-0x140],r11d
    ff2f:	89 8d d0 fe ff ff    	mov    DWORD PTR [rbp-0x130],ecx
    ff35:	c5 f9 7f b5 b0 fd ff 	vmovdqa XMMWORD PTR [rbp-0x250],xmm6
    ff3c:	ff 
    ff3d:	0f 8e 5a 04 00 00    	jle    1039d <try_secant_tail.constprop.0+0x76d>
    ff43:	48 b8 89 6c 4e ec 98 	movabs rax,0x82efa98ec4e6c89
    ff4a:	fa 2e 08 
    ff4d:	8b b5 48 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b8]
    ff53:	c5 fb 12 bd 80 fe ff 	vmovddup xmm7,QWORD PTR [rbp-0x180]
    ff5a:	ff 
    ff5b:	c7 85 e0 fd ff ff 00 	mov    DWORD PTR [rbp-0x220],0x0
    ff62:	00 00 00 
    ff65:	49 31 c5             	xor    r13,rax
    ff68:	44 89 85 c8 fe ff ff 	mov    DWORD PTR [rbp-0x138],r8d
    ff6f:	48 b8 15 7c 4a 7f b9 	movabs rax,0x9e3779b97f4a7c15
    ff76:	79 37 9e 
    ff79:	4c 01 e8             	add    rax,r13
    ff7c:	c5 f9 29 bd 70 fd ff 	vmovapd XMMWORD PTR [rbp-0x290],xmm7
    ff83:	ff 
    ff84:	c4 e1 f9 6e ff       	vmovq  xmm7,rdi
    ff89:	4c 8b ad a8 fe ff ff 	mov    r13,QWORD PTR [rbp-0x158]
    ff90:	48 89 c1             	mov    rcx,rax
    ff93:	c4 e3 c1 22 ea 01    	vpinsrq xmm5,xmm7,rdx,0x1
    ff99:	ba 01 00 00 00       	mov    edx,0x1
    ff9e:	c7 85 c0 fe ff ff 00 	mov    DWORD PTR [rbp-0x140],0x0
    ffa5:	00 00 00 
    ffa8:	48 c1 e9 1e          	shr    rcx,0x1e
    ffac:	4c 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r10
    ffb3:	48 31 c1             	xor    rcx,rax
    ffb6:	c5 f9 7f ad a0 fd ff 	vmovdqa XMMWORD PTR [rbp-0x260],xmm5
    ffbd:	ff 
    ffbe:	48 b8 b9 e5 e4 1c 6d 	movabs rax,0xbf58476d1ce4e5b9
    ffc5:	47 58 bf 
    ffc8:	48 0f af c8          	imul   rcx,rax
    ffcc:	48 89 c8             	mov    rax,rcx
    ffcf:	48 c1 e8 1b          	shr    rax,0x1b
    ffd3:	48 31 c8             	xor    rax,rcx
    ffd6:	48 b9 eb 11 31 13 bb 	movabs rcx,0x94d049bb133111eb
    ffdd:	49 d0 94 
    ffe0:	48 0f af c1          	imul   rax,rcx
    ffe4:	48 89 c1             	mov    rcx,rax
    ffe7:	48 c1 e9 1f          	shr    rcx,0x1f
    ffeb:	48 31 c1             	xor    rcx,rax
    ffee:	89 f0                	mov    eax,esi
    fff0:	c1 e8 1f             	shr    eax,0x1f
    fff3:	48 89 8d d8 fd ff ff 	mov    QWORD PTR [rbp-0x228],rcx
    fffa:	01 f0                	add    eax,esi
    fffc:	d1 f8                	sar    eax,1
    fffe:	41 39 c4             	cmp    r12d,eax
   10001:	41 89 f4             	mov    r12d,esi
   10004:	0f 9d c1             	setge  cl
   10007:	83 bd 4c fe ff ff 01 	cmp    DWORD PTR [rbp-0x1b4],0x1
   1000e:	0f 9f c0             	setg   al
   10011:	48 c1 e3 04          	shl    rbx,0x4
   10015:	21 c1                	and    ecx,eax
   10017:	8d 04 36             	lea    eax,[rsi+rsi*1]
   1001a:	49 c1 e7 04          	shl    r15,0x4
   1001e:	48 89 9d 98 fd ff ff 	mov    QWORD PTR [rbp-0x268],rbx
   10025:	85 c0                	test   eax,eax
   10027:	88 8d a3 fe ff ff    	mov    BYTE PTR [rbp-0x15d],cl
   1002d:	8d 5e ff             	lea    ebx,[rsi-0x1]
   10030:	0f 4f d0             	cmovg  edx,eax
   10033:	8d 44 36 fc          	lea    eax,[rsi+rsi*1-0x4]
   10037:	4c 89 bd 90 fd ff ff 	mov    QWORD PTR [rbp-0x270],r15
   1003e:	89 85 84 fd ff ff    	mov    DWORD PTR [rbp-0x27c],eax
   10044:	48 89 f8             	mov    rax,rdi
   10047:	48 f7 d8             	neg    rax
   1004a:	89 95 c0 fd ff ff    	mov    DWORD PTR [rbp-0x240],edx
   10050:	83 e0 1f             	and    eax,0x1f
   10053:	89 9d a4 fe ff ff    	mov    DWORD PTR [rbp-0x15c],ebx
   10059:	44 89 db             	mov    ebx,r11d
   1005c:	89 85 e4 fd ff ff    	mov    DWORD PTR [rbp-0x21c],eax
   10062:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   10068:	85 db                	test   ebx,ebx
   1006a:	0f 85 dd 23 00 00    	jne    1244d <try_secant_tail.constprop.0+0x281d>
   10070:	89 9d 88 fe ff ff    	mov    DWORD PTR [rbp-0x178],ebx
   10076:	48 8b 9d 50 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1b0]
   1007d:	4d 89 e9             	mov    r9,r13
   10080:	c5 fb 10 b5 80 fe ff 	vmovsd xmm6,QWORD PTR [rbp-0x180]
   10087:	ff 
   10088:	c5 c9 16 b5 90 fe ff 	vmovhpd xmm6,xmm6,QWORD PTR [rbp-0x170]
   1008f:	ff 
   10090:	c5 f9 29 b5 60 fe ff 	vmovapd XMMWORD PTR [rbp-0x1a0],xmm6
   10097:	ff 
   10098:	44 3b a5 d0 fe ff ff 	cmp    r12d,DWORD PTR [rbp-0x130]
   1009f:	0f 8e 2f 06 00 00    	jle    106d4 <try_secant_tail.constprop.0+0xaa4>
   100a5:	83 bd c0 fe ff ff 1f 	cmp    DWORD PTR [rbp-0x140],0x1f
   100ac:	0f 9f c0             	setg   al
   100af:	84 85 a3 fe ff ff    	test   BYTE PTR [rbp-0x15d],al
   100b5:	74 2c                	je     100e3 <try_secant_tail.constprop.0+0x4b3>
   100b7:	8b b5 f8 fe ff ff    	mov    esi,DWORD PTR [rbp-0x108]
   100bd:	3b b5 c8 fe ff ff    	cmp    esi,DWORD PTR [rbp-0x138]
   100c3:	7c 1e                	jl     100e3 <try_secant_tail.constprop.0+0x4b3>
   100c5:	8b 85 cc fe ff ff    	mov    eax,DWORD PTR [rbp-0x134]
   100cb:	29 f0                	sub    eax,esi
   100cd:	48 98                	cdqe
   100cf:	48 0f af 85 f0 fe ff 	imul   rax,QWORD PTR [rbp-0x110]
   100d6:	ff 
   100d7:	48 3d 3f 42 0f 00    	cmp    rax,0xf423f
   100dd:	0f 8f 7d 0c 00 00    	jg     10d60 <try_secant_tail.constprop.0+0x1130>
   100e3:	4c 63 85 f8 fe ff ff 	movsxd r8,DWORD PTR [rbp-0x108]
   100ea:	4c 8b 95 f0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x110]
   100f1:	48 8b 85 b8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x148]
   100f8:	4d 0f af d0          	imul   r10,r8
   100fc:	45 85 e4             	test   r12d,r12d
   100ff:	4a 8d 3c d0          	lea    rdi,[rax+r10*8]
   10103:	0f 8e 20 05 00 00    	jle    10629 <try_secant_tail.constprop.0+0x9f9>
   10109:	83 bd a4 fe ff ff 02 	cmp    DWORD PTR [rbp-0x15c],0x2
   10110:	48 8b 85 18 ff ff ff 	mov    rax,QWORD PTR [rbp-0xe8]
   10117:	0f 86 0f 17 00 00    	jbe    1182c <try_secant_tail.constprop.0+0x1bfc>
   1011d:	44 89 e1             	mov    ecx,r12d
   10120:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
   10124:	31 d2                	xor    edx,edx
   10126:	c5 fd 28 dc          	vmovapd ymm3,ymm4
   1012a:	c1 e9 02             	shr    ecx,0x2
   1012d:	c5 fd 28 cc          	vmovapd ymm1,ymm4
   10131:	c5 fd 28 d4          	vmovapd ymm2,ymm4
   10135:	48 c1 e1 05          	shl    rcx,0x5
   10139:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   10140:	c5 fd 10 04 17       	vmovupd ymm0,YMMWORD PTR [rdi+rdx*1]
   10145:	c4 e2 fd b8 1c 10    	vfmadd231pd ymm3,ymm0,YMMWORD PTR [rax+rdx*1]
   1014b:	c4 c2 fd b8 0c 16    	vfmadd231pd ymm1,ymm0,YMMWORD PTR [r14+rdx*1]
   10151:	c4 c2 fd b8 14 11    	vfmadd231pd ymm2,ymm0,YMMWORD PTR [r9+rdx*1]
   10157:	48 83 c2 20          	add    rdx,0x20
   1015b:	48 39 d1             	cmp    rcx,rdx
   1015e:	c4 e2 fd b8 e0       	vfmadd231pd ymm4,ymm0,ymm0
   10163:	75 db                	jne    10140 <try_secant_tail.constprop.0+0x510>
   10165:	c4 e3 7d 19 d6 01    	vextractf128 xmm6,ymm2,0x1
   1016b:	c4 e3 7d 19 e0 01    	vextractf128 xmm0,ymm4,0x1
   10171:	c4 e3 7d 19 dd 01    	vextractf128 xmm5,ymm3,0x1
   10177:	44 89 e2             	mov    edx,r12d
   1017a:	c5 c9 58 f2          	vaddpd xmm6,xmm6,xmm2
   1017e:	c4 e3 7d 19 ca 01    	vextractf128 xmm2,ymm1,0x1
   10184:	c5 f9 58 e4          	vaddpd xmm4,xmm0,xmm4
   10188:	83 e2 fc             	and    edx,0xfffffffc
   1018b:	c5 e9 58 d1          	vaddpd xmm2,xmm2,xmm1
   1018f:	c5 d1 58 db          	vaddpd xmm3,xmm5,xmm3
   10193:	41 39 d4             	cmp    r12d,edx
   10196:	89 d1                	mov    ecx,edx
   10198:	c5 49 15 c6          	vunpckhpd xmm8,xmm6,xmm6
   1019c:	c5 d9 15 c4          	vunpckhpd xmm0,xmm4,xmm4
   101a0:	c5 e9 15 fa          	vunpckhpd xmm7,xmm2,xmm2
   101a4:	c5 39 58 c6          	vaddpd xmm8,xmm8,xmm6
   101a8:	c5 e1 15 eb          	vunpckhpd xmm5,xmm3,xmm3
   101ac:	c5 c1 58 fa          	vaddpd xmm7,xmm7,xmm2
   101b0:	c5 f9 58 c4          	vaddpd xmm0,xmm0,xmm4
   101b4:	c5 d1 58 eb          	vaddpd xmm5,xmm5,xmm3
   101b8:	c5 b9 14 ff          	vunpcklpd xmm7,xmm8,xmm7
   101bc:	0f 84 a1 00 00 00    	je     10263 <try_secant_tail.constprop.0+0x633>
   101c2:	44 89 e6             	mov    esi,r12d
   101c5:	29 ce                	sub    esi,ecx
   101c7:	83 fe 01             	cmp    esi,0x1
   101ca:	74 69                	je     10235 <try_secant_tail.constprop.0+0x605>
   101cc:	4c 8b bd b8 fe ff ff 	mov    r15,QWORD PTR [rbp-0x148]
   101d3:	4d 8d 2c 0a          	lea    r13,[r10+rcx*1]
   101d7:	4c 8b 9d f0 fe ff ff 	mov    r11,QWORD PTR [rbp-0x110]
   101de:	c4 81 79 10 04 ef    	vmovupd xmm0,XMMWORD PTR [r15+r13*8]
   101e4:	c4 e2 f9 b8 1c c8    	vfmadd231pd xmm3,xmm0,XMMWORD PTR [rax+rcx*8]
   101ea:	49 01 cb             	add    r11,rcx
   101ed:	40 f6 c6 01          	test   sil,0x1
   101f1:	c4 c2 f9 b8 14 ce    	vfmadd231pd xmm2,xmm0,XMMWORD PTR [r14+rcx*8]
   101f7:	c4 e2 f9 b8 e0       	vfmadd231pd xmm4,xmm0,xmm0
   101fc:	c5 f9 28 cb          	vmovapd xmm1,xmm3
   10200:	c5 f9 28 d8          	vmovapd xmm3,xmm0
   10204:	c4 82 c9 98 1c de    	vfmadd132pd xmm3,xmm6,XMMWORD PTR [r14+r11*8]
   1020a:	c5 f1 15 e9          	vunpckhpd xmm5,xmm1,xmm1
   1020e:	c5 d1 58 e9          	vaddpd xmm5,xmm5,xmm1
   10212:	c5 d9 15 c4          	vunpckhpd xmm0,xmm4,xmm4
   10216:	c5 f9 58 c4          	vaddpd xmm0,xmm0,xmm4
   1021a:	c5 e1 15 cb          	vunpckhpd xmm1,xmm3,xmm3
   1021e:	c5 f1 58 cb          	vaddpd xmm1,xmm1,xmm3
   10222:	c5 e9 15 da          	vunpckhpd xmm3,xmm2,xmm2
   10226:	c5 e1 58 d2          	vaddpd xmm2,xmm3,xmm2
   1022a:	c5 f1 14 fa          	vunpcklpd xmm7,xmm1,xmm2
   1022e:	74 33                	je     10263 <try_secant_tail.constprop.0+0x633>
   10230:	83 e6 fe             	and    esi,0xfffffffe
   10233:	01 f2                	add    edx,esi
   10235:	48 63 ca             	movsxd rcx,edx
   10238:	44 01 e2             	add    edx,r12d
   1023b:	c5 fb 10 14 cf       	vmovsd xmm2,QWORD PTR [rdi+rcx*8]
   10240:	48 63 d2             	movsxd rdx,edx
   10243:	c4 e2 e9 b9 2c c8    	vfmadd231sd xmm5,xmm2,QWORD PTR [rax+rcx*8]
   10249:	c5 fb 12 da          	vmovddup xmm3,xmm2
   1024d:	c4 e2 e9 b9 c2       	vfmadd231sd xmm0,xmm2,xmm2
   10252:	c4 c1 7b 10 14 d6    	vmovsd xmm2,QWORD PTR [r14+rdx*8]
   10258:	c4 c1 69 16 14 ce    	vmovhpd xmm2,xmm2,QWORD PTR [r14+rcx*8]
   1025e:	c4 e2 e1 b8 fa       	vfmadd231pd xmm7,xmm3,xmm2
   10263:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
   10267:	c5 f9 2f c2          	vcomisd xmm0,xmm2
   1026b:	0f 86 c7 03 00 00    	jbe    10638 <try_secant_tail.constprop.0+0xa08>
   10271:	48 b8 00 00 00 00 00 	movabs rax,0x7ff0000000000000
   10278:	00 f0 7f 
   1027b:	c4 e1 f9 7e c6       	vmovq  rsi,xmm0
   10280:	c4 e2 c8 f2 c0       	andn   rax,rsi,rax
   10285:	0f 84 ad 03 00 00    	je     10638 <try_secant_tail.constprop.0+0xa08>
   1028b:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
   1028f:	c5 fb 10 b5 b0 fe ff 	vmovsd xmm6,QWORD PTR [rbp-0x150]
   10296:	ff 
   10297:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   1029e:	8b b5 c8 fe ff ff    	mov    esi,DWORD PTR [rbp-0x138]
   102a4:	39 b5 f8 fe ff ff    	cmp    DWORD PTR [rbp-0x108],esi
   102aa:	c5 cb 5e c0          	vdivsd xmm0,xmm6,xmm0
   102ae:	c4 a1 7b 10 1c c0    	vmovsd xmm3,QWORD PTR [rax+r8*8]
   102b4:	c5 c1 54 3d 00 00 00 	vandpd xmm7,xmm7,XMMWORD PTR [rip+0x0]        # 102bc <try_secant_tail.constprop.0+0x68c>
   102bb:	00 
   102bc:	c5 fb 59 e3          	vmulsd xmm4,xmm0,xmm3
   102c0:	0f 8d 1c 13 00 00    	jge    115e2 <try_secant_tail.constprop.0+0x19b2>
   102c6:	c5 c1 15 cf          	vunpckhpd xmm1,xmm7,xmm7
   102ca:	c5 fb 10 15 00 00 00 	vmovsd xmm2,QWORD PTR [rip+0x0]        # 102d2 <try_secant_tail.constprop.0+0x6a2>
   102d1:	00 
   102d2:	c5 f1 5f cf          	vmaxpd xmm1,xmm1,xmm7
   102d6:	c5 f3 59 c8          	vmulsd xmm1,xmm1,xmm0
   102da:	c5 f9 2f ca          	vcomisd xmm1,xmm2
   102de:	77 3e                	ja     1031e <try_secant_tail.constprop.0+0x6ee>
   102e0:	c5 fb 10 bd 90 fe ff 	vmovsd xmm7,QWORD PTR [rbp-0x170]
   102e7:	ff 
   102e8:	c5 c3 58 8d b0 fe ff 	vaddsd xmm1,xmm7,QWORD PTR [rbp-0x150]
   102ef:	ff 
   102f0:	c5 e3 5c ed          	vsubsd xmm5,xmm3,xmm5
   102f4:	c5 d9 54 25 00 00 00 	vandpd xmm4,xmm4,XMMWORD PTR [rip+0x0]        # 102fc <try_secant_tail.constprop.0+0x6cc>
   102fb:	00 
   102fc:	c5 db 58 c9          	vaddsd xmm1,xmm4,xmm1
   10300:	c5 f3 59 0d 00 00 00 	vmulsd xmm1,xmm1,QWORD PTR [rip+0x0]        # 10308 <try_secant_tail.constprop.0+0x6d8>
   10307:	00 
   10308:	c5 d3 59 e8          	vmulsd xmm5,xmm5,xmm0
   1030c:	c5 d1 54 2d 00 00 00 	vandpd xmm5,xmm5,XMMWORD PTR [rip+0x0]        # 10314 <try_secant_tail.constprop.0+0x6e4>
   10313:	00 
   10314:	c5 f9 2f e9          	vcomisd xmm5,xmm1
   10318:	0f 86 41 15 00 00    	jbe    1185f <try_secant_tail.constprop.0+0x1c2f>
   1031e:	c5 f8 77             	vzeroupper
   10321:	44 8b ad 00 ff ff ff 	mov    r13d,DWORD PTR [rbp-0x100]
   10328:	44 89 ee             	mov    esi,r13d
   1032b:	c5 fb 11 9d a8 fe ff 	vmovsd QWORD PTR [rbp-0x158],xmm3
   10332:	ff 
   10333:	e8 08 ff fe ff       	call   240 <norm2>
   10338:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   1033c:	c5 fb 10 9d a8 fe ff 	vmovsd xmm3,QWORD PTR [rbp-0x158]
   10343:	ff 
   10344:	c5 f9 2f c1          	vcomisd xmm0,xmm1
   10348:	0f 85 ca 03 00 00    	jne    10718 <try_secant_tail.constprop.0+0xae8>
   1034e:	c5 e1 54 1d 00 00 00 	vandpd xmm3,xmm3,XMMWORD PTR [rip+0x0]        # 10356 <try_secant_tail.constprop.0+0x726>
   10355:	00 
   10356:	c5 f9 2f 1d 00 00 00 	vcomisd xmm3,QWORD PTR [rip+0x0]        # 1035e <try_secant_tail.constprop.0+0x72e>
   1035d:	00 
   1035e:	4d 89 cd             	mov    r13,r9
   10361:	0f 87 2e 23 00 00    	ja     12695 <try_secant_tail.constprop.0+0x2a65>
   10367:	83 85 c0 fe ff ff 01 	add    DWORD PTR [rbp-0x140],0x1
   1036e:	8b 9d 0c ff ff ff    	mov    ebx,DWORD PTR [rbp-0xf4]
   10374:	83 85 f8 fe ff ff 01 	add    DWORD PTR [rbp-0x108],0x1
   1037b:	8b b5 f8 fe ff ff    	mov    esi,DWORD PTR [rbp-0x108]
   10381:	39 b5 cc fe ff ff    	cmp    DWORD PTR [rbp-0x134],esi
   10387:	0f 8f db fc ff ff    	jg     10068 <try_secant_tail.constprop.0+0x438>
   1038d:	89 9d c0 fe ff ff    	mov    DWORD PTR [rbp-0x140],ebx
   10393:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   1039a:	c5 f8 77             	vzeroupper
   1039d:	48 8b bd 58 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1a8]
   103a4:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   103ab:	e8 00 00 00 00       	call   103b0 <try_secant_tail.constprop.0+0x780>
   103b0:	48 8b bd 10 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f0]
   103b7:	e8 00 00 00 00       	call   103bc <try_secant_tail.constprop.0+0x78c>
   103bc:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   103c3:	e8 00 00 00 00       	call   103c8 <try_secant_tail.constprop.0+0x798>
   103c8:	8b 8d c0 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x140]
   103ce:	4c 8b 95 f8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x108]
   103d5:	85 c9                	test   ecx,ecx
   103d7:	0f 85 92 26 00 00    	jne    12a6f <try_secant_tail.constprop.0+0x2e3f>
   103dd:	8b b5 d0 fe ff ff    	mov    esi,DWORD PTR [rbp-0x130]
   103e3:	4c 8d 6d b0          	lea    r13,[rbp-0x50]
   103e7:	4d 89 d4             	mov    r12,r10
   103ea:	4d 89 d7             	mov    r15,r10
   103ed:	39 b5 48 fe ff ff    	cmp    DWORD PTR [rbp-0x1b8],esi
   103f3:	48 8d 5d c0          	lea    rbx,[rbp-0x40]
   103f7:	0f 84 02 23 00 00    	je     126ff <try_secant_tail.constprop.0+0x2acf>
   103fd:	c4 c1 7b 10 45 00    	vmovsd xmm0,QWORD PTR [r13+0x0]
   10403:	48 8b bd 18 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1e8]
   1040a:	4c 89 e6             	mov    rsi,r12
   1040d:	e8 3e 9f ff ff       	call   a350 <bs_check_certified.constprop.0>
   10412:	83 f8 01             	cmp    eax,0x1
   10415:	0f 85 88 21 00 00    	jne    125a3 <try_secant_tail.constprop.0+0x2973>
   1041b:	49 83 c5 08          	add    r13,0x8
   1041f:	4c 03 a5 f0 fd ff ff 	add    r12,QWORD PTR [rbp-0x210]
   10426:	4c 39 eb             	cmp    rbx,r13
   10429:	75 d2                	jne    103fd <try_secant_tail.constprop.0+0x7cd>
   1042b:	48 8b bd b8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x148]
   10432:	44 8b 85 48 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1b8]
   10439:	41 89 c4             	mov    r12d,eax
   1043c:	4c 8d 8d 40 ff ff ff 	lea    r9,[rbp-0xc0]
   10443:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 1044b <try_secant_tail.constprop.0+0x81b>
   1044a:	00 
   1044b:	8b 8d cc fe ff ff    	mov    ecx,DWORD PTR [rbp-0x134]
   10451:	4c 89 bd f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r15
   10458:	48 8b 95 18 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xe8]
   1045f:	48 8b b5 98 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x168]
   10466:	e8 85 04 ff ff       	call   8f0 <compat_scan_fused>
   1046b:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
   10472:	4c 8b 95 f8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x108]
   10479:	85 c0                	test   eax,eax
   1047b:	0f 85 30 21 00 00    	jne    125b1 <try_secant_tail.constprop.0+0x2981>
   10481:	48 8b b5 c8 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x238]
   10488:	48 8b 9d d0 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x230]
   1048f:	8b 95 04 ff ff ff    	mov    edx,DWORD PTR [rbp-0xfc]
   10495:	c5 fb 10 85 40 ff ff 	vmovsd xmm0,QWORD PTR [rbp-0xc0]
   1049c:	ff 
   1049d:	48 85 f6             	test   rsi,rsi
   104a0:	c7 03 02 00 00 00    	mov    DWORD PTR [rbx],0x2
   104a6:	89 53 04             	mov    DWORD PTR [rbx+0x4],edx
   104a9:	c5 fb 11 43 18       	vmovsd QWORD PTR [rbx+0x18],xmm0
   104ae:	0f 84 8c 21 00 00    	je     12640 <try_secant_tail.constprop.0+0x2a10>
   104b4:	8b 9d 48 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x1b8]
   104ba:	85 db                	test   ebx,ebx
   104bc:	0f 8e 5b 24 00 00    	jle    1291d <try_secant_tail.constprop.0+0x2ced>
   104c2:	8d 53 ff             	lea    edx,[rbx-0x1]
   104c5:	48 8b 8d 18 ff ff ff 	mov    rcx,QWORD PTR [rbp-0xe8]
   104cc:	83 fa 02             	cmp    edx,0x2
   104cf:	0f 86 6b 24 00 00    	jbe    12940 <try_secant_tail.constprop.0+0x2d10>
   104d5:	89 da                	mov    edx,ebx
   104d7:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   104db:	31 c0                	xor    eax,eax
   104dd:	c1 ea 02             	shr    edx,0x2
   104e0:	c5 fd 28 d3          	vmovapd ymm2,ymm3
   104e4:	48 c1 e2 05          	shl    rdx,0x5
   104e8:	66 90                	xchg   ax,ax
   104ea:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   104f1:	00 00 00 00 
   104f5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   104fc:	00 00 00 00 
   10500:	c5 fd 10 0c 06       	vmovupd ymm1,YMMWORD PTR [rsi+rax*1]
   10505:	c5 fd 10 04 01       	vmovupd ymm0,YMMWORD PTR [rcx+rax*1]
   1050a:	48 83 c0 20          	add    rax,0x20
   1050e:	48 39 d0             	cmp    rax,rdx
   10511:	c5 fd 5c c1          	vsubpd ymm0,ymm0,ymm1
   10515:	c4 e2 f5 b8 d1       	vfmadd231pd ymm2,ymm1,ymm1
   1051a:	c4 e2 fd b8 d8       	vfmadd231pd ymm3,ymm0,ymm0
   1051f:	75 df                	jne    10500 <try_secant_tail.constprop.0+0x8d0>
   10521:	8b 9d 48 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x1b8]
   10527:	c4 e3 7d 19 d8 01    	vextractf128 xmm0,ymm3,0x1
   1052d:	c4 e3 7d 19 d1 01    	vextractf128 xmm1,ymm2,0x1
   10533:	c5 f9 58 db          	vaddpd xmm3,xmm0,xmm3
   10537:	c5 f1 58 d2          	vaddpd xmm2,xmm1,xmm2
   1053b:	89 d8                	mov    eax,ebx
   1053d:	83 e0 fc             	and    eax,0xfffffffc
   10540:	c5 e1 15 c3          	vunpckhpd xmm0,xmm3,xmm3
   10544:	c5 e9 15 ca          	vunpckhpd xmm1,xmm2,xmm2
   10548:	39 d8                	cmp    eax,ebx
   1054a:	89 c2                	mov    edx,eax
   1054c:	c5 f9 58 c3          	vaddpd xmm0,xmm0,xmm3
   10550:	c5 f1 58 ca          	vaddpd xmm1,xmm1,xmm2
   10554:	0f 84 87 23 00 00    	je     128e1 <try_secant_tail.constprop.0+0x2cb1>
   1055a:	c5 f8 77             	vzeroupper
   1055d:	8b b5 48 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b8]
   10563:	29 d6                	sub    esi,edx
   10565:	83 fe 01             	cmp    esi,0x1
   10568:	74 3a                	je     105a4 <try_secant_tail.constprop.0+0x974>
   1056a:	48 8b 9d c8 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x238]
   10571:	c5 f9 10 04 d1       	vmovupd xmm0,XMMWORD PTR [rcx+rdx*8]
   10576:	40 f6 c6 01          	test   sil,0x1
   1057a:	c5 f9 10 0c d3       	vmovupd xmm1,XMMWORD PTR [rbx+rdx*8]
   1057f:	c5 f9 5c c1          	vsubpd xmm0,xmm0,xmm1
   10583:	c4 e2 f1 b8 d1       	vfmadd231pd xmm2,xmm1,xmm1
   10588:	c4 e2 e1 98 c0       	vfmadd132pd xmm0,xmm3,xmm0
   1058d:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   10591:	c5 f1 58 c0          	vaddpd xmm0,xmm1,xmm0
   10595:	c5 e9 15 ca          	vunpckhpd xmm1,xmm2,xmm2
   10599:	c5 f1 58 ca          	vaddpd xmm1,xmm1,xmm2
   1059d:	74 26                	je     105c5 <try_secant_tail.constprop.0+0x995>
   1059f:	83 e6 fe             	and    esi,0xfffffffe
   105a2:	01 f0                	add    eax,esi
   105a4:	48 8b 9d c8 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x238]
   105ab:	48 98                	cdqe
   105ad:	c5 fb 10 14 c1       	vmovsd xmm2,QWORD PTR [rcx+rax*8]
   105b2:	c5 fb 10 1c c3       	vmovsd xmm3,QWORD PTR [rbx+rax*8]
   105b7:	c5 eb 5c d3          	vsubsd xmm2,xmm2,xmm3
   105bb:	c4 e2 e1 b9 cb       	vfmadd231sd xmm1,xmm3,xmm3
   105c0:	c4 e2 e9 b9 c2       	vfmadd231sd xmm0,xmm2,xmm2
   105c5:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
   105c9:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
   105cd:	c5 f3 58 0d 00 00 00 	vaddsd xmm1,xmm1,QWORD PTR [rip+0x0]        # 105d5 <try_secant_tail.constprop.0+0x9a5>
   105d4:	00 
   105d5:	c5 fb 5e c1          	vdivsd xmm0,xmm0,xmm1
   105d9:	48 8b 85 d0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x230]
   105e0:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   105e7:	c7 40 0c 01 00 00 00 	mov    DWORD PTR [rax+0xc],0x1
   105ee:	c5 fb 11 40 20       	vmovsd QWORD PTR [rax+0x20],xmm0
   105f3:	e8 00 00 00 00       	call   105f8 <try_secant_tail.constprop.0+0x9c8>
   105f8:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   105ff:	e8 00 00 00 00       	call   10604 <try_secant_tail.constprop.0+0x9d4>
   10604:	48 8b bd 20 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe0]
   1060b:	e8 00 00 00 00       	call   10610 <try_secant_tail.constprop.0+0x9e0>
   10610:	4c 89 f7             	mov    rdi,r14
   10613:	e8 00 00 00 00       	call   10618 <try_secant_tail.constprop.0+0x9e8>
   10618:	48 8b bd f8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x108]
   1061f:	e8 00 00 00 00       	call   10624 <try_secant_tail.constprop.0+0x9f4>
   10624:	e9 9e f6 ff ff       	jmp    fcc7 <try_secant_tail.constprop.0+0x97>
   10629:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
   1062d:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
   10631:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   10638:	c5 f9 29 bd 70 fe ff 	vmovapd XMMWORD PTR [rbp-0x190],xmm7
   1063f:	ff 
   10640:	44 89 e6             	mov    esi,r12d
   10643:	c5 fb 11 ad a8 fe ff 	vmovsd QWORD PTR [rbp-0x158],xmm5
   1064a:	ff 
   1064b:	c5 f8 77             	vzeroupper
   1064e:	e8 ed fb fe ff       	call   240 <norm2>
   10653:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
   10657:	c5 fb 10 ad a8 fe ff 	vmovsd xmm5,QWORD PTR [rbp-0x158]
   1065e:	ff 
   1065f:	c5 f9 2f c2          	vcomisd xmm0,xmm2
   10663:	c5 f9 28 bd 70 fe ff 	vmovapd xmm7,XMMWORD PTR [rbp-0x190]
   1066a:	ff 
   1066b:	0f 85 1e fc ff ff    	jne    1028f <try_secant_tail.constprop.0+0x65f>
   10671:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   10678:	c4 a1 7b 10 1c c0    	vmovsd xmm3,QWORD PTR [rax+r8*8]
   1067e:	c5 e1 54 05 00 00 00 	vandpd xmm0,xmm3,XMMWORD PTR [rip+0x0]        # 10686 <try_secant_tail.constprop.0+0xa56>
   10685:	00 
   10686:	c5 f9 2f 05 00 00 00 	vcomisd xmm0,QWORD PTR [rip+0x0]        # 1068e <try_secant_tail.constprop.0+0xa5e>
   1068d:	00 
   1068e:	0f 87 8d fc ff ff    	ja     10321 <try_secant_tail.constprop.0+0x6f1>
   10694:	8b bd c8 fe ff ff    	mov    edi,DWORD PTR [rbp-0x138]
   1069a:	8b b5 f8 fe ff ff    	mov    esi,DWORD PTR [rbp-0x108]
   106a0:	8d 46 01             	lea    eax,[rsi+0x1]
   106a3:	39 fe                	cmp    esi,edi
   106a5:	0f 4d f8             	cmovge edi,eax
   106a8:	39 85 cc fe ff ff    	cmp    DWORD PTR [rbp-0x134],eax
   106ae:	89 bd c8 fe ff ff    	mov    DWORD PTR [rbp-0x138],edi
   106b4:	0f 8e ce 22 00 00    	jle    12988 <try_secant_tail.constprop.0+0x2d58>
   106ba:	83 85 c0 fe ff ff 01 	add    DWORD PTR [rbp-0x140],0x1
   106c1:	44 3b a5 d0 fe ff ff 	cmp    r12d,DWORD PTR [rbp-0x130]
   106c8:	89 85 f8 fe ff ff    	mov    DWORD PTR [rbp-0x108],eax
   106ce:	0f 8f d1 f9 ff ff    	jg     100a5 <try_secant_tail.constprop.0+0x475>
   106d4:	49 89 da             	mov    r10,rbx
   106d7:	c5 f8 77             	vzeroupper
   106da:	48 8b bd 58 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1a8]
   106e1:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   106e8:	e8 00 00 00 00       	call   106ed <try_secant_tail.constprop.0+0xabd>
   106ed:	48 8b bd 10 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f0]
   106f4:	e8 00 00 00 00       	call   106f9 <try_secant_tail.constprop.0+0xac9>
   106f9:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   10700:	e8 00 00 00 00       	call   10705 <try_secant_tail.constprop.0+0xad5>
   10705:	4c 8b 95 f8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x108]
   1070c:	e9 cc fc ff ff       	jmp    103dd <try_secant_tail.constprop.0+0x7ad>
   10711:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   10718:	c5 fb 10 bd b0 fe ff 	vmovsd xmm7,QWORD PTR [rbp-0x150]
   1071f:	ff 
   10720:	49 63 cd             	movsxd rcx,r13d
   10723:	4c 8b bd 20 ff ff ff 	mov    r15,QWORD PTR [rbp-0xe0]
   1072a:	45 85 ed             	test   r13d,r13d
   1072d:	48 8d 04 cd 00 00 00 	lea    rax,[rcx*8+0x0]
   10734:	00 
   10735:	48 89 8d 20 fe ff ff 	mov    QWORD PTR [rbp-0x1e0],rcx
   1073c:	48 8b b5 10 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xf0]
   10743:	c5 c3 5e c0          	vdivsd xmm0,xmm7,xmm0
   10747:	4d 8d 14 07          	lea    r10,[r15+rax*1]
   1074b:	48 89 85 08 fe ff ff 	mov    QWORD PTR [rbp-0x1f8],rax
   10752:	4d 8d 04 02          	lea    r8,[r10+rax*1]
   10756:	c5 fb 59 fb          	vmulsd xmm7,xmm0,xmm3
   1075a:	c5 fb 11 bd a8 fe ff 	vmovsd QWORD PTR [rbp-0x158],xmm7
   10761:	ff 
   10762:	0f 8e 58 11 00 00    	jle    118c0 <try_secant_tail.constprop.0+0x1c90>
   10768:	41 83 fd 01          	cmp    r13d,0x1
   1076c:	0f 84 02 1a 00 00    	je     12174 <try_secant_tail.constprop.0+0x2544>
   10772:	48 8d 04 cd f8 ff ff 	lea    rax,[rcx*8-0x8]
   10779:	ff 
   1077a:	48 83 f8 10          	cmp    rax,0x10
   1077e:	4c 89 d0             	mov    rax,r10
   10781:	0f 97 c2             	seta   dl
   10784:	48 29 f8             	sub    rax,rdi
   10787:	48 83 e8 08          	sub    rax,0x8
   1078b:	48 83 f8 10          	cmp    rax,0x10
   1078f:	0f 97 c0             	seta   al
   10792:	84 c2                	test   dl,al
   10794:	0f 84 69 1a 00 00    	je     12203 <try_secant_tail.constprop.0+0x25d3>
   1079a:	49 8d 47 f8          	lea    rax,[r15-0x8]
   1079e:	48 29 f8             	sub    rax,rdi
   107a1:	48 83 f8 10          	cmp    rax,0x10
   107a5:	0f 86 58 1a 00 00    	jbe    12203 <try_secant_tail.constprop.0+0x25d3>
   107ab:	41 8d 45 ff          	lea    eax,[r13-0x1]
   107af:	44 89 ad 70 fe ff ff 	mov    DWORD PTR [rbp-0x190],r13d
   107b6:	83 f8 02             	cmp    eax,0x2
   107b9:	0f 86 52 1a 00 00    	jbe    12211 <try_secant_tail.constprop.0+0x25e1>
   107bf:	44 89 e9             	mov    ecx,r13d
   107c2:	c4 e2 7d 19 d0       	vbroadcastsd ymm2,xmm0
   107c7:	31 d2                	xor    edx,edx
   107c9:	c1 e9 02             	shr    ecx,0x2
   107cc:	48 c1 e1 05          	shl    rcx,0x5
   107d0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   107d5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   107dc:	00 00 00 00 
   107e0:	c5 ed 59 0c 17       	vmulpd ymm1,ymm2,YMMWORD PTR [rdi+rdx*1]
   107e5:	c4 c1 7d 11 0c 17    	vmovupd YMMWORD PTR [r15+rdx*1],ymm1
   107eb:	c4 c1 7d 11 0c 12    	vmovupd YMMWORD PTR [r10+rdx*1],ymm1
   107f1:	48 83 c2 20          	add    rdx,0x20
   107f5:	48 39 d1             	cmp    rcx,rdx
   107f8:	75 e6                	jne    107e0 <try_secant_tail.constprop.0+0xbb0>
   107fa:	44 89 ea             	mov    edx,r13d
   107fd:	83 e2 fc             	and    edx,0xfffffffc
   10800:	41 39 d5             	cmp    r13d,edx
   10803:	89 d1                	mov    ecx,edx
   10805:	0f 84 79 10 00 00    	je     11884 <try_secant_tail.constprop.0+0x1c54>
   1080b:	45 89 eb             	mov    r11d,r13d
   1080e:	41 29 d3             	sub    r11d,edx
   10811:	41 83 fb 01          	cmp    r11d,0x1
   10815:	44 89 9d 70 fe ff ff 	mov    DWORD PTR [rbp-0x190],r11d
   1081c:	0f 84 23 1c 00 00    	je     12445 <try_secant_tail.constprop.0+0x2815>
   10822:	c5 f8 77             	vzeroupper
   10825:	c5 fb 12 c8          	vmovddup xmm1,xmm0
   10829:	c5 f1 59 0c cf       	vmulpd xmm1,xmm1,XMMWORD PTR [rdi+rcx*8]
   1082e:	c4 c1 79 11 0c cf    	vmovupd XMMWORD PTR [r15+rcx*8],xmm1
   10834:	48 03 8d 20 fe ff ff 	add    rcx,QWORD PTR [rbp-0x1e0]
   1083b:	c4 c1 79 11 0c cf    	vmovupd XMMWORD PTR [r15+rcx*8],xmm1
   10841:	8b 8d 70 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x190]
   10847:	f6 c1 01             	test   cl,0x1
   1084a:	74 1e                	je     1086a <try_secant_tail.constprop.0+0xc3a>
   1084c:	41 89 cb             	mov    r11d,ecx
   1084f:	41 83 e3 fe          	and    r11d,0xfffffffe
   10853:	44 01 da             	add    edx,r11d
   10856:	48 63 d2             	movsxd rdx,edx
   10859:	c5 fb 59 04 d7       	vmulsd xmm0,xmm0,QWORD PTR [rdi+rdx*8]
   1085e:	c4 c1 7b 11 04 d7    	vmovsd QWORD PTR [r15+rdx*8],xmm0
   10864:	c4 c1 7b 11 04 d2    	vmovsd QWORD PTR [r10+rdx*8],xmm0
   1086a:	8b 95 d0 fe ff ff    	mov    edx,DWORD PTR [rbp-0x130]
   10870:	4c 89 d7             	mov    rdi,r10
   10873:	44 89 e9             	mov    ecx,r13d
   10876:	4c 89 8d 30 fe ff ff 	mov    QWORD PTR [rbp-0x1d0],r9
   1087d:	89 85 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],eax
   10883:	4c 89 95 70 fe ff ff 	mov    QWORD PTR [rbp-0x190],r10
   1088a:	e8 01 2b ff ff       	call   3390 <project_cgs2>
   1088f:	4c 8b 95 70 fe ff ff 	mov    r10,QWORD PTR [rbp-0x190]
   10896:	44 89 ee             	mov    esi,r13d
   10899:	c5 fb 11 85 e8 fd ff 	vmovsd QWORD PTR [rbp-0x218],xmm0
   108a0:	ff 
   108a1:	4c 89 d7             	mov    rdi,r10
   108a4:	e8 97 f9 fe ff       	call   240 <norm2>
   108a9:	83 bd 38 fe ff ff 02 	cmp    DWORD PTR [rbp-0x1c8],0x2
   108b0:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   108b7:	44 89 ea             	mov    edx,r13d
   108ba:	4c 8b 8d 30 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1d0]
   108c1:	c5 f9 28 d0          	vmovapd xmm2,xmm0
   108c5:	0f 86 4f 19 00 00    	jbe    1221a <try_secant_tail.constprop.0+0x25ea>
   108cb:	44 89 ea             	mov    edx,r13d
   108ce:	31 c0                	xor    eax,eax
   108d0:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   108d4:	c1 ea 02             	shr    edx,0x2
   108d7:	48 c1 e2 05          	shl    rdx,0x5
   108db:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   108e0:	c5 fd 10 04 07       	vmovupd ymm0,YMMWORD PTR [rdi+rax*1]
   108e5:	c4 c1 7d 59 04 07    	vmulpd ymm0,ymm0,YMMWORD PTR [r15+rax*1]
   108eb:	48 83 c0 20          	add    rax,0x20
   108ef:	48 39 d0             	cmp    rax,rdx
   108f2:	c5 f5 58 c8          	vaddpd ymm1,ymm1,ymm0
   108f6:	75 e8                	jne    108e0 <try_secant_tail.constprop.0+0xcb0>
   108f8:	c4 e3 7d 19 c8 01    	vextractf128 xmm0,ymm1,0x1
   108fe:	41 f6 c5 03          	test   r13b,0x3
   10902:	c5 f9 58 c1          	vaddpd xmm0,xmm0,xmm1
   10906:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   1090a:	c5 f1 58 c8          	vaddpd xmm1,xmm1,xmm0
   1090e:	0f 84 10 0f 00 00    	je     11824 <try_secant_tail.constprop.0+0x1bf4>
   10914:	44 89 e8             	mov    eax,r13d
   10917:	83 e0 fc             	and    eax,0xfffffffc
   1091a:	89 c1                	mov    ecx,eax
   1091c:	c5 f8 77             	vzeroupper
   1091f:	44 89 ea             	mov    edx,r13d
   10922:	29 c2                	sub    edx,eax
   10924:	83 fa 01             	cmp    edx,0x1
   10927:	74 1e                	je     10947 <try_secant_tail.constprop.0+0xd17>
   10929:	c4 c1 79 10 34 c7    	vmovupd xmm6,XMMWORD PTR [r15+rax*8]
   1092f:	c4 e2 c9 b8 04 c7    	vfmadd231pd xmm0,xmm6,XMMWORD PTR [rdi+rax*8]
   10935:	f6 c2 01             	test   dl,0x1
   10938:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   1093c:	c5 f1 58 c8          	vaddpd xmm1,xmm1,xmm0
   10940:	74 14                	je     10956 <try_secant_tail.constprop.0+0xd26>
   10942:	83 e2 fe             	and    edx,0xfffffffe
   10945:	01 d1                	add    ecx,edx
   10947:	48 63 c9             	movsxd rcx,ecx
   1094a:	c4 c1 7b 10 3c cf    	vmovsd xmm7,QWORD PTR [r15+rcx*8]
   10950:	c4 e2 c1 b9 0c cf    	vfmadd231sd xmm1,xmm7,QWORD PTR [rdi+rcx*8]
   10956:	c5 fb 10 bd a8 fe ff 	vmovsd xmm7,QWORD PTR [rbp-0x158]
   1095d:	ff 
   1095e:	c5 c3 5c f1          	vsubsd xmm6,xmm7,xmm1
   10962:	c5 fb 11 b5 00 fe ff 	vmovsd QWORD PTR [rbp-0x200],xmm6
   10969:	ff 
   1096a:	44 89 ee             	mov    esi,r13d
   1096d:	4c 89 95 30 fe ff ff 	mov    QWORD PTR [rbp-0x1d0],r10
   10974:	4c 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r9
   1097b:	c5 fb 11 95 28 fe ff 	vmovsd QWORD PTR [rbp-0x1d8],xmm2
   10982:	ff 
   10983:	e8 b8 f8 fe ff       	call   240 <norm2>
   10988:	db ad 30 ff ff ff    	fld    TBYTE PTR [rbp-0xd0]
   1098e:	c5 fb 11 85 f8 fd ff 	vmovsd QWORD PTR [rbp-0x208],xmm0
   10995:	ff 
   10996:	db bd 70 fe ff ff    	fstp   TBYTE PTR [rbp-0x190]
   1099c:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 109a3 <try_secant_tail.constprop.0+0xd73>
   109a3:	e8 00 00 00 00       	call   109a8 <try_secant_tail.constprop.0+0xd78>
   109a8:	4c 8b 8d 38 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c8]
   109af:	4c 8b 95 30 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1d0]
   109b6:	c5 fb 10 95 28 fe ff 	vmovsd xmm2,QWORD PTR [rbp-0x1d8]
   109bd:	ff 
   109be:	d9 ee                	fldz
   109c0:	c5 fb 10 88 00 00 00 	vmovsd xmm1,QWORD PTR [rax+0x0]
   109c7:	00 
   109c8:	db ad 70 fe ff ff    	fld    TBYTE PTR [rbp-0x190]
   109ce:	db f1                	fcomi  st,st(1)
   109d0:	dd d9                	fstp   st(1)
   109d2:	0f 86 08 07 00 00    	jbe    110e0 <try_secant_tail.constprop.0+0x14b0>
   109d8:	d9 c0                	fld    st(0)
   109da:	d9 fa                	fsqrt
   109dc:	dd 9d 70 fe ff ff    	fstp   QWORD PTR [rbp-0x190]
   109e2:	c5 fb 10 85 70 fe ff 	vmovsd xmm0,QWORD PTR [rbp-0x190]
   109e9:	ff 
   109ea:	c5 f9 2f c1          	vcomisd xmm0,xmm1
   109ee:	76 08                	jbe    109f8 <try_secant_tail.constprop.0+0xdc8>
   109f0:	c5 fb 11 80 00 00 00 	vmovsd QWORD PTR [rax+0x0],xmm0
   109f7:	00 
   109f8:	c5 f9 2f 05 00 00 00 	vcomisd xmm0,QWORD PTR [rip+0x0]        # 10a00 <try_secant_tail.constprop.0+0xdd0>
   109ff:	00 
   10a00:	0f 82 4b 08 00 00    	jb     11251 <try_secant_tail.constprop.0+0x1621>
   10a06:	dd d8                	fstp   st(0)
   10a08:	eb 02                	jmp    10a0c <try_secant_tail.constprop.0+0xddc>
   10a0a:	dd d8                	fstp   st(0)
   10a0c:	8b 85 88 fe ff ff    	mov    eax,DWORD PTR [rbp-0x178]
   10a12:	49 89 da             	mov    r10,rbx
   10a15:	89 85 c0 fe ff ff    	mov    DWORD PTR [rbp-0x140],eax
   10a1b:	8b bd f8 fe ff ff    	mov    edi,DWORD PTR [rbp-0x108]
   10a21:	85 ff                	test   edi,edi
   10a23:	0f 88 c4 02 00 00    	js     10ced <try_secant_tail.constprop.0+0x10bd>
   10a29:	4c 89 95 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],r10
   10a30:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 10a37 <try_secant_tail.constprop.0+0xe07>
   10a37:	e8 00 00 00 00       	call   10a3c <try_secant_tail.constprop.0+0xe0c>
   10a3c:	4c 8b 95 f0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x110]
   10a43:	48 63 98 00 00 00 00 	movsxd rbx,DWORD PTR [rax+0x0]
   10a4a:	83 80 00 00 00 00 01 	add    DWORD PTR [rax+0x0],0x1
   10a51:	85 db                	test   ebx,ebx
   10a53:	0f 8e 64 02 00 00    	jle    10cbd <try_secant_tail.constprop.0+0x108d>
   10a59:	8d 53 ff             	lea    edx,[rbx-0x1]
   10a5c:	83 fa 07             	cmp    edx,0x7
   10a5f:	0f 86 d2 1a 00 00    	jbe    12537 <try_secant_tail.constprop.0+0x2907>
   10a65:	c4 e2 7d 58 85 f8 fe 	vpbroadcastd ymm0,DWORD PTR [rbp-0x108]
   10a6c:	ff ff 
   10a6e:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   10a75:	00 
   10a76:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   10a7b:	0f 85 cc 1b 00 00    	jne    1264d <try_secant_tail.constprop.0+0x2a1d>
   10a81:	41 89 dc             	mov    r12d,ebx
   10a84:	41 c1 ec 03          	shr    r12d,0x3
   10a88:	41 83 fc 01          	cmp    r12d,0x1
   10a8c:	0f 84 d0 1b 00 00    	je     12662 <try_secant_tail.constprop.0+0x2a32>
   10a92:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   10a99:	00 
   10a9a:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   10a9f:	0f 85 26 1e 00 00    	jne    128cb <try_secant_tail.constprop.0+0x2c9b>
   10aa5:	41 83 fc 02          	cmp    r12d,0x2
   10aa9:	0f 84 c5 00 00 00    	je     10b74 <try_secant_tail.constprop.0+0xf44>
   10aaf:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   10ab6:	00 
   10ab7:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   10abc:	0f 85 27 1e 00 00    	jne    128e9 <try_secant_tail.constprop.0+0x2cb9>
   10ac2:	41 83 fc 03          	cmp    r12d,0x3
   10ac6:	0f 84 a8 00 00 00    	je     10b74 <try_secant_tail.constprop.0+0xf44>
   10acc:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   10ad3:	00 
   10ad4:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   10ad9:	0f 85 17 1e 00 00    	jne    128f6 <try_secant_tail.constprop.0+0x2cc6>
   10adf:	41 83 fc 04          	cmp    r12d,0x4
   10ae3:	0f 84 8b 00 00 00    	je     10b74 <try_secant_tail.constprop.0+0xf44>
   10ae9:	4c 89 95 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],r10
   10af0:	c5 fd 7f 85 d0 fe ff 	vmovdqa YMMWORD PTR [rbp-0x130],ymm0
   10af7:	ff 
   10af8:	c5 f8 77             	vzeroupper
   10afb:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 10b02 <try_secant_tail.constprop.0+0xed2>
   10b02:	e8 00 00 00 00       	call   10b07 <try_secant_tail.constprop.0+0xed7>
   10b07:	c5 fd 6f 85 d0 fe ff 	vmovdqa ymm0,YMMWORD PTR [rbp-0x130]
   10b0e:	ff 
   10b0f:	4c 8b 95 f0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x110]
   10b16:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   10b1d:	00 
   10b1e:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   10b23:	0f 85 da 1d 00 00    	jne    12903 <try_secant_tail.constprop.0+0x2cd3>
   10b29:	41 83 fc 05          	cmp    r12d,0x5
   10b2d:	74 45                	je     10b74 <try_secant_tail.constprop.0+0xf44>
   10b2f:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   10b36:	00 
   10b37:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   10b3c:	0f 85 ce 1d 00 00    	jne    12910 <try_secant_tail.constprop.0+0x2ce0>
   10b42:	41 83 fc 06          	cmp    r12d,0x6
   10b46:	74 2c                	je     10b74 <try_secant_tail.constprop.0+0xf44>
   10b48:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   10b4f:	00 
   10b50:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   10b55:	0f 85 cb 1d 00 00    	jne    12926 <try_secant_tail.constprop.0+0x2cf6>
   10b5b:	41 83 fc 07          	cmp    r12d,0x7
   10b5f:	74 13                	je     10b74 <try_secant_tail.constprop.0+0xf44>
   10b61:	c5 fd 76 80 00 00 00 	vpcmpeqd ymm0,ymm0,YMMWORD PTR [rax+0x0]
   10b68:	00 
   10b69:	c4 e2 7d 17 c0       	vptest ymm0,ymm0
   10b6e:	0f 85 bf 1d 00 00    	jne    12933 <try_secant_tail.constprop.0+0x2d03>
   10b74:	f6 c3 07             	test   bl,0x7
   10b77:	0f 84 a3 1a 00 00    	je     12620 <try_secant_tail.constprop.0+0x29f0>
   10b7d:	89 d8                	mov    eax,ebx
   10b7f:	83 e0 f8             	and    eax,0xfffffff8
   10b82:	89 85 c0 fe ff ff    	mov    DWORD PTR [rbp-0x140],eax
   10b88:	4c 89 95 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],r10
   10b8f:	c5 f8 77             	vzeroupper
   10b92:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 10b99 <try_secant_tail.constprop.0+0xf69>
   10b99:	e8 00 00 00 00       	call   10b9e <try_secant_tail.constprop.0+0xf6e>
   10b9e:	48 63 95 c0 fe ff ff 	movsxd rdx,DWORD PTR [rbp-0x140]
   10ba5:	8b bd f8 fe ff ff    	mov    edi,DWORD PTR [rbp-0x108]
   10bab:	4c 8b 95 f0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x110]
   10bb2:	3b bc 90 00 00 00 00 	cmp    edi,DWORD PTR [rax+rdx*4+0x0]
   10bb9:	0f 84 2e 01 00 00    	je     10ced <try_secant_tail.constprop.0+0x10bd>
   10bbf:	44 8d 62 01          	lea    r12d,[rdx+0x1]
   10bc3:	44 39 e3             	cmp    ebx,r12d
   10bc6:	0f 8e ec 00 00 00    	jle    10cb8 <try_secant_tail.constprop.0+0x1088>
   10bcc:	4c 89 95 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],r10
   10bd3:	4d 63 e4             	movsxd r12,r12d
   10bd6:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 10bdd <try_secant_tail.constprop.0+0xfad>
   10bdd:	e8 00 00 00 00       	call   10be2 <try_secant_tail.constprop.0+0xfb2>
   10be2:	8b bd f8 fe ff ff    	mov    edi,DWORD PTR [rbp-0x108]
   10be8:	4c 8b 95 f0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x110]
   10bef:	42 3b bc a0 00 00 00 	cmp    edi,DWORD PTR [rax+r12*4+0x0]
   10bf6:	00 
   10bf7:	0f 84 f0 00 00 00    	je     10ced <try_secant_tail.constprop.0+0x10bd>
   10bfd:	8b 85 c0 fe ff ff    	mov    eax,DWORD PTR [rbp-0x140]
   10c03:	44 8d 60 02          	lea    r12d,[rax+0x2]
   10c07:	44 39 e3             	cmp    ebx,r12d
   10c0a:	0f 8e a8 00 00 00    	jle    10cb8 <try_secant_tail.constprop.0+0x1088>
   10c10:	4c 89 95 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],r10
   10c17:	4d 63 e4             	movsxd r12,r12d
   10c1a:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 10c21 <try_secant_tail.constprop.0+0xff1>
   10c21:	e8 00 00 00 00       	call   10c26 <try_secant_tail.constprop.0+0xff6>
   10c26:	44 8b bd f8 fe ff ff 	mov    r15d,DWORD PTR [rbp-0x108]
   10c2d:	4c 8b 95 f0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x110]
   10c34:	46 3b bc a0 00 00 00 	cmp    r15d,DWORD PTR [rax+r12*4+0x0]
   10c3b:	00 
   10c3c:	48 8d 90 00 00 00 00 	lea    rdx,[rax+0x0]
   10c43:	0f 84 a4 00 00 00    	je     10ced <try_secant_tail.constprop.0+0x10bd>
   10c49:	8b b5 c0 fe ff ff    	mov    esi,DWORD PTR [rbp-0x140]
   10c4f:	8d 46 03             	lea    eax,[rsi+0x3]
   10c52:	39 c3                	cmp    ebx,eax
   10c54:	7e 62                	jle    10cb8 <try_secant_tail.constprop.0+0x1088>
   10c56:	48 98                	cdqe
   10c58:	44 3b 3c 82          	cmp    r15d,DWORD PTR [rdx+rax*4]
   10c5c:	0f 84 8b 00 00 00    	je     10ced <try_secant_tail.constprop.0+0x10bd>
   10c62:	8d 46 04             	lea    eax,[rsi+0x4]
   10c65:	39 c3                	cmp    ebx,eax
   10c67:	7e 4f                	jle    10cb8 <try_secant_tail.constprop.0+0x1088>
   10c69:	48 98                	cdqe
   10c6b:	44 3b 3c 82          	cmp    r15d,DWORD PTR [rdx+rax*4]
   10c6f:	74 7c                	je     10ced <try_secant_tail.constprop.0+0x10bd>
   10c71:	8d 46 05             	lea    eax,[rsi+0x5]
   10c74:	39 c3                	cmp    ebx,eax
   10c76:	7e 40                	jle    10cb8 <try_secant_tail.constprop.0+0x1088>
   10c78:	48 98                	cdqe
   10c7a:	44 3b 3c 82          	cmp    r15d,DWORD PTR [rdx+rax*4]
   10c7e:	74 6d                	je     10ced <try_secant_tail.constprop.0+0x10bd>
   10c80:	8d 46 06             	lea    eax,[rsi+0x6]
   10c83:	39 c3                	cmp    ebx,eax
   10c85:	7e 31                	jle    10cb8 <try_secant_tail.constprop.0+0x1088>
   10c87:	48 98                	cdqe
   10c89:	44 3b 3c 82          	cmp    r15d,DWORD PTR [rdx+rax*4]
   10c8d:	74 5e                	je     10ced <try_secant_tail.constprop.0+0x10bd>
   10c8f:	44 8d 66 07          	lea    r12d,[rsi+0x7]
   10c93:	44 39 e3             	cmp    ebx,r12d
   10c96:	7e 20                	jle    10cb8 <try_secant_tail.constprop.0+0x1088>
   10c98:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 10c9f <try_secant_tail.constprop.0+0x106f>
   10c9f:	e8 00 00 00 00       	call   10ca4 <try_secant_tail.constprop.0+0x1074>
   10ca4:	4d 63 e4             	movsxd r12,r12d
   10ca7:	4c 8b 95 f0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x110]
   10cae:	46 3b bc a0 00 00 00 	cmp    r15d,DWORD PTR [rax+r12*4+0x0]
   10cb5:	00 
   10cb6:	74 35                	je     10ced <try_secant_tail.constprop.0+0x10bd>
   10cb8:	83 fb 40             	cmp    ebx,0x40
   10cbb:	74 30                	je     10ced <try_secant_tail.constprop.0+0x10bd>
   10cbd:	4c 89 95 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],r10
   10cc4:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 10ccb <try_secant_tail.constprop.0+0x109b>
   10ccb:	e8 00 00 00 00       	call   10cd0 <try_secant_tail.constprop.0+0x10a0>
   10cd0:	8b bd f8 fe ff ff    	mov    edi,DWORD PTR [rbp-0x108]
   10cd6:	8d 53 01             	lea    edx,[rbx+0x1]
   10cd9:	4c 8b 95 f0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x110]
   10ce0:	89 90 00 00 00 00    	mov    DWORD PTR [rax+0x0],edx
   10ce6:	89 bc 98 00 00 00 00 	mov    DWORD PTR [rax+rbx*4+0x0],edi
   10ced:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
   10cf4:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   10cfb:	e8 00 00 00 00       	call   10d00 <try_secant_tail.constprop.0+0x10d0>
   10d00:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   10d07:	e8 00 00 00 00       	call   10d0c <try_secant_tail.constprop.0+0x10dc>
   10d0c:	48 8b bd 20 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe0]
   10d13:	e8 00 00 00 00       	call   10d18 <try_secant_tail.constprop.0+0x10e8>
   10d18:	4c 89 f7             	mov    rdi,r14
   10d1b:	e8 00 00 00 00       	call   10d20 <try_secant_tail.constprop.0+0x10f0>
   10d20:	48 8b bd f8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x108]
   10d27:	e8 00 00 00 00       	call   10d2c <try_secant_tail.constprop.0+0x10fc>
   10d2c:	48 8b bd 58 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1a8]
   10d33:	e8 00 00 00 00       	call   10d38 <try_secant_tail.constprop.0+0x1108>
   10d38:	48 8b bd 10 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f0]
   10d3f:	e8 00 00 00 00       	call   10d44 <try_secant_tail.constprop.0+0x1114>
   10d44:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   10d4b:	e8 00 00 00 00       	call   10d50 <try_secant_tail.constprop.0+0x1120>
   10d50:	45 31 e4             	xor    r12d,r12d
   10d53:	e9 6f ef ff ff       	jmp    fcc7 <try_secant_tail.constprop.0+0x97>
   10d58:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
   10d5f:	00 
   10d60:	41 89 f5             	mov    r13d,esi
   10d63:	8d 86 00 08 00 00    	lea    eax,[rsi+0x800]
   10d69:	8b b5 cc fe ff ff    	mov    esi,DWORD PTR [rbp-0x134]
   10d6f:	4c 89 8d d0 fe ff ff 	mov    QWORD PTR [rbp-0x130],r9
   10d76:	48 8b bd 58 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1a8]
   10d7d:	b9 00 08 00 00       	mov    ecx,0x800
   10d82:	39 f0                	cmp    eax,esi
   10d84:	0f 4f c6             	cmovg  eax,esi
   10d87:	31 f6                	xor    esi,esi
   10d89:	89 85 c8 fe ff ff    	mov    DWORD PTR [rbp-0x138],eax
   10d8f:	41 89 c7             	mov    r15d,eax
   10d92:	45 29 ef             	sub    r15d,r13d
   10d95:	49 63 d7             	movsxd rdx,r15d
   10d98:	c5 f8 77             	vzeroupper
   10d9b:	e8 00 00 00 00       	call   10da0 <try_secant_tail.constprop.0+0x1170>
   10da0:	48 8b 8d 90 fd ff ff 	mov    rcx,QWORD PTR [rbp-0x270]
   10da7:	31 f6                	xor    esi,esi
   10da9:	48 8b bd 10 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f0]
   10db0:	48 89 ca             	mov    rdx,rcx
   10db3:	e8 00 00 00 00       	call   10db8 <try_secant_tail.constprop.0+0x1188>
   10db8:	48 8b 8d 98 fd ff ff 	mov    rcx,QWORD PTR [rbp-0x268]
   10dbf:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   10dc6:	31 f6                	xor    esi,esi
   10dc8:	48 89 ca             	mov    rdx,rcx
   10dcb:	e8 00 00 00 00       	call   10dd0 <try_secant_tail.constprop.0+0x11a0>
   10dd0:	48 8b 85 40 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c0]
   10dd7:	31 c9                	xor    ecx,ecx
   10dd9:	31 d2                	xor    edx,edx
   10ddb:	44 89 6d 9c          	mov    DWORD PTR [rbp-0x64],r13d
   10ddf:	c5 f9 6f ad a0 fd ff 	vmovdqa xmm5,XMMWORD PTR [rbp-0x260]
   10de6:	ff 
   10de7:	4c 8d ad 40 ff ff ff 	lea    r13,[rbp-0xc0]
   10dee:	48 8d 3d db 3c ff ff 	lea    rdi,[rip+0xffffffffffff3cdb]        # 4ad0 <try_secant_tail._omp_fn.0>
   10df5:	48 89 45 90          	mov    QWORD PTR [rbp-0x70],rax
   10df9:	48 8b 85 d8 fd ff ff 	mov    rax,QWORD PTR [rbp-0x228]
   10e00:	4c 89 ee             	mov    rsi,r13
   10e03:	c5 f9 28 b5 60 fe ff 	vmovapd xmm6,XMMWORD PTR [rbp-0x1a0]
   10e0a:	ff 
   10e0b:	c5 f9 6f bd b0 fd ff 	vmovdqa xmm7,XMMWORD PTR [rbp-0x250]
   10e12:	ff 
   10e13:	44 89 7d a0          	mov    DWORD PTR [rbp-0x60],r15d
   10e17:	48 89 85 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],rax
   10e1e:	48 8b 05 00 00 00 00 	mov    rax,QWORD PTR [rip+0x0]        # 10e25 <try_secant_tail.constprop.0+0x11f5>
   10e25:	4c 89 b5 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],r14
   10e2c:	48 89 85 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],rax
   10e33:	48 8b 85 18 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1e8]
   10e3a:	44 89 65 98          	mov    DWORD PTR [rbp-0x68],r12d
   10e3e:	48 89 85 60 ff ff ff 	mov    QWORD PTR [rbp-0xa0],rax
   10e45:	c5 f9 7f 6d 80       	vmovdqa XMMWORD PTR [rbp-0x80],xmm5
   10e4a:	c5 f9 29 b5 70 ff ff 	vmovapd XMMWORD PTR [rbp-0x90],xmm6
   10e51:	ff 
   10e52:	c5 f9 7f bd 40 ff ff 	vmovdqa XMMWORD PTR [rbp-0xc0],xmm7
   10e59:	ff 
   10e5a:	e8 00 00 00 00       	call   10e5f <try_secant_tail.constprop.0+0x122f>
   10e5f:	44 8b 8d 4c fe ff ff 	mov    r9d,DWORD PTR [rbp-0x1b4]
   10e66:	45 85 c9             	test   r9d,r9d
   10e69:	4c 8b 8d d0 fe ff ff 	mov    r9,QWORD PTR [rbp-0x130]
   10e70:	0f 8e 9b 01 00 00    	jle    11011 <try_secant_tail.constprop.0+0x13e1>
   10e76:	45 85 e4             	test   r12d,r12d
   10e79:	c5 fb 10 55 b8       	vmovsd xmm2,QWORD PTR [rbp-0x48]
   10e7e:	c5 fb 10 45 b0       	vmovsd xmm0,QWORD PTR [rbp-0x50]
   10e83:	0f 8e 1c 01 00 00    	jle    10fa5 <try_secant_tail.constprop.0+0x1375>
   10e89:	8b bd c0 fd ff ff    	mov    edi,DWORD PTR [rbp-0x240]
   10e8f:	4c 89 ad 70 fe ff ff 	mov    QWORD PTR [rbp-0x190],r13
   10e96:	31 f6                	xor    esi,esi
   10e98:	45 31 d2             	xor    r10d,r10d
   10e9b:	44 89 bd a8 fe ff ff 	mov    DWORD PTR [rbp-0x158],r15d
   10ea2:	4c 8b 9d 10 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1f0]
   10ea9:	89 f8                	mov    eax,edi
   10eab:	44 89 a5 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r12d
   10eb2:	4c 8b bd 88 fd ff ff 	mov    r15,QWORD PTR [rbp-0x278]
   10eb9:	4c 89 b5 30 fe ff ff 	mov    QWORD PTR [rbp-0x1d0],r14
   10ec0:	c1 e8 02             	shr    eax,0x2
   10ec3:	44 8b a5 84 fd ff ff 	mov    r12d,DWORD PTR [rbp-0x27c]
   10eca:	44 8b b5 4c fe ff ff 	mov    r14d,DWORD PTR [rbp-0x1b4]
   10ed1:	4c 89 8d d0 fe ff ff 	mov    QWORD PTR [rbp-0x130],r9
   10ed8:	48 c1 e0 05          	shl    rax,0x5
   10edc:	41 89 f9             	mov    r9d,edi
   10edf:	90                   	nop
   10ee0:	41 81 fc fb ff ff 7f 	cmp    r12d,0x7ffffffb
   10ee7:	4c 8d 04 f5 00 00 00 	lea    r8,[rsi*8+0x0]
   10eee:	00 
   10eef:	0f 87 53 03 00 00    	ja     11248 <try_secant_tail.constprop.0+0x1618>
   10ef5:	4b 8d 0c 03          	lea    rcx,[r11+r8*1]
   10ef9:	31 d2                	xor    edx,edx
   10efb:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   10f00:	c5 fd 10 0c 11       	vmovupd ymm1,YMMWORD PTR [rcx+rdx*1]
   10f05:	c5 f5 58 0c 13       	vaddpd ymm1,ymm1,YMMWORD PTR [rbx+rdx*1]
   10f0a:	c5 fd 11 0c 13       	vmovupd YMMWORD PTR [rbx+rdx*1],ymm1
   10f0f:	48 83 c2 20          	add    rdx,0x20
   10f13:	48 39 d0             	cmp    rax,rdx
   10f16:	75 e8                	jne    10f00 <try_secant_tail.constprop.0+0x12d0>
   10f18:	41 f6 c1 03          	test   r9b,0x3
   10f1c:	0f 84 9e 01 00 00    	je     110c0 <try_secant_tail.constprop.0+0x1490>
   10f22:	44 89 ca             	mov    edx,r9d
   10f25:	83 e2 fc             	and    edx,0xfffffffc
   10f28:	89 d1                	mov    ecx,edx
   10f2a:	44 89 cf             	mov    edi,r9d
   10f2d:	29 d7                	sub    edi,edx
   10f2f:	83 ff 01             	cmp    edi,0x1
   10f32:	74 24                	je     10f58 <try_secant_tail.constprop.0+0x1328>
   10f34:	4c 8d 2c d3          	lea    r13,[rbx+rdx*8]
   10f38:	48 01 f2             	add    rdx,rsi
   10f3b:	40 f6 c7 01          	test   dil,0x1
   10f3f:	c4 c1 79 10 4d 00    	vmovupd xmm1,XMMWORD PTR [r13+0x0]
   10f45:	c4 c1 71 58 0c d3    	vaddpd xmm1,xmm1,XMMWORD PTR [r11+rdx*8]
   10f4b:	c4 c1 79 11 4d 00    	vmovupd XMMWORD PTR [r13+0x0],xmm1
   10f51:	74 1f                	je     10f72 <try_secant_tail.constprop.0+0x1342>
   10f53:	83 e7 fe             	and    edi,0xfffffffe
   10f56:	01 f9                	add    ecx,edi
   10f58:	48 63 c9             	movsxd rcx,ecx
   10f5b:	4d 01 d8             	add    r8,r11
   10f5e:	48 c1 e1 03          	shl    rcx,0x3
   10f62:	c5 fb 10 0c 0b       	vmovsd xmm1,QWORD PTR [rbx+rcx*1]
   10f67:	c4 c1 73 58 0c 08    	vaddsd xmm1,xmm1,QWORD PTR [r8+rcx*1]
   10f6d:	c5 fb 11 0c 0b       	vmovsd QWORD PTR [rbx+rcx*1],xmm1
   10f72:	41 83 c2 01          	add    r10d,0x1
   10f76:	4c 01 fe             	add    rsi,r15
   10f79:	45 39 d6             	cmp    r14d,r10d
   10f7c:	0f 85 5e ff ff ff    	jne    10ee0 <try_secant_tail.constprop.0+0x12b0>
   10f82:	4c 8b 8d d0 fe ff ff 	mov    r9,QWORD PTR [rbp-0x130]
   10f89:	44 8b bd a8 fe ff ff 	mov    r15d,DWORD PTR [rbp-0x158]
   10f90:	4c 8b ad 70 fe ff ff 	mov    r13,QWORD PTR [rbp-0x190]
   10f97:	44 8b a5 38 fe ff ff 	mov    r12d,DWORD PTR [rbp-0x1c8]
   10f9e:	4c 8b b5 30 fe ff ff 	mov    r14,QWORD PTR [rbp-0x1d0]
   10fa5:	8b 95 4c fe ff ff    	mov    edx,DWORD PTR [rbp-0x1b4]
   10fab:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   10fb2:	c5 f9 14 c2          	vunpcklpd xmm0,xmm0,xmm2
   10fb6:	c5 f9 28 c0          	vmovapd xmm0,xmm0
   10fba:	d1 ea                	shr    edx,1
   10fbc:	48 89 f8             	mov    rax,rdi
   10fbf:	48 c1 e2 05          	shl    rdx,0x5
   10fc3:	48 01 fa             	add    rdx,rdi
   10fc6:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
   10fcd:	00 00 00 
   10fd0:	c5 fd 58 00          	vaddpd ymm0,ymm0,YMMWORD PTR [rax]
   10fd4:	48 83 c0 20          	add    rax,0x20
   10fd8:	48 39 d0             	cmp    rax,rdx
   10fdb:	75 f3                	jne    10fd0 <try_secant_tail.constprop.0+0x13a0>
   10fdd:	8b bd 4c fe ff ff    	mov    edi,DWORD PTR [rbp-0x1b4]
   10fe3:	c5 f9 28 c8          	vmovapd xmm1,xmm0
   10fe7:	c4 e3 7d 19 c0 01    	vextractf128 xmm0,ymm0,0x1
   10fed:	c5 f1 58 c0          	vaddpd xmm0,xmm1,xmm0
   10ff1:	40 f6 c7 01          	test   dil,0x1
   10ff5:	74 15                	je     1100c <try_secant_tail.constprop.0+0x13dc>
   10ff7:	89 f8                	mov    eax,edi
   10ff9:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   11000:	83 e0 fe             	and    eax,0xfffffffe
   11003:	48 c1 e0 04          	shl    rax,0x4
   11007:	c5 f9 58 04 06       	vaddpd xmm0,xmm0,XMMWORD PTR [rsi+rax*1]
   1100c:	c5 f9 29 45 b0       	vmovapd XMMWORD PTR [rbp-0x50],xmm0
   11011:	45 85 ff             	test   r15d,r15d
   11014:	0f 8e dd 07 00 00    	jle    117f7 <try_secant_tail.constprop.0+0x1bc7>
   1101a:	8b b5 e4 fd ff ff    	mov    esi,DWORD PTR [rbp-0x21c]
   11020:	ba 2f 00 00 00       	mov    edx,0x2f
   11025:	41 8d 4f ff          	lea    ecx,[r15-0x1]
   11029:	8d 46 20             	lea    eax,[rsi+0x20]
   1102c:	39 d0                	cmp    eax,edx
   1102e:	0f 42 c2             	cmovb  eax,edx
   11031:	39 c1                	cmp    ecx,eax
   11033:	0f 82 3f 15 00 00    	jb     12578 <try_secant_tail.constprop.0+0x2948>
   11039:	85 f6                	test   esi,esi
   1103b:	0f 84 76 01 00 00    	je     111b7 <try_secant_tail.constprop.0+0x1587>
   11041:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   11048:	89 f1                	mov    ecx,esi
   1104a:	31 c0                	xor    eax,eax
   1104c:	eb 11                	jmp    1105f <try_secant_tail.constprop.0+0x142f>
   1104e:	66 90                	xchg   ax,ax
   11050:	83 c0 01             	add    eax,0x1
   11053:	48 83 c2 01          	add    rdx,0x1
   11057:	39 c6                	cmp    esi,eax
   11059:	0f 84 5a 01 00 00    	je     111b9 <try_secant_tail.constprop.0+0x1589>
   1105f:	80 3a 00             	cmp    BYTE PTR [rdx],0x0
   11062:	74 ec                	je     11050 <try_secant_tail.constprop.0+0x1420>
   11064:	8b 95 0c ff ff ff    	mov    edx,DWORD PTR [rbp-0xf4]
   1106a:	8b bd 04 ff ff ff    	mov    edi,DWORD PTR [rbp-0xfc]
   11070:	85 d2                	test   edx,edx
   11072:	89 bd d0 fe ff ff    	mov    DWORD PTR [rbp-0x130],edi
   11078:	0f 85 2f 18 00 00    	jne    128ad <try_secant_tail.constprop.0+0x2c7d>
   1107e:	01 85 f8 fe ff ff    	add    DWORD PTR [rbp-0x108],eax
   11084:	48 8b bd f0 fd ff ff 	mov    rdi,QWORD PTR [rbp-0x210]
   1108b:	48 63 85 f8 fe ff ff 	movsxd rax,DWORD PTR [rbp-0x108]
   11092:	48 8b b5 98 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x168]
   11099:	44 8b ad 00 ff ff ff 	mov    r13d,DWORD PTR [rbp-0x100]
   110a0:	48 0f af f8          	imul   rdi,rax
   110a4:	48 03 bd b8 fe ff ff 	add    rdi,QWORD PTR [rbp-0x148]
   110ab:	c5 fb 10 1c c6       	vmovsd xmm3,QWORD PTR [rsi+rax*8]
   110b0:	c5 f8 77             	vzeroupper
   110b3:	e9 70 f2 ff ff       	jmp    10328 <try_secant_tail.constprop.0+0x6f8>
   110b8:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
   110bf:	00 
   110c0:	41 83 c2 01          	add    r10d,0x1
   110c4:	45 39 d6             	cmp    r14d,r10d
   110c7:	0f 84 b5 fe ff ff    	je     10f82 <try_secant_tail.constprop.0+0x1352>
   110cd:	4c 01 fe             	add    rsi,r15
   110d0:	4c 8d 04 f5 00 00 00 	lea    r8,[rsi*8+0x0]
   110d7:	00 
   110d8:	e9 18 fe ff ff       	jmp    10ef5 <try_secant_tail.constprop.0+0x12c5>
   110dd:	0f 1f 00             	nop    DWORD PTR [rax]
   110e0:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   110e4:	c5 f9 2f c1          	vcomisd xmm0,xmm1
   110e8:	76 0b                	jbe    110f5 <try_secant_tail.constprop.0+0x14c5>
   110ea:	48 c7 80 00 00 00 00 	mov    QWORD PTR [rax+0x0],0x0
   110f1:	00 00 00 00 
   110f5:	c5 fb 10 25 00 00 00 	vmovsd xmm4,QWORD PTR [rip+0x0]        # 110fd <try_secant_tail.constprop.0+0x14cd>
   110fc:	00 
   110fd:	c5 f9 2f d4          	vcomisd xmm2,xmm4
   11101:	0f 86 8b 01 00 00    	jbe    11292 <try_secant_tail.constprop.0+0x1662>
   11107:	c5 f9 28 c4          	vmovapd xmm0,xmm4
   1110b:	c5 eb 5c c8          	vsubsd xmm1,xmm2,xmm0
   1110f:	c5 f9 2f 0d 00 00 00 	vcomisd xmm1,QWORD PTR [rip+0x0]        # 11117 <try_secant_tail.constprop.0+0x14e7>
   11116:	00 
   11117:	0f 86 5b 01 00 00    	jbe    11278 <try_secant_tail.constprop.0+0x1648>
   1111d:	44 8b 9d 04 ff ff ff 	mov    r11d,DWORD PTR [rbp-0xfc]
   11124:	45 39 dd             	cmp    r13d,r11d
   11127:	0f 8e dd f8 ff ff    	jle    10a0a <try_secant_tail.constprop.0+0xdda>
   1112d:	8b 85 08 ff ff ff    	mov    eax,DWORD PTR [rbp-0xf8]
   11133:	41 39 c3             	cmp    r11d,eax
   11136:	0f 8c e4 07 00 00    	jl     11920 <try_secant_tail.constprop.0+0x1cf0>
   1113c:	dd d8                	fstp   st(0)
   1113e:	83 f8 07             	cmp    eax,0x7
   11141:	48 63 8d 00 ff ff ff 	movsxd rcx,DWORD PTR [rbp-0x100]
   11148:	0f 8f d1 0e 00 00    	jg     1201f <try_secant_tail.constprop.0+0x23ef>
   1114e:	41 b8 08 00 00 00    	mov    r8d,0x8
   11154:	44 39 c1             	cmp    ecx,r8d
   11157:	44 0f 4e c1          	cmovle r8d,ecx
   1115b:	44 39 c0             	cmp    eax,r8d
   1115e:	7d 1b                	jge    1117b <try_secant_tail.constprop.0+0x154b>
   11160:	48 b8 ff ff ff ff ff 	movabs rax,0x1fffffffffffffff
   11167:	ff ff 1f 
   1116a:	31 d2                	xor    edx,edx
   1116c:	49 63 f0             	movsxd rsi,r8d
   1116f:	48 f7 f1             	div    rcx
   11172:	48 39 f0             	cmp    rax,rsi
   11175:	0f 83 df 0e 00 00    	jae    1205a <try_secant_tail.constprop.0+0x242a>
   1117b:	44 8b 85 0c ff ff ff 	mov    r8d,DWORD PTR [rbp-0xf4]
   11182:	45 85 c0             	test   r8d,r8d
   11185:	0f 85 c9 18 00 00    	jne    12a54 <try_secant_tail.constprop.0+0x2e24>
   1118b:	83 85 f8 fe ff ff 01 	add    DWORD PTR [rbp-0x108],0x1
   11192:	8b 85 f8 fe ff ff    	mov    eax,DWORD PTR [rbp-0x108]
   11198:	39 85 cc fe ff ff    	cmp    DWORD PTR [rbp-0x134],eax
   1119e:	0f 8e a1 18 00 00    	jle    12a45 <try_secant_tail.constprop.0+0x2e15>
   111a4:	83 85 c0 fe ff ff 01 	add    DWORD PTR [rbp-0x140],0x1
   111ab:	44 89 9d d0 fe ff ff 	mov    DWORD PTR [rbp-0x130],r11d
   111b2:	e9 e1 ee ff ff       	jmp    10098 <try_secant_tail.constprop.0+0x468>
   111b7:	31 c9                	xor    ecx,ecx
   111b9:	44 89 f8             	mov    eax,r15d
   111bc:	c5 f9 6e c9          	vmovd  xmm1,ecx
   111c0:	c5 e9 ef d2          	vpxor  xmm2,xmm2,xmm2
   111c4:	bf 20 00 00 00       	mov    edi,0x20
   111c9:	8b 95 e4 fd ff ff    	mov    edx,DWORD PTR [rbp-0x21c]
   111cf:	c5 f9 6e df          	vmovd  xmm3,edi
   111d3:	c4 e2 7d 58 c9       	vpbroadcastd ymm1,xmm1
   111d8:	c5 f5 fe 0d 00 00 00 	vpaddd ymm1,ymm1,YMMWORD PTR [rip+0x0]        # 111e0 <try_secant_tail.constprop.0+0x15b0>
   111df:	00 
   111e0:	c4 e2 7d 58 db       	vpbroadcastd ymm3,xmm3
   111e5:	29 d0                	sub    eax,edx
   111e7:	48 03 95 58 fe ff ff 	add    rdx,QWORD PTR [rbp-0x1a8]
   111ee:	89 c6                	mov    esi,eax
   111f0:	c1 ee 05             	shr    esi,0x5
   111f3:	48 c1 e6 05          	shl    rsi,0x5
   111f7:	48 01 d6             	add    rsi,rdx
   111fa:	eb 15                	jmp    11211 <try_secant_tail.constprop.0+0x15e1>
   111fc:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   11200:	48 83 c2 20          	add    rdx,0x20
   11204:	c5 f5 fe cb          	vpaddd ymm1,ymm1,ymm3
   11208:	48 39 f2             	cmp    rdx,rsi
   1120b:	0f 84 40 06 00 00    	je     11851 <try_secant_tail.constprop.0+0x1c21>
   11211:	c5 ed 74 02          	vpcmpeqb ymm0,ymm2,YMMWORD PTR [rdx]
   11215:	c5 fd 74 c2          	vpcmpeqb ymm0,ymm0,ymm2
   11219:	c4 e2 7d 17 c0       	vptest ymm0,ymm0
   1121e:	74 e0                	je     11200 <try_secant_tail.constprop.0+0x15d0>
   11220:	c5 f9 7e c8          	vmovd  eax,xmm1
   11224:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   1122b:	48 98                	cdqe
   1122d:	eb 0e                	jmp    1123d <try_secant_tail.constprop.0+0x160d>
   1122f:	90                   	nop
   11230:	48 83 c0 01          	add    rax,0x1
   11234:	41 39 c7             	cmp    r15d,eax
   11237:	0f 8e ba 05 00 00    	jle    117f7 <try_secant_tail.constprop.0+0x1bc7>
   1123d:	80 3c 02 00          	cmp    BYTE PTR [rdx+rax*1],0x0
   11241:	74 ed                	je     11230 <try_secant_tail.constprop.0+0x1600>
   11243:	e9 1c fe ff ff       	jmp    11064 <try_secant_tail.constprop.0+0x1434>
   11248:	31 c9                	xor    ecx,ecx
   1124a:	31 d2                	xor    edx,edx
   1124c:	e9 d9 fc ff ff       	jmp    10f2a <try_secant_tail.constprop.0+0x12fa>
   11251:	c5 fb 58 8d b0 fe ff 	vaddsd xmm1,xmm0,QWORD PTR [rbp-0x150]
   11258:	ff 
   11259:	c5 fb 10 25 00 00 00 	vmovsd xmm4,QWORD PTR [rip+0x0]        # 11261 <try_secant_tail.constprop.0+0x1631>
   11260:	00 
   11261:	c5 f3 59 cc          	vmulsd xmm1,xmm1,xmm4
   11265:	c4 e2 f1 99 c0       	vfmadd132sd xmm0,xmm1,xmm0
   1126a:	c5 f9 2f d0          	vcomisd xmm2,xmm0
   1126e:	0f 87 97 fe ff ff    	ja     1110b <try_secant_tail.constprop.0+0x14db>
   11274:	dd d8                	fstp   st(0)
   11276:	eb 02                	jmp    1127a <try_secant_tail.constprop.0+0x164a>
   11278:	dd d8                	fstp   st(0)
   1127a:	c5 fb 58 c2          	vaddsd xmm0,xmm0,xmm2
   1127e:	c5 fb 10 0d 00 00 00 	vmovsd xmm1,QWORD PTR [rip+0x0]        # 11286 <try_secant_tail.constprop.0+0x1656>
   11285:	00 
   11286:	c5 f9 2f c8          	vcomisd xmm1,xmm0
   1128a:	0f 86 7c f7 ff ff    	jbe    10a0c <try_secant_tail.constprop.0+0xddc>
   11290:	eb 02                	jmp    11294 <try_secant_tail.constprop.0+0x1664>
   11292:	dd d8                	fstp   st(0)
   11294:	c5 fb 10 ad a8 fe ff 	vmovsd xmm5,QWORD PTR [rbp-0x158]
   1129b:	ff 
   1129c:	c5 d1 54 05 00 00 00 	vandpd xmm0,xmm5,XMMWORD PTR [rip+0x0]        # 112a4 <try_secant_tail.constprop.0+0x1674>
   112a3:	00 
   112a4:	c5 fb 58 85 b0 fe ff 	vaddsd xmm0,xmm0,QWORD PTR [rbp-0x150]
   112ab:	ff 
   112ac:	c5 fb 58 85 f8 fd ff 	vaddsd xmm0,xmm0,QWORD PTR [rbp-0x208]
   112b3:	ff 
   112b4:	c5 fb 59 05 00 00 00 	vmulsd xmm0,xmm0,QWORD PTR [rip+0x0]        # 112bc <try_secant_tail.constprop.0+0x168c>
   112bb:	00 
   112bc:	c5 fb 10 ad 00 fe ff 	vmovsd xmm5,QWORD PTR [rbp-0x200]
   112c3:	ff 
   112c4:	c5 d1 54 0d 00 00 00 	vandpd xmm1,xmm5,XMMWORD PTR [rip+0x0]        # 112cc <try_secant_tail.constprop.0+0x169c>
   112cb:	00 
   112cc:	8b 85 04 ff ff ff    	mov    eax,DWORD PTR [rbp-0xfc]
   112d2:	89 85 d0 fe ff ff    	mov    DWORD PTR [rbp-0x130],eax
   112d8:	c5 f9 2f c8          	vcomisd xmm1,xmm0
   112dc:	0f 86 aa 05 00 00    	jbe    1188c <try_secant_tail.constprop.0+0x1c5c>
   112e2:	8b 85 88 fe ff ff    	mov    eax,DWORD PTR [rbp-0x178]
   112e8:	44 3b ad d0 fe ff ff 	cmp    r13d,DWORD PTR [rbp-0x130]
   112ef:	4c 89 ff             	mov    rdi,r15
   112f2:	89 85 c0 fe ff ff    	mov    DWORD PTR [rbp-0x140],eax
   112f8:	0f 84 03 17 00 00    	je     12a01 <try_secant_tail.constprop.0+0x2dd1>
   112fe:	48 89 fe             	mov    rsi,rdi
   11301:	48 8b bd 18 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1e8]
   11308:	48 89 9d d0 fe ff ff 	mov    QWORD PTR [rbp-0x130],rbx
   1130f:	e8 5c 29 ff ff       	call   3c70 <local_dependency_svd>
   11314:	4c 8b 95 d0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x130]
   1131b:	83 f8 01             	cmp    eax,0x1
   1131e:	0f 85 f7 f6 ff ff    	jne    10a1b <try_secant_tail.constprop.0+0xdeb>
   11324:	8b 85 04 ff ff ff    	mov    eax,DWORD PTR [rbp-0xfc]
   1132a:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   11331:	c7 85 0c ff ff ff 01 	mov    DWORD PTR [rbp-0xf4],0x1
   11338:	00 00 00 
   1133b:	89 85 d0 fe ff ff    	mov    DWORD PTR [rbp-0x130],eax
   11341:	48 8b bd 58 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1a8]
   11348:	4c 8d ad 40 ff ff ff 	lea    r13,[rbp-0xc0]
   1134f:	e8 00 00 00 00       	call   11354 <try_secant_tail.constprop.0+0x1724>
   11354:	48 8b bd 10 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f0]
   1135b:	e8 00 00 00 00       	call   11360 <try_secant_tail.constprop.0+0x1730>
   11360:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   11367:	e8 00 00 00 00       	call   1136c <try_secant_tail.constprop.0+0x173c>
   1136c:	4c 8b 95 f8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x108]
   11373:	48 8b 85 d0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x230]
   1137a:	8b 9d d0 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x130]
   11380:	4c 89 ee             	mov    rsi,r13
   11383:	48 8d 3d a6 f2 fe ff 	lea    rdi,[rip+0xfffffffffffef2a6]        # 630 <relres._omp_fn.0>
   1138a:	c5 f9 6e bd cc fe ff 	vmovd  xmm7,DWORD PTR [rbp-0x134]
   11391:	ff 
   11392:	c5 f9 6f ad b0 fd ff 	vmovdqa xmm5,XMMWORD PTR [rbp-0x250]
   11399:	ff 
   1139a:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   113a1:	89 58 04             	mov    DWORD PTR [rax+0x4],ebx
   113a4:	8b 9d 48 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x1b8]
   113aa:	c7 00 03 00 00 00    	mov    DWORD PTR [rax],0x3
   113b0:	48 8b 85 18 ff ff ff 	mov    rax,QWORD PTR [rbp-0xe8]
   113b7:	c4 e3 41 22 c3 01    	vpinsrd xmm0,xmm7,ebx,0x1
   113bd:	48 c7 85 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],0x0
   113c4:	00 00 00 00 
   113c8:	48 89 85 70 ff ff ff 	mov    QWORD PTR [rbp-0x90],rax
   113cf:	48 63 85 cc fe ff ff 	movsxd rax,DWORD PTR [rbp-0x134]
   113d6:	48 0f af 85 f0 fe ff 	imul   rax,QWORD PTR [rbp-0x110]
   113dd:	ff 
   113de:	c7 85 58 ff ff ff 00 	mov    DWORD PTR [rbp-0xa8],0x0
   113e5:	00 00 00 
   113e8:	48 c7 85 40 ff ff ff 	mov    QWORD PTR [rbp-0xc0],0x0
   113ef:	00 00 00 00 
   113f3:	c7 85 48 ff ff ff 00 	mov    DWORD PTR [rbp-0xb8],0x0
   113fa:	00 00 00 
   113fd:	48 3d 3f 42 0f 00    	cmp    rax,0xf423f
   11403:	c5 f9 d6 85 78 ff ff 	vmovq  QWORD PTR [rbp-0x88],xmm0
   1140a:	ff 
   1140b:	0f 9f c2             	setg   dl
   1140e:	81 fb 7f 01 00 00    	cmp    ebx,0x17f
   11414:	c5 f9 7f ad 60 ff ff 	vmovdqa XMMWORD PTR [rbp-0xa0],xmm5
   1141b:	ff 
   1141c:	0f 9e c0             	setle  al
   1141f:	31 c9                	xor    ecx,ecx
   11421:	21 c2                	and    edx,eax
   11423:	83 f2 01             	xor    edx,0x1
   11426:	0f b6 d2             	movzx  edx,dl
   11429:	e8 00 00 00 00       	call   1142e <try_secant_tail.constprop.0+0x17fe>
   1142e:	db ad 50 ff ff ff    	fld    TBYTE PTR [rbp-0xb0]
   11434:	4c 8b 95 f8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x108]
   1143b:	db ad 40 ff ff ff    	fld    TBYTE PTR [rbp-0xc0]
   11441:	d9 ee                	fldz
   11443:	df f1                	fcomip st,st(1)
   11445:	0f 84 ea 11 00 00    	je     12635 <try_secant_tail.constprop.0+0x2a05>
   1144b:	d9 fa                	fsqrt
   1144d:	d9 c9                	fxch   st(1)
   1144f:	48 8b b5 c8 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x238]
   11456:	48 8b 85 d0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x230]
   1145d:	48 85 f6             	test   rsi,rsi
   11460:	d9 fa                	fsqrt
   11462:	de f1                	fdivrp st(1),st
   11464:	dd 58 18             	fstp   QWORD PTR [rax+0x18]
   11467:	0f 84 f2 14 00 00    	je     1295f <try_secant_tail.constprop.0+0x2d2f>
   1146d:	8b 9d 48 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x1b8]
   11473:	85 db                	test   ebx,ebx
   11475:	0f 8e 5f 15 00 00    	jle    129da <try_secant_tail.constprop.0+0x2daa>
   1147b:	8d 43 ff             	lea    eax,[rbx-0x1]
   1147e:	48 8b 95 18 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xe8]
   11485:	83 f8 02             	cmp    eax,0x2
   11488:	0f 86 35 15 00 00    	jbe    129c3 <try_secant_tail.constprop.0+0x2d93>
   1148e:	89 d9                	mov    ecx,ebx
   11490:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   11494:	31 c0                	xor    eax,eax
   11496:	c1 e9 02             	shr    ecx,0x2
   11499:	c5 fd 28 d3          	vmovapd ymm2,ymm3
   1149d:	48 c1 e1 05          	shl    rcx,0x5
   114a1:	c5 fd 10 0c 06       	vmovupd ymm1,YMMWORD PTR [rsi+rax*1]
   114a6:	c5 fd 10 04 02       	vmovupd ymm0,YMMWORD PTR [rdx+rax*1]
   114ab:	48 83 c0 20          	add    rax,0x20
   114af:	48 39 c8             	cmp    rax,rcx
   114b2:	c5 fd 5c c1          	vsubpd ymm0,ymm0,ymm1
   114b6:	c4 e2 f5 b8 d1       	vfmadd231pd ymm2,ymm1,ymm1
   114bb:	c4 e2 fd b8 d8       	vfmadd231pd ymm3,ymm0,ymm0
   114c0:	75 df                	jne    114a1 <try_secant_tail.constprop.0+0x1871>
   114c2:	c4 e3 7d 19 d8 01    	vextractf128 xmm0,ymm3,0x1
   114c8:	c4 e3 7d 19 d1 01    	vextractf128 xmm1,ymm2,0x1
   114ce:	8b b5 48 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b8]
   114d4:	8b bd 48 fe ff ff    	mov    edi,DWORD PTR [rbp-0x1b8]
   114da:	c5 f9 58 db          	vaddpd xmm3,xmm0,xmm3
   114de:	c5 f1 58 d2          	vaddpd xmm2,xmm1,xmm2
   114e2:	83 e6 fc             	and    esi,0xfffffffc
   114e5:	39 f7                	cmp    edi,esi
   114e7:	89 b5 c4 fd ff ff    	mov    DWORD PTR [rbp-0x23c],esi
   114ed:	89 f0                	mov    eax,esi
   114ef:	c5 e1 15 c3          	vunpckhpd xmm0,xmm3,xmm3
   114f3:	c5 e9 15 ca          	vunpckhpd xmm1,xmm2,xmm2
   114f7:	c5 f9 58 c3          	vaddpd xmm0,xmm0,xmm3
   114fb:	c5 f1 58 ca          	vaddpd xmm1,xmm1,xmm2
   114ff:	0f 84 52 14 00 00    	je     12957 <try_secant_tail.constprop.0+0x2d27>
   11505:	c5 f8 77             	vzeroupper
   11508:	8b 8d 48 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b8]
   1150e:	29 c1                	sub    ecx,eax
   11510:	83 f9 01             	cmp    ecx,0x1
   11513:	74 3d                	je     11552 <try_secant_tail.constprop.0+0x1922>
   11515:	48 8b 9d c8 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x238]
   1151c:	c5 f9 10 04 c2       	vmovupd xmm0,XMMWORD PTR [rdx+rax*8]
   11521:	f6 c1 01             	test   cl,0x1
   11524:	c5 f9 10 0c c3       	vmovupd xmm1,XMMWORD PTR [rbx+rax*8]
   11529:	c5 f9 5c c1          	vsubpd xmm0,xmm0,xmm1
   1152d:	c4 e2 f1 b8 d1       	vfmadd231pd xmm2,xmm1,xmm1
   11532:	c4 e2 e1 98 c0       	vfmadd132pd xmm0,xmm3,xmm0
   11537:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   1153b:	c5 f1 58 c0          	vaddpd xmm0,xmm1,xmm0
   1153f:	c5 e9 15 ca          	vunpckhpd xmm1,xmm2,xmm2
   11543:	c5 f1 58 ca          	vaddpd xmm1,xmm1,xmm2
   11547:	74 2f                	je     11578 <try_secant_tail.constprop.0+0x1948>
   11549:	83 e1 fe             	and    ecx,0xfffffffe
   1154c:	01 8d c4 fd ff ff    	add    DWORD PTR [rbp-0x23c],ecx
   11552:	48 63 85 c4 fd ff ff 	movsxd rax,DWORD PTR [rbp-0x23c]
   11559:	48 8b 9d c8 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x238]
   11560:	c5 fb 10 14 c2       	vmovsd xmm2,QWORD PTR [rdx+rax*8]
   11565:	c5 fb 10 1c c3       	vmovsd xmm3,QWORD PTR [rbx+rax*8]
   1156a:	c5 eb 5c d3          	vsubsd xmm2,xmm2,xmm3
   1156e:	c4 e2 e1 b9 cb       	vfmadd231sd xmm1,xmm3,xmm3
   11573:	c4 e2 e9 b9 c2       	vfmadd231sd xmm0,xmm2,xmm2
   11578:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
   1157c:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
   11580:	c5 f3 58 0d 00 00 00 	vaddsd xmm1,xmm1,QWORD PTR [rip+0x0]        # 11588 <try_secant_tail.constprop.0+0x1958>
   11587:	00 
   11588:	c5 fb 5e c1          	vdivsd xmm0,xmm0,xmm1
   1158c:	48 8b 85 d0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x230]
   11593:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   1159a:	c5 fb 11 40 20       	vmovsd QWORD PTR [rax+0x20],xmm0
   1159f:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
   115a6:	41 bc 01 00 00 00    	mov    r12d,0x1
   115ac:	e8 00 00 00 00       	call   115b1 <try_secant_tail.constprop.0+0x1981>
   115b1:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   115b8:	e8 00 00 00 00       	call   115bd <try_secant_tail.constprop.0+0x198d>
   115bd:	48 8b bd 20 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe0]
   115c4:	e8 00 00 00 00       	call   115c9 <try_secant_tail.constprop.0+0x1999>
   115c9:	4c 89 f7             	mov    rdi,r14
   115cc:	e8 00 00 00 00       	call   115d1 <try_secant_tail.constprop.0+0x19a1>
   115d1:	48 8b bd f8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x108]
   115d8:	e8 00 00 00 00       	call   115dd <try_secant_tail.constprop.0+0x19ad>
   115dd:	e9 e5 e6 ff ff       	jmp    fcc7 <try_secant_tail.constprop.0+0x97>
   115e2:	8b 85 f8 fe ff ff    	mov    eax,DWORD PTR [rbp-0x108]
   115e8:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
   115ec:	49 b8 eb 11 31 13 bb 	movabs r8,0x94d049bb133111eb
   115f3:	49 d0 94 
   115f6:	48 be 15 7c 4a 7f b9 	movabs rsi,0x9e3779b97f4a7c15
   115fd:	79 37 9e 
   11600:	48 03 b5 d8 fd ff ff 	add    rsi,QWORD PTR [rbp-0x228]
   11607:	c5 7b 12 c4          	vmovddup xmm8,xmm4
   1160b:	49 bb b9 e5 e4 1c 6d 	movabs r11,0xbf58476d1ce4e5b9
   11612:	47 58 bf 
   11615:	83 c0 01             	add    eax,0x1
   11618:	48 63 d0             	movsxd rdx,eax
   1161b:	89 85 c8 fe ff ff    	mov    DWORD PTR [rbp-0x138],eax
   11621:	48 89 d0             	mov    rax,rdx
   11624:	49 0f af d3          	imul   rdx,r11
   11628:	49 0f af c0          	imul   rax,r8
   1162c:	48 01 f0             	add    rax,rsi
   1162f:	48 89 c1             	mov    rcx,rax
   11632:	48 c1 e9 1e          	shr    rcx,0x1e
   11636:	48 31 c8             	xor    rax,rcx
   11639:	49 0f af c3          	imul   rax,r11
   1163d:	48 89 c1             	mov    rcx,rax
   11640:	48 c1 e9 1b          	shr    rcx,0x1b
   11644:	48 31 c1             	xor    rcx,rax
   11647:	48 8d 04 32          	lea    rax,[rdx+rsi*1]
   1164b:	48 89 c2             	mov    rdx,rax
   1164e:	49 0f af c8          	imul   rcx,r8
   11652:	48 c1 ea 1e          	shr    rdx,0x1e
   11656:	48 31 c2             	xor    rdx,rax
   11659:	49 0f af d3          	imul   rdx,r11
   1165d:	48 89 d0             	mov    rax,rdx
   11660:	48 c1 e8 1b          	shr    rax,0x1b
   11664:	48 31 d0             	xor    rax,rdx
   11667:	48 89 ca             	mov    rdx,rcx
   1166a:	49 0f af c0          	imul   rax,r8
   1166e:	48 c1 ea 1f          	shr    rdx,0x1f
   11672:	48 31 ca             	xor    rdx,rcx
   11675:	48 c1 ea 0b          	shr    rdx,0xb
   11679:	c4 e1 cb 2a d2       	vcvtsi2sd xmm2,xmm6,rdx
   1167e:	48 89 c2             	mov    rdx,rax
   11681:	48 c1 ea 1f          	shr    rdx,0x1f
   11685:	48 31 d0             	xor    rax,rdx
   11688:	48 c1 e8 0b          	shr    rax,0xb
   1168c:	45 85 e4             	test   r12d,r12d
   1168f:	c4 e1 cb 2a c8       	vcvtsi2sd xmm1,xmm6,rax
   11694:	c5 fb 12 35 00 00 00 	vmovddup xmm6,QWORD PTR [rip+0x0]        # 1169c <try_secant_tail.constprop.0+0x1a6c>
   1169b:	00 
   1169c:	c5 e9 14 d1          	vunpcklpd xmm2,xmm2,xmm1
   116a0:	c5 fb 12 0d 00 00 00 	vmovddup xmm1,QWORD PTR [rip+0x0]        # 116a8 <try_secant_tail.constprop.0+0x1a78>
   116a7:	00 
   116a8:	c4 e2 f1 98 d6       	vfmadd132pd xmm2,xmm1,xmm6
   116ad:	c5 e9 59 95 70 fd ff 	vmulpd xmm2,xmm2,XMMWORD PTR [rbp-0x290]
   116b4:	ff 
   116b5:	c5 39 59 c2          	vmulpd xmm8,xmm8,xmm2
   116b9:	0f 8e 29 01 00 00    	jle    117e8 <try_secant_tail.constprop.0+0x1bb8>
   116bf:	48 8b 85 f0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x210]
   116c6:	c5 6b 59 d0          	vmulsd xmm10,xmm2,xmm0
   116ca:	41 83 fc 01          	cmp    r12d,0x1
   116ce:	c5 e9 15 d2          	vunpckhpd xmm2,xmm2,xmm2
   116d2:	c5 eb 59 f0          	vmulsd xmm6,xmm2,xmm0
   116d6:	48 8d 14 03          	lea    rdx,[rbx+rax*1]
   116da:	0f 84 de 0d 00 00    	je     124be <try_secant_tail.constprop.0+0x288e>
   116e0:	48 8d 43 20          	lea    rax,[rbx+0x20]
   116e4:	48 39 c2             	cmp    rdx,rax
   116e7:	0f 82 d1 0d 00 00    	jb     124be <try_secant_tail.constprop.0+0x288e>
   116ed:	83 bd a4 fe ff ff 02 	cmp    DWORD PTR [rbp-0x15c],0x2
   116f4:	0f 86 be 11 00 00    	jbe    128b8 <try_secant_tail.constprop.0+0x2c88>
   116fa:	44 89 e1             	mov    ecx,r12d
   116fd:	c4 42 7d 19 da       	vbroadcastsd ymm11,xmm10
   11702:	c4 62 7d 19 ce       	vbroadcastsd ymm9,xmm6
   11707:	31 c0                	xor    eax,eax
   11709:	c1 e9 02             	shr    ecx,0x2
   1170c:	48 c1 e1 05          	shl    rcx,0x5
   11710:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   11714:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   1171b:	00 00 00 00 
   1171f:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   11726:	00 00 00 00 
   1172a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   11731:	00 00 00 00 
   11735:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   1173c:	00 00 00 00 
   11740:	c5 fd 10 0c 07       	vmovupd ymm1,YMMWORD PTR [rdi+rax*1]
   11745:	c5 7d 29 da          	vmovapd ymm2,ymm11
   11749:	c4 e2 f5 a8 14 03    	vfmadd213pd ymm2,ymm1,YMMWORD PTR [rbx+rax*1]
   1174f:	c5 fd 11 14 03       	vmovupd YMMWORD PTR [rbx+rax*1],ymm2
   11754:	c4 e2 b5 a8 0c 02    	vfmadd213pd ymm1,ymm9,YMMWORD PTR [rdx+rax*1]
   1175a:	c5 fd 11 0c 02       	vmovupd YMMWORD PTR [rdx+rax*1],ymm1
   1175f:	48 83 c0 20          	add    rax,0x20
   11763:	48 39 c8             	cmp    rax,rcx
   11766:	75 d8                	jne    11740 <try_secant_tail.constprop.0+0x1b10>
   11768:	44 89 e0             	mov    eax,r12d
   1176b:	83 e0 fc             	and    eax,0xfffffffc
   1176e:	41 39 c4             	cmp    r12d,eax
   11771:	89 c2                	mov    edx,eax
   11773:	74 73                	je     117e8 <try_secant_tail.constprop.0+0x1bb8>
   11775:	44 89 e1             	mov    ecx,r12d
   11778:	29 c1                	sub    ecx,eax
   1177a:	83 f9 01             	cmp    ecx,0x1
   1177d:	74 46                	je     117c5 <try_secant_tail.constprop.0+0x1b95>
   1177f:	4c 8d 04 d3          	lea    r8,[rbx+rdx*8]
   11783:	c4 41 7b 12 ca       	vmovddup xmm9,xmm10
   11788:	c5 fb 12 d6          	vmovddup xmm2,xmm6
   1178c:	49 01 d2             	add    r10,rdx
   1178f:	48 8b b5 f0 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x110]
   11796:	48 01 d6             	add    rsi,rdx
   11799:	48 8b 95 b8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x148]
   117a0:	f6 c1 01             	test   cl,0x1
   117a3:	c4 a1 79 10 0c d2    	vmovupd xmm1,XMMWORD PTR [rdx+r10*8]
   117a9:	c4 42 f1 a8 08       	vfmadd213pd xmm9,xmm1,XMMWORD PTR [r8]
   117ae:	c4 41 79 11 08       	vmovupd XMMWORD PTR [r8],xmm9
   117b3:	c4 e2 e9 a8 0c f3    	vfmadd213pd xmm1,xmm2,XMMWORD PTR [rbx+rsi*8]
   117b9:	c5 f9 11 0c f3       	vmovupd XMMWORD PTR [rbx+rsi*8],xmm1
   117be:	74 28                	je     117e8 <try_secant_tail.constprop.0+0x1bb8>
   117c0:	83 e1 fe             	and    ecx,0xfffffffe
   117c3:	01 c8                	add    eax,ecx
   117c5:	48 63 d0             	movsxd rdx,eax
   117c8:	44 01 e0             	add    eax,r12d
   117cb:	c5 fb 10 0c d7       	vmovsd xmm1,QWORD PTR [rdi+rdx*8]
   117d0:	c4 62 f1 a9 14 d3    	vfmadd213sd xmm10,xmm1,QWORD PTR [rbx+rdx*8]
   117d6:	48 98                	cdqe
   117d8:	c5 7b 11 14 d3       	vmovsd QWORD PTR [rbx+rdx*8],xmm10
   117dd:	c4 e2 c9 a9 0c c3    	vfmadd213sd xmm1,xmm6,QWORD PTR [rbx+rax*8]
   117e3:	c5 fb 11 0c c3       	vmovsd QWORD PTR [rbx+rax*8],xmm1
   117e8:	c5 39 58 45 b0       	vaddpd xmm8,xmm8,XMMWORD PTR [rbp-0x50]
   117ed:	c5 79 29 45 b0       	vmovapd XMMWORD PTR [rbp-0x50],xmm8
   117f2:	e9 cf ea ff ff       	jmp    102c6 <try_secant_tail.constprop.0+0x696>
   117f7:	8b 85 04 ff ff ff    	mov    eax,DWORD PTR [rbp-0xfc]
   117fd:	44 01 bd c0 fe ff ff 	add    DWORD PTR [rbp-0x140],r15d
   11804:	4d 89 cd             	mov    r13,r9
   11807:	8b 9d 0c ff ff ff    	mov    ebx,DWORD PTR [rbp-0xf4]
   1180d:	89 85 d0 fe ff ff    	mov    DWORD PTR [rbp-0x130],eax
   11813:	8b 85 c8 fe ff ff    	mov    eax,DWORD PTR [rbp-0x138]
   11819:	89 85 f8 fe ff ff    	mov    DWORD PTR [rbp-0x108],eax
   1181f:	e9 57 eb ff ff       	jmp    1037b <try_secant_tail.constprop.0+0x74b>
   11824:	c5 f8 77             	vzeroupper
   11827:	e9 2a f1 ff ff       	jmp    10956 <try_secant_tail.constprop.0+0xd26>
   1182c:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
   11830:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
   11834:	31 d2                	xor    edx,edx
   11836:	31 c9                	xor    ecx,ecx
   11838:	c5 f9 28 e7          	vmovapd xmm4,xmm7
   1183c:	c5 f9 28 df          	vmovapd xmm3,xmm7
   11840:	c5 f9 28 d7          	vmovapd xmm2,xmm7
   11844:	c5 f9 28 f7          	vmovapd xmm6,xmm7
   11848:	c5 f9 28 c5          	vmovapd xmm0,xmm5
   1184c:	e9 71 e9 ff ff       	jmp    101c2 <try_secant_tail.constprop.0+0x592>
   11851:	a8 1f                	test   al,0x1f
   11853:	74 a2                	je     117f7 <try_secant_tail.constprop.0+0x1bc7>
   11855:	83 e0 e0             	and    eax,0xffffffe0
   11858:	01 c8                	add    eax,ecx
   1185a:	e9 c5 f9 ff ff       	jmp    11224 <try_secant_tail.constprop.0+0x15f4>
   1185f:	83 85 f8 fe ff ff 01 	add    DWORD PTR [rbp-0x108],0x1
   11866:	8b 85 f8 fe ff ff    	mov    eax,DWORD PTR [rbp-0x108]
   1186c:	39 85 cc fe ff ff    	cmp    DWORD PTR [rbp-0x134],eax
   11872:	0f 8e 9f 11 00 00    	jle    12a17 <try_secant_tail.constprop.0+0x2de7>
   11878:	83 85 c0 fe ff ff 01 	add    DWORD PTR [rbp-0x140],0x1
   1187f:	e9 14 e8 ff ff       	jmp    10098 <try_secant_tail.constprop.0+0x468>
   11884:	c5 f8 77             	vzeroupper
   11887:	e9 de ef ff ff       	jmp    1086a <try_secant_tail.constprop.0+0xc3a>
   1188c:	8b b5 0c ff ff ff    	mov    esi,DWORD PTR [rbp-0xf4]
   11892:	85 f6                	test   esi,esi
   11894:	0f 85 1a 11 00 00    	jne    129b4 <try_secant_tail.constprop.0+0x2d84>
   1189a:	83 85 f8 fe ff ff 01 	add    DWORD PTR [rbp-0x108],0x1
   118a1:	8b 85 f8 fe ff ff    	mov    eax,DWORD PTR [rbp-0x108]
   118a7:	39 85 cc fe ff ff    	cmp    DWORD PTR [rbp-0x134],eax
   118ad:	7f c9                	jg     11878 <try_secant_tail.constprop.0+0x1c48>
   118af:	49 89 da             	mov    r10,rbx
   118b2:	e9 23 ee ff ff       	jmp    106da <try_secant_tail.constprop.0+0xaaa>
   118b7:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
   118be:	00 00 
   118c0:	8b 95 d0 fe ff ff    	mov    edx,DWORD PTR [rbp-0x130]
   118c6:	4c 89 d7             	mov    rdi,r10
   118c9:	44 89 e9             	mov    ecx,r13d
   118cc:	4c 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r9
   118d3:	4c 89 95 70 fe ff ff 	mov    QWORD PTR [rbp-0x190],r10
   118da:	e8 b1 1a ff ff       	call   3390 <project_cgs2>
   118df:	4c 8b 95 70 fe ff ff 	mov    r10,QWORD PTR [rbp-0x190]
   118e6:	44 89 ee             	mov    esi,r13d
   118e9:	c5 fb 11 85 e8 fd ff 	vmovsd QWORD PTR [rbp-0x218],xmm0
   118f0:	ff 
   118f1:	4c 89 d7             	mov    rdi,r10
   118f4:	e8 47 e9 fe ff       	call   240 <norm2>
   118f9:	c5 fb 10 b5 a8 fe ff 	vmovsd xmm6,QWORD PTR [rbp-0x158]
   11900:	ff 
   11901:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   11908:	4c 8b 8d 38 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c8]
   1190f:	c5 f9 28 d0          	vmovapd xmm2,xmm0
   11913:	c5 fb 11 b5 00 fe ff 	vmovsd QWORD PTR [rbp-0x200],xmm6
   1191a:	ff 
   1191b:	e9 4a f0 ff ff       	jmp    1096a <try_secant_tail.constprop.0+0xd3a>
   11920:	4c 89 f8             	mov    rax,r15
   11923:	45 89 ef             	mov    r15d,r13d
   11926:	4d 89 cd             	mov    r13,r9
   11929:	c5 fb 10 8d 00 fe ff 	vmovsd xmm1,QWORD PTR [rbp-0x200]
   11930:	ff 
   11931:	49 89 c1             	mov    r9,rax
   11934:	48 8b 85 10 ff ff ff 	mov    rax,QWORD PTR [rbp-0xf0]
   1193b:	8b 9d 88 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x178]
   11941:	48 89 85 a8 fe ff ff 	mov    QWORD PTR [rbp-0x158],rax
   11948:	48 89 c7             	mov    rdi,rax
   1194b:	49 63 c3             	movsxd rax,r11d
   1194e:	48 0f af 85 20 fe ff 	imul   rax,QWORD PTR [rbp-0x1e0]
   11955:	ff 
   11956:	48 89 85 90 fe ff ff 	mov    QWORD PTR [rbp-0x170],rax
   1195d:	48 c1 e0 03          	shl    rax,0x3
   11961:	48 89 85 88 fe ff ff 	mov    QWORD PTR [rbp-0x178],rax
   11968:	48 01 f8             	add    rax,rdi
   1196b:	45 85 ff             	test   r15d,r15d
   1196e:	0f 8e d7 00 00 00    	jle    11a4b <try_secant_tail.constprop.0+0x1e1b>
   11974:	c5 fb 10 ad b0 fe ff 	vmovsd xmm5,QWORD PTR [rbp-0x150]
   1197b:	ff 
   1197c:	41 83 ff 01          	cmp    r15d,0x1
   11980:	c5 d3 5e ea          	vdivsd xmm5,xmm5,xmm2
   11984:	0f 84 66 0c 00 00    	je     125f0 <try_secant_tail.constprop.0+0x29c0>
   1198a:	48 8b bd 08 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f8]
   11991:	48 89 c2             	mov    rdx,rax
   11994:	49 8d 4c 39 08       	lea    rcx,[r9+rdi*1+0x8]
   11999:	48 29 ca             	sub    rdx,rcx
   1199c:	48 83 fa 10          	cmp    rdx,0x10
   119a0:	0f 86 73 0c 00 00    	jbe    12619 <try_secant_tail.constprop.0+0x29e9>
   119a6:	41 8d 57 ff          	lea    edx,[r15-0x1]
   119aa:	44 89 ff             	mov    edi,r15d
   119ad:	83 fa 02             	cmp    edx,0x2
   119b0:	0f 86 22 0f 00 00    	jbe    128d8 <try_secant_tail.constprop.0+0x2ca8>
   119b6:	44 89 f9             	mov    ecx,r15d
   119b9:	c4 e2 7d 19 dd       	vbroadcastsd ymm3,xmm5
   119be:	31 d2                	xor    edx,edx
   119c0:	c1 e9 02             	shr    ecx,0x2
   119c3:	48 c1 e1 05          	shl    rcx,0x5
   119c7:	0f 1f 00             	nop    DWORD PTR [rax]
   119ca:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   119d1:	00 00 00 00 
   119d5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   119dc:	00 00 00 00 
   119e0:	c4 c1 65 59 04 12    	vmulpd ymm0,ymm3,YMMWORD PTR [r10+rdx*1]
   119e6:	c5 fd 11 04 10       	vmovupd YMMWORD PTR [rax+rdx*1],ymm0
   119eb:	48 83 c2 20          	add    rdx,0x20
   119ef:	48 39 d1             	cmp    rcx,rdx
   119f2:	75 ec                	jne    119e0 <try_secant_tail.constprop.0+0x1db0>
   119f4:	44 89 f9             	mov    ecx,r15d
   119f7:	83 e1 fc             	and    ecx,0xfffffffc
   119fa:	41 39 cf             	cmp    r15d,ecx
   119fd:	89 ce                	mov    esi,ecx
   119ff:	74 4a                	je     11a4b <try_secant_tail.constprop.0+0x1e1b>
   11a01:	44 89 ff             	mov    edi,r15d
   11a04:	29 cf                	sub    edi,ecx
   11a06:	83 ff 01             	cmp    edi,0x1
   11a09:	74 32                	je     11a3d <try_secant_tail.constprop.0+0x1e0d>
   11a0b:	48 8b 95 20 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1e0]
   11a12:	c5 fb 12 c5          	vmovddup xmm0,xmm5
   11a16:	48 01 f2             	add    rdx,rsi
   11a19:	48 03 b5 90 fe ff ff 	add    rsi,QWORD PTR [rbp-0x170]
   11a20:	40 f6 c7 01          	test   dil,0x1
   11a24:	c4 c1 79 59 04 d1    	vmulpd xmm0,xmm0,XMMWORD PTR [r9+rdx*8]
   11a2a:	48 8b 95 a8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x158]
   11a31:	c5 f9 11 04 f2       	vmovupd XMMWORD PTR [rdx+rsi*8],xmm0
   11a36:	74 13                	je     11a4b <try_secant_tail.constprop.0+0x1e1b>
   11a38:	83 e7 fe             	and    edi,0xfffffffe
   11a3b:	01 f9                	add    ecx,edi
   11a3d:	48 63 c9             	movsxd rcx,ecx
   11a40:	c4 c1 53 59 2c ca    	vmulsd xmm5,xmm5,QWORD PTR [r10+rcx*8]
   11a46:	c5 fb 11 2c c8       	vmovsd QWORD PTR [rax+rcx*8],xmm5
   11a4b:	41 83 fb 5f          	cmp    r11d,0x5f
   11a4f:	8b 8d 00 ff ff ff    	mov    ecx,DWORD PTR [rbp-0x100]
   11a55:	0f 8e cc 07 00 00    	jle    12227 <try_secant_tail.constprop.0+0x25f7>
   11a5b:	d9 ee                	fldz
   11a5d:	d9 c9                	fxch   st(1)
   11a5f:	db f1                	fcomi  st,st(1)
   11a61:	dd d9                	fstp   st(1)
   11a63:	0f 86 d2 06 00 00    	jbe    1213b <try_secant_tail.constprop.0+0x250b>
   11a69:	d9 c0                	fld    st(0)
   11a6b:	c5 eb 58 05 00 00 00 	vaddsd xmm0,xmm2,QWORD PTR [rip+0x0]        # 11a73 <try_secant_tail.constprop.0+0x1e43>
   11a72:	00 
   11a73:	c5 fb 10 ad e8 fd ff 	vmovsd xmm5,QWORD PTR [rbp-0x218]
   11a7a:	ff 
   11a7b:	d9 fa                	fsqrt
   11a7d:	c5 d3 5e c0          	vdivsd xmm0,xmm5,xmm0
   11a81:	dd 9d c0 fe ff ff    	fstp   QWORD PTR [rbp-0x140]
   11a87:	c5 fb 10 9d c0 fe ff 	vmovsd xmm3,QWORD PTR [rbp-0x140]
   11a8e:	ff 
   11a8f:	c4 e2 d9 99 d8       	vfmadd132sd xmm3,xmm4,xmm0
   11a94:	c5 fb 11 9d c0 fe ff 	vmovsd QWORD PTR [rbp-0x140],xmm3
   11a9b:	ff 
   11a9c:	dd 85 c0 fe ff ff    	fld    QWORD PTR [rbp-0x140]
   11aa2:	d8 c8                	fmul   st,st(0)
   11aa4:	d8 c0                	fadd   st,st(0)
   11aa6:	85 c9                	test   ecx,ecx
   11aa8:	0f 8e 7a 0b 00 00    	jle    12628 <try_secant_tail.constprop.0+0x29f8>
   11aae:	8d 51 ff             	lea    edx,[rcx-0x1]
   11ab1:	83 fa 02             	cmp    edx,0x2
   11ab4:	0f 86 f8 0b 00 00    	jbe    126b2 <try_secant_tail.constprop.0+0x2a82>
   11aba:	89 ce                	mov    esi,ecx
   11abc:	48 89 c2             	mov    rdx,rax
   11abf:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   11ac3:	c1 ee 02             	shr    esi,0x2
   11ac6:	48 c1 e6 05          	shl    rsi,0x5
   11aca:	48 01 c6             	add    rsi,rax
   11acd:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
   11ad4:	00 
   11ad5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   11adc:	00 00 00 00 
   11ae0:	c5 fd 10 02          	vmovupd ymm0,YMMWORD PTR [rdx]
   11ae4:	48 83 c2 20          	add    rdx,0x20
   11ae8:	48 39 f2             	cmp    rdx,rsi
   11aeb:	c5 fd 59 c0          	vmulpd ymm0,ymm0,ymm0
   11aef:	c5 e5 58 d8          	vaddpd ymm3,ymm3,ymm0
   11af3:	75 eb                	jne    11ae0 <try_secant_tail.constprop.0+0x1eb0>
   11af5:	c4 e3 7d 19 d8 01    	vextractf128 xmm0,ymm3,0x1
   11afb:	89 ca                	mov    edx,ecx
   11afd:	c5 f9 58 db          	vaddpd xmm3,xmm0,xmm3
   11b01:	83 e2 fc             	and    edx,0xfffffffc
   11b04:	39 d1                	cmp    ecx,edx
   11b06:	89 d6                	mov    esi,edx
   11b08:	c5 e1 15 c3          	vunpckhpd xmm0,xmm3,xmm3
   11b0c:	c5 f9 58 c3          	vaddpd xmm0,xmm0,xmm3
   11b10:	74 3e                	je     11b50 <try_secant_tail.constprop.0+0x1f20>
   11b12:	29 f1                	sub    ecx,esi
   11b14:	83 f9 01             	cmp    ecx,0x1
   11b17:	74 2a                	je     11b43 <try_secant_tail.constprop.0+0x1f13>
   11b19:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
   11b20:	48 03 b5 90 fe ff ff 	add    rsi,QWORD PTR [rbp-0x170]
   11b27:	f6 c1 01             	test   cl,0x1
   11b2a:	c5 f9 10 04 f7       	vmovupd xmm0,XMMWORD PTR [rdi+rsi*8]
   11b2f:	c4 e2 f9 b8 d8       	vfmadd231pd xmm3,xmm0,xmm0
   11b34:	c5 e1 15 c3          	vunpckhpd xmm0,xmm3,xmm3
   11b38:	c5 f9 58 c3          	vaddpd xmm0,xmm0,xmm3
   11b3c:	74 12                	je     11b50 <try_secant_tail.constprop.0+0x1f20>
   11b3e:	83 e1 fe             	and    ecx,0xfffffffe
   11b41:	01 ca                	add    edx,ecx
   11b43:	48 63 d2             	movsxd rdx,edx
   11b46:	c5 fb 10 1c d0       	vmovsd xmm3,QWORD PTR [rax+rdx*8]
   11b4b:	c4 e2 e1 b9 c3       	vfmadd231sd xmm0,xmm3,xmm3
   11b50:	c5 fb 5c 85 b0 fe ff 	vsubsd xmm0,xmm0,QWORD PTR [rbp-0x150]
   11b57:	ff 
   11b58:	c5 f9 54 05 00 00 00 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x0]        # 11b60 <try_secant_tail.constprop.0+0x1f30>
   11b5f:	00 
   11b60:	c5 fb 58 fc          	vaddsd xmm7,xmm0,xmm4
   11b64:	c5 fb 11 bd c0 fe ff 	vmovsd QWORD PTR [rbp-0x140],xmm7
   11b6b:	ff 
   11b6c:	dd 85 c0 fe ff ff    	fld    QWORD PTR [rbp-0x140]
   11b72:	d8 c8                	fmul   st,st(0)
   11b74:	d9 c9                	fxch   st(1)
   11b76:	de c2                	faddp  st(2),st
   11b78:	de c1                	faddp  st(1),st
   11b7a:	45 85 ff             	test   r15d,r15d
   11b7d:	db bd 30 ff ff ff    	fstp   TBYTE PTR [rbp-0xd0]
   11b83:	0f 8e cc 00 00 00    	jle    11c55 <try_secant_tail.constprop.0+0x2025>
   11b89:	c5 f3 5e ca          	vdivsd xmm1,xmm1,xmm2
   11b8d:	41 83 ff 01          	cmp    r15d,0x1
   11b91:	48 8b 95 18 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xe8]
   11b98:	0f 84 f7 08 00 00    	je     12495 <try_secant_tail.constprop.0+0x2865>
   11b9e:	48 8b b5 a8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x158]
   11ba5:	48 8b bd 88 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x178]
   11bac:	48 89 d1             	mov    rcx,rdx
   11baf:	48 8d 74 3e 08       	lea    rsi,[rsi+rdi*1+0x8]
   11bb4:	48 29 f1             	sub    rcx,rsi
   11bb7:	48 83 f9 10          	cmp    rcx,0x10
   11bbb:	0f 86 d4 08 00 00    	jbe    12495 <try_secant_tail.constprop.0+0x2865>
   11bc1:	41 8d 4f ff          	lea    ecx,[r15-0x1]
   11bc5:	44 89 fe             	mov    esi,r15d
   11bc8:	83 f9 02             	cmp    ecx,0x2
   11bcb:	0f 86 f3 0c 00 00    	jbe    128c4 <try_secant_tail.constprop.0+0x2c94>
   11bd1:	c1 ee 02             	shr    esi,0x2
   11bd4:	c4 e2 7d 19 d1       	vbroadcastsd ymm2,xmm1
   11bd9:	31 c9                	xor    ecx,ecx
   11bdb:	48 c1 e6 05          	shl    rsi,0x5
   11bdf:	90                   	nop
   11be0:	c5 fd 10 04 08       	vmovupd ymm0,YMMWORD PTR [rax+rcx*1]
   11be5:	c4 e2 ed a8 04 0a    	vfmadd213pd ymm0,ymm2,YMMWORD PTR [rdx+rcx*1]
   11beb:	c5 fd 11 04 0a       	vmovupd YMMWORD PTR [rdx+rcx*1],ymm0
   11bf0:	48 83 c1 20          	add    rcx,0x20
   11bf4:	48 39 ce             	cmp    rsi,rcx
   11bf7:	75 e7                	jne    11be0 <try_secant_tail.constprop.0+0x1fb0>
   11bf9:	44 89 fb             	mov    ebx,r15d
   11bfc:	83 e3 fc             	and    ebx,0xfffffffc
   11bff:	41 39 df             	cmp    r15d,ebx
   11c02:	89 d9                	mov    ecx,ebx
   11c04:	74 4f                	je     11c55 <try_secant_tail.constprop.0+0x2025>
   11c06:	44 89 fe             	mov    esi,r15d
   11c09:	29 de                	sub    esi,ebx
   11c0b:	83 fe 01             	cmp    esi,0x1
   11c0e:	74 32                	je     11c42 <try_secant_tail.constprop.0+0x2012>
   11c10:	4c 8b 85 90 fe ff ff 	mov    r8,QWORD PTR [rbp-0x170]
   11c17:	48 8d 3c ca          	lea    rdi,[rdx+rcx*8]
   11c1b:	c5 fb 12 c1          	vmovddup xmm0,xmm1
   11c1f:	c5 f9 10 37          	vmovupd xmm6,XMMWORD PTR [rdi]
   11c23:	4c 01 c1             	add    rcx,r8
   11c26:	4c 8b 85 a8 fe ff ff 	mov    r8,QWORD PTR [rbp-0x158]
   11c2d:	40 f6 c6 01          	test   sil,0x1
   11c31:	c4 c2 c9 98 04 c8    	vfmadd132pd xmm0,xmm6,XMMWORD PTR [r8+rcx*8]
   11c37:	c5 f9 11 07          	vmovupd XMMWORD PTR [rdi],xmm0
   11c3b:	74 18                	je     11c55 <try_secant_tail.constprop.0+0x2025>
   11c3d:	83 e6 fe             	and    esi,0xfffffffe
   11c40:	01 f3                	add    ebx,esi
   11c42:	48 63 cb             	movsxd rcx,ebx
   11c45:	c5 fb 10 2c ca       	vmovsd xmm5,QWORD PTR [rdx+rcx*8]
   11c4a:	c4 e2 d1 99 0c c8    	vfmadd132sd xmm1,xmm5,QWORD PTR [rax+rcx*8]
   11c50:	c5 fb 11 0c ca       	vmovsd QWORD PTR [rdx+rcx*8],xmm1
   11c55:	8b 9d 0c ff ff ff    	mov    ebx,DWORD PTR [rbp-0xf4]
   11c5b:	41 8d 43 01          	lea    eax,[r11+0x1]
   11c5f:	89 85 04 ff ff ff    	mov    DWORD PTR [rbp-0xfc],eax
   11c65:	85 db                	test   ebx,ebx
   11c67:	89 9d c0 fe ff ff    	mov    DWORD PTR [rbp-0x140],ebx
   11c6d:	0f 85 f9 0c 00 00    	jne    1296c <try_secant_tail.constprop.0+0x2d3c>
   11c73:	41 39 c4             	cmp    r12d,eax
   11c76:	0f 84 47 0a 00 00    	je     126c3 <try_secant_tail.constprop.0+0x2a93>
   11c7c:	8b 85 e0 fd ff ff    	mov    eax,DWORD PTR [rbp-0x220]
   11c82:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   11c89:	44 89 e6             	mov    esi,r12d
   11c8c:	4d 89 e9             	mov    r9,r13
   11c8f:	83 c0 01             	add    eax,0x1
   11c92:	89 85 60 fe ff ff    	mov    DWORD PTR [rbp-0x1a0],eax
   11c98:	c5 f8 77             	vzeroupper
   11c9b:	e8 a0 e5 fe ff       	call   240 <norm2>
   11ca0:	48 63 85 d0 fe ff ff 	movsxd rax,DWORD PTR [rbp-0x130]
   11ca7:	4c 8b 9d f0 fe ff ff 	mov    r11,QWORD PTR [rbp-0x110]
   11cae:	48 8b 9d a8 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x158]
   11cb5:	c5 fb 10 3d 00 00 00 	vmovsd xmm7,QWORD PTR [rip+0x0]        # 11cbd <try_secant_tail.constprop.0+0x208d>
   11cbc:	00 
   11cbd:	45 31 ed             	xor    r13d,r13d
   11cc0:	c7 85 d0 fe ff ff 02 	mov    DWORD PTR [rbp-0x130],0x2
   11cc7:	00 00 00 
   11cca:	4c 0f af d8          	imul   r11,rax
   11cce:	49 8d 46 f8          	lea    rax,[r14-0x8]
   11cd2:	c5 fb 11 85 90 fe ff 	vmovsd QWORD PTR [rbp-0x170],xmm0
   11cd9:	ff 
   11cda:	48 29 d8             	sub    rax,rbx
   11cdd:	c5 fb 11 bd 88 fe ff 	vmovsd QWORD PTR [rbp-0x178],xmm7
   11ce4:	ff 
   11ce5:	48 89 85 70 fe ff ff 	mov    QWORD PTR [rbp-0x190],rax
   11cec:	4e 8d 3c db          	lea    r15,[rbx+r11*8]
   11cf0:	4c 89 db             	mov    rbx,r11
   11cf3:	4b 8d 3c ee          	lea    rdi,[r14+r13*8]
   11cf7:	45 85 e4             	test   r12d,r12d
   11cfa:	49 89 fa             	mov    r10,rdi
   11cfd:	0f 8e 0d 04 00 00    	jle    12110 <try_secant_tail.constprop.0+0x24e0>
   11d03:	45 89 e0             	mov    r8d,r12d
   11d06:	4c 8b 9d a8 fe ff ff 	mov    r11,QWORD PTR [rbp-0x158]
   11d0d:	41 c1 e8 02          	shr    r8d,0x2
   11d11:	49 c1 e0 05          	shl    r8,0x5
   11d15:	83 bd a4 fe ff ff 02 	cmp    DWORD PTR [rbp-0x15c],0x2
   11d1c:	0f 86 1b 02 00 00    	jbe    11f3d <try_secant_tail.constprop.0+0x230d>
   11d22:	31 c0                	xor    eax,eax
   11d24:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   11d28:	66 90                	xchg   ax,ax
   11d2a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   11d31:	00 00 00 00 
   11d35:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   11d3c:	00 00 00 00 
   11d40:	c5 fd 10 04 07       	vmovupd ymm0,YMMWORD PTR [rdi+rax*1]
   11d45:	c4 c1 7d 59 04 07    	vmulpd ymm0,ymm0,YMMWORD PTR [r15+rax*1]
   11d4b:	48 83 c0 20          	add    rax,0x20
   11d4f:	4c 39 c0             	cmp    rax,r8
   11d52:	c5 f5 58 c8          	vaddpd ymm1,ymm1,ymm0
   11d56:	75 e8                	jne    11d40 <try_secant_tail.constprop.0+0x2110>
   11d58:	c4 e3 7d 19 c8 01    	vextractf128 xmm0,ymm1,0x1
   11d5e:	44 89 e2             	mov    edx,r12d
   11d61:	c5 f9 58 c9          	vaddpd xmm1,xmm0,xmm1
   11d65:	83 e2 fc             	and    edx,0xfffffffc
   11d68:	41 39 d4             	cmp    r12d,edx
   11d6b:	89 d0                	mov    eax,edx
   11d6d:	c5 f1 15 c1          	vunpckhpd xmm0,xmm1,xmm1
   11d71:	c5 f9 58 c1          	vaddpd xmm0,xmm0,xmm1
   11d75:	0f 84 5a 02 00 00    	je     11fd5 <try_secant_tail.constprop.0+0x23a5>
   11d7b:	44 89 e1             	mov    ecx,r12d
   11d7e:	29 c1                	sub    ecx,eax
   11d80:	83 f9 01             	cmp    ecx,0x1
   11d83:	74 25                	je     11daa <try_secant_tail.constprop.0+0x217a>
   11d85:	48 8d 34 03          	lea    rsi,[rbx+rax*1]
   11d89:	4c 01 e8             	add    rax,r13
   11d8c:	f6 c1 01             	test   cl,0x1
   11d8f:	c4 c1 79 10 3c f3    	vmovupd xmm7,XMMWORD PTR [r11+rsi*8]
   11d95:	c4 c2 c1 b8 0c c6    	vfmadd231pd xmm1,xmm7,XMMWORD PTR [r14+rax*8]
   11d9b:	c5 f1 15 c1          	vunpckhpd xmm0,xmm1,xmm1
   11d9f:	c5 f9 58 c1          	vaddpd xmm0,xmm0,xmm1
   11da3:	74 14                	je     11db9 <try_secant_tail.constprop.0+0x2189>
   11da5:	83 e1 fe             	and    ecx,0xfffffffe
   11da8:	01 ca                	add    edx,ecx
   11daa:	48 63 d2             	movsxd rdx,edx
   11dad:	c4 c1 7b 10 34 d7    	vmovsd xmm6,QWORD PTR [r15+rdx*8]
   11db3:	c4 e2 c9 b9 04 d7    	vfmadd231sd xmm0,xmm6,QWORD PTR [rdi+rdx*8]
   11db9:	41 83 fc 01          	cmp    r12d,0x1
   11dbd:	0f 84 2d 02 00 00    	je     11ff0 <try_secant_tail.constprop.0+0x23c0>
   11dc3:	48 8b b5 70 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x190]
   11dca:	4c 89 e8             	mov    rax,r13
   11dcd:	48 29 d8             	sub    rax,rbx
   11dd0:	48 8d 04 c6          	lea    rax,[rsi+rax*8]
   11dd4:	48 83 f8 10          	cmp    rax,0x10
   11dd8:	0f 86 12 02 00 00    	jbe    11ff0 <try_secant_tail.constprop.0+0x23c0>
   11dde:	83 bd a4 fe ff ff 02 	cmp    DWORD PTR [rbp-0x15c],0x2
   11de5:	0f 86 ac 07 00 00    	jbe    12597 <try_secant_tail.constprop.0+0x2967>
   11deb:	c4 e2 7d 19 d0       	vbroadcastsd ymm2,xmm0
   11df0:	31 c0                	xor    eax,eax
   11df2:	0f 1f 00             	nop    DWORD PTR [rax]
   11df5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   11dfc:	00 00 00 00 
   11e00:	c4 c1 7d 10 0c 07    	vmovupd ymm1,YMMWORD PTR [r15+rax*1]
   11e06:	c4 e2 ed ac 0c 07    	vfnmadd213pd ymm1,ymm2,YMMWORD PTR [rdi+rax*1]
   11e0c:	c5 fd 11 0c 07       	vmovupd YMMWORD PTR [rdi+rax*1],ymm1
   11e11:	48 83 c0 20          	add    rax,0x20
   11e15:	4c 39 c0             	cmp    rax,r8
   11e18:	75 e6                	jne    11e00 <try_secant_tail.constprop.0+0x21d0>
   11e1a:	44 89 e0             	mov    eax,r12d
   11e1d:	83 e0 fc             	and    eax,0xfffffffc
   11e20:	41 39 c4             	cmp    r12d,eax
   11e23:	89 c2                	mov    edx,eax
   11e25:	0f 84 1b 03 00 00    	je     12146 <try_secant_tail.constprop.0+0x2516>
   11e2b:	44 89 e1             	mov    ecx,r12d
   11e2e:	29 c1                	sub    ecx,eax
   11e30:	83 f9 01             	cmp    ecx,0x1
   11e33:	74 27                	je     11e5c <try_secant_tail.constprop.0+0x222c>
   11e35:	4a 8d 34 2a          	lea    rsi,[rdx+r13*1]
   11e39:	48 01 da             	add    rdx,rbx
   11e3c:	c5 fb 12 c8          	vmovddup xmm1,xmm0
   11e40:	f6 c1 01             	test   cl,0x1
   11e43:	c4 c1 79 10 2c f6    	vmovupd xmm5,XMMWORD PTR [r14+rsi*8]
   11e49:	c4 c2 d1 9c 0c d3    	vfnmadd132pd xmm1,xmm5,XMMWORD PTR [r11+rdx*8]
   11e4f:	c4 c1 79 11 0c f6    	vmovupd XMMWORD PTR [r14+rsi*8],xmm1
   11e55:	74 17                	je     11e6e <try_secant_tail.constprop.0+0x223e>
   11e57:	83 e1 fe             	and    ecx,0xfffffffe
   11e5a:	01 c8                	add    eax,ecx
   11e5c:	48 98                	cdqe
   11e5e:	c5 fb 10 34 c7       	vmovsd xmm6,QWORD PTR [rdi+rax*8]
   11e63:	c4 c2 c9 9d 04 c7    	vfnmadd132sd xmm0,xmm6,QWORD PTR [r15+rax*8]
   11e69:	c5 fb 11 04 c7       	vmovsd QWORD PTR [rdi+rax*8],xmm0
   11e6e:	44 89 e6             	mov    esi,r12d
   11e71:	c5 f8 77             	vzeroupper
   11e74:	e8 c7 e3 fe ff       	call   240 <norm2>
   11e79:	c5 fb 10 ad 88 fe ff 	vmovsd xmm5,QWORD PTR [rbp-0x178]
   11e80:	ff 
   11e81:	c5 f9 2f e8          	vcomisd xmm5,xmm0
   11e85:	0f 87 c3 00 00 00    	ja     11f4e <try_secant_tail.constprop.0+0x231e>
   11e8b:	c5 fb 10 bd b0 fe ff 	vmovsd xmm7,QWORD PTR [rbp-0x150]
   11e92:	ff 
   11e93:	83 bd a4 fe ff ff 02 	cmp    DWORD PTR [rbp-0x15c],0x2
   11e9a:	c5 c3 5e d0          	vdivsd xmm2,xmm7,xmm0
   11e9e:	0f 86 43 07 00 00    	jbe    125e7 <try_secant_tail.constprop.0+0x29b7>
   11ea4:	44 89 e0             	mov    eax,r12d
   11ea7:	c4 e2 7d 19 ca       	vbroadcastsd ymm1,xmm2
   11eac:	c1 e8 02             	shr    eax,0x2
   11eaf:	48 c1 e0 05          	shl    rax,0x5
   11eb3:	48 01 f8             	add    rax,rdi
   11eb6:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
   11ebd:	00 00 00 
   11ec0:	c5 f5 59 07          	vmulpd ymm0,ymm1,YMMWORD PTR [rdi]
   11ec4:	48 83 c7 20          	add    rdi,0x20
   11ec8:	c5 fd 11 47 e0       	vmovupd YMMWORD PTR [rdi-0x20],ymm0
   11ecd:	48 39 c7             	cmp    rdi,rax
   11ed0:	75 ee                	jne    11ec0 <try_secant_tail.constprop.0+0x2290>
   11ed2:	44 89 e2             	mov    edx,r12d
   11ed5:	83 e2 fc             	and    edx,0xfffffffc
   11ed8:	41 39 d4             	cmp    r12d,edx
   11edb:	89 d0                	mov    eax,edx
   11edd:	74 36                	je     11f15 <try_secant_tail.constprop.0+0x22e5>
   11edf:	44 89 e1             	mov    ecx,r12d
   11ee2:	29 c1                	sub    ecx,eax
   11ee4:	83 f9 01             	cmp    ecx,0x1
   11ee7:	74 1d                	je     11f06 <try_secant_tail.constprop.0+0x22d6>
   11ee9:	4c 01 e8             	add    rax,r13
   11eec:	c5 fb 12 c2          	vmovddup xmm0,xmm2
   11ef0:	f6 c1 01             	test   cl,0x1
   11ef3:	c4 c1 79 59 04 c6    	vmulpd xmm0,xmm0,XMMWORD PTR [r14+rax*8]
   11ef9:	c4 c1 79 11 04 c6    	vmovupd XMMWORD PTR [r14+rax*8],xmm0
   11eff:	74 14                	je     11f15 <try_secant_tail.constprop.0+0x22e5>
   11f01:	83 e1 fe             	and    ecx,0xfffffffe
   11f04:	01 ca                	add    edx,ecx
   11f06:	48 63 d2             	movsxd rdx,edx
   11f09:	c4 c1 6b 59 14 d2    	vmulsd xmm2,xmm2,QWORD PTR [r10+rdx*8]
   11f0f:	c4 c1 7b 11 14 d2    	vmovsd QWORD PTR [r10+rdx*8],xmm2
   11f15:	83 ad d0 fe ff ff 01 	sub    DWORD PTR [rbp-0x130],0x1
   11f1c:	0f 84 8d 00 00 00    	je     11faf <try_secant_tail.constprop.0+0x237f>
   11f22:	4c 03 ad f0 fe ff ff 	add    r13,QWORD PTR [rbp-0x110]
   11f29:	83 bd a4 fe ff ff 02 	cmp    DWORD PTR [rbp-0x15c],0x2
   11f30:	4b 8d 3c ee          	lea    rdi,[r14+r13*8]
   11f34:	49 89 fa             	mov    r10,rdi
   11f37:	0f 87 e5 fd ff ff    	ja     11d22 <try_secant_tail.constprop.0+0x20f2>
   11f3d:	31 d2                	xor    edx,edx
   11f3f:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   11f43:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   11f47:	31 c0                	xor    eax,eax
   11f49:	e9 2d fe ff ff       	jmp    11d7b <try_secant_tail.constprop.0+0x214b>
   11f4e:	8b 85 e0 fd ff ff    	mov    eax,DWORD PTR [rbp-0x220]
   11f54:	48 8b b5 18 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1e8]
   11f5b:	4c 89 d7             	mov    rdi,r10
   11f5e:	4c 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r9
   11f65:	8d 14 c5 00 00 00 00 	lea    edx,[rax*8+0x0]
   11f6c:	29 c2                	sub    edx,eax
   11f6e:	48 b8 03 ed 92 d1 32 	movabs rax,0xd1b54a32d192ed03
   11f75:	4a b5 d1 
   11f78:	83 c2 0a             	add    edx,0xa
   11f7b:	2b 95 d0 fe ff ff    	sub    edx,DWORD PTR [rbp-0x130]
   11f81:	48 63 d2             	movsxd rdx,edx
   11f84:	48 0f af d0          	imul   rdx,rax
   11f88:	48 03 95 68 fd ff ff 	add    rdx,QWORD PTR [rbp-0x298]
   11f8f:	e8 0c 1b ff ff       	call   3aa0 <secant_refresh>
   11f94:	4c 03 ad f0 fe ff ff 	add    r13,QWORD PTR [rbp-0x110]
   11f9b:	83 ad d0 fe ff ff 01 	sub    DWORD PTR [rbp-0x130],0x1
   11fa2:	4c 8b 8d 38 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c8]
   11fa9:	0f 85 44 fd ff ff    	jne    11cf3 <try_secant_tail.constprop.0+0x20c3>
   11faf:	8b 85 04 ff ff ff    	mov    eax,DWORD PTR [rbp-0xfc]
   11fb5:	8b 9d 0c ff ff ff    	mov    ebx,DWORD PTR [rbp-0xf4]
   11fbb:	4d 89 cd             	mov    r13,r9
   11fbe:	89 85 d0 fe ff ff    	mov    DWORD PTR [rbp-0x130],eax
   11fc4:	8b 85 60 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1a0]
   11fca:	89 85 e0 fd ff ff    	mov    DWORD PTR [rbp-0x220],eax
   11fd0:	e9 9f e3 ff ff       	jmp    10374 <try_secant_tail.constprop.0+0x744>
   11fd5:	4c 89 ea             	mov    rdx,r13
   11fd8:	49 8d 46 f8          	lea    rax,[r14-0x8]
   11fdc:	48 29 da             	sub    rdx,rbx
   11fdf:	4c 29 d8             	sub    rax,r11
   11fe2:	48 8d 04 d0          	lea    rax,[rax+rdx*8]
   11fe6:	48 83 f8 10          	cmp    rax,0x10
   11fea:	0f 87 fb fd ff ff    	ja     11deb <try_secant_tail.constprop.0+0x21bb>
   11ff0:	48 8b 95 f0 fd ff ff 	mov    rdx,QWORD PTR [rbp-0x210]
   11ff7:	31 c0                	xor    eax,eax
   11ff9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   12000:	c4 c1 7b 10 0c 07    	vmovsd xmm1,QWORD PTR [r15+rax*1]
   12006:	c4 e2 f9 ad 0c 07    	vfnmadd213sd xmm1,xmm0,QWORD PTR [rdi+rax*1]
   1200c:	c5 fb 11 0c 07       	vmovsd QWORD PTR [rdi+rax*1],xmm1
   12011:	48 83 c0 08          	add    rax,0x8
   12015:	48 39 c2             	cmp    rdx,rax
   12018:	75 e6                	jne    12000 <try_secant_tail.constprop.0+0x23d0>
   1201a:	e9 4f fe ff ff       	jmp    11e6e <try_secant_tail.constprop.0+0x223e>
   1201f:	85 c9                	test   ecx,ecx
   12021:	8d 51 03             	lea    edx,[rcx+0x3]
   12024:	44 8d 04 85 00 00 00 	lea    r8d,[rax*4+0x0]
   1202b:	00 
   1202c:	0f 49 d1             	cmovns edx,ecx
   1202f:	c1 fa 02             	sar    edx,0x2
   12032:	39 d0                	cmp    eax,edx
   12034:	44 0f 4f c1          	cmovg  r8d,ecx
   12038:	e9 1e f1 ff ff       	jmp    1115b <try_secant_tail.constprop.0+0x152b>
   1203d:	c5 fb 10 3d 00 00 00 	vmovsd xmm7,QWORD PTR [rip+0x0]        # 12045 <try_secant_tail.constprop.0+0x2415>
   12044:	00 
   12045:	c5 fb 11 bd b0 fe ff 	vmovsd QWORD PTR [rbp-0x150],xmm7
   1204c:	ff 
   1204d:	c5 fb 11 bd 80 fe ff 	vmovsd QWORD PTR [rbp-0x180],xmm7
   12054:	ff 
   12055:	e9 f9 dd ff ff       	jmp    fe53 <try_secant_tail.constprop.0+0x223>
   1205a:	48 0f af f1          	imul   rsi,rcx
   1205e:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
   12065:	4c 89 8d a8 fe ff ff 	mov    QWORD PTR [rbp-0x158],r9
   1206c:	44 89 85 70 fe ff ff 	mov    DWORD PTR [rbp-0x190],r8d
   12073:	4c 89 95 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r10
   1207a:	48 c1 e6 03          	shl    rsi,0x3
   1207e:	c5 fb 11 95 30 fe ff 	vmovsd QWORD PTR [rbp-0x1d0],xmm2
   12085:	ff 
   12086:	c5 fb 11 a5 28 fe ff 	vmovsd QWORD PTR [rbp-0x1d8],xmm4
   1208d:	ff 
   1208e:	e8 00 00 00 00       	call   12093 <try_secant_tail.constprop.0+0x2463>
   12093:	44 8b 9d 04 ff ff ff 	mov    r11d,DWORD PTR [rbp-0xfc]
   1209a:	4c 8b 8d a8 fe ff ff 	mov    r9,QWORD PTR [rbp-0x158]
   120a1:	48 85 c0             	test   rax,rax
   120a4:	0f 84 d1 f0 ff ff    	je     1117b <try_secant_tail.constprop.0+0x154b>
   120aa:	44 8b 85 70 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x190]
   120b1:	4c 89 fe             	mov    rsi,r15
   120b4:	48 89 c7             	mov    rdi,rax
   120b7:	45 89 ef             	mov    r15d,r13d
   120ba:	48 89 85 a8 fe ff ff 	mov    QWORD PTR [rbp-0x158],rax
   120c1:	4d 89 cd             	mov    r13,r9
   120c4:	4c 8b 95 38 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c8]
   120cb:	49 89 f1             	mov    r9,rsi
   120ce:	48 89 85 10 ff ff ff 	mov    QWORD PTR [rbp-0xf0],rax
   120d5:	db ad 30 ff ff ff    	fld    TBYTE PTR [rbp-0xd0]
   120db:	c5 fb 10 95 30 fe ff 	vmovsd xmm2,QWORD PTR [rbp-0x1d0]
   120e2:	ff 
   120e3:	44 89 85 08 ff ff ff 	mov    DWORD PTR [rbp-0xf8],r8d
   120ea:	c5 fb 10 8d 00 fe ff 	vmovsd xmm1,QWORD PTR [rbp-0x200]
   120f1:	ff 
   120f2:	8b 9d 88 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x178]
   120f8:	c5 fb 10 a5 28 fe ff 	vmovsd xmm4,QWORD PTR [rbp-0x1d8]
   120ff:	ff 
   12100:	e9 46 f8 ff ff       	jmp    1194b <try_secant_tail.constprop.0+0x1d1b>
   12105:	4c 03 ad f0 fe ff ff 	add    r13,QWORD PTR [rbp-0x110]
   1210c:	4f 8d 14 ee          	lea    r10,[r14+r13*8]
   12110:	44 89 e6             	mov    esi,r12d
   12113:	4c 89 d7             	mov    rdi,r10
   12116:	e8 25 e1 fe ff       	call   240 <norm2>
   1211b:	c5 fb 10 ad 88 fe ff 	vmovsd xmm5,QWORD PTR [rbp-0x178]
   12122:	ff 
   12123:	c5 f9 2f e8          	vcomisd xmm5,xmm0
   12127:	0f 87 21 fe ff ff    	ja     11f4e <try_secant_tail.constprop.0+0x231e>
   1212d:	83 ad d0 fe ff ff 01 	sub    DWORD PTR [rbp-0x130],0x1
   12134:	75 cf                	jne    12105 <try_secant_tail.constprop.0+0x24d5>
   12136:	e9 74 fe ff ff       	jmp    11faf <try_secant_tail.constprop.0+0x237f>
   1213b:	d9 05 00 00 00 00    	fld    DWORD PTR [rip+0x0]        # 12141 <try_secant_tail.constprop.0+0x2511>
   12141:	e9 60 f9 ff ff       	jmp    11aa6 <try_secant_tail.constprop.0+0x1e76>
   12146:	44 89 e6             	mov    esi,r12d
   12149:	c5 f8 77             	vzeroupper
   1214c:	e8 ef e0 fe ff       	call   240 <norm2>
   12151:	c5 fb 10 bd 88 fe ff 	vmovsd xmm7,QWORD PTR [rbp-0x178]
   12158:	ff 
   12159:	c5 f9 2f f8          	vcomisd xmm7,xmm0
   1215d:	0f 87 eb fd ff ff    	ja     11f4e <try_secant_tail.constprop.0+0x231e>
   12163:	c5 fb 10 b5 b0 fe ff 	vmovsd xmm6,QWORD PTR [rbp-0x150]
   1216a:	ff 
   1216b:	c5 cb 5e d0          	vdivsd xmm2,xmm6,xmm0
   1216f:	e9 30 fd ff ff       	jmp    11ea4 <try_secant_tail.constprop.0+0x2274>
   12174:	48 89 c2             	mov    rdx,rax
   12177:	31 c0                	xor    eax,eax
   12179:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   12180:	c5 fb 59 0c 07       	vmulsd xmm1,xmm0,QWORD PTR [rdi+rax*1]
   12185:	c4 c1 7b 11 0c 07    	vmovsd QWORD PTR [r15+rax*1],xmm1
   1218b:	c4 c1 7b 11 0c 02    	vmovsd QWORD PTR [r10+rax*1],xmm1
   12191:	48 83 c0 08          	add    rax,0x8
   12195:	48 39 c2             	cmp    rdx,rax
   12198:	75 e6                	jne    12180 <try_secant_tail.constprop.0+0x2550>
   1219a:	8b 95 d0 fe ff ff    	mov    edx,DWORD PTR [rbp-0x130]
   121a0:	4c 89 d7             	mov    rdi,r10
   121a3:	44 89 e9             	mov    ecx,r13d
   121a6:	4c 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r9
   121ad:	4c 89 95 70 fe ff ff 	mov    QWORD PTR [rbp-0x190],r10
   121b4:	e8 d7 11 ff ff       	call   3390 <project_cgs2>
   121b9:	4c 8b 95 70 fe ff ff 	mov    r10,QWORD PTR [rbp-0x190]
   121c0:	44 89 ee             	mov    esi,r13d
   121c3:	c5 fb 11 85 e8 fd ff 	vmovsd QWORD PTR [rbp-0x218],xmm0
   121ca:	ff 
   121cb:	4c 89 d7             	mov    rdi,r10
   121ce:	e8 6d e0 fe ff       	call   240 <norm2>
   121d3:	41 8d 45 ff          	lea    eax,[r13-0x1]
   121d7:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   121de:	4c 8b 8d 38 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c8]
   121e5:	83 f8 02             	cmp    eax,0x2
   121e8:	c5 f9 28 d0          	vmovapd xmm2,xmm0
   121ec:	0f 87 d9 e6 ff ff    	ja     108cb <try_secant_tail.constprop.0+0xc9b>
   121f2:	31 c9                	xor    ecx,ecx
   121f4:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   121f8:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   121fc:	31 c0                	xor    eax,eax
   121fe:	e9 1c e7 ff ff       	jmp    1091f <try_secant_tail.constprop.0+0xcef>
   12203:	48 8b 95 08 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1f8]
   1220a:	31 c0                	xor    eax,eax
   1220c:	e9 6f ff ff ff       	jmp    12180 <try_secant_tail.constprop.0+0x2550>
   12211:	31 d2                	xor    edx,edx
   12213:	31 c9                	xor    ecx,ecx
   12215:	e9 0b e6 ff ff       	jmp    10825 <try_secant_tail.constprop.0+0xbf5>
   1221a:	31 c9                	xor    ecx,ecx
   1221c:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   12220:	31 c0                	xor    eax,eax
   12222:	e9 02 e7 ff ff       	jmp    10929 <try_secant_tail.constprop.0+0xcf9>
   12227:	85 c9                	test   ecx,ecx
   12229:	0f 8e 7e 07 00 00    	jle    129ad <try_secant_tail.constprop.0+0x2d7d>
   1222f:	8d 51 ff             	lea    edx,[rcx-0x1]
   12232:	83 fa 02             	cmp    edx,0x2
   12235:	0f 86 61 07 00 00    	jbe    1299c <try_secant_tail.constprop.0+0x2d6c>
   1223b:	89 ce                	mov    esi,ecx
   1223d:	48 89 c2             	mov    rdx,rax
   12240:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   12244:	c1 ee 02             	shr    esi,0x2
   12247:	48 c1 e6 05          	shl    rsi,0x5
   1224b:	48 01 c6             	add    rsi,rax
   1224e:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   12255:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   1225c:	00 00 00 00 
   12260:	c5 fd 10 02          	vmovupd ymm0,YMMWORD PTR [rdx]
   12264:	48 83 c2 20          	add    rdx,0x20
   12268:	48 39 f2             	cmp    rdx,rsi
   1226b:	c5 fd 59 c0          	vmulpd ymm0,ymm0,ymm0
   1226f:	c5 e5 58 d8          	vaddpd ymm3,ymm3,ymm0
   12273:	75 eb                	jne    12260 <try_secant_tail.constprop.0+0x2630>
   12275:	c4 e3 7d 19 d8 01    	vextractf128 xmm0,ymm3,0x1
   1227b:	89 ce                	mov    esi,ecx
   1227d:	c5 f9 58 db          	vaddpd xmm3,xmm0,xmm3
   12281:	83 e6 fc             	and    esi,0xfffffffc
   12284:	39 f1                	cmp    ecx,esi
   12286:	89 f2                	mov    edx,esi
   12288:	c5 e1 15 c3          	vunpckhpd xmm0,xmm3,xmm3
   1228c:	c5 f9 58 c3          	vaddpd xmm0,xmm0,xmm3
   12290:	74 42                	je     122d4 <try_secant_tail.constprop.0+0x26a4>
   12292:	89 cf                	mov    edi,ecx
   12294:	29 d7                	sub    edi,edx
   12296:	83 ff 01             	cmp    edi,0x1
   12299:	74 2c                	je     122c7 <try_secant_tail.constprop.0+0x2697>
   1229b:	4c 8b 85 a8 fe ff ff 	mov    r8,QWORD PTR [rbp-0x158]
   122a2:	48 03 95 90 fe ff ff 	add    rdx,QWORD PTR [rbp-0x170]
   122a9:	40 f6 c7 01          	test   dil,0x1
   122ad:	c4 c1 79 10 04 d0    	vmovupd xmm0,XMMWORD PTR [r8+rdx*8]
   122b3:	c4 e2 f9 b8 d8       	vfmadd231pd xmm3,xmm0,xmm0
   122b8:	c5 e1 15 c3          	vunpckhpd xmm0,xmm3,xmm3
   122bc:	c5 f9 58 c3          	vaddpd xmm0,xmm0,xmm3
   122c0:	74 12                	je     122d4 <try_secant_tail.constprop.0+0x26a4>
   122c2:	83 e7 fe             	and    edi,0xfffffffe
   122c5:	01 fe                	add    esi,edi
   122c7:	48 63 d6             	movsxd rdx,esi
   122ca:	c5 fb 10 1c d0       	vmovsd xmm3,QWORD PTR [rax+rdx*8]
   122cf:	c4 e2 e1 b9 c3       	vfmadd231sd xmm0,xmm3,xmm3
   122d4:	c5 fb 5c ad b0 fe ff 	vsubsd xmm5,xmm0,QWORD PTR [rbp-0x150]
   122db:	ff 
   122dc:	c5 fb 11 ad c0 fe ff 	vmovsd QWORD PTR [rbp-0x140],xmm5
   122e3:	ff 
   122e4:	dd 85 c0 fe ff ff    	fld    QWORD PTR [rbp-0x140]
   122ea:	d8 c8                	fmul   st,st(0)
   122ec:	45 85 db             	test   r11d,r11d
   122ef:	0f 8e 49 01 00 00    	jle    1243e <try_secant_tail.constprop.0+0x280e>
   122f5:	85 c9                	test   ecx,ecx
   122f7:	0f 8e 41 01 00 00    	jle    1243e <try_secant_tail.constprop.0+0x280e>
   122fd:	89 ca                	mov    edx,ecx
   122ff:	4c 89 ad 70 fe ff ff 	mov    QWORD PTR [rbp-0x190],r13
   12306:	45 31 d2             	xor    r10d,r10d
   12309:	45 31 c0             	xor    r8d,r8d
   1230c:	44 89 a5 30 fe ff ff 	mov    DWORD PTR [rbp-0x1d0],r12d
   12313:	c1 ea 02             	shr    edx,0x2
   12316:	89 9d 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],ebx
   1231c:	48 8b 9d a8 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x158]
   12323:	48 c1 e2 05          	shl    rdx,0x5
   12327:	44 89 bd 60 fe ff ff 	mov    DWORD PTR [rbp-0x1a0],r15d
   1232e:	44 8d 79 ff          	lea    r15d,[rcx-0x1]
   12332:	4c 89 b5 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],r14
   12339:	4c 63 f1             	movsxd r14,ecx
   1233c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   12340:	41 83 ff 02          	cmp    r15d,0x2
   12344:	4e 8d 24 c5 00 00 00 	lea    r12,[r8*8+0x0]
   1234b:	00 
   1234c:	0f 86 2d 02 00 00    	jbe    1257f <try_secant_tail.constprop.0+0x294f>
   12352:	4a 8d 3c 23          	lea    rdi,[rbx+r12*1]
   12356:	31 f6                	xor    esi,esi
   12358:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   1235c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   12360:	c5 fd 10 04 37       	vmovupd ymm0,YMMWORD PTR [rdi+rsi*1]
   12365:	c5 fd 59 04 30       	vmulpd ymm0,ymm0,YMMWORD PTR [rax+rsi*1]
   1236a:	48 83 c6 20          	add    rsi,0x20
   1236e:	48 39 d6             	cmp    rsi,rdx
   12371:	c5 e5 58 d8          	vaddpd ymm3,ymm3,ymm0
   12375:	75 e9                	jne    12360 <try_secant_tail.constprop.0+0x2730>
   12377:	c4 e3 7d 19 d8 01    	vextractf128 xmm0,ymm3,0x1
   1237d:	89 ce                	mov    esi,ecx
   1237f:	c5 f9 58 c3          	vaddpd xmm0,xmm0,xmm3
   12383:	83 e6 fc             	and    esi,0xfffffffc
   12386:	39 ce                	cmp    esi,ecx
   12388:	89 f7                	mov    edi,esi
   1238a:	c5 f9 15 d8          	vunpckhpd xmm3,xmm0,xmm0
   1238e:	c5 e1 58 d8          	vaddpd xmm3,xmm3,xmm0
   12392:	c5 f9 13 9d c0 fe ff 	vmovlpd QWORD PTR [rbp-0x140],xmm3
   12399:	ff 
   1239a:	74 64                	je     12400 <try_secant_tail.constprop.0+0x27d0>
   1239c:	41 89 c9             	mov    r9d,ecx
   1239f:	41 29 f9             	sub    r9d,edi
   123a2:	41 83 f9 01          	cmp    r9d,0x1
   123a6:	74 36                	je     123de <try_secant_tail.constprop.0+0x27ae>
   123a8:	4c 8b ad 90 fe ff ff 	mov    r13,QWORD PTR [rbp-0x170]
   123af:	49 01 fd             	add    r13,rdi
   123b2:	4c 01 c7             	add    rdi,r8
   123b5:	41 f6 c1 01          	test   r9b,0x1
   123b9:	c4 a1 79 10 3c eb    	vmovupd xmm7,XMMWORD PTR [rbx+r13*8]
   123bf:	c4 e2 c1 b8 04 fb    	vfmadd231pd xmm0,xmm7,XMMWORD PTR [rbx+rdi*8]
   123c5:	c5 f9 15 d8          	vunpckhpd xmm3,xmm0,xmm0
   123c9:	c5 e1 58 c0          	vaddpd xmm0,xmm3,xmm0
   123cd:	c5 f9 13 85 c0 fe ff 	vmovlpd QWORD PTR [rbp-0x140],xmm0
   123d4:	ff 
   123d5:	74 29                	je     12400 <try_secant_tail.constprop.0+0x27d0>
   123d7:	41 83 e1 fe          	and    r9d,0xfffffffe
   123db:	44 01 ce             	add    esi,r9d
   123de:	48 63 f6             	movsxd rsi,esi
   123e1:	c5 fb 10 ad c0 fe ff 	vmovsd xmm5,QWORD PTR [rbp-0x140]
   123e8:	ff 
   123e9:	48 8d 3c f3          	lea    rdi,[rbx+rsi*8]
   123ed:	c5 fb 10 3c f0       	vmovsd xmm7,QWORD PTR [rax+rsi*8]
   123f2:	c4 a2 c1 b9 2c 27    	vfmadd231sd xmm5,xmm7,QWORD PTR [rdi+r12*1]
   123f8:	c5 fb 11 ad c0 fe ff 	vmovsd QWORD PTR [rbp-0x140],xmm5
   123ff:	ff 
   12400:	dd 85 c0 fe ff ff    	fld    QWORD PTR [rbp-0x140]
   12406:	41 83 c2 01          	add    r10d,0x1
   1240a:	4d 01 f0             	add    r8,r14
   1240d:	45 39 da             	cmp    r10d,r11d
   12410:	d8 c8                	fmul   st,st(0)
   12412:	d8 c0                	fadd   st,st(0)
   12414:	de c1                	faddp  st(1),st
   12416:	0f 85 24 ff ff ff    	jne    12340 <try_secant_tail.constprop.0+0x2710>
   1241c:	4c 8b ad 70 fe ff ff 	mov    r13,QWORD PTR [rbp-0x190]
   12423:	44 8b bd 60 fe ff ff 	mov    r15d,DWORD PTR [rbp-0x1a0]
   1242a:	8b 9d 38 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x1c8]
   12430:	44 8b a5 30 fe ff ff 	mov    r12d,DWORD PTR [rbp-0x1d0]
   12437:	4c 8b b5 28 fe ff ff 	mov    r14,QWORD PTR [rbp-0x1d8]
   1243e:	de c1                	faddp  st(1),st
   12440:	e9 35 f7 ff ff       	jmp    11b7a <try_secant_tail.constprop.0+0x1f4a>
   12445:	c5 f8 77             	vzeroupper
   12448:	e9 09 e4 ff ff       	jmp    10856 <try_secant_tail.constprop.0+0xc26>
   1244d:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   12454:	4c 8d ad 40 ff ff ff 	lea    r13,[rbp-0xc0]
   1245b:	c5 f8 77             	vzeroupper
   1245e:	48 8b bd 58 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1a8]
   12465:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   1246c:	e8 00 00 00 00       	call   12471 <try_secant_tail.constprop.0+0x2841>
   12471:	48 8b bd 10 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f0]
   12478:	e8 00 00 00 00       	call   1247d <try_secant_tail.constprop.0+0x284d>
   1247d:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   12484:	e8 00 00 00 00       	call   12489 <try_secant_tail.constprop.0+0x2859>
   12489:	4c 8b 95 f8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x108]
   12490:	e9 de ee ff ff       	jmp    11373 <try_secant_tail.constprop.0+0x1743>
   12495:	48 8b b5 08 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1f8]
   1249c:	31 c9                	xor    ecx,ecx
   1249e:	66 90                	xchg   ax,ax
   124a0:	c5 fb 10 04 08       	vmovsd xmm0,QWORD PTR [rax+rcx*1]
   124a5:	c4 e2 f1 a9 04 0a    	vfmadd213sd xmm0,xmm1,QWORD PTR [rdx+rcx*1]
   124ab:	c5 fb 11 04 0a       	vmovsd QWORD PTR [rdx+rcx*1],xmm0
   124b0:	48 83 c1 08          	add    rcx,0x8
   124b4:	48 39 ce             	cmp    rsi,rcx
   124b7:	75 e7                	jne    124a0 <try_secant_tail.constprop.0+0x2870>
   124b9:	e9 97 f7 ff ff       	jmp    11c55 <try_secant_tail.constprop.0+0x2025>
   124be:	48 8b 8d f0 fd ff ff 	mov    rcx,QWORD PTR [rbp-0x210]
   124c5:	31 c0                	xor    eax,eax
   124c7:	66 90                	xchg   ax,ax
   124c9:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   124d0:	00 00 00 00 
   124d4:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   124db:	00 00 00 00 
   124df:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   124e6:	00 00 00 00 
   124ea:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   124f1:	00 00 00 00 
   124f5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   124fc:	00 00 00 00 
   12500:	c5 fb 10 0c 07       	vmovsd xmm1,QWORD PTR [rdi+rax*1]
   12505:	c5 79 29 d2          	vmovapd xmm2,xmm10
   12509:	c4 e2 f1 a9 14 03    	vfmadd213sd xmm2,xmm1,QWORD PTR [rbx+rax*1]
   1250f:	c5 fb 11 14 03       	vmovsd QWORD PTR [rbx+rax*1],xmm2
   12514:	c4 e2 c9 a9 0c 02    	vfmadd213sd xmm1,xmm6,QWORD PTR [rdx+rax*1]
   1251a:	c5 fb 11 0c 02       	vmovsd QWORD PTR [rdx+rax*1],xmm1
   1251f:	48 83 c0 08          	add    rax,0x8
   12523:	48 39 c1             	cmp    rcx,rax
   12526:	75 d8                	jne    12500 <try_secant_tail.constprop.0+0x28d0>
   12528:	c5 39 58 45 b0       	vaddpd xmm8,xmm8,XMMWORD PTR [rbp-0x50]
   1252d:	c5 79 29 45 b0       	vmovapd XMMWORD PTR [rbp-0x50],xmm8
   12532:	e9 8f dd ff ff       	jmp    102c6 <try_secant_tail.constprop.0+0x696>
   12537:	8b b5 f8 fe ff ff    	mov    esi,DWORD PTR [rbp-0x108]
   1253d:	3b b0 00 00 00 00    	cmp    esi,DWORD PTR [rax+0x0]
   12543:	0f 84 a4 e7 ff ff    	je     10ced <try_secant_tail.constprop.0+0x10bd>
   12549:	83 fb 01             	cmp    ebx,0x1
   1254c:	0f 84 6b e7 ff ff    	je     10cbd <try_secant_tail.constprop.0+0x108d>
   12552:	3b b0 00 00 00 00    	cmp    esi,DWORD PTR [rax+0x0]
   12558:	0f 84 8f e7 ff ff    	je     10ced <try_secant_tail.constprop.0+0x10bd>
   1255e:	83 fb 02             	cmp    ebx,0x2
   12561:	41 bc 02 00 00 00    	mov    r12d,0x2
   12567:	0f 85 a3 e6 ff ff    	jne    10c10 <try_secant_tail.constprop.0+0xfe0>
   1256d:	e9 4b e7 ff ff       	jmp    10cbd <try_secant_tail.constprop.0+0x108d>
   12572:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   12578:	31 c0                	xor    eax,eax
   1257a:	e9 a5 ec ff ff       	jmp    11224 <try_secant_tail.constprop.0+0x15f4>
   1257f:	48 c7 85 c0 fe ff ff 	mov    QWORD PTR [rbp-0x140],0x0
   12586:	00 00 00 00 
   1258a:	31 f6                	xor    esi,esi
   1258c:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   12590:	31 ff                	xor    edi,edi
   12592:	e9 05 fe ff ff       	jmp    1239c <try_secant_tail.constprop.0+0x276c>
   12597:	31 c0                	xor    eax,eax
   12599:	44 89 e1             	mov    ecx,r12d
   1259c:	31 d2                	xor    edx,edx
   1259e:	e9 92 f8 ff ff       	jmp    11e35 <try_secant_tail.constprop.0+0x2205>
   125a3:	4c 89 bd f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r15
   125aa:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
   125b1:	e8 00 00 00 00       	call   125b6 <try_secant_tail.constprop.0+0x2986>
   125b6:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   125bd:	e8 00 00 00 00       	call   125c2 <try_secant_tail.constprop.0+0x2992>
   125c2:	48 8b bd 20 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe0]
   125c9:	e8 00 00 00 00       	call   125ce <try_secant_tail.constprop.0+0x299e>
   125ce:	4c 89 f7             	mov    rdi,r14
   125d1:	e8 00 00 00 00       	call   125d6 <try_secant_tail.constprop.0+0x29a6>
   125d6:	48 8b bd f8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x108]
   125dd:	e8 00 00 00 00       	call   125e2 <try_secant_tail.constprop.0+0x29b2>
   125e2:	e9 69 e7 ff ff       	jmp    10d50 <try_secant_tail.constprop.0+0x1120>
   125e7:	31 d2                	xor    edx,edx
   125e9:	31 c0                	xor    eax,eax
   125eb:	e9 ef f8 ff ff       	jmp    11edf <try_secant_tail.constprop.0+0x22af>
   125f0:	48 8b 8d 08 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1f8]
   125f7:	31 d2                	xor    edx,edx
   125f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   12600:	c4 c1 53 59 04 12    	vmulsd xmm0,xmm5,QWORD PTR [r10+rdx*1]
   12606:	c5 fb 11 04 10       	vmovsd QWORD PTR [rax+rdx*1],xmm0
   1260b:	48 83 c2 08          	add    rdx,0x8
   1260f:	48 39 d1             	cmp    rcx,rdx
   12612:	75 ec                	jne    12600 <try_secant_tail.constprop.0+0x29d0>
   12614:	e9 32 f4 ff ff       	jmp    11a4b <try_secant_tail.constprop.0+0x1e1b>
   12619:	48 89 f9             	mov    rcx,rdi
   1261c:	31 d2                	xor    edx,edx
   1261e:	eb e0                	jmp    12600 <try_secant_tail.constprop.0+0x29d0>
   12620:	c5 f8 77             	vzeroupper
   12623:	e9 90 e6 ff ff       	jmp    10cb8 <try_secant_tail.constprop.0+0x1088>
   12628:	dd 05 00 00 00 00    	fld    QWORD PTR [rip+0x0]        # 1262e <try_secant_tail.constprop.0+0x29fe>
   1262e:	d9 c9                	fxch   st(1)
   12630:	e9 41 f5 ff ff       	jmp    11b76 <try_secant_tail.constprop.0+0x1f46>
   12635:	dd d8                	fstp   st(0)
   12637:	d9 e8                	fld1
   12639:	d9 c9                	fxch   st(1)
   1263b:	e9 0f ee ff ff       	jmp    1144f <try_secant_tail.constprop.0+0x181f>
   12640:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 12648 <try_secant_tail.constprop.0+0x2a18>
   12647:	00 
   12648:	e9 8c df ff ff       	jmp    105d9 <try_secant_tail.constprop.0+0x9a9>
   1264d:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 12655 <try_secant_tail.constprop.0+0x2a25>
   12654:	00 
   12655:	c5 f9 7e 85 c0 fe ff 	vmovd  DWORD PTR [rbp-0x140],xmm0
   1265c:	ff 
   1265d:	e9 26 e5 ff ff       	jmp    10b88 <try_secant_tail.constprop.0+0xf58>
   12662:	8b bd f8 fe ff ff    	mov    edi,DWORD PTR [rbp-0x108]
   12668:	3b b8 00 00 00 00    	cmp    edi,DWORD PTR [rax+0x0]
   1266e:	0f 84 68 04 00 00    	je     12adc <try_secant_tail.constprop.0+0x2eac>
   12674:	83 fb 09             	cmp    ebx,0x9
   12677:	41 bc 09 00 00 00    	mov    r12d,0x9
   1267d:	c7 85 c0 fe ff ff 08 	mov    DWORD PTR [rbp-0x140],0x8
   12684:	00 00 00 
   12687:	0f 84 47 04 00 00    	je     12ad4 <try_secant_tail.constprop.0+0x2ea4>
   1268d:	c5 f8 77             	vzeroupper
   12690:	e9 37 e5 ff ff       	jmp    10bcc <try_secant_tail.constprop.0+0xf9c>
   12695:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   1269c:	c7 85 0c ff ff ff 01 	mov    DWORD PTR [rbp-0xf4],0x1
   126a3:	00 00 00 
   126a6:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   126ad:	e9 8f ec ff ff       	jmp    11341 <try_secant_tail.constprop.0+0x1711>
   126b2:	31 d2                	xor    edx,edx
   126b4:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   126b8:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   126bc:	31 f6                	xor    esi,esi
   126be:	e9 4f f4 ff ff       	jmp    11b12 <try_secant_tail.constprop.0+0x1ee2>
   126c3:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   126ca:	48 8b bd 58 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1a8]
   126d1:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   126d8:	c5 f8 77             	vzeroupper
   126db:	e8 00 00 00 00       	call   126e0 <try_secant_tail.constprop.0+0x2ab0>
   126e0:	48 8b bd 10 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f0]
   126e7:	e8 00 00 00 00       	call   126ec <try_secant_tail.constprop.0+0x2abc>
   126ec:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   126f3:	e8 00 00 00 00       	call   126f8 <try_secant_tail.constprop.0+0x2ac8>
   126f8:	4c 8b 95 f8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x108]
   126ff:	8b 9d 48 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x1b8]
   12705:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 1270d <try_secant_tail.constprop.0+0x2add>
   1270c:	00 
   1270d:	4c 8d 8d 40 ff ff ff 	lea    r9,[rbp-0xc0]
   12714:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   1271b:	48 8b b5 98 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x168]
   12722:	48 8b bd b8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x148]
   12729:	8b 8d cc fe ff ff    	mov    ecx,DWORD PTR [rbp-0x134]
   1272f:	48 8b 95 18 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xe8]
   12736:	41 89 d8             	mov    r8d,ebx
   12739:	e8 b2 e1 fe ff       	call   8f0 <compat_scan_fused>
   1273e:	48 8b b5 c8 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x238]
   12745:	48 8b bd d0 fd ff ff 	mov    rdi,QWORD PTR [rbp-0x230]
   1274c:	83 f8 01             	cmp    eax,0x1
   1274f:	c5 fb 10 85 40 ff ff 	vmovsd xmm0,QWORD PTR [rbp-0xc0]
   12756:	ff 
   12757:	4c 8b 95 f8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x108]
   1275e:	19 c0                	sbb    eax,eax
   12760:	89 5f 04             	mov    DWORD PTR [rdi+0x4],ebx
   12763:	83 e0 fe             	and    eax,0xfffffffe
   12766:	c5 fb 11 47 18       	vmovsd QWORD PTR [rdi+0x18],xmm0
   1276b:	83 c0 03             	add    eax,0x3
   1276e:	48 85 f6             	test   rsi,rsi
   12771:	89 07                	mov    DWORD PTR [rdi],eax
   12773:	0f 84 7b 02 00 00    	je     129f4 <try_secant_tail.constprop.0+0x2dc4>
   12779:	85 db                	test   ebx,ebx
   1277b:	0f 8e 6a 02 00 00    	jle    129eb <try_secant_tail.constprop.0+0x2dbb>
   12781:	8d 43 ff             	lea    eax,[rbx-0x1]
   12784:	48 8b 95 18 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xe8]
   1278b:	83 f8 02             	cmp    eax,0x2
   1278e:	0f 86 9a 02 00 00    	jbe    12a2e <try_secant_tail.constprop.0+0x2dfe>
   12794:	89 d9                	mov    ecx,ebx
   12796:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   1279a:	31 c0                	xor    eax,eax
   1279c:	c1 e9 02             	shr    ecx,0x2
   1279f:	c5 fd 28 d3          	vmovapd ymm2,ymm3
   127a3:	48 c1 e1 05          	shl    rcx,0x5
   127a7:	c5 fd 10 0c 06       	vmovupd ymm1,YMMWORD PTR [rsi+rax*1]
   127ac:	c5 fd 10 04 02       	vmovupd ymm0,YMMWORD PTR [rdx+rax*1]
   127b1:	48 83 c0 20          	add    rax,0x20
   127b5:	48 39 c8             	cmp    rax,rcx
   127b8:	c5 fd 5c c1          	vsubpd ymm0,ymm0,ymm1
   127bc:	c4 e2 f5 b8 d1       	vfmadd231pd ymm2,ymm1,ymm1
   127c1:	c4 e2 fd b8 d8       	vfmadd231pd ymm3,ymm0,ymm0
   127c6:	75 df                	jne    127a7 <try_secant_tail.constprop.0+0x2b77>
   127c8:	8b 9d 48 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x1b8]
   127ce:	c4 e3 7d 19 d8 01    	vextractf128 xmm0,ymm3,0x1
   127d4:	c4 e3 7d 19 d1 01    	vextractf128 xmm1,ymm2,0x1
   127da:	c5 f9 58 db          	vaddpd xmm3,xmm0,xmm3
   127de:	c5 f1 58 d2          	vaddpd xmm2,xmm1,xmm2
   127e2:	89 df                	mov    edi,ebx
   127e4:	83 e7 fc             	and    edi,0xfffffffc
   127e7:	c5 e1 15 c3          	vunpckhpd xmm0,xmm3,xmm3
   127eb:	c5 e9 15 ca          	vunpckhpd xmm1,xmm2,xmm2
   127ef:	39 df                	cmp    edi,ebx
   127f1:	89 bd c4 fd ff ff    	mov    DWORD PTR [rbp-0x23c],edi
   127f7:	c5 f9 58 c3          	vaddpd xmm0,xmm0,xmm3
   127fb:	c5 f1 58 ca          	vaddpd xmm1,xmm1,xmm2
   127ff:	89 f8                	mov    eax,edi
   12801:	0f 84 dc 01 00 00    	je     129e3 <try_secant_tail.constprop.0+0x2db3>
   12807:	c5 f8 77             	vzeroupper
   1280a:	8b 8d 48 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b8]
   12810:	29 c1                	sub    ecx,eax
   12812:	83 f9 01             	cmp    ecx,0x1
   12815:	74 3d                	je     12854 <try_secant_tail.constprop.0+0x2c24>
   12817:	48 8b 9d c8 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x238]
   1281e:	c5 f9 10 04 c2       	vmovupd xmm0,XMMWORD PTR [rdx+rax*8]
   12823:	f6 c1 01             	test   cl,0x1
   12826:	c5 f9 10 0c c3       	vmovupd xmm1,XMMWORD PTR [rbx+rax*8]
   1282b:	c5 f9 5c c1          	vsubpd xmm0,xmm0,xmm1
   1282f:	c4 e2 f1 b8 d1       	vfmadd231pd xmm2,xmm1,xmm1
   12834:	c4 e2 e1 98 c0       	vfmadd132pd xmm0,xmm3,xmm0
   12839:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   1283d:	c5 f1 58 c0          	vaddpd xmm0,xmm1,xmm0
   12841:	c5 e9 15 ca          	vunpckhpd xmm1,xmm2,xmm2
   12845:	c5 f1 58 ca          	vaddpd xmm1,xmm1,xmm2
   12849:	74 2f                	je     1287a <try_secant_tail.constprop.0+0x2c4a>
   1284b:	83 e1 fe             	and    ecx,0xfffffffe
   1284e:	01 8d c4 fd ff ff    	add    DWORD PTR [rbp-0x23c],ecx
   12854:	48 63 85 c4 fd ff ff 	movsxd rax,DWORD PTR [rbp-0x23c]
   1285b:	48 8b 9d c8 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x238]
   12862:	c5 fb 10 14 c2       	vmovsd xmm2,QWORD PTR [rdx+rax*8]
   12867:	c5 fb 10 1c c3       	vmovsd xmm3,QWORD PTR [rbx+rax*8]
   1286c:	c5 eb 5c d3          	vsubsd xmm2,xmm2,xmm3
   12870:	c4 e2 e1 b9 cb       	vfmadd231sd xmm1,xmm3,xmm3
   12875:	c4 e2 e9 b9 c2       	vfmadd231sd xmm0,xmm2,xmm2
   1287a:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
   1287e:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
   12882:	c5 f3 58 0d 00 00 00 	vaddsd xmm1,xmm1,QWORD PTR [rip+0x0]        # 1288a <try_secant_tail.constprop.0+0x2c5a>
   12889:	00 
   1288a:	c5 fb 5e c1          	vdivsd xmm0,xmm0,xmm1
   1288e:	48 8b 85 d0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x230]
   12895:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   1289c:	c7 40 0c 00 00 00 00 	mov    DWORD PTR [rax+0xc],0x0
   128a3:	c5 fb 11 40 20       	vmovsd QWORD PTR [rax+0x20],xmm0
   128a8:	e9 f2 ec ff ff       	jmp    1159f <try_secant_tail.constprop.0+0x196f>
   128ad:	49 89 da             	mov    r10,rbx
   128b0:	c5 f8 77             	vzeroupper
   128b3:	e9 a6 fb ff ff       	jmp    1245e <try_secant_tail.constprop.0+0x282e>
   128b8:	44 89 e1             	mov    ecx,r12d
   128bb:	31 c0                	xor    eax,eax
   128bd:	31 d2                	xor    edx,edx
   128bf:	e9 bb ee ff ff       	jmp    1177f <try_secant_tail.constprop.0+0x1b4f>
   128c4:	31 c9                	xor    ecx,ecx
   128c6:	e9 45 f3 ff ff       	jmp    11c10 <try_secant_tail.constprop.0+0x1fe0>
   128cb:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 128d3 <try_secant_tail.constprop.0+0x2ca3>
   128d2:	00 
   128d3:	e9 7d fd ff ff       	jmp    12655 <try_secant_tail.constprop.0+0x2a25>
   128d8:	31 c9                	xor    ecx,ecx
   128da:	31 f6                	xor    esi,esi
   128dc:	e9 2a f1 ff ff       	jmp    11a0b <try_secant_tail.constprop.0+0x1ddb>
   128e1:	c5 f8 77             	vzeroupper
   128e4:	e9 dc dc ff ff       	jmp    105c5 <try_secant_tail.constprop.0+0x995>
   128e9:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 128f1 <try_secant_tail.constprop.0+0x2cc1>
   128f0:	00 
   128f1:	e9 5f fd ff ff       	jmp    12655 <try_secant_tail.constprop.0+0x2a25>
   128f6:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 128fe <try_secant_tail.constprop.0+0x2cce>
   128fd:	00 
   128fe:	e9 52 fd ff ff       	jmp    12655 <try_secant_tail.constprop.0+0x2a25>
   12903:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 1290b <try_secant_tail.constprop.0+0x2cdb>
   1290a:	00 
   1290b:	e9 45 fd ff ff       	jmp    12655 <try_secant_tail.constprop.0+0x2a25>
   12910:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 12918 <try_secant_tail.constprop.0+0x2ce8>
   12917:	00 
   12918:	e9 38 fd ff ff       	jmp    12655 <try_secant_tail.constprop.0+0x2a25>
   1291d:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   12921:	e9 b3 dc ff ff       	jmp    105d9 <try_secant_tail.constprop.0+0x9a9>
   12926:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 1292e <try_secant_tail.constprop.0+0x2cfe>
   1292d:	00 
   1292e:	e9 22 fd ff ff       	jmp    12655 <try_secant_tail.constprop.0+0x2a25>
   12933:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 1293b <try_secant_tail.constprop.0+0x2d0b>
   1293a:	00 
   1293b:	e9 15 fd ff ff       	jmp    12655 <try_secant_tail.constprop.0+0x2a25>
   12940:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   12944:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   12948:	31 d2                	xor    edx,edx
   1294a:	c5 f9 28 d3          	vmovapd xmm2,xmm3
   1294e:	c5 f9 28 c1          	vmovapd xmm0,xmm1
   12952:	e9 06 dc ff ff       	jmp    1055d <try_secant_tail.constprop.0+0x92d>
   12957:	c5 f8 77             	vzeroupper
   1295a:	e9 19 ec ff ff       	jmp    11578 <try_secant_tail.constprop.0+0x1948>
   1295f:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 12967 <try_secant_tail.constprop.0+0x2d37>
   12966:	00 
   12967:	e9 20 ec ff ff       	jmp    1158c <try_secant_tail.constprop.0+0x195c>
   1296c:	89 85 d0 fe ff ff    	mov    DWORD PTR [rbp-0x130],eax
   12972:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   12979:	4c 8d ad 40 ff ff ff 	lea    r13,[rbp-0xc0]
   12980:	c5 f8 77             	vzeroupper
   12983:	e9 d6 fa ff ff       	jmp    1245e <try_secant_tail.constprop.0+0x282e>
   12988:	8b 85 88 fe ff ff    	mov    eax,DWORD PTR [rbp-0x178]
   1298e:	49 89 da             	mov    r10,rbx
   12991:	89 85 c0 fe ff ff    	mov    DWORD PTR [rbp-0x140],eax
   12997:	e9 01 da ff ff       	jmp    1039d <try_secant_tail.constprop.0+0x76d>
   1299c:	31 f6                	xor    esi,esi
   1299e:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   129a2:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   129a6:	31 d2                	xor    edx,edx
   129a8:	e9 e5 f8 ff ff       	jmp    12292 <try_secant_tail.constprop.0+0x2662>
   129ad:	d9 e8                	fld1
   129af:	e9 38 f9 ff ff       	jmp    122ec <try_secant_tail.constprop.0+0x26bc>
   129b4:	49 89 da             	mov    r10,rbx
   129b7:	4c 8d ad 40 ff ff ff 	lea    r13,[rbp-0xc0]
   129be:	e9 9b fa ff ff       	jmp    1245e <try_secant_tail.constprop.0+0x282e>
   129c3:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   129c7:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   129cb:	31 c0                	xor    eax,eax
   129cd:	c5 f9 28 d3          	vmovapd xmm2,xmm3
   129d1:	c5 f9 28 c1          	vmovapd xmm0,xmm1
   129d5:	e9 2e eb ff ff       	jmp    11508 <try_secant_tail.constprop.0+0x18d8>
   129da:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   129de:	e9 a9 eb ff ff       	jmp    1158c <try_secant_tail.constprop.0+0x195c>
   129e3:	c5 f8 77             	vzeroupper
   129e6:	e9 8f fe ff ff       	jmp    1287a <try_secant_tail.constprop.0+0x2c4a>
   129eb:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   129ef:	e9 9a fe ff ff       	jmp    1288e <try_secant_tail.constprop.0+0x2c5e>
   129f4:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 129fc <try_secant_tail.constprop.0+0x2dcc>
   129fb:	00 
   129fc:	e9 8d fe ff ff       	jmp    1288e <try_secant_tail.constprop.0+0x2c5e>
   12a01:	48 89 9d f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],rbx
   12a08:	c7 85 0c ff ff ff 01 	mov    DWORD PTR [rbp-0xf4],0x1
   12a0f:	00 00 00 
   12a12:	e9 2a e9 ff ff       	jmp    11341 <try_secant_tail.constprop.0+0x1711>
   12a17:	8b 85 88 fe ff ff    	mov    eax,DWORD PTR [rbp-0x178]
   12a1d:	49 89 da             	mov    r10,rbx
   12a20:	89 85 c0 fe ff ff    	mov    DWORD PTR [rbp-0x140],eax
   12a26:	c5 f8 77             	vzeroupper
   12a29:	e9 6f d9 ff ff       	jmp    1039d <try_secant_tail.constprop.0+0x76d>
   12a2e:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   12a32:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   12a36:	31 c0                	xor    eax,eax
   12a38:	c5 f9 28 d3          	vmovapd xmm2,xmm3
   12a3c:	c5 f9 28 c1          	vmovapd xmm0,xmm1
   12a40:	e9 c5 fd ff ff       	jmp    1280a <try_secant_tail.constprop.0+0x2bda>
   12a45:	44 89 9d d0 fe ff ff 	mov    DWORD PTR [rbp-0x130],r11d
   12a4c:	49 89 da             	mov    r10,rbx
   12a4f:	e9 86 dc ff ff       	jmp    106da <try_secant_tail.constprop.0+0xaaa>
   12a54:	44 89 9d d0 fe ff ff 	mov    DWORD PTR [rbp-0x130],r11d
   12a5b:	49 89 da             	mov    r10,rbx
   12a5e:	4c 8d ad 40 ff ff ff 	lea    r13,[rbp-0xc0]
   12a65:	e9 f4 f9 ff ff       	jmp    1245e <try_secant_tail.constprop.0+0x282e>
   12a6a:	e8 00 00 00 00       	call   12a6f <try_secant_tail.constprop.0+0x2e3f>
   12a6f:	4c 8d ad 40 ff ff ff 	lea    r13,[rbp-0xc0]
   12a76:	e9 f8 e8 ff ff       	jmp    11373 <try_secant_tail.constprop.0+0x1743>
   12a7b:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   12a82:	4c 89 f7             	mov    rdi,r14
   12a85:	e8 00 00 00 00       	call   12a8a <try_secant_tail.constprop.0+0x2e5a>
   12a8a:	48 8b bd f8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x108]
   12a91:	e8 00 00 00 00       	call   12a96 <try_secant_tail.constprop.0+0x2e66>
   12a96:	48 8b bd 18 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1e8]
   12a9d:	e8 7e d7 fe ff       	call   220 <bs_free>
   12aa2:	e9 1a d2 ff ff       	jmp    fcc1 <try_secant_tail.constprop.0+0x91>
   12aa7:	48 8b bd 58 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1a8]
   12aae:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   12ab5:	e8 00 00 00 00       	call   12aba <try_secant_tail.constprop.0+0x2e8a>
   12aba:	48 8b bd 10 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f0]
   12ac1:	e8 00 00 00 00       	call   12ac6 <try_secant_tail.constprop.0+0x2e96>
   12ac6:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   12acd:	e8 00 00 00 00       	call   12ad2 <try_secant_tail.constprop.0+0x2ea2>
   12ad2:	eb ae                	jmp    12a82 <try_secant_tail.constprop.0+0x2e52>
   12ad4:	c5 f8 77             	vzeroupper
   12ad7:	e9 e1 e1 ff ff       	jmp    10cbd <try_secant_tail.constprop.0+0x108d>
   12adc:	c5 f8 77             	vzeroupper
   12adf:	e9 09 e2 ff ff       	jmp    10ced <try_secant_tail.constprop.0+0x10bd>
