/tmp/abs-stage2b-measured-normal/tail.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000031b40 <abs_tail_replay>:
   31b40:	f3 0f 1e fa          	endbr64
   31b44:	4c 8d 54 24 08       	lea    r10,[rsp+0x8]
   31b49:	48 83 e4 e0          	and    rsp,0xffffffffffffffe0
   31b4d:	c5 f9 ef c0          	vpxor  xmm0,xmm0,xmm0
   31b51:	41 ff 72 f8          	push   QWORD PTR [r10-0x8]
   31b55:	55                   	push   rbp
   31b56:	48 89 e5             	mov    rbp,rsp
   31b59:	41 52                	push   r10
   31b5b:	53                   	push   rbx
   31b5c:	48 83 ec 48          	sub    rsp,0x48
   31b60:	49 8b 02             	mov    rax,QWORD PTR [r10]
   31b63:	64 48 8b 1c 25 28 00 	mov    rbx,QWORD PTR fs:0x28
   31b6a:	00 00 
   31b6c:	48 89 5d e8          	mov    QWORD PTR [rbp-0x18],rbx
   31b70:	49 8b 5a 08          	mov    rbx,QWORD PTR [r10+0x8]
   31b74:	c5 f9 7f 45 c0       	vmovdqa XMMWORD PTR [rbp-0x40],xmm0
   31b79:	4c 8d 55 c0          	lea    r10,[rbp-0x40]
   31b7d:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   31b81:	c5 f9 29 45 d0       	vmovapd XMMWORD PTR [rbp-0x30],xmm0
   31b86:	48 c7 45 e0 00 00 00 	mov    QWORD PTR [rbp-0x20],0x0
   31b8d:	00 
   31b8e:	41 52                	push   r10
   31b90:	50                   	push   rax
   31b91:	41 51                	push   r9
   31b93:	45 89 c1             	mov    r9d,r8d
   31b96:	41 89 c8             	mov    r8d,ecx
   31b99:	89 d1                	mov    ecx,edx
   31b9b:	31 d2                	xor    edx,edx
   31b9d:	e8 3e e3 fd ff       	call   fee0 <try_secant_tail.constprop.0>
   31ba2:	c5 fb 10 55 e0       	vmovsd xmm2,QWORD PTR [rbp-0x20]
   31ba7:	c5 fe e6 45 c0       	vcvtdq2pd ymm0,XMMWORD PTR [rbp-0x40]
   31bac:	c5 fd 11 03          	vmovupd YMMWORD PTR [rbx],ymm0
   31bb0:	c5 f8 57 c0          	vxorps xmm0,xmm0,xmm0
   31bb4:	c5 fb 10 5d d0       	vmovsd xmm3,QWORD PTR [rbp-0x30]
   31bb9:	c5 e1 16 4d d8       	vmovhpd xmm1,xmm3,QWORD PTR [rbp-0x28]
   31bbe:	48 83 c4 20          	add    rsp,0x20
   31bc2:	c5 fb 2a c0          	vcvtsi2sd xmm0,xmm0,eax
   31bc6:	c5 e9 14 c0          	vunpcklpd xmm0,xmm2,xmm0
   31bca:	c4 e3 75 18 c0 01    	vinsertf128 ymm0,ymm1,xmm0,0x1
   31bd0:	c5 fd 11 43 20       	vmovupd YMMWORD PTR [rbx+0x20],ymm0
   31bd5:	48 8b 45 e8          	mov    rax,QWORD PTR [rbp-0x18]
   31bd9:	64 48 2b 04 25 28 00 	sub    rax,QWORD PTR fs:0x28
   31be0:	00 00 
   31be2:	75 10                	jne    31bf4 <abs_tail_replay+0xb4>
   31be4:	c5 f8 77             	vzeroupper
   31be7:	48 8d 65 f0          	lea    rsp,[rbp-0x10]
   31beb:	5b                   	pop    rbx
   31bec:	41 5a                	pop    r10
   31bee:	5d                   	pop    rbp
   31bef:	49 8d 62 f8          	lea    rsp,[r10-0x8]
   31bf3:	c3                   	ret
   31bf4:	c5 f8 77             	vzeroupper
   31bf7:	e8 00 00 00 00       	call   31bfc <abs_tail_replay+0xbc>
