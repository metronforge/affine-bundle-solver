/tmp/abs-stage2b-measured-normal/tail.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000004ad0 <try_secant_tail._omp_fn.0>:
    4ad0:	f3 0f 1e fa          	endbr64
    4ad4:	55                   	push   rbp
    4ad5:	48 89 e5             	mov    rbp,rsp
    4ad8:	41 57                	push   r15
    4ada:	41 56                	push   r14
    4adc:	41 55                	push   r13
    4ade:	49 89 fd             	mov    r13,rdi
    4ae1:	41 54                	push   r12
    4ae3:	53                   	push   rbx
    4ae4:	48 83 e4 e0          	and    rsp,0xffffffffffffffe0
    4ae8:	48 81 ec c0 00 00 00 	sub    rsp,0xc0
    4aef:	e8 00 00 00 00       	call   4af4 <try_secant_tail._omp_fn.0+0x24>
    4af4:	48 63 d8             	movsxd rbx,eax
    4af7:	e8 00 00 00 00       	call   4afc <try_secant_tail._omp_fn.0+0x2c>
    4afc:	89 c1                	mov    ecx,eax
    4afe:	41 8b 45 60          	mov    eax,DWORD PTR [r13+0x60]
    4b02:	99                   	cdq
    4b03:	f7 f9                	idiv   ecx
    4b05:	39 d3                	cmp    ebx,edx
    4b07:	8d 48 01             	lea    ecx,[rax+0x1]
    4b0a:	0f 4c c1             	cmovl  eax,ecx
    4b0d:	b9 00 00 00 00       	mov    ecx,0x0
    4b12:	0f 4c d1             	cmovl  edx,ecx
    4b15:	89 c1                	mov    ecx,eax
    4b17:	0f af cb             	imul   ecx,ebx
    4b1a:	01 ca                	add    edx,ecx
    4b1c:	8d 0c 10             	lea    ecx,[rax+rdx*1]
    4b1f:	39 ca                	cmp    edx,ecx
    4b21:	0f 8d 27 06 00 00    	jge    514e <try_secant_tail._omp_fn.0+0x67e>
    4b27:	49 63 7d 58          	movsxd rdi,DWORD PTR [r13+0x58]
    4b2b:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
    4b2f:	4c 63 ca             	movsxd r9,edx
    4b32:	89 c0                	mov    eax,eax
    4b34:	4d 8b 65 20          	mov    r12,QWORD PTR [r13+0x20]
    4b38:	4d 8b 75 48          	mov    r14,QWORD PTR [r13+0x48]
    4b3c:	48 89 b4 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rsi
    4b43:	00 
    4b44:	48 89 fe             	mov    rsi,rdi
    4b47:	45 8b 7d 5c          	mov    r15d,DWORD PTR [r13+0x5c]
    4b4b:	49 89 fa             	mov    r10,rdi
    4b4e:	48 0f af f3          	imul   rsi,rbx
    4b52:	4c 89 64 24 70       	mov    QWORD PTR [rsp+0x70],r12
    4b57:	4d 8b 65 40          	mov    r12,QWORD PTR [r13+0x40]
    4b5b:	48 c1 e3 04          	shl    rbx,0x4
    4b5f:	49 03 5d 50          	add    rbx,QWORD PTR [r13+0x50]
    4b63:	4d 8b 45 28          	mov    r8,QWORD PTR [r13+0x28]
    4b67:	4c 89 74 24 60       	mov    QWORD PTR [rsp+0x60],r14
    4b6c:	4d 01 cc             	add    r12,r9
    4b6f:	48 89 bc 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rdi
    4b76:	00 
    4b77:	c4 c1 7b 10 7d 30    	vmovsd xmm7,QWORD PTR [r13+0x30]
    4b7d:	48 89 f1             	mov    rcx,rsi
    4b80:	4c 01 e0             	add    rax,r12
    4b83:	48 89 5c 24 50       	mov    QWORD PTR [rsp+0x50],rbx
    4b88:	48 8b 9c 24 a8 00 00 	mov    rbx,QWORD PTR [rsp+0xa8]
    4b8f:	00 
    4b90:	48 c1 e1 04          	shl    rcx,0x4
    4b94:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    4b99:	41 8d 42 ff          	lea    eax,[r10-0x1]
    4b9d:	4d 8d 1c 0e          	lea    r11,[r14+rcx*1]
    4ba1:	89 84 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],eax
    4ba8:	48 8d 04 36          	lea    rax,[rsi+rsi*1]
    4bac:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    4bb1:	4c 89 9c 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],r11
    4bb8:	00 
    4bb9:	4c 8d 1c fd 00 00 00 	lea    r11,[rdi*8+0x0]
    4bc0:	00 
    4bc1:	49 63 ff             	movsxd rdi,r15d
    4bc4:	4c 01 cf             	add    rdi,r9
    4bc7:	4d 8b 4d 08          	mov    r9,QWORD PTR [r13+0x8]
    4bcb:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
    4bd0:	48 01 d8             	add    rax,rbx
    4bd3:	48 89 44 24 20       	mov    QWORD PTR [rsp+0x20],rax
    4bd8:	48 c1 e0 03          	shl    rax,0x3
    4bdc:	4d 8d 34 f9          	lea    r14,[r9+rdi*8]
    4be0:	4c 89 5c 24 28       	mov    QWORD PTR [rsp+0x28],r11
    4be5:	4f 8d 0c 18          	lea    r9,[r8+r11*1]
    4be9:	48 0f af fb          	imul   rdi,rbx
    4bed:	48 8d 1c 06          	lea    rbx,[rsi+rax*1]
    4bf1:	c5 fb 11 7c 24 58    	vmovsd QWORD PTR [rsp+0x58],xmm7
    4bf7:	48 2b b4 24 b0 00 00 	sub    rsi,QWORD PTR [rsp+0xb0]
    4bfe:	00 
    4bff:	4c 8d 59 20          	lea    r11,[rcx+0x20]
    4c03:	c4 c1 7b 10 7d 10    	vmovsd xmm7,QWORD PTR [r13+0x10]
    4c09:	48 89 bc 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rdi
    4c10:	00 
    4c11:	48 8d 3c 06          	lea    rdi,[rsi+rax*1]
    4c15:	48 89 7c 24 40       	mov    QWORD PTR [rsp+0x40],rdi
    4c1a:	48 8d 78 20          	lea    rdi,[rax+0x20]
    4c1e:	48 39 f9             	cmp    rcx,rdi
    4c21:	c5 fb 11 7c 24 68    	vmovsd QWORD PTR [rsp+0x68],xmm7
    4c27:	40 0f 9d c7          	setge  dil
    4c2b:	4c 39 d8             	cmp    rax,r11
    4c2e:	0f 9d c0             	setge  al
    4c31:	09 c7                	or     edi,eax
    4c33:	48 8d 04 31          	lea    rax,[rcx+rsi*1]
    4c37:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    4c3c:	41 8d 44 17 01       	lea    eax,[r15+rdx*1+0x1]
    4c41:	44 29 e0             	sub    eax,r12d
    4c44:	40 88 7c 24 3f       	mov    BYTE PTR [rsp+0x3f],dil
    4c49:	89 84 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],eax
    4c50:	48 b8 15 7c 4a 7f b9 	movabs rax,0x9e3779b97f4a7c15
    4c57:	79 37 9e 
    4c5a:	49 03 45 18          	add    rax,QWORD PTR [r13+0x18]
    4c5e:	c5 fb 10 3d 00 00 00 	vmovsd xmm7,QWORD PTR [rip+0x0]        # 4c66 <try_secant_tail._omp_fn.0+0x196>
    4c65:	00 
    4c66:	c4 c1 43 58 7d 38    	vaddsd xmm7,xmm7,QWORD PTR [r13+0x38]
    4c6c:	48 89 44 24 48       	mov    QWORD PTR [rsp+0x48],rax
    4c71:	4c 8b 9c 24 b8 00 00 	mov    r11,QWORD PTR [rsp+0xb8]
    4c78:	00 
    4c79:	4c 89 8c 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],r9
    4c80:	00 
    4c81:	4c 8b ac 24 a0 00 00 	mov    r13,QWORD PTR [rsp+0xa0]
    4c88:	00 
    4c89:	c5 fb 11 7c 24 10    	vmovsd QWORD PTR [rsp+0x10],xmm7
    4c8f:	90                   	nop
    4c90:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
    4c97:	00 
    4c98:	45 85 d2             	test   r10d,r10d
    4c9b:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    4c9f:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
    4ca3:	4a 8d 04 ed 00 00 00 	lea    rax,[r13*8+0x0]
    4caa:	00 
    4cab:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    4cb2:	00 
    4cb3:	48 8d 3c 06          	lea    rdi,[rsi+rax*1]
    4cb7:	0f 8e ab 04 00 00    	jle    5168 <try_secant_tail._omp_fn.0+0x698>
    4cbd:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    4cc2:	83 bc 24 9c 00 00 00 	cmp    DWORD PTR [rsp+0x9c],0x2
    4cc9:	02 
    4cca:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
    4cce:	0f 86 f4 04 00 00    	jbe    51c8 <try_secant_tail._omp_fn.0+0x6f8>
    4cd4:	44 89 d1             	mov    ecx,r10d
    4cd7:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
    4cdb:	4c 8b 8c 24 b8 00 00 	mov    r9,QWORD PTR [rsp+0xb8]
    4ce2:	00 
    4ce3:	31 d2                	xor    edx,edx
    4ce5:	c5 fd 28 dc          	vmovapd ymm3,ymm4
    4ce9:	c1 e9 02             	shr    ecx,0x2
    4cec:	c5 fd 28 cc          	vmovapd ymm1,ymm4
    4cf0:	c5 fd 28 d4          	vmovapd ymm2,ymm4
    4cf4:	48 c1 e1 05          	shl    rcx,0x5
    4cf8:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
    4cff:	00 
    4d00:	c5 fd 10 04 17       	vmovupd ymm0,YMMWORD PTR [rdi+rdx*1]
    4d05:	c4 e2 fd b8 1c 10    	vfmadd231pd ymm3,ymm0,YMMWORD PTR [rax+rdx*1]
    4d0b:	c4 c2 fd b8 0c 10    	vfmadd231pd ymm1,ymm0,YMMWORD PTR [r8+rdx*1]
    4d11:	c4 c2 fd b8 14 11    	vfmadd231pd ymm2,ymm0,YMMWORD PTR [r9+rdx*1]
    4d17:	48 83 c2 20          	add    rdx,0x20
    4d1b:	48 39 d1             	cmp    rcx,rdx
    4d1e:	c4 e2 fd b8 e0       	vfmadd231pd ymm4,ymm0,ymm0
    4d23:	75 db                	jne    4d00 <try_secant_tail._omp_fn.0+0x230>
    4d25:	c4 e3 7d 19 d6 01    	vextractf128 xmm6,ymm2,0x1
    4d2b:	c4 e3 7d 19 e5 01    	vextractf128 xmm5,ymm4,0x1
    4d31:	44 89 d2             	mov    edx,r10d
    4d34:	4c 89 8c 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],r9
    4d3b:	00 
    4d3c:	c5 c9 58 f2          	vaddpd xmm6,xmm6,xmm2
    4d40:	c5 d1 58 ec          	vaddpd xmm5,xmm5,xmm4
    4d44:	c4 e3 7d 19 dc 01    	vextractf128 xmm4,ymm3,0x1
    4d4a:	83 e2 fc             	and    edx,0xfffffffc
    4d4d:	c5 d9 58 db          	vaddpd xmm3,xmm4,xmm3
    4d51:	41 39 d2             	cmp    r10d,edx
    4d54:	89 d1                	mov    ecx,edx
    4d56:	c5 c9 15 d6          	vunpckhpd xmm2,xmm6,xmm6
    4d5a:	c5 d1 15 c5          	vunpckhpd xmm0,xmm5,xmm5
    4d5e:	c5 69 58 c6          	vaddpd xmm8,xmm2,xmm6
    4d62:	c4 e3 7d 19 ca 01    	vextractf128 xmm2,ymm1,0x1
    4d68:	c5 e1 15 e3          	vunpckhpd xmm4,xmm3,xmm3
    4d6c:	c5 e9 58 c9          	vaddpd xmm1,xmm2,xmm1
    4d70:	c5 f9 58 c5          	vaddpd xmm0,xmm0,xmm5
    4d74:	c5 d9 58 e3          	vaddpd xmm4,xmm4,xmm3
    4d78:	c5 f1 15 f9          	vunpckhpd xmm7,xmm1,xmm1
    4d7c:	c5 c1 58 f9          	vaddpd xmm7,xmm7,xmm1
    4d80:	c5 b9 14 d7          	vunpcklpd xmm2,xmm8,xmm7
    4d84:	0f 84 ac 00 00 00    	je     4e36 <try_secant_tail._omp_fn.0+0x366>
    4d8a:	44 89 d6             	mov    esi,r10d
    4d8d:	29 ce                	sub    esi,ecx
    4d8f:	83 fe 01             	cmp    esi,0x1
    4d92:	74 74                	je     4e08 <try_secant_tail._omp_fn.0+0x338>
    4d94:	4c 8b bc 24 a8 00 00 	mov    r15,QWORD PTR [rsp+0xa8]
    4d9b:	00 
    4d9c:	4c 8b 8c 24 b0 00 00 	mov    r9,QWORD PTR [rsp+0xb0]
    4da3:	00 
    4da4:	49 01 cf             	add    r15,rcx
    4da7:	40 f6 c6 01          	test   sil,0x1
    4dab:	4c 89 bc 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r15
    4db2:	00 
    4db3:	4d 8d 7c 0d 00       	lea    r15,[r13+rcx*1+0x0]
    4db8:	c4 81 79 10 04 f9    	vmovupd xmm0,XMMWORD PTR [r9+r15*8]
    4dbe:	4c 8b bc 24 90 00 00 	mov    r15,QWORD PTR [rsp+0x90]
    4dc5:	00 
    4dc6:	c4 e2 f9 b8 1c c8    	vfmadd231pd xmm3,xmm0,XMMWORD PTR [rax+rcx*8]
    4dcc:	c4 c2 f9 b8 0c c8    	vfmadd231pd xmm1,xmm0,XMMWORD PTR [r8+rcx*8]
    4dd2:	c4 82 f9 b8 34 f8    	vfmadd231pd xmm6,xmm0,XMMWORD PTR [r8+r15*8]
    4dd8:	c4 e2 f9 b8 e8       	vfmadd231pd xmm5,xmm0,xmm0
    4ddd:	c5 e1 15 e3          	vunpckhpd xmm4,xmm3,xmm3
    4de1:	c5 d9 58 e3          	vaddpd xmm4,xmm4,xmm3
    4de5:	c5 c9 15 d6          	vunpckhpd xmm2,xmm6,xmm6
    4de9:	c5 f1 15 d9          	vunpckhpd xmm3,xmm1,xmm1
    4ded:	c5 e9 58 d6          	vaddpd xmm2,xmm2,xmm6
    4df1:	c5 e1 58 c9          	vaddpd xmm1,xmm3,xmm1
    4df5:	c5 d1 15 c5          	vunpckhpd xmm0,xmm5,xmm5
    4df9:	c5 f9 58 c5          	vaddpd xmm0,xmm0,xmm5
    4dfd:	c5 e9 14 d1          	vunpcklpd xmm2,xmm2,xmm1
    4e01:	74 33                	je     4e36 <try_secant_tail._omp_fn.0+0x366>
    4e03:	83 e6 fe             	and    esi,0xfffffffe
    4e06:	01 f2                	add    edx,esi
    4e08:	48 63 ca             	movsxd rcx,edx
    4e0b:	44 01 d2             	add    edx,r10d
    4e0e:	c5 fb 10 0c cf       	vmovsd xmm1,QWORD PTR [rdi+rcx*8]
    4e13:	48 63 d2             	movsxd rdx,edx
    4e16:	c4 e2 f1 b9 24 c8    	vfmadd231sd xmm4,xmm1,QWORD PTR [rax+rcx*8]
    4e1c:	c5 fb 12 d9          	vmovddup xmm3,xmm1
    4e20:	c4 e2 f1 b9 c1       	vfmadd231sd xmm0,xmm1,xmm1
    4e25:	c4 c1 7b 10 0c d0    	vmovsd xmm1,QWORD PTR [r8+rdx*8]
    4e2b:	c4 c1 71 16 0c c8    	vmovhpd xmm1,xmm1,QWORD PTR [r8+rcx*8]
    4e31:	c4 e2 f1 b8 d3       	vfmadd231pd xmm2,xmm1,xmm3
    4e36:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
    4e3a:	c5 f9 2f c1          	vcomisd xmm0,xmm1
    4e3e:	0f 86 24 03 00 00    	jbe    5168 <try_secant_tail._omp_fn.0+0x698>
    4e44:	48 b8 00 00 00 00 00 	movabs rax,0x7ff0000000000000
    4e4b:	00 f0 7f 
    4e4e:	c4 e1 f9 7e c6       	vmovq  rsi,xmm0
    4e53:	c4 e2 c8 f2 c0       	andn   rax,rsi,rax
    4e58:	0f 84 0a 03 00 00    	je     5168 <try_secant_tail._omp_fn.0+0x698>
    4e5e:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
    4e62:	8b 84 24 98 00 00 00 	mov    eax,DWORD PTR [rsp+0x98]
    4e69:	c5 fb 10 3d 00 00 00 	vmovsd xmm7,QWORD PTR [rip+0x0]        # 4e71 <try_secant_tail._omp_fn.0+0x3a1>
    4e70:	00 
    4e71:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
    4e75:	48 be eb 11 31 13 bb 	movabs rsi,0x94d049bb133111eb
    4e7c:	49 d0 94 
    4e7f:	48 ba b9 e5 e4 1c 6d 	movabs rdx,0xbf58476d1ce4e5b9
    4e86:	47 58 bf 
    4e89:	c5 fb 10 35 00 00 00 	vmovsd xmm6,QWORD PTR [rip+0x0]        # 4e91 <try_secant_tail._omp_fn.0+0x3c1>
    4e90:	00 
    4e91:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # 4e99 <try_secant_tail._omp_fn.0+0x3c9>
    4e98:	00 
    4e99:	c5 c3 5e c0          	vdivsd xmm0,xmm7,xmm0
    4e9d:	44 01 e0             	add    eax,r12d
    4ea0:	49 89 d1             	mov    r9,rdx
    4ea3:	c5 7b 10 64 24 58    	vmovsd xmm12,QWORD PTR [rsp+0x58]
    4ea9:	48 98                	cdqe
    4eab:	c5 e9 54 15 00 00 00 	vandpd xmm2,xmm2,XMMWORD PTR [rip+0x0]        # 4eb3 <try_secant_tail._omp_fn.0+0x3e3>
    4eb2:	00 
    4eb3:	48 89 c1             	mov    rcx,rax
    4eb6:	48 0f af ce          	imul   rcx,rsi
    4eba:	48 03 4c 24 48       	add    rcx,QWORD PTR [rsp+0x48]
    4ebf:	49 89 cf             	mov    r15,rcx
    4ec2:	49 c1 ef 1e          	shr    r15,0x1e
    4ec6:	49 31 cf             	xor    r15,rcx
    4ec9:	4c 0f af fa          	imul   r15,rdx
    4ecd:	4c 89 fa             	mov    rdx,r15
    4ed0:	48 c1 ea 1b          	shr    rdx,0x1b
    4ed4:	4c 31 fa             	xor    rdx,r15
    4ed7:	48 0f af d6          	imul   rdx,rsi
    4edb:	49 89 d7             	mov    r15,rdx
    4ede:	49 c1 ef 1f          	shr    r15,0x1f
    4ee2:	49 31 d7             	xor    r15,rdx
    4ee5:	48 ba ce d3 b3 09 b2 	movabs rdx,0x2a87fdb209b3d3ce
    4eec:	fd 87 2a 
    4eef:	48 0f af c2          	imul   rax,rdx
    4ef3:	49 c1 ef 0b          	shr    r15,0xb
    4ef7:	c4 c1 e3 2a cf       	vcvtsi2sd xmm1,xmm3,r15
    4efc:	c4 e2 d1 99 ce       	vfmadd132sd xmm1,xmm5,xmm6
    4f01:	48 01 c8             	add    rax,rcx
    4f04:	48 89 c1             	mov    rcx,rax
    4f07:	c4 c1 7b 59 3e       	vmulsd xmm7,xmm0,QWORD PTR [r14]
    4f0c:	48 c1 e9 1e          	shr    rcx,0x1e
    4f10:	c4 41 73 59 c4       	vmulsd xmm8,xmm1,xmm12
    4f15:	48 89 ca             	mov    rdx,rcx
    4f18:	48 31 c2             	xor    rdx,rax
    4f1b:	49 0f af d1          	imul   rdx,r9
    4f1f:	48 89 d0             	mov    rax,rdx
    4f22:	48 c1 e8 1b          	shr    rax,0x1b
    4f26:	48 31 d0             	xor    rax,rdx
    4f29:	48 0f af c6          	imul   rax,rsi
    4f2d:	48 89 c2             	mov    rdx,rax
    4f30:	48 c1 ea 1f          	shr    rdx,0x1f
    4f34:	48 31 c2             	xor    rdx,rax
    4f37:	48 c1 ea 0b          	shr    rdx,0xb
    4f3b:	45 85 d2             	test   r10d,r10d
    4f3e:	c4 e1 e3 2a da       	vcvtsi2sd xmm3,xmm3,rdx
    4f43:	c4 e2 d1 99 de       	vfmadd132sd xmm3,xmm5,xmm6
    4f48:	c4 c1 63 59 dc       	vmulsd xmm3,xmm3,xmm12
    4f4d:	0f 8e 7a 01 00 00    	jle    50cd <try_secant_tail._omp_fn.0+0x5fd>
    4f53:	c4 41 7b 59 c8       	vmulsd xmm9,xmm0,xmm8
    4f58:	41 83 fa 01          	cmp    r10d,0x1
    4f5c:	c5 7b 59 d3          	vmulsd xmm10,xmm0,xmm3
    4f60:	0f 84 87 02 00 00    	je     51ed <try_secant_tail._omp_fn.0+0x71d>
    4f66:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    4f6b:	48 8b b4 24 a0 00 00 	mov    rsi,QWORD PTR [rsp+0xa0]
    4f72:	00 
    4f73:	48 83 e8 08          	sub    rax,0x8
    4f77:	48 29 f0             	sub    rax,rsi
    4f7a:	48 83 f8 10          	cmp    rax,0x10
    4f7e:	0f 97 c0             	seta   al
    4f81:	84 44 24 3f          	test   BYTE PTR [rsp+0x3f],al
    4f85:	0f 84 62 02 00 00    	je     51ed <try_secant_tail._omp_fn.0+0x71d>
    4f8b:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    4f90:	48 83 e8 08          	sub    rax,0x8
    4f94:	48 29 f0             	sub    rax,rsi
    4f97:	48 83 f8 10          	cmp    rax,0x10
    4f9b:	0f 86 4c 02 00 00    	jbe    51ed <try_secant_tail._omp_fn.0+0x71d>
    4fa1:	83 bc 24 9c 00 00 00 	cmp    DWORD PTR [rsp+0x9c],0x2
    4fa8:	02 
    4fa9:	0f 86 87 02 00 00    	jbe    5236 <try_secant_tail._omp_fn.0+0x766>
    4faf:	44 89 d2             	mov    edx,r10d
    4fb2:	c4 c2 7d 19 f1       	vbroadcastsd ymm6,xmm9
    4fb7:	c4 c2 7d 19 ea       	vbroadcastsd ymm5,xmm10
    4fbc:	31 c0                	xor    eax,eax
    4fbe:	c1 ea 02             	shr    edx,0x2
    4fc1:	4c 8b 8c 24 b8 00 00 	mov    r9,QWORD PTR [rsp+0xb8]
    4fc8:	00 
    4fc9:	48 c1 e2 05          	shl    rdx,0x5
    4fcd:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    4fd4:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    4fdb:	00 00 00 00 
    4fdf:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    4fe6:	00 00 00 00 
    4fea:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    4ff1:	00 00 00 00 
    4ff5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    4ffc:	00 00 00 00 
    5000:	c5 fd 10 0c 07       	vmovupd ymm1,YMMWORD PTR [rdi+rax*1]
    5005:	c5 7d 28 d9          	vmovapd ymm11,ymm1
    5009:	c4 42 cd a8 1c 03    	vfmadd213pd ymm11,ymm6,YMMWORD PTR [r11+rax*1]
    500f:	c4 41 7d 11 1c 03    	vmovupd YMMWORD PTR [r11+rax*1],ymm11
    5015:	c4 e2 d5 a8 0c 03    	vfmadd213pd ymm1,ymm5,YMMWORD PTR [rbx+rax*1]
    501b:	c5 fd 11 0c 03       	vmovupd YMMWORD PTR [rbx+rax*1],ymm1
    5020:	48 83 c0 20          	add    rax,0x20
    5024:	48 39 c2             	cmp    rdx,rax
    5027:	75 d7                	jne    5000 <try_secant_tail._omp_fn.0+0x530>
    5029:	44 89 d0             	mov    eax,r10d
    502c:	4c 89 8c 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],r9
    5033:	00 
    5034:	83 e0 fc             	and    eax,0xfffffffc
    5037:	44 39 d0             	cmp    eax,r10d
    503a:	89 c2                	mov    edx,eax
    503c:	0f 84 8b 00 00 00    	je     50cd <try_secant_tail._omp_fn.0+0x5fd>
    5042:	44 89 d1             	mov    ecx,r10d
    5045:	29 c1                	sub    ecx,eax
    5047:	83 f9 01             	cmp    ecx,0x1
    504a:	74 55                	je     50a1 <try_secant_tail._omp_fn.0+0x5d1>
    504c:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    5051:	4c 8b 4c 24 60       	mov    r9,QWORD PTR [rsp+0x60]
    5056:	c4 c1 7b 12 e9       	vmovddup xmm5,xmm9
    505b:	c4 c1 7b 12 ca       	vmovddup xmm1,xmm10
    5060:	48 01 d6             	add    rsi,rdx
    5063:	4d 8d 3c f1          	lea    r15,[r9+rsi*8]
    5067:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    506c:	48 01 d6             	add    rsi,rdx
    506f:	4c 01 ea             	add    rdx,r13
    5072:	f6 c1 01             	test   cl,0x1
    5075:	49 8d 34 f1          	lea    rsi,[r9+rsi*8]
    5079:	4c 8b 8c 24 b0 00 00 	mov    r9,QWORD PTR [rsp+0xb0]
    5080:	00 
    5081:	c4 c1 79 10 34 d1    	vmovupd xmm6,XMMWORD PTR [r9+rdx*8]
    5087:	c4 c2 c9 a8 2f       	vfmadd213pd xmm5,xmm6,XMMWORD PTR [r15]
    508c:	c4 c1 79 11 2f       	vmovupd XMMWORD PTR [r15],xmm5
    5091:	c4 e2 c9 a8 0e       	vfmadd213pd xmm1,xmm6,XMMWORD PTR [rsi]
    5096:	c5 f9 11 0e          	vmovupd XMMWORD PTR [rsi],xmm1
    509a:	74 31                	je     50cd <try_secant_tail._omp_fn.0+0x5fd>
    509c:	83 e1 fe             	and    ecx,0xfffffffe
    509f:	01 c8                	add    eax,ecx
    50a1:	48 98                	cdqe
    50a3:	48 8d 14 c5 00 00 00 	lea    rdx,[rax*8+0x0]
    50aa:	00 
    50ab:	c5 fb 10 0c c7       	vmovsd xmm1,QWORD PTR [rdi+rax*8]
    50b0:	c4 42 f1 a9 0c 13    	vfmadd213sd xmm9,xmm1,QWORD PTR [r11+rdx*1]
    50b6:	c4 41 7b 11 0c 13    	vmovsd QWORD PTR [r11+rdx*1],xmm9
    50bc:	48 03 54 24 28       	add    rdx,QWORD PTR [rsp+0x28]
    50c1:	c4 c2 a9 a9 0c 13    	vfmadd213sd xmm1,xmm10,QWORD PTR [r11+rdx*1]
    50c7:	c4 c1 7b 11 0c 13    	vmovsd QWORD PTR [r11+rdx*1],xmm1
    50cd:	c5 e9 15 ca          	vunpckhpd xmm1,xmm2,xmm2
    50d1:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    50d6:	c5 f1 5f ca          	vmaxpd xmm1,xmm1,xmm2
    50da:	c4 62 c1 a9 00       	vfmadd213sd xmm8,xmm7,QWORD PTR [rax]
    50df:	c4 e2 c1 a9 58 08    	vfmadd213sd xmm3,xmm7,QWORD PTR [rax+0x8]
    50e5:	c5 f3 59 c8          	vmulsd xmm1,xmm1,xmm0
    50e9:	c5 f9 2f 0d 00 00 00 	vcomisd xmm1,QWORD PTR [rip+0x0]        # 50f1 <try_secant_tail._omp_fn.0+0x621>
    50f0:	00 
    50f1:	c5 7b 11 00          	vmovsd QWORD PTR [rax],xmm8
    50f5:	c5 fb 11 58 08       	vmovsd QWORD PTR [rax+0x8],xmm3
    50fa:	77 2f                	ja     512b <try_secant_tail._omp_fn.0+0x65b>
    50fc:	c4 c1 7b 10 0e       	vmovsd xmm1,QWORD PTR [r14]
    5101:	c5 c1 54 15 00 00 00 	vandpd xmm2,xmm7,XMMWORD PTR [rip+0x0]        # 5109 <try_secant_tail._omp_fn.0+0x639>
    5108:	00 
    5109:	c5 eb 58 54 24 10    	vaddsd xmm2,xmm2,QWORD PTR [rsp+0x10]
    510f:	c5 eb 59 54 24 68    	vmulsd xmm2,xmm2,QWORD PTR [rsp+0x68]
    5115:	c5 f3 5c cc          	vsubsd xmm1,xmm1,xmm4
    5119:	c5 f3 59 c8          	vmulsd xmm1,xmm1,xmm0
    511d:	c5 f1 54 0d 00 00 00 	vandpd xmm1,xmm1,XMMWORD PTR [rip+0x0]        # 5125 <try_secant_tail._omp_fn.0+0x655>
    5124:	00 
    5125:	c5 f9 2f ca          	vcomisd xmm1,xmm2
    5129:	76 05                	jbe    5130 <try_secant_tail._omp_fn.0+0x660>
    512b:	41 c6 04 24 01       	mov    BYTE PTR [r12],0x1
    5130:	49 83 c4 01          	add    r12,0x1
    5134:	49 83 c6 08          	add    r14,0x8
    5138:	4c 03 ac 24 a8 00 00 	add    r13,QWORD PTR [rsp+0xa8]
    513f:	00 
    5140:	4c 39 64 24 78       	cmp    QWORD PTR [rsp+0x78],r12
    5145:	0f 85 45 fb ff ff    	jne    4c90 <try_secant_tail._omp_fn.0+0x1c0>
    514b:	c5 f8 77             	vzeroupper
    514e:	48 8d 65 d8          	lea    rsp,[rbp-0x28]
    5152:	5b                   	pop    rbx
    5153:	41 5c                	pop    r12
    5155:	41 5d                	pop    r13
    5157:	41 5e                	pop    r14
    5159:	41 5f                	pop    r15
    515b:	5d                   	pop    rbp
    515c:	e9 00 00 00 00       	jmp    5161 <try_secant_tail._omp_fn.0+0x691>
    5161:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    5168:	c5 f9 29 94 24 80 00 	vmovapd XMMWORD PTR [rsp+0x80],xmm2
    516f:	00 00 
    5171:	44 89 d6             	mov    esi,r10d
    5174:	c5 fb 11 a4 24 90 00 	vmovsd QWORD PTR [rsp+0x90],xmm4
    517b:	00 00 
    517d:	c5 f8 77             	vzeroupper
    5180:	e8 bb b0 ff ff       	call   240 <norm2>
    5185:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
    5189:	c5 fb 10 a4 24 90 00 	vmovsd xmm4,QWORD PTR [rsp+0x90]
    5190:	00 00 
    5192:	c5 f9 28 94 24 80 00 	vmovapd xmm2,XMMWORD PTR [rsp+0x80]
    5199:	00 00 
    519b:	c5 f9 2f c1          	vcomisd xmm0,xmm1
    519f:	0f 85 bd fc ff ff    	jne    4e62 <try_secant_tail._omp_fn.0+0x392>
    51a5:	c4 c1 7b 10 06       	vmovsd xmm0,QWORD PTR [r14]
    51aa:	c5 f9 54 05 00 00 00 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x0]        # 51b2 <try_secant_tail._omp_fn.0+0x6e2>
    51b1:	00 
    51b2:	c5 f9 2f 44 24 68    	vcomisd xmm0,QWORD PTR [rsp+0x68]
    51b8:	0f 86 72 ff ff ff    	jbe    5130 <try_secant_tail._omp_fn.0+0x660>
    51be:	41 c6 04 24 01       	mov    BYTE PTR [r12],0x1
    51c3:	e9 68 ff ff ff       	jmp    5130 <try_secant_tail._omp_fn.0+0x660>
    51c8:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    51cc:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
    51d0:	31 c9                	xor    ecx,ecx
    51d2:	31 d2                	xor    edx,edx
    51d4:	c5 f9 28 ea          	vmovapd xmm5,xmm2
    51d8:	c5 f9 28 da          	vmovapd xmm3,xmm2
    51dc:	c5 f9 28 ca          	vmovapd xmm1,xmm2
    51e0:	c5 f9 28 f2          	vmovapd xmm6,xmm2
    51e4:	c5 f9 28 c4          	vmovapd xmm0,xmm4
    51e8:	e9 9d fb ff ff       	jmp    4d8a <try_secant_tail._omp_fn.0+0x2ba>
    51ed:	48 8b 4c 24 28       	mov    rcx,QWORD PTR [rsp+0x28]
    51f2:	4c 8b 8c 24 b8 00 00 	mov    r9,QWORD PTR [rsp+0xb8]
    51f9:	00 
    51fa:	31 c0                	xor    eax,eax
    51fc:	49 8d 14 0b          	lea    rdx,[r11+rcx*1]
    5200:	c5 fb 10 0c 07       	vmovsd xmm1,QWORD PTR [rdi+rax*1]
    5205:	c5 79 29 cd          	vmovapd xmm5,xmm9
    5209:	c4 c2 f1 a9 2c 03    	vfmadd213sd xmm5,xmm1,QWORD PTR [r11+rax*1]
    520f:	c4 c1 7b 11 2c 03    	vmovsd QWORD PTR [r11+rax*1],xmm5
    5215:	c4 e2 a9 a9 0c 02    	vfmadd213sd xmm1,xmm10,QWORD PTR [rdx+rax*1]
    521b:	c5 fb 11 0c 02       	vmovsd QWORD PTR [rdx+rax*1],xmm1
    5220:	48 83 c0 08          	add    rax,0x8
    5224:	48 39 c1             	cmp    rcx,rax
    5227:	75 d7                	jne    5200 <try_secant_tail._omp_fn.0+0x730>
    5229:	4c 89 8c 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],r9
    5230:	00 
    5231:	e9 97 fe ff ff       	jmp    50cd <try_secant_tail._omp_fn.0+0x5fd>
    5236:	44 89 d1             	mov    ecx,r10d
    5239:	31 c0                	xor    eax,eax
    523b:	31 d2                	xor    edx,edx
    523d:	e9 0a fe ff ff       	jmp    504c <try_secant_tail._omp_fn.0+0x57c>
