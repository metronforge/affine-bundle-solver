/tmp/abs-stage2b-measured-normal/tail.o:     file format elf64-x86-64


Disassembly of section .text:

000000000000fee0 <try_secant_tail.constprop.0>:
    fee0:	4c 8d 54 24 08       	lea    r10,[rsp+0x8]
    fee5:	48 83 e4 e0          	and    rsp,0xffffffffffffffe0
    fee9:	41 ff 72 f8          	push   QWORD PTR [r10-0x8]
    feed:	55                   	push   rbp
    feee:	48 89 e5             	mov    rbp,rsp
    fef1:	41 57                	push   r15
    fef3:	41 56                	push   r14
    fef5:	45 89 c6             	mov    r14d,r8d
    fef8:	41 55                	push   r13
    fefa:	41 54                	push   r12
    fefc:	41 52                	push   r10
    fefe:	53                   	push   rbx
    feff:	48 81 ec 80 02 00 00 	sub    rsp,0x280
    ff06:	49 8b 42 10          	mov    rax,QWORD PTR [r10+0x10]
    ff0a:	48 89 bd b8 fe ff ff 	mov    QWORD PTR [rbp-0x148],rdi
    ff11:	48 89 b5 98 fe ff ff 	mov    QWORD PTR [rbp-0x168],rsi
    ff18:	49 8b 1a             	mov    rbx,QWORD PTR [r10]
    ff1b:	48 89 95 c8 fd ff ff 	mov    QWORD PTR [rbp-0x238],rdx
    ff22:	4d 8b 6a 08          	mov    r13,QWORD PTR [r10+0x8]
    ff26:	89 8d cc fe ff ff    	mov    DWORD PTR [rbp-0x134],ecx
    ff2c:	48 89 de             	mov    rsi,rbx
    ff2f:	44 89 85 48 fe ff ff 	mov    DWORD PTR [rbp-0x1b8],r8d
    ff36:	44 89 8d f8 fe ff ff 	mov    DWORD PTR [rbp-0x108],r9d
    ff3d:	48 89 85 d0 fd ff ff 	mov    QWORD PTR [rbp-0x230],rax
    ff44:	64 48 8b 04 25 28 00 	mov    rax,QWORD PTR fs:0x28
    ff4b:	00 00 
    ff4d:	48 89 45 c8          	mov    QWORD PTR [rbp-0x38],rax
    ff51:	48 8d 85 00 ff ff ff 	lea    rax,[rbp-0x100]
    ff58:	48 89 c7             	mov    rdi,rax
    ff5b:	48 89 85 18 fe ff ff 	mov    QWORD PTR [rbp-0x1e8],rax
    ff62:	e8 c9 b8 ff ff       	call   b830 <bs_copy>
    ff67:	85 c0                	test   eax,eax
    ff69:	89 85 c4 fd ff ff    	mov    DWORD PTR [rbp-0x23c],eax
    ff6f:	74 34                	je     ffa5 <try_secant_tail.constprop.0+0xc5>
    ff71:	41 bc ff ff ff ff    	mov    r12d,0xffffffff
    ff77:	48 8b 45 c8          	mov    rax,QWORD PTR [rbp-0x38]
    ff7b:	64 48 2b 04 25 28 00 	sub    rax,QWORD PTR fs:0x28
    ff82:	00 00 
    ff84:	0f 85 a0 2d 00 00    	jne    12d2a <try_secant_tail.constprop.0+0x2e4a>
    ff8a:	48 81 c4 80 02 00 00 	add    rsp,0x280
    ff91:	44 89 e0             	mov    eax,r12d
    ff94:	5b                   	pop    rbx
    ff95:	41 5a                	pop    r10
    ff97:	41 5c                	pop    r12
    ff99:	41 5d                	pop    r13
    ff9b:	41 5e                	pop    r14
    ff9d:	41 5f                	pop    r15
    ff9f:	5d                   	pop    rbp
    ffa0:	49 8d 62 f8          	lea    rsp,[r10-0x8]
    ffa4:	c3                   	ret
    ffa5:	4d 63 fe             	movsxd r15,r14d
    ffa8:	4c 89 ff             	mov    rdi,r15
    ffab:	4c 89 bd f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],r15
    ffb2:	48 c1 e7 04          	shl    rdi,0x4
    ffb6:	e8 00 00 00 00       	call   ffbb <try_secant_tail.constprop.0+0xdb>
    ffbb:	be 08 00 00 00       	mov    esi,0x8
    ffc0:	49 89 c6             	mov    r14,rax
    ffc3:	4b 8d 04 3f          	lea    rax,[r15+r15*1]
    ffc7:	48 89 c7             	mov    rdi,rax
    ffca:	48 89 85 88 fd ff ff 	mov    QWORD PTR [rbp-0x278],rax
    ffd1:	e8 00 00 00 00       	call   ffd6 <try_secant_tail.constprop.0+0xf6>
    ffd6:	4d 85 f6             	test   r14,r14
    ffd9:	49 89 c2             	mov    r10,rax
    ffdc:	0f 84 59 2d 00 00    	je     12d3b <try_secant_tail.constprop.0+0x2e5b>
    ffe2:	48 85 c0             	test   rax,rax
    ffe5:	0f 84 50 2d 00 00    	je     12d3b <try_secant_tail.constprop.0+0x2e5b>
    ffeb:	48 89 85 d0 fe ff ff 	mov    QWORD PTR [rbp-0x130],rax
    fff2:	4c 8b a5 18 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1e8]
    fff9:	4c 89 f7             	mov    rdi,r14
    fffc:	48 b8 d0 31 9f 29 22 	movabs rax,0xa4093822299f31d0
   10003:	38 09 a4 
   10006:	4c 31 e8             	xor    rax,r13
   10009:	48 c7 45 b0 00 00 00 	mov    QWORD PTR [rbp-0x50],0x0
   10010:	00 
   10011:	48 ba 15 7c 4a 7f b9 	movabs rdx,0x9e3779b97f4a7c15
   10018:	79 37 9e 
   1001b:	48 01 d0             	add    rax,rdx
   1001e:	4c 89 e6             	mov    rsi,r12
   10021:	48 c7 45 b8 00 00 00 	mov    QWORD PTR [rbp-0x48],0x0
   10028:	00 
   10029:	48 89 c2             	mov    rdx,rax
   1002c:	48 c1 ea 1e          	shr    rdx,0x1e
   10030:	48 31 c2             	xor    rdx,rax
   10033:	48 b8 b9 e5 e4 1c 6d 	movabs rax,0xbf58476d1ce4e5b9
   1003a:	47 58 bf 
   1003d:	48 0f af d0          	imul   rdx,rax
   10041:	48 89 d0             	mov    rax,rdx
   10044:	48 c1 e8 1b          	shr    rax,0x1b
   10048:	48 31 d0             	xor    rax,rdx
   1004b:	48 ba eb 11 31 13 bb 	movabs rdx,0x94d049bb133111eb
   10052:	49 d0 94 
   10055:	48 0f af c2          	imul   rax,rdx
   10059:	48 89 c2             	mov    rdx,rax
   1005c:	48 c1 ea 1f          	shr    rdx,0x1f
   10060:	48 31 c2             	xor    rdx,rax
   10063:	49 89 d7             	mov    r15,rdx
   10066:	48 89 95 68 fd ff ff 	mov    QWORD PTR [rbp-0x298],rdx
   1006d:	48 ba 03 ed 92 d1 32 	movabs rdx,0xd1b54a32d192ed03
   10074:	4a b5 d1 
   10077:	4c 01 fa             	add    rdx,r15
   1007a:	e8 21 3a ff ff       	call   3aa0 <secant_refresh>
   1007f:	48 8b 85 f0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x110]
   10086:	4c 89 e6             	mov    rsi,r12
   10089:	48 ba 06 da 25 a3 65 	movabs rdx,0xa36a9465a325da06
   10090:	94 6a a3 
   10093:	4c 01 fa             	add    rdx,r15
   10096:	48 c1 e0 03          	shl    rax,0x3
   1009a:	49 8d 3c 06          	lea    rdi,[r14+rax*1]
   1009e:	48 89 85 f0 fd ff ff 	mov    QWORD PTR [rbp-0x210],rax
   100a5:	48 89 bd a8 fe ff ff 	mov    QWORD PTR [rbp-0x158],rdi
   100ac:	e8 ef 39 ff ff       	call   3aa0 <secant_refresh>
   100b1:	e8 00 00 00 00       	call   100b6 <try_secant_tail.constprop.0+0x1d6>
   100b6:	44 8b 63 04          	mov    r12d,DWORD PTR [rbx+0x4]
   100ba:	4c 8b 95 d0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x130]
   100c1:	89 85 4c fe ff ff    	mov    DWORD PTR [rbp-0x1b4],eax
   100c7:	8b 85 cc fe ff ff    	mov    eax,DWORD PTR [rbp-0x134]
   100cd:	2b 85 f8 fe ff ff    	sub    eax,DWORD PTR [rbp-0x108]
   100d3:	85 c0                	test   eax,eax
   100d5:	0f 8e 22 22 00 00    	jle    122fd <try_secant_tail.constprop.0+0x241d>
   100db:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
   100df:	c5 d3 2a c0          	vcvtsi2sd xmm0,xmm5,eax
   100e3:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
   100e7:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # 100ef <try_secant_tail.constprop.0+0x20f>
   100ee:	00 
   100ef:	c5 fb 11 ad b0 fe ff 	vmovsd QWORD PTR [rbp-0x150],xmm5
   100f6:	ff 
   100f7:	c5 d3 5e f0          	vdivsd xmm6,xmm5,xmm0
   100fb:	c5 fb 11 b5 80 fe ff 	vmovsd QWORD PTR [rbp-0x180],xmm6
   10102:	ff 
   10103:	8b b5 48 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b8]
   10109:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   10110:	4c 89 95 d0 fe ff ff 	mov    QWORD PTR [rbp-0x130],r10
   10117:	e8 24 01 ff ff       	call   240 <norm2>
   1011c:	be 01 00 00 00       	mov    esi,0x1
   10121:	bf 00 08 00 00       	mov    edi,0x800
   10126:	c5 fb 11 85 90 fe ff 	vmovsd QWORD PTR [rbp-0x170],xmm0
   1012d:	ff 
   1012e:	e8 00 00 00 00       	call   10133 <try_secant_tail.constprop.0+0x253>
   10133:	48 63 9d 4c fe ff ff 	movsxd rbx,DWORD PTR [rbp-0x1b4]
   1013a:	be 08 00 00 00       	mov    esi,0x8
   1013f:	4c 8b bd f0 fe ff ff 	mov    r15,QWORD PTR [rbp-0x110]
   10146:	48 89 85 58 fe ff ff 	mov    QWORD PTR [rbp-0x1a8],rax
   1014d:	4c 0f af fb          	imul   r15,rbx
   10151:	4b 8d 3c 3f          	lea    rdi,[r15+r15*1]
   10155:	e8 00 00 00 00       	call   1015a <try_secant_tail.constprop.0+0x27a>
   1015a:	48 8d 3c 1b          	lea    rdi,[rbx+rbx*1]
   1015e:	be 08 00 00 00       	mov    esi,0x8
   10163:	48 89 85 10 fe ff ff 	mov    QWORD PTR [rbp-0x1f0],rax
   1016a:	e8 00 00 00 00       	call   1016f <try_secant_tail.constprop.0+0x28f>
   1016f:	48 8b bd 58 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1a8]
   10176:	48 8b 95 10 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1f0]
   1017d:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   10184:	49 89 c3             	mov    r11,rax
   10187:	4c 8b 95 d0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x130]
   1018e:	48 85 ff             	test   rdi,rdi
   10191:	0f 94 c0             	sete   al
   10194:	48 85 d2             	test   rdx,rdx
   10197:	0f 94 c1             	sete   cl
   1019a:	08 c8                	or     al,cl
   1019c:	0f 85 c5 2b 00 00    	jne    12d67 <try_secant_tail.constprop.0+0x2e87>
   101a2:	4d 85 db             	test   r11,r11
   101a5:	0f 84 bc 2b 00 00    	je     12d67 <try_secant_tail.constprop.0+0x2e87>
   101ab:	c5 fa 7e ad b8 fe ff 	vmovq  xmm5,QWORD PTR [rbp-0x148]
   101b2:	ff 
   101b3:	44 8b 9d 0c ff ff ff 	mov    r11d,DWORD PTR [rbp-0xf4]
   101ba:	c4 e3 d1 22 b5 98 fe 	vpinsrq xmm6,xmm5,QWORD PTR [rbp-0x168],0x1
   101c1:	ff ff 01 
   101c4:	8b 8d 04 ff ff ff    	mov    ecx,DWORD PTR [rbp-0xfc]
   101ca:	44 8b 85 f8 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x108]
   101d1:	44 39 85 cc fe ff ff 	cmp    DWORD PTR [rbp-0x134],r8d
   101d8:	44 89 9d c0 fe ff ff 	mov    DWORD PTR [rbp-0x140],r11d
   101df:	89 8d d0 fe ff ff    	mov    DWORD PTR [rbp-0x130],ecx
   101e5:	c5 f9 7f b5 b0 fd ff 	vmovdqa XMMWORD PTR [rbp-0x250],xmm6
   101ec:	ff 
   101ed:	0f 8e 6a 04 00 00    	jle    1065d <try_secant_tail.constprop.0+0x77d>
   101f3:	48 b8 89 6c 4e ec 98 	movabs rax,0x82efa98ec4e6c89
   101fa:	fa 2e 08 
   101fd:	8b b5 48 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b8]
   10203:	c5 fb 12 bd 80 fe ff 	vmovddup xmm7,QWORD PTR [rbp-0x180]
   1020a:	ff 
   1020b:	c7 85 e0 fd ff ff 00 	mov    DWORD PTR [rbp-0x220],0x0
   10212:	00 00 00 
   10215:	49 31 c5             	xor    r13,rax
   10218:	44 89 85 c8 fe ff ff 	mov    DWORD PTR [rbp-0x138],r8d
   1021f:	48 b8 15 7c 4a 7f b9 	movabs rax,0x9e3779b97f4a7c15
   10226:	79 37 9e 
   10229:	4c 01 e8             	add    rax,r13
   1022c:	c5 f9 29 bd 70 fd ff 	vmovapd XMMWORD PTR [rbp-0x290],xmm7
   10233:	ff 
   10234:	c4 e1 f9 6e ff       	vmovq  xmm7,rdi
   10239:	4c 8b ad a8 fe ff ff 	mov    r13,QWORD PTR [rbp-0x158]
   10240:	48 89 c1             	mov    rcx,rax
   10243:	c4 e3 c1 22 ea 01    	vpinsrq xmm5,xmm7,rdx,0x1
   10249:	ba 01 00 00 00       	mov    edx,0x1
   1024e:	c7 85 c0 fe ff ff 00 	mov    DWORD PTR [rbp-0x140],0x0
   10255:	00 00 00 
   10258:	48 c1 e9 1e          	shr    rcx,0x1e
   1025c:	4c 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r10
   10263:	48 31 c1             	xor    rcx,rax
   10266:	c5 f9 7f ad a0 fd ff 	vmovdqa XMMWORD PTR [rbp-0x260],xmm5
   1026d:	ff 
   1026e:	48 b8 b9 e5 e4 1c 6d 	movabs rax,0xbf58476d1ce4e5b9
   10275:	47 58 bf 
   10278:	48 0f af c8          	imul   rcx,rax
   1027c:	48 89 c8             	mov    rax,rcx
   1027f:	48 c1 e8 1b          	shr    rax,0x1b
   10283:	48 31 c8             	xor    rax,rcx
   10286:	48 b9 eb 11 31 13 bb 	movabs rcx,0x94d049bb133111eb
   1028d:	49 d0 94 
   10290:	48 0f af c1          	imul   rax,rcx
   10294:	48 89 c1             	mov    rcx,rax
   10297:	48 c1 e9 1f          	shr    rcx,0x1f
   1029b:	48 31 c1             	xor    rcx,rax
   1029e:	89 f0                	mov    eax,esi
   102a0:	c1 e8 1f             	shr    eax,0x1f
   102a3:	48 89 8d d8 fd ff ff 	mov    QWORD PTR [rbp-0x228],rcx
   102aa:	01 f0                	add    eax,esi
   102ac:	d1 f8                	sar    eax,1
   102ae:	41 39 c4             	cmp    r12d,eax
   102b1:	41 89 f4             	mov    r12d,esi
   102b4:	0f 9d c1             	setge  cl
   102b7:	83 bd 4c fe ff ff 01 	cmp    DWORD PTR [rbp-0x1b4],0x1
   102be:	0f 9f c0             	setg   al
   102c1:	48 c1 e3 04          	shl    rbx,0x4
   102c5:	21 c1                	and    ecx,eax
   102c7:	8d 04 36             	lea    eax,[rsi+rsi*1]
   102ca:	49 c1 e7 04          	shl    r15,0x4
   102ce:	48 89 9d 98 fd ff ff 	mov    QWORD PTR [rbp-0x268],rbx
   102d5:	85 c0                	test   eax,eax
   102d7:	88 8d a3 fe ff ff    	mov    BYTE PTR [rbp-0x15d],cl
   102dd:	8d 5e ff             	lea    ebx,[rsi-0x1]
   102e0:	0f 4f d0             	cmovg  edx,eax
   102e3:	8d 44 36 fc          	lea    eax,[rsi+rsi*1-0x4]
   102e7:	4c 89 bd 90 fd ff ff 	mov    QWORD PTR [rbp-0x270],r15
   102ee:	89 85 84 fd ff ff    	mov    DWORD PTR [rbp-0x27c],eax
   102f4:	48 89 f8             	mov    rax,rdi
   102f7:	48 f7 d8             	neg    rax
   102fa:	89 95 c0 fd ff ff    	mov    DWORD PTR [rbp-0x240],edx
   10300:	83 e0 1f             	and    eax,0x1f
   10303:	89 9d a4 fe ff ff    	mov    DWORD PTR [rbp-0x15c],ebx
   10309:	44 89 db             	mov    ebx,r11d
   1030c:	89 85 e4 fd ff ff    	mov    DWORD PTR [rbp-0x21c],eax
   10312:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   10318:	85 db                	test   ebx,ebx
   1031a:	0f 85 ed 23 00 00    	jne    1270d <try_secant_tail.constprop.0+0x282d>
   10320:	89 9d 88 fe ff ff    	mov    DWORD PTR [rbp-0x178],ebx
   10326:	48 8b 9d 50 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1b0]
   1032d:	4d 89 e9             	mov    r9,r13
   10330:	c5 fb 10 b5 80 fe ff 	vmovsd xmm6,QWORD PTR [rbp-0x180]
   10337:	ff 
   10338:	c5 c9 16 b5 90 fe ff 	vmovhpd xmm6,xmm6,QWORD PTR [rbp-0x170]
   1033f:	ff 
   10340:	c5 f9 29 b5 60 fe ff 	vmovapd XMMWORD PTR [rbp-0x1a0],xmm6
   10347:	ff 
   10348:	44 3b a5 d0 fe ff ff 	cmp    r12d,DWORD PTR [rbp-0x130]
   1034f:	0f 8e 3f 06 00 00    	jle    10994 <try_secant_tail.constprop.0+0xab4>
   10355:	83 bd c0 fe ff ff 1f 	cmp    DWORD PTR [rbp-0x140],0x1f
   1035c:	0f 9f c0             	setg   al
   1035f:	84 85 a3 fe ff ff    	test   BYTE PTR [rbp-0x15d],al
   10365:	74 2c                	je     10393 <try_secant_tail.constprop.0+0x4b3>
   10367:	8b b5 f8 fe ff ff    	mov    esi,DWORD PTR [rbp-0x108]
   1036d:	3b b5 c8 fe ff ff    	cmp    esi,DWORD PTR [rbp-0x138]
   10373:	7c 1e                	jl     10393 <try_secant_tail.constprop.0+0x4b3>
   10375:	8b 85 cc fe ff ff    	mov    eax,DWORD PTR [rbp-0x134]
   1037b:	29 f0                	sub    eax,esi
   1037d:	48 98                	cdqe
   1037f:	48 0f af 85 f0 fe ff 	imul   rax,QWORD PTR [rbp-0x110]
   10386:	ff 
   10387:	48 3d 3f 42 0f 00    	cmp    rax,0xf423f
   1038d:	0f 8f 8d 0c 00 00    	jg     11020 <try_secant_tail.constprop.0+0x1140>
   10393:	4c 63 85 f8 fe ff ff 	movsxd r8,DWORD PTR [rbp-0x108]
   1039a:	4c 8b 95 f0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x110]
   103a1:	48 8b 85 b8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x148]
   103a8:	4d 0f af d0          	imul   r10,r8
   103ac:	45 85 e4             	test   r12d,r12d
   103af:	4a 8d 3c d0          	lea    rdi,[rax+r10*8]
   103b3:	0f 8e 30 05 00 00    	jle    108e9 <try_secant_tail.constprop.0+0xa09>
   103b9:	83 bd a4 fe ff ff 02 	cmp    DWORD PTR [rbp-0x15c],0x2
   103c0:	48 8b 85 18 ff ff ff 	mov    rax,QWORD PTR [rbp-0xe8]
   103c7:	0f 86 1f 17 00 00    	jbe    11aec <try_secant_tail.constprop.0+0x1c0c>
   103cd:	44 89 e1             	mov    ecx,r12d
   103d0:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
   103d4:	31 d2                	xor    edx,edx
   103d6:	c5 fd 28 dc          	vmovapd ymm3,ymm4
   103da:	c1 e9 02             	shr    ecx,0x2
   103dd:	c5 fd 28 cc          	vmovapd ymm1,ymm4
   103e1:	c5 fd 28 d4          	vmovapd ymm2,ymm4
   103e5:	48 c1 e1 05          	shl    rcx,0x5
   103e9:	90                   	nop
   103ea:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   103f1:	00 00 00 00 
   103f5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   103fc:	00 00 00 00 
   10400:	c5 fd 10 04 17       	vmovupd ymm0,YMMWORD PTR [rdi+rdx*1]
   10405:	c4 e2 fd b8 1c 10    	vfmadd231pd ymm3,ymm0,YMMWORD PTR [rax+rdx*1]
   1040b:	c4 c2 fd b8 0c 16    	vfmadd231pd ymm1,ymm0,YMMWORD PTR [r14+rdx*1]
   10411:	c4 c2 fd b8 14 11    	vfmadd231pd ymm2,ymm0,YMMWORD PTR [r9+rdx*1]
   10417:	48 83 c2 20          	add    rdx,0x20
   1041b:	48 39 d1             	cmp    rcx,rdx
   1041e:	c4 e2 fd b8 e0       	vfmadd231pd ymm4,ymm0,ymm0
   10423:	75 db                	jne    10400 <try_secant_tail.constprop.0+0x520>
   10425:	c4 e3 7d 19 d6 01    	vextractf128 xmm6,ymm2,0x1
   1042b:	c4 e3 7d 19 e0 01    	vextractf128 xmm0,ymm4,0x1
   10431:	c4 e3 7d 19 dd 01    	vextractf128 xmm5,ymm3,0x1
   10437:	44 89 e2             	mov    edx,r12d
   1043a:	c5 c9 58 f2          	vaddpd xmm6,xmm6,xmm2
   1043e:	c4 e3 7d 19 ca 01    	vextractf128 xmm2,ymm1,0x1
   10444:	c5 f9 58 e4          	vaddpd xmm4,xmm0,xmm4
   10448:	83 e2 fc             	and    edx,0xfffffffc
   1044b:	c5 e9 58 d1          	vaddpd xmm2,xmm2,xmm1
   1044f:	c5 d1 58 db          	vaddpd xmm3,xmm5,xmm3
   10453:	41 39 d4             	cmp    r12d,edx
   10456:	89 d1                	mov    ecx,edx
   10458:	c5 49 15 c6          	vunpckhpd xmm8,xmm6,xmm6
   1045c:	c5 d9 15 c4          	vunpckhpd xmm0,xmm4,xmm4
   10460:	c5 e9 15 fa          	vunpckhpd xmm7,xmm2,xmm2
   10464:	c5 39 58 c6          	vaddpd xmm8,xmm8,xmm6
   10468:	c5 e1 15 eb          	vunpckhpd xmm5,xmm3,xmm3
   1046c:	c5 c1 58 fa          	vaddpd xmm7,xmm7,xmm2
   10470:	c5 f9 58 c4          	vaddpd xmm0,xmm0,xmm4
   10474:	c5 d1 58 eb          	vaddpd xmm5,xmm5,xmm3
   10478:	c5 b9 14 ff          	vunpcklpd xmm7,xmm8,xmm7
   1047c:	0f 84 a1 00 00 00    	je     10523 <try_secant_tail.constprop.0+0x643>
   10482:	44 89 e6             	mov    esi,r12d
   10485:	29 ce                	sub    esi,ecx
   10487:	83 fe 01             	cmp    esi,0x1
   1048a:	74 69                	je     104f5 <try_secant_tail.constprop.0+0x615>
   1048c:	4c 8b bd b8 fe ff ff 	mov    r15,QWORD PTR [rbp-0x148]
   10493:	4d 8d 2c 0a          	lea    r13,[r10+rcx*1]
   10497:	4c 8b 9d f0 fe ff ff 	mov    r11,QWORD PTR [rbp-0x110]
   1049e:	c4 81 79 10 04 ef    	vmovupd xmm0,XMMWORD PTR [r15+r13*8]
   104a4:	c4 e2 f9 b8 1c c8    	vfmadd231pd xmm3,xmm0,XMMWORD PTR [rax+rcx*8]
   104aa:	49 01 cb             	add    r11,rcx
   104ad:	40 f6 c6 01          	test   sil,0x1
   104b1:	c4 c2 f9 b8 14 ce    	vfmadd231pd xmm2,xmm0,XMMWORD PTR [r14+rcx*8]
   104b7:	c4 e2 f9 b8 e0       	vfmadd231pd xmm4,xmm0,xmm0
   104bc:	c5 f9 28 cb          	vmovapd xmm1,xmm3
   104c0:	c5 f9 28 d8          	vmovapd xmm3,xmm0
   104c4:	c4 82 c9 98 1c de    	vfmadd132pd xmm3,xmm6,XMMWORD PTR [r14+r11*8]
   104ca:	c5 f1 15 e9          	vunpckhpd xmm5,xmm1,xmm1
   104ce:	c5 d1 58 e9          	vaddpd xmm5,xmm5,xmm1
   104d2:	c5 d9 15 c4          	vunpckhpd xmm0,xmm4,xmm4
   104d6:	c5 f9 58 c4          	vaddpd xmm0,xmm0,xmm4
   104da:	c5 e1 15 cb          	vunpckhpd xmm1,xmm3,xmm3
   104de:	c5 f1 58 cb          	vaddpd xmm1,xmm1,xmm3
   104e2:	c5 e9 15 da          	vunpckhpd xmm3,xmm2,xmm2
   104e6:	c5 e1 58 d2          	vaddpd xmm2,xmm3,xmm2
   104ea:	c5 f1 14 fa          	vunpcklpd xmm7,xmm1,xmm2
   104ee:	74 33                	je     10523 <try_secant_tail.constprop.0+0x643>
   104f0:	83 e6 fe             	and    esi,0xfffffffe
   104f3:	01 f2                	add    edx,esi
   104f5:	48 63 ca             	movsxd rcx,edx
   104f8:	44 01 e2             	add    edx,r12d
   104fb:	c5 fb 10 14 cf       	vmovsd xmm2,QWORD PTR [rdi+rcx*8]
   10500:	48 63 d2             	movsxd rdx,edx
   10503:	c4 e2 e9 b9 2c c8    	vfmadd231sd xmm5,xmm2,QWORD PTR [rax+rcx*8]
   10509:	c5 fb 12 da          	vmovddup xmm3,xmm2
   1050d:	c4 e2 e9 b9 c2       	vfmadd231sd xmm0,xmm2,xmm2
   10512:	c4 c1 7b 10 14 d6    	vmovsd xmm2,QWORD PTR [r14+rdx*8]
   10518:	c4 c1 69 16 14 ce    	vmovhpd xmm2,xmm2,QWORD PTR [r14+rcx*8]
   1051e:	c4 e2 e1 b8 fa       	vfmadd231pd xmm7,xmm3,xmm2
   10523:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
   10527:	c5 f9 2f c2          	vcomisd xmm0,xmm2
   1052b:	0f 86 c7 03 00 00    	jbe    108f8 <try_secant_tail.constprop.0+0xa18>
   10531:	48 b8 00 00 00 00 00 	movabs rax,0x7ff0000000000000
   10538:	00 f0 7f 
   1053b:	c4 e1 f9 7e c6       	vmovq  rsi,xmm0
   10540:	c4 e2 c8 f2 c0       	andn   rax,rsi,rax
   10545:	0f 84 ad 03 00 00    	je     108f8 <try_secant_tail.constprop.0+0xa18>
   1054b:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
   1054f:	c5 fb 10 b5 b0 fe ff 	vmovsd xmm6,QWORD PTR [rbp-0x150]
   10556:	ff 
   10557:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   1055e:	8b b5 c8 fe ff ff    	mov    esi,DWORD PTR [rbp-0x138]
   10564:	39 b5 f8 fe ff ff    	cmp    DWORD PTR [rbp-0x108],esi
   1056a:	c5 cb 5e c0          	vdivsd xmm0,xmm6,xmm0
   1056e:	c4 a1 7b 10 1c c0    	vmovsd xmm3,QWORD PTR [rax+r8*8]
   10574:	c5 c1 54 3d 00 00 00 	vandpd xmm7,xmm7,XMMWORD PTR [rip+0x0]        # 1057c <try_secant_tail.constprop.0+0x69c>
   1057b:	00 
   1057c:	c5 fb 59 e3          	vmulsd xmm4,xmm0,xmm3
   10580:	0f 8d 1c 13 00 00    	jge    118a2 <try_secant_tail.constprop.0+0x19c2>
   10586:	c5 c1 15 cf          	vunpckhpd xmm1,xmm7,xmm7
   1058a:	c5 fb 10 15 00 00 00 	vmovsd xmm2,QWORD PTR [rip+0x0]        # 10592 <try_secant_tail.constprop.0+0x6b2>
   10591:	00 
   10592:	c5 f1 5f cf          	vmaxpd xmm1,xmm1,xmm7
   10596:	c5 f3 59 c8          	vmulsd xmm1,xmm1,xmm0
   1059a:	c5 f9 2f ca          	vcomisd xmm1,xmm2
   1059e:	77 3e                	ja     105de <try_secant_tail.constprop.0+0x6fe>
   105a0:	c5 fb 10 bd 90 fe ff 	vmovsd xmm7,QWORD PTR [rbp-0x170]
   105a7:	ff 
   105a8:	c5 c3 58 8d b0 fe ff 	vaddsd xmm1,xmm7,QWORD PTR [rbp-0x150]
   105af:	ff 
   105b0:	c5 e3 5c ed          	vsubsd xmm5,xmm3,xmm5
   105b4:	c5 d9 54 25 00 00 00 	vandpd xmm4,xmm4,XMMWORD PTR [rip+0x0]        # 105bc <try_secant_tail.constprop.0+0x6dc>
   105bb:	00 
   105bc:	c5 db 58 c9          	vaddsd xmm1,xmm4,xmm1
   105c0:	c5 f3 59 0d 00 00 00 	vmulsd xmm1,xmm1,QWORD PTR [rip+0x0]        # 105c8 <try_secant_tail.constprop.0+0x6e8>
   105c7:	00 
   105c8:	c5 d3 59 e8          	vmulsd xmm5,xmm5,xmm0
   105cc:	c5 d1 54 2d 00 00 00 	vandpd xmm5,xmm5,XMMWORD PTR [rip+0x0]        # 105d4 <try_secant_tail.constprop.0+0x6f4>
   105d3:	00 
   105d4:	c5 f9 2f e9          	vcomisd xmm5,xmm1
   105d8:	0f 86 41 15 00 00    	jbe    11b1f <try_secant_tail.constprop.0+0x1c3f>
   105de:	c5 f8 77             	vzeroupper
   105e1:	44 8b ad 00 ff ff ff 	mov    r13d,DWORD PTR [rbp-0x100]
   105e8:	44 89 ee             	mov    esi,r13d
   105eb:	c5 fb 11 9d a8 fe ff 	vmovsd QWORD PTR [rbp-0x158],xmm3
   105f2:	ff 
   105f3:	e8 48 fc fe ff       	call   240 <norm2>
   105f8:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   105fc:	c5 fb 10 9d a8 fe ff 	vmovsd xmm3,QWORD PTR [rbp-0x158]
   10603:	ff 
   10604:	c5 f9 2f c1          	vcomisd xmm0,xmm1
   10608:	0f 85 ca 03 00 00    	jne    109d8 <try_secant_tail.constprop.0+0xaf8>
   1060e:	c5 e1 54 1d 00 00 00 	vandpd xmm3,xmm3,XMMWORD PTR [rip+0x0]        # 10616 <try_secant_tail.constprop.0+0x736>
   10615:	00 
   10616:	c5 f9 2f 1d 00 00 00 	vcomisd xmm3,QWORD PTR [rip+0x0]        # 1061e <try_secant_tail.constprop.0+0x73e>
   1061d:	00 
   1061e:	4d 89 cd             	mov    r13,r9
   10621:	0f 87 2e 23 00 00    	ja     12955 <try_secant_tail.constprop.0+0x2a75>
   10627:	83 85 c0 fe ff ff 01 	add    DWORD PTR [rbp-0x140],0x1
   1062e:	8b 9d 0c ff ff ff    	mov    ebx,DWORD PTR [rbp-0xf4]
   10634:	83 85 f8 fe ff ff 01 	add    DWORD PTR [rbp-0x108],0x1
   1063b:	8b b5 f8 fe ff ff    	mov    esi,DWORD PTR [rbp-0x108]
   10641:	39 b5 cc fe ff ff    	cmp    DWORD PTR [rbp-0x134],esi
   10647:	0f 8f cb fc ff ff    	jg     10318 <try_secant_tail.constprop.0+0x438>
   1064d:	89 9d c0 fe ff ff    	mov    DWORD PTR [rbp-0x140],ebx
   10653:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   1065a:	c5 f8 77             	vzeroupper
   1065d:	48 8b bd 58 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1a8]
   10664:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   1066b:	e8 00 00 00 00       	call   10670 <try_secant_tail.constprop.0+0x790>
   10670:	48 8b bd 10 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f0]
   10677:	e8 00 00 00 00       	call   1067c <try_secant_tail.constprop.0+0x79c>
   1067c:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   10683:	e8 00 00 00 00       	call   10688 <try_secant_tail.constprop.0+0x7a8>
   10688:	8b 8d c0 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x140]
   1068e:	4c 8b 95 f8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x108]
   10695:	85 c9                	test   ecx,ecx
   10697:	0f 85 92 26 00 00    	jne    12d2f <try_secant_tail.constprop.0+0x2e4f>
   1069d:	8b b5 d0 fe ff ff    	mov    esi,DWORD PTR [rbp-0x130]
   106a3:	4c 8d 6d b0          	lea    r13,[rbp-0x50]
   106a7:	4d 89 d4             	mov    r12,r10
   106aa:	4d 89 d7             	mov    r15,r10
   106ad:	39 b5 48 fe ff ff    	cmp    DWORD PTR [rbp-0x1b8],esi
   106b3:	48 8d 5d c0          	lea    rbx,[rbp-0x40]
   106b7:	0f 84 02 23 00 00    	je     129bf <try_secant_tail.constprop.0+0x2adf>
   106bd:	c4 c1 7b 10 45 00    	vmovsd xmm0,QWORD PTR [r13+0x0]
   106c3:	48 8b bd 18 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1e8]
   106ca:	4c 89 e6             	mov    rsi,r12
   106cd:	e8 7e 9c ff ff       	call   a350 <bs_check_certified.constprop.0>
   106d2:	83 f8 01             	cmp    eax,0x1
   106d5:	0f 85 88 21 00 00    	jne    12863 <try_secant_tail.constprop.0+0x2983>
   106db:	49 83 c5 08          	add    r13,0x8
   106df:	4c 03 a5 f0 fd ff ff 	add    r12,QWORD PTR [rbp-0x210]
   106e6:	4c 39 eb             	cmp    rbx,r13
   106e9:	75 d2                	jne    106bd <try_secant_tail.constprop.0+0x7dd>
   106eb:	48 8b bd b8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x148]
   106f2:	44 8b 85 48 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1b8]
   106f9:	41 89 c4             	mov    r12d,eax
   106fc:	4c 8d 8d 40 ff ff ff 	lea    r9,[rbp-0xc0]
   10703:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 1070b <try_secant_tail.constprop.0+0x82b>
   1070a:	00 
   1070b:	8b 8d cc fe ff ff    	mov    ecx,DWORD PTR [rbp-0x134]
   10711:	4c 89 bd f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r15
   10718:	48 8b 95 18 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xe8]
   1071f:	48 8b b5 98 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x168]
   10726:	e8 c5 01 ff ff       	call   8f0 <compat_scan_fused>
   1072b:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
   10732:	4c 8b 95 f8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x108]
   10739:	85 c0                	test   eax,eax
   1073b:	0f 85 30 21 00 00    	jne    12871 <try_secant_tail.constprop.0+0x2991>
   10741:	48 8b b5 c8 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x238]
   10748:	48 8b 9d d0 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x230]
   1074f:	8b 95 04 ff ff ff    	mov    edx,DWORD PTR [rbp-0xfc]
   10755:	c5 fb 10 85 40 ff ff 	vmovsd xmm0,QWORD PTR [rbp-0xc0]
   1075c:	ff 
   1075d:	48 85 f6             	test   rsi,rsi
   10760:	c7 03 02 00 00 00    	mov    DWORD PTR [rbx],0x2
   10766:	89 53 04             	mov    DWORD PTR [rbx+0x4],edx
   10769:	c5 fb 11 43 18       	vmovsd QWORD PTR [rbx+0x18],xmm0
   1076e:	0f 84 8c 21 00 00    	je     12900 <try_secant_tail.constprop.0+0x2a20>
   10774:	8b 9d 48 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x1b8]
   1077a:	85 db                	test   ebx,ebx
   1077c:	0f 8e 5b 24 00 00    	jle    12bdd <try_secant_tail.constprop.0+0x2cfd>
   10782:	8d 53 ff             	lea    edx,[rbx-0x1]
   10785:	48 8b 8d 18 ff ff ff 	mov    rcx,QWORD PTR [rbp-0xe8]
   1078c:	83 fa 02             	cmp    edx,0x2
   1078f:	0f 86 6b 24 00 00    	jbe    12c00 <try_secant_tail.constprop.0+0x2d20>
   10795:	89 da                	mov    edx,ebx
   10797:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   1079b:	31 c0                	xor    eax,eax
   1079d:	c1 ea 02             	shr    edx,0x2
   107a0:	c5 fd 28 d3          	vmovapd ymm2,ymm3
   107a4:	48 c1 e2 05          	shl    rdx,0x5
   107a8:	66 90                	xchg   ax,ax
   107aa:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   107b1:	00 00 00 00 
   107b5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   107bc:	00 00 00 00 
   107c0:	c5 fd 10 0c 06       	vmovupd ymm1,YMMWORD PTR [rsi+rax*1]
   107c5:	c5 fd 10 04 01       	vmovupd ymm0,YMMWORD PTR [rcx+rax*1]
   107ca:	48 83 c0 20          	add    rax,0x20
   107ce:	48 39 d0             	cmp    rax,rdx
   107d1:	c5 fd 5c c1          	vsubpd ymm0,ymm0,ymm1
   107d5:	c4 e2 f5 b8 d1       	vfmadd231pd ymm2,ymm1,ymm1
   107da:	c4 e2 fd b8 d8       	vfmadd231pd ymm3,ymm0,ymm0
   107df:	75 df                	jne    107c0 <try_secant_tail.constprop.0+0x8e0>
   107e1:	8b 9d 48 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x1b8]
   107e7:	c4 e3 7d 19 d8 01    	vextractf128 xmm0,ymm3,0x1
   107ed:	c4 e3 7d 19 d1 01    	vextractf128 xmm1,ymm2,0x1
   107f3:	c5 f9 58 db          	vaddpd xmm3,xmm0,xmm3
   107f7:	c5 f1 58 d2          	vaddpd xmm2,xmm1,xmm2
   107fb:	89 d8                	mov    eax,ebx
   107fd:	83 e0 fc             	and    eax,0xfffffffc
   10800:	c5 e1 15 c3          	vunpckhpd xmm0,xmm3,xmm3
   10804:	c5 e9 15 ca          	vunpckhpd xmm1,xmm2,xmm2
   10808:	39 d8                	cmp    eax,ebx
   1080a:	89 c2                	mov    edx,eax
   1080c:	c5 f9 58 c3          	vaddpd xmm0,xmm0,xmm3
   10810:	c5 f1 58 ca          	vaddpd xmm1,xmm1,xmm2
   10814:	0f 84 87 23 00 00    	je     12ba1 <try_secant_tail.constprop.0+0x2cc1>
   1081a:	c5 f8 77             	vzeroupper
   1081d:	8b b5 48 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b8]
   10823:	29 d6                	sub    esi,edx
   10825:	83 fe 01             	cmp    esi,0x1
   10828:	74 3a                	je     10864 <try_secant_tail.constprop.0+0x984>
   1082a:	48 8b 9d c8 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x238]
   10831:	c5 f9 10 04 d1       	vmovupd xmm0,XMMWORD PTR [rcx+rdx*8]
   10836:	40 f6 c6 01          	test   sil,0x1
   1083a:	c5 f9 10 0c d3       	vmovupd xmm1,XMMWORD PTR [rbx+rdx*8]
   1083f:	c5 f9 5c c1          	vsubpd xmm0,xmm0,xmm1
   10843:	c4 e2 f1 b8 d1       	vfmadd231pd xmm2,xmm1,xmm1
   10848:	c4 e2 e1 98 c0       	vfmadd132pd xmm0,xmm3,xmm0
   1084d:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   10851:	c5 f1 58 c0          	vaddpd xmm0,xmm1,xmm0
   10855:	c5 e9 15 ca          	vunpckhpd xmm1,xmm2,xmm2
   10859:	c5 f1 58 ca          	vaddpd xmm1,xmm1,xmm2
   1085d:	74 26                	je     10885 <try_secant_tail.constprop.0+0x9a5>
   1085f:	83 e6 fe             	and    esi,0xfffffffe
   10862:	01 f0                	add    eax,esi
   10864:	48 8b 9d c8 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x238]
   1086b:	48 98                	cdqe
   1086d:	c5 fb 10 14 c1       	vmovsd xmm2,QWORD PTR [rcx+rax*8]
   10872:	c5 fb 10 1c c3       	vmovsd xmm3,QWORD PTR [rbx+rax*8]
   10877:	c5 eb 5c d3          	vsubsd xmm2,xmm2,xmm3
   1087b:	c4 e2 e1 b9 cb       	vfmadd231sd xmm1,xmm3,xmm3
   10880:	c4 e2 e9 b9 c2       	vfmadd231sd xmm0,xmm2,xmm2
   10885:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
   10889:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
   1088d:	c5 f3 58 0d 00 00 00 	vaddsd xmm1,xmm1,QWORD PTR [rip+0x0]        # 10895 <try_secant_tail.constprop.0+0x9b5>
   10894:	00 
   10895:	c5 fb 5e c1          	vdivsd xmm0,xmm0,xmm1
   10899:	48 8b 85 d0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x230]
   108a0:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   108a7:	c7 40 0c 01 00 00 00 	mov    DWORD PTR [rax+0xc],0x1
   108ae:	c5 fb 11 40 20       	vmovsd QWORD PTR [rax+0x20],xmm0
   108b3:	e8 00 00 00 00       	call   108b8 <try_secant_tail.constprop.0+0x9d8>
   108b8:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   108bf:	e8 00 00 00 00       	call   108c4 <try_secant_tail.constprop.0+0x9e4>
   108c4:	48 8b bd 20 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe0]
   108cb:	e8 00 00 00 00       	call   108d0 <try_secant_tail.constprop.0+0x9f0>
   108d0:	4c 89 f7             	mov    rdi,r14
   108d3:	e8 00 00 00 00       	call   108d8 <try_secant_tail.constprop.0+0x9f8>
   108d8:	48 8b bd f8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x108]
   108df:	e8 00 00 00 00       	call   108e4 <try_secant_tail.constprop.0+0xa04>
   108e4:	e9 8e f6 ff ff       	jmp    ff77 <try_secant_tail.constprop.0+0x97>
   108e9:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
   108ed:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
   108f1:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   108f8:	c5 f9 29 bd 70 fe ff 	vmovapd XMMWORD PTR [rbp-0x190],xmm7
   108ff:	ff 
   10900:	44 89 e6             	mov    esi,r12d
   10903:	c5 fb 11 ad a8 fe ff 	vmovsd QWORD PTR [rbp-0x158],xmm5
   1090a:	ff 
   1090b:	c5 f8 77             	vzeroupper
   1090e:	e8 2d f9 fe ff       	call   240 <norm2>
   10913:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
   10917:	c5 fb 10 ad a8 fe ff 	vmovsd xmm5,QWORD PTR [rbp-0x158]
   1091e:	ff 
   1091f:	c5 f9 2f c2          	vcomisd xmm0,xmm2
   10923:	c5 f9 28 bd 70 fe ff 	vmovapd xmm7,XMMWORD PTR [rbp-0x190]
   1092a:	ff 
   1092b:	0f 85 1e fc ff ff    	jne    1054f <try_secant_tail.constprop.0+0x66f>
   10931:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   10938:	c4 a1 7b 10 1c c0    	vmovsd xmm3,QWORD PTR [rax+r8*8]
   1093e:	c5 e1 54 05 00 00 00 	vandpd xmm0,xmm3,XMMWORD PTR [rip+0x0]        # 10946 <try_secant_tail.constprop.0+0xa66>
   10945:	00 
   10946:	c5 f9 2f 05 00 00 00 	vcomisd xmm0,QWORD PTR [rip+0x0]        # 1094e <try_secant_tail.constprop.0+0xa6e>
   1094d:	00 
   1094e:	0f 87 8d fc ff ff    	ja     105e1 <try_secant_tail.constprop.0+0x701>
   10954:	8b bd c8 fe ff ff    	mov    edi,DWORD PTR [rbp-0x138]
   1095a:	8b b5 f8 fe ff ff    	mov    esi,DWORD PTR [rbp-0x108]
   10960:	8d 46 01             	lea    eax,[rsi+0x1]
   10963:	39 fe                	cmp    esi,edi
   10965:	0f 4d f8             	cmovge edi,eax
   10968:	39 85 cc fe ff ff    	cmp    DWORD PTR [rbp-0x134],eax
   1096e:	89 bd c8 fe ff ff    	mov    DWORD PTR [rbp-0x138],edi
   10974:	0f 8e ce 22 00 00    	jle    12c48 <try_secant_tail.constprop.0+0x2d68>
   1097a:	83 85 c0 fe ff ff 01 	add    DWORD PTR [rbp-0x140],0x1
   10981:	44 3b a5 d0 fe ff ff 	cmp    r12d,DWORD PTR [rbp-0x130]
   10988:	89 85 f8 fe ff ff    	mov    DWORD PTR [rbp-0x108],eax
   1098e:	0f 8f c1 f9 ff ff    	jg     10355 <try_secant_tail.constprop.0+0x475>
   10994:	49 89 da             	mov    r10,rbx
   10997:	c5 f8 77             	vzeroupper
   1099a:	48 8b bd 58 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1a8]
   109a1:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   109a8:	e8 00 00 00 00       	call   109ad <try_secant_tail.constprop.0+0xacd>
   109ad:	48 8b bd 10 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f0]
   109b4:	e8 00 00 00 00       	call   109b9 <try_secant_tail.constprop.0+0xad9>
   109b9:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   109c0:	e8 00 00 00 00       	call   109c5 <try_secant_tail.constprop.0+0xae5>
   109c5:	4c 8b 95 f8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x108]
   109cc:	e9 cc fc ff ff       	jmp    1069d <try_secant_tail.constprop.0+0x7bd>
   109d1:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   109d8:	c5 fb 10 bd b0 fe ff 	vmovsd xmm7,QWORD PTR [rbp-0x150]
   109df:	ff 
   109e0:	49 63 cd             	movsxd rcx,r13d
   109e3:	4c 8b bd 20 ff ff ff 	mov    r15,QWORD PTR [rbp-0xe0]
   109ea:	45 85 ed             	test   r13d,r13d
   109ed:	48 8d 04 cd 00 00 00 	lea    rax,[rcx*8+0x0]
   109f4:	00 
   109f5:	48 89 8d 20 fe ff ff 	mov    QWORD PTR [rbp-0x1e0],rcx
   109fc:	48 8b b5 10 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xf0]
   10a03:	c5 c3 5e c0          	vdivsd xmm0,xmm7,xmm0
   10a07:	4d 8d 14 07          	lea    r10,[r15+rax*1]
   10a0b:	48 89 85 08 fe ff ff 	mov    QWORD PTR [rbp-0x1f8],rax
   10a12:	4d 8d 04 02          	lea    r8,[r10+rax*1]
   10a16:	c5 fb 59 fb          	vmulsd xmm7,xmm0,xmm3
   10a1a:	c5 fb 11 bd a8 fe ff 	vmovsd QWORD PTR [rbp-0x158],xmm7
   10a21:	ff 
   10a22:	0f 8e 58 11 00 00    	jle    11b80 <try_secant_tail.constprop.0+0x1ca0>
   10a28:	41 83 fd 01          	cmp    r13d,0x1
   10a2c:	0f 84 02 1a 00 00    	je     12434 <try_secant_tail.constprop.0+0x2554>
   10a32:	48 8d 04 cd f8 ff ff 	lea    rax,[rcx*8-0x8]
   10a39:	ff 
   10a3a:	48 83 f8 10          	cmp    rax,0x10
   10a3e:	4c 89 d0             	mov    rax,r10
   10a41:	0f 97 c2             	seta   dl
   10a44:	48 29 f8             	sub    rax,rdi
   10a47:	48 83 e8 08          	sub    rax,0x8
   10a4b:	48 83 f8 10          	cmp    rax,0x10
   10a4f:	0f 97 c0             	seta   al
   10a52:	84 c2                	test   dl,al
   10a54:	0f 84 69 1a 00 00    	je     124c3 <try_secant_tail.constprop.0+0x25e3>
   10a5a:	49 8d 47 f8          	lea    rax,[r15-0x8]
   10a5e:	48 29 f8             	sub    rax,rdi
   10a61:	48 83 f8 10          	cmp    rax,0x10
   10a65:	0f 86 58 1a 00 00    	jbe    124c3 <try_secant_tail.constprop.0+0x25e3>
   10a6b:	41 8d 45 ff          	lea    eax,[r13-0x1]
   10a6f:	44 89 ad 70 fe ff ff 	mov    DWORD PTR [rbp-0x190],r13d
   10a76:	83 f8 02             	cmp    eax,0x2
   10a79:	0f 86 52 1a 00 00    	jbe    124d1 <try_secant_tail.constprop.0+0x25f1>
   10a7f:	44 89 e9             	mov    ecx,r13d
   10a82:	c4 e2 7d 19 d0       	vbroadcastsd ymm2,xmm0
   10a87:	31 d2                	xor    edx,edx
   10a89:	c1 e9 02             	shr    ecx,0x2
   10a8c:	48 c1 e1 05          	shl    rcx,0x5
   10a90:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   10a95:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   10a9c:	00 00 00 00 
   10aa0:	c5 ed 59 0c 17       	vmulpd ymm1,ymm2,YMMWORD PTR [rdi+rdx*1]
   10aa5:	c4 c1 7d 11 0c 17    	vmovupd YMMWORD PTR [r15+rdx*1],ymm1
   10aab:	c4 c1 7d 11 0c 12    	vmovupd YMMWORD PTR [r10+rdx*1],ymm1
   10ab1:	48 83 c2 20          	add    rdx,0x20
   10ab5:	48 39 d1             	cmp    rcx,rdx
   10ab8:	75 e6                	jne    10aa0 <try_secant_tail.constprop.0+0xbc0>
   10aba:	44 89 ea             	mov    edx,r13d
   10abd:	83 e2 fc             	and    edx,0xfffffffc
   10ac0:	41 39 d5             	cmp    r13d,edx
   10ac3:	89 d1                	mov    ecx,edx
   10ac5:	0f 84 79 10 00 00    	je     11b44 <try_secant_tail.constprop.0+0x1c64>
   10acb:	45 89 eb             	mov    r11d,r13d
   10ace:	41 29 d3             	sub    r11d,edx
   10ad1:	41 83 fb 01          	cmp    r11d,0x1
   10ad5:	44 89 9d 70 fe ff ff 	mov    DWORD PTR [rbp-0x190],r11d
   10adc:	0f 84 23 1c 00 00    	je     12705 <try_secant_tail.constprop.0+0x2825>
   10ae2:	c5 f8 77             	vzeroupper
   10ae5:	c5 fb 12 c8          	vmovddup xmm1,xmm0
   10ae9:	c5 f1 59 0c cf       	vmulpd xmm1,xmm1,XMMWORD PTR [rdi+rcx*8]
   10aee:	c4 c1 79 11 0c cf    	vmovupd XMMWORD PTR [r15+rcx*8],xmm1
   10af4:	48 03 8d 20 fe ff ff 	add    rcx,QWORD PTR [rbp-0x1e0]
   10afb:	c4 c1 79 11 0c cf    	vmovupd XMMWORD PTR [r15+rcx*8],xmm1
   10b01:	8b 8d 70 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x190]
   10b07:	f6 c1 01             	test   cl,0x1
   10b0a:	74 1e                	je     10b2a <try_secant_tail.constprop.0+0xc4a>
   10b0c:	41 89 cb             	mov    r11d,ecx
   10b0f:	41 83 e3 fe          	and    r11d,0xfffffffe
   10b13:	44 01 da             	add    edx,r11d
   10b16:	48 63 d2             	movsxd rdx,edx
   10b19:	c5 fb 59 04 d7       	vmulsd xmm0,xmm0,QWORD PTR [rdi+rdx*8]
   10b1e:	c4 c1 7b 11 04 d7    	vmovsd QWORD PTR [r15+rdx*8],xmm0
   10b24:	c4 c1 7b 11 04 d2    	vmovsd QWORD PTR [r10+rdx*8],xmm0
   10b2a:	8b 95 d0 fe ff ff    	mov    edx,DWORD PTR [rbp-0x130]
   10b30:	4c 89 d7             	mov    rdi,r10
   10b33:	44 89 e9             	mov    ecx,r13d
   10b36:	4c 89 8d 30 fe ff ff 	mov    QWORD PTR [rbp-0x1d0],r9
   10b3d:	89 85 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],eax
   10b43:	4c 89 95 70 fe ff ff 	mov    QWORD PTR [rbp-0x190],r10
   10b4a:	e8 41 28 ff ff       	call   3390 <project_cgs2>
   10b4f:	4c 8b 95 70 fe ff ff 	mov    r10,QWORD PTR [rbp-0x190]
   10b56:	44 89 ee             	mov    esi,r13d
   10b59:	c5 fb 11 85 e8 fd ff 	vmovsd QWORD PTR [rbp-0x218],xmm0
   10b60:	ff 
   10b61:	4c 89 d7             	mov    rdi,r10
   10b64:	e8 d7 f6 fe ff       	call   240 <norm2>
   10b69:	83 bd 38 fe ff ff 02 	cmp    DWORD PTR [rbp-0x1c8],0x2
   10b70:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   10b77:	44 89 ea             	mov    edx,r13d
   10b7a:	4c 8b 8d 30 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1d0]
   10b81:	c5 f9 28 d0          	vmovapd xmm2,xmm0
   10b85:	0f 86 4f 19 00 00    	jbe    124da <try_secant_tail.constprop.0+0x25fa>
   10b8b:	44 89 ea             	mov    edx,r13d
   10b8e:	31 c0                	xor    eax,eax
   10b90:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   10b94:	c1 ea 02             	shr    edx,0x2
   10b97:	48 c1 e2 05          	shl    rdx,0x5
   10b9b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   10ba0:	c5 fd 10 04 07       	vmovupd ymm0,YMMWORD PTR [rdi+rax*1]
   10ba5:	c4 c1 7d 59 04 07    	vmulpd ymm0,ymm0,YMMWORD PTR [r15+rax*1]
   10bab:	48 83 c0 20          	add    rax,0x20
   10baf:	48 39 d0             	cmp    rax,rdx
   10bb2:	c5 f5 58 c8          	vaddpd ymm1,ymm1,ymm0
   10bb6:	75 e8                	jne    10ba0 <try_secant_tail.constprop.0+0xcc0>
   10bb8:	c4 e3 7d 19 c8 01    	vextractf128 xmm0,ymm1,0x1
   10bbe:	41 f6 c5 03          	test   r13b,0x3
   10bc2:	c5 f9 58 c1          	vaddpd xmm0,xmm0,xmm1
   10bc6:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   10bca:	c5 f1 58 c8          	vaddpd xmm1,xmm1,xmm0
   10bce:	0f 84 10 0f 00 00    	je     11ae4 <try_secant_tail.constprop.0+0x1c04>
   10bd4:	44 89 e8             	mov    eax,r13d
   10bd7:	83 e0 fc             	and    eax,0xfffffffc
   10bda:	89 c1                	mov    ecx,eax
   10bdc:	c5 f8 77             	vzeroupper
   10bdf:	44 89 ea             	mov    edx,r13d
   10be2:	29 c2                	sub    edx,eax
   10be4:	83 fa 01             	cmp    edx,0x1
   10be7:	74 1e                	je     10c07 <try_secant_tail.constprop.0+0xd27>
   10be9:	c4 c1 79 10 34 c7    	vmovupd xmm6,XMMWORD PTR [r15+rax*8]
   10bef:	c4 e2 c9 b8 04 c7    	vfmadd231pd xmm0,xmm6,XMMWORD PTR [rdi+rax*8]
   10bf5:	f6 c2 01             	test   dl,0x1
   10bf8:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   10bfc:	c5 f1 58 c8          	vaddpd xmm1,xmm1,xmm0
   10c00:	74 14                	je     10c16 <try_secant_tail.constprop.0+0xd36>
   10c02:	83 e2 fe             	and    edx,0xfffffffe
   10c05:	01 d1                	add    ecx,edx
   10c07:	48 63 c9             	movsxd rcx,ecx
   10c0a:	c4 c1 7b 10 3c cf    	vmovsd xmm7,QWORD PTR [r15+rcx*8]
   10c10:	c4 e2 c1 b9 0c cf    	vfmadd231sd xmm1,xmm7,QWORD PTR [rdi+rcx*8]
   10c16:	c5 fb 10 bd a8 fe ff 	vmovsd xmm7,QWORD PTR [rbp-0x158]
   10c1d:	ff 
   10c1e:	c5 c3 5c f1          	vsubsd xmm6,xmm7,xmm1
   10c22:	c5 fb 11 b5 00 fe ff 	vmovsd QWORD PTR [rbp-0x200],xmm6
   10c29:	ff 
   10c2a:	44 89 ee             	mov    esi,r13d
   10c2d:	4c 89 95 30 fe ff ff 	mov    QWORD PTR [rbp-0x1d0],r10
   10c34:	4c 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r9
   10c3b:	c5 fb 11 95 28 fe ff 	vmovsd QWORD PTR [rbp-0x1d8],xmm2
   10c42:	ff 
   10c43:	e8 f8 f5 fe ff       	call   240 <norm2>
   10c48:	db ad 30 ff ff ff    	fld    TBYTE PTR [rbp-0xd0]
   10c4e:	c5 fb 11 85 f8 fd ff 	vmovsd QWORD PTR [rbp-0x208],xmm0
   10c55:	ff 
   10c56:	db bd 70 fe ff ff    	fstp   TBYTE PTR [rbp-0x190]
   10c5c:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 10c63 <try_secant_tail.constprop.0+0xd83>
   10c63:	e8 00 00 00 00       	call   10c68 <try_secant_tail.constprop.0+0xd88>
   10c68:	4c 8b 8d 38 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c8]
   10c6f:	4c 8b 95 30 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1d0]
   10c76:	c5 fb 10 95 28 fe ff 	vmovsd xmm2,QWORD PTR [rbp-0x1d8]
   10c7d:	ff 
   10c7e:	d9 ee                	fldz
   10c80:	c5 fb 10 88 00 00 00 	vmovsd xmm1,QWORD PTR [rax+0x0]
   10c87:	00 
   10c88:	db ad 70 fe ff ff    	fld    TBYTE PTR [rbp-0x190]
   10c8e:	db f1                	fcomi  st,st(1)
   10c90:	dd d9                	fstp   st(1)
   10c92:	0f 86 08 07 00 00    	jbe    113a0 <try_secant_tail.constprop.0+0x14c0>
   10c98:	d9 c0                	fld    st(0)
   10c9a:	d9 fa                	fsqrt
   10c9c:	dd 9d 70 fe ff ff    	fstp   QWORD PTR [rbp-0x190]
   10ca2:	c5 fb 10 85 70 fe ff 	vmovsd xmm0,QWORD PTR [rbp-0x190]
   10ca9:	ff 
   10caa:	c5 f9 2f c1          	vcomisd xmm0,xmm1
   10cae:	76 08                	jbe    10cb8 <try_secant_tail.constprop.0+0xdd8>
   10cb0:	c5 fb 11 80 00 00 00 	vmovsd QWORD PTR [rax+0x0],xmm0
   10cb7:	00 
   10cb8:	c5 f9 2f 05 00 00 00 	vcomisd xmm0,QWORD PTR [rip+0x0]        # 10cc0 <try_secant_tail.constprop.0+0xde0>
   10cbf:	00 
   10cc0:	0f 82 4b 08 00 00    	jb     11511 <try_secant_tail.constprop.0+0x1631>
   10cc6:	dd d8                	fstp   st(0)
   10cc8:	eb 02                	jmp    10ccc <try_secant_tail.constprop.0+0xdec>
   10cca:	dd d8                	fstp   st(0)
   10ccc:	8b 85 88 fe ff ff    	mov    eax,DWORD PTR [rbp-0x178]
   10cd2:	49 89 da             	mov    r10,rbx
   10cd5:	89 85 c0 fe ff ff    	mov    DWORD PTR [rbp-0x140],eax
   10cdb:	8b bd f8 fe ff ff    	mov    edi,DWORD PTR [rbp-0x108]
   10ce1:	85 ff                	test   edi,edi
   10ce3:	0f 88 c4 02 00 00    	js     10fad <try_secant_tail.constprop.0+0x10cd>
   10ce9:	4c 89 95 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],r10
   10cf0:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 10cf7 <try_secant_tail.constprop.0+0xe17>
   10cf7:	e8 00 00 00 00       	call   10cfc <try_secant_tail.constprop.0+0xe1c>
   10cfc:	4c 8b 95 f0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x110]
   10d03:	48 63 98 00 00 00 00 	movsxd rbx,DWORD PTR [rax+0x0]
   10d0a:	83 80 00 00 00 00 01 	add    DWORD PTR [rax+0x0],0x1
   10d11:	85 db                	test   ebx,ebx
   10d13:	0f 8e 64 02 00 00    	jle    10f7d <try_secant_tail.constprop.0+0x109d>
   10d19:	8d 53 ff             	lea    edx,[rbx-0x1]
   10d1c:	83 fa 07             	cmp    edx,0x7
   10d1f:	0f 86 d2 1a 00 00    	jbe    127f7 <try_secant_tail.constprop.0+0x2917>
   10d25:	c4 e2 7d 58 85 f8 fe 	vpbroadcastd ymm0,DWORD PTR [rbp-0x108]
   10d2c:	ff ff 
   10d2e:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   10d35:	00 
   10d36:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   10d3b:	0f 85 cc 1b 00 00    	jne    1290d <try_secant_tail.constprop.0+0x2a2d>
   10d41:	41 89 dc             	mov    r12d,ebx
   10d44:	41 c1 ec 03          	shr    r12d,0x3
   10d48:	41 83 fc 01          	cmp    r12d,0x1
   10d4c:	0f 84 d0 1b 00 00    	je     12922 <try_secant_tail.constprop.0+0x2a42>
   10d52:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   10d59:	00 
   10d5a:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   10d5f:	0f 85 26 1e 00 00    	jne    12b8b <try_secant_tail.constprop.0+0x2cab>
   10d65:	41 83 fc 02          	cmp    r12d,0x2
   10d69:	0f 84 c5 00 00 00    	je     10e34 <try_secant_tail.constprop.0+0xf54>
   10d6f:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   10d76:	00 
   10d77:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   10d7c:	0f 85 27 1e 00 00    	jne    12ba9 <try_secant_tail.constprop.0+0x2cc9>
   10d82:	41 83 fc 03          	cmp    r12d,0x3
   10d86:	0f 84 a8 00 00 00    	je     10e34 <try_secant_tail.constprop.0+0xf54>
   10d8c:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   10d93:	00 
   10d94:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   10d99:	0f 85 17 1e 00 00    	jne    12bb6 <try_secant_tail.constprop.0+0x2cd6>
   10d9f:	41 83 fc 04          	cmp    r12d,0x4
   10da3:	0f 84 8b 00 00 00    	je     10e34 <try_secant_tail.constprop.0+0xf54>
   10da9:	4c 89 95 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],r10
   10db0:	c5 fd 7f 85 d0 fe ff 	vmovdqa YMMWORD PTR [rbp-0x130],ymm0
   10db7:	ff 
   10db8:	c5 f8 77             	vzeroupper
   10dbb:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 10dc2 <try_secant_tail.constprop.0+0xee2>
   10dc2:	e8 00 00 00 00       	call   10dc7 <try_secant_tail.constprop.0+0xee7>
   10dc7:	c5 fd 6f 85 d0 fe ff 	vmovdqa ymm0,YMMWORD PTR [rbp-0x130]
   10dce:	ff 
   10dcf:	4c 8b 95 f0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x110]
   10dd6:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   10ddd:	00 
   10dde:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   10de3:	0f 85 da 1d 00 00    	jne    12bc3 <try_secant_tail.constprop.0+0x2ce3>
   10de9:	41 83 fc 05          	cmp    r12d,0x5
   10ded:	74 45                	je     10e34 <try_secant_tail.constprop.0+0xf54>
   10def:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   10df6:	00 
   10df7:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   10dfc:	0f 85 ce 1d 00 00    	jne    12bd0 <try_secant_tail.constprop.0+0x2cf0>
   10e02:	41 83 fc 06          	cmp    r12d,0x6
   10e06:	74 2c                	je     10e34 <try_secant_tail.constprop.0+0xf54>
   10e08:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   10e0f:	00 
   10e10:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   10e15:	0f 85 cb 1d 00 00    	jne    12be6 <try_secant_tail.constprop.0+0x2d06>
   10e1b:	41 83 fc 07          	cmp    r12d,0x7
   10e1f:	74 13                	je     10e34 <try_secant_tail.constprop.0+0xf54>
   10e21:	c5 fd 76 80 00 00 00 	vpcmpeqd ymm0,ymm0,YMMWORD PTR [rax+0x0]
   10e28:	00 
   10e29:	c4 e2 7d 17 c0       	vptest ymm0,ymm0
   10e2e:	0f 85 bf 1d 00 00    	jne    12bf3 <try_secant_tail.constprop.0+0x2d13>
   10e34:	f6 c3 07             	test   bl,0x7
   10e37:	0f 84 a3 1a 00 00    	je     128e0 <try_secant_tail.constprop.0+0x2a00>
   10e3d:	89 d8                	mov    eax,ebx
   10e3f:	83 e0 f8             	and    eax,0xfffffff8
   10e42:	89 85 c0 fe ff ff    	mov    DWORD PTR [rbp-0x140],eax
   10e48:	4c 89 95 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],r10
   10e4f:	c5 f8 77             	vzeroupper
   10e52:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 10e59 <try_secant_tail.constprop.0+0xf79>
   10e59:	e8 00 00 00 00       	call   10e5e <try_secant_tail.constprop.0+0xf7e>
   10e5e:	48 63 95 c0 fe ff ff 	movsxd rdx,DWORD PTR [rbp-0x140]
   10e65:	8b bd f8 fe ff ff    	mov    edi,DWORD PTR [rbp-0x108]
   10e6b:	4c 8b 95 f0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x110]
   10e72:	3b bc 90 00 00 00 00 	cmp    edi,DWORD PTR [rax+rdx*4+0x0]
   10e79:	0f 84 2e 01 00 00    	je     10fad <try_secant_tail.constprop.0+0x10cd>
   10e7f:	44 8d 62 01          	lea    r12d,[rdx+0x1]
   10e83:	44 39 e3             	cmp    ebx,r12d
   10e86:	0f 8e ec 00 00 00    	jle    10f78 <try_secant_tail.constprop.0+0x1098>
   10e8c:	4c 89 95 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],r10
   10e93:	4d 63 e4             	movsxd r12,r12d
   10e96:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 10e9d <try_secant_tail.constprop.0+0xfbd>
   10e9d:	e8 00 00 00 00       	call   10ea2 <try_secant_tail.constprop.0+0xfc2>
   10ea2:	8b bd f8 fe ff ff    	mov    edi,DWORD PTR [rbp-0x108]
   10ea8:	4c 8b 95 f0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x110]
   10eaf:	42 3b bc a0 00 00 00 	cmp    edi,DWORD PTR [rax+r12*4+0x0]
   10eb6:	00 
   10eb7:	0f 84 f0 00 00 00    	je     10fad <try_secant_tail.constprop.0+0x10cd>
   10ebd:	8b 85 c0 fe ff ff    	mov    eax,DWORD PTR [rbp-0x140]
   10ec3:	44 8d 60 02          	lea    r12d,[rax+0x2]
   10ec7:	44 39 e3             	cmp    ebx,r12d
   10eca:	0f 8e a8 00 00 00    	jle    10f78 <try_secant_tail.constprop.0+0x1098>
   10ed0:	4c 89 95 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],r10
   10ed7:	4d 63 e4             	movsxd r12,r12d
   10eda:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 10ee1 <try_secant_tail.constprop.0+0x1001>
   10ee1:	e8 00 00 00 00       	call   10ee6 <try_secant_tail.constprop.0+0x1006>
   10ee6:	44 8b bd f8 fe ff ff 	mov    r15d,DWORD PTR [rbp-0x108]
   10eed:	4c 8b 95 f0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x110]
   10ef4:	46 3b bc a0 00 00 00 	cmp    r15d,DWORD PTR [rax+r12*4+0x0]
   10efb:	00 
   10efc:	48 8d 90 00 00 00 00 	lea    rdx,[rax+0x0]
   10f03:	0f 84 a4 00 00 00    	je     10fad <try_secant_tail.constprop.0+0x10cd>
   10f09:	8b b5 c0 fe ff ff    	mov    esi,DWORD PTR [rbp-0x140]
   10f0f:	8d 46 03             	lea    eax,[rsi+0x3]
   10f12:	39 c3                	cmp    ebx,eax
   10f14:	7e 62                	jle    10f78 <try_secant_tail.constprop.0+0x1098>
   10f16:	48 98                	cdqe
   10f18:	44 3b 3c 82          	cmp    r15d,DWORD PTR [rdx+rax*4]
   10f1c:	0f 84 8b 00 00 00    	je     10fad <try_secant_tail.constprop.0+0x10cd>
   10f22:	8d 46 04             	lea    eax,[rsi+0x4]
   10f25:	39 c3                	cmp    ebx,eax
   10f27:	7e 4f                	jle    10f78 <try_secant_tail.constprop.0+0x1098>
   10f29:	48 98                	cdqe
   10f2b:	44 3b 3c 82          	cmp    r15d,DWORD PTR [rdx+rax*4]
   10f2f:	74 7c                	je     10fad <try_secant_tail.constprop.0+0x10cd>
   10f31:	8d 46 05             	lea    eax,[rsi+0x5]
   10f34:	39 c3                	cmp    ebx,eax
   10f36:	7e 40                	jle    10f78 <try_secant_tail.constprop.0+0x1098>
   10f38:	48 98                	cdqe
   10f3a:	44 3b 3c 82          	cmp    r15d,DWORD PTR [rdx+rax*4]
   10f3e:	74 6d                	je     10fad <try_secant_tail.constprop.0+0x10cd>
   10f40:	8d 46 06             	lea    eax,[rsi+0x6]
   10f43:	39 c3                	cmp    ebx,eax
   10f45:	7e 31                	jle    10f78 <try_secant_tail.constprop.0+0x1098>
   10f47:	48 98                	cdqe
   10f49:	44 3b 3c 82          	cmp    r15d,DWORD PTR [rdx+rax*4]
   10f4d:	74 5e                	je     10fad <try_secant_tail.constprop.0+0x10cd>
   10f4f:	44 8d 66 07          	lea    r12d,[rsi+0x7]
   10f53:	44 39 e3             	cmp    ebx,r12d
   10f56:	7e 20                	jle    10f78 <try_secant_tail.constprop.0+0x1098>
   10f58:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 10f5f <try_secant_tail.constprop.0+0x107f>
   10f5f:	e8 00 00 00 00       	call   10f64 <try_secant_tail.constprop.0+0x1084>
   10f64:	4d 63 e4             	movsxd r12,r12d
   10f67:	4c 8b 95 f0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x110]
   10f6e:	46 3b bc a0 00 00 00 	cmp    r15d,DWORD PTR [rax+r12*4+0x0]
   10f75:	00 
   10f76:	74 35                	je     10fad <try_secant_tail.constprop.0+0x10cd>
   10f78:	83 fb 40             	cmp    ebx,0x40
   10f7b:	74 30                	je     10fad <try_secant_tail.constprop.0+0x10cd>
   10f7d:	4c 89 95 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],r10
   10f84:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 10f8b <try_secant_tail.constprop.0+0x10ab>
   10f8b:	e8 00 00 00 00       	call   10f90 <try_secant_tail.constprop.0+0x10b0>
   10f90:	8b bd f8 fe ff ff    	mov    edi,DWORD PTR [rbp-0x108]
   10f96:	8d 53 01             	lea    edx,[rbx+0x1]
   10f99:	4c 8b 95 f0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x110]
   10fa0:	89 90 00 00 00 00    	mov    DWORD PTR [rax+0x0],edx
   10fa6:	89 bc 98 00 00 00 00 	mov    DWORD PTR [rax+rbx*4+0x0],edi
   10fad:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
   10fb4:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   10fbb:	e8 00 00 00 00       	call   10fc0 <try_secant_tail.constprop.0+0x10e0>
   10fc0:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   10fc7:	e8 00 00 00 00       	call   10fcc <try_secant_tail.constprop.0+0x10ec>
   10fcc:	48 8b bd 20 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe0]
   10fd3:	e8 00 00 00 00       	call   10fd8 <try_secant_tail.constprop.0+0x10f8>
   10fd8:	4c 89 f7             	mov    rdi,r14
   10fdb:	e8 00 00 00 00       	call   10fe0 <try_secant_tail.constprop.0+0x1100>
   10fe0:	48 8b bd f8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x108]
   10fe7:	e8 00 00 00 00       	call   10fec <try_secant_tail.constprop.0+0x110c>
   10fec:	48 8b bd 58 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1a8]
   10ff3:	e8 00 00 00 00       	call   10ff8 <try_secant_tail.constprop.0+0x1118>
   10ff8:	48 8b bd 10 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f0]
   10fff:	e8 00 00 00 00       	call   11004 <try_secant_tail.constprop.0+0x1124>
   11004:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   1100b:	e8 00 00 00 00       	call   11010 <try_secant_tail.constprop.0+0x1130>
   11010:	45 31 e4             	xor    r12d,r12d
   11013:	e9 5f ef ff ff       	jmp    ff77 <try_secant_tail.constprop.0+0x97>
   11018:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
   1101f:	00 
   11020:	41 89 f5             	mov    r13d,esi
   11023:	8d 86 00 08 00 00    	lea    eax,[rsi+0x800]
   11029:	8b b5 cc fe ff ff    	mov    esi,DWORD PTR [rbp-0x134]
   1102f:	4c 89 8d d0 fe ff ff 	mov    QWORD PTR [rbp-0x130],r9
   11036:	48 8b bd 58 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1a8]
   1103d:	b9 00 08 00 00       	mov    ecx,0x800
   11042:	39 f0                	cmp    eax,esi
   11044:	0f 4f c6             	cmovg  eax,esi
   11047:	31 f6                	xor    esi,esi
   11049:	89 85 c8 fe ff ff    	mov    DWORD PTR [rbp-0x138],eax
   1104f:	41 89 c7             	mov    r15d,eax
   11052:	45 29 ef             	sub    r15d,r13d
   11055:	49 63 d7             	movsxd rdx,r15d
   11058:	c5 f8 77             	vzeroupper
   1105b:	e8 00 00 00 00       	call   11060 <try_secant_tail.constprop.0+0x1180>
   11060:	48 8b 8d 90 fd ff ff 	mov    rcx,QWORD PTR [rbp-0x270]
   11067:	31 f6                	xor    esi,esi
   11069:	48 8b bd 10 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f0]
   11070:	48 89 ca             	mov    rdx,rcx
   11073:	e8 00 00 00 00       	call   11078 <try_secant_tail.constprop.0+0x1198>
   11078:	48 8b 8d 98 fd ff ff 	mov    rcx,QWORD PTR [rbp-0x268]
   1107f:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   11086:	31 f6                	xor    esi,esi
   11088:	48 89 ca             	mov    rdx,rcx
   1108b:	e8 00 00 00 00       	call   11090 <try_secant_tail.constprop.0+0x11b0>
   11090:	48 8b 85 40 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c0]
   11097:	31 c9                	xor    ecx,ecx
   11099:	31 d2                	xor    edx,edx
   1109b:	44 89 6d 9c          	mov    DWORD PTR [rbp-0x64],r13d
   1109f:	c5 f9 6f ad a0 fd ff 	vmovdqa xmm5,XMMWORD PTR [rbp-0x260]
   110a6:	ff 
   110a7:	4c 8d ad 40 ff ff ff 	lea    r13,[rbp-0xc0]
   110ae:	48 8d 3d 1b 3a ff ff 	lea    rdi,[rip+0xffffffffffff3a1b]        # 4ad0 <try_secant_tail._omp_fn.0>
   110b5:	48 89 45 90          	mov    QWORD PTR [rbp-0x70],rax
   110b9:	48 8b 85 d8 fd ff ff 	mov    rax,QWORD PTR [rbp-0x228]
   110c0:	4c 89 ee             	mov    rsi,r13
   110c3:	c5 f9 28 b5 60 fe ff 	vmovapd xmm6,XMMWORD PTR [rbp-0x1a0]
   110ca:	ff 
   110cb:	c5 f9 6f bd b0 fd ff 	vmovdqa xmm7,XMMWORD PTR [rbp-0x250]
   110d2:	ff 
   110d3:	44 89 7d a0          	mov    DWORD PTR [rbp-0x60],r15d
   110d7:	48 89 85 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],rax
   110de:	48 8b 05 00 00 00 00 	mov    rax,QWORD PTR [rip+0x0]        # 110e5 <try_secant_tail.constprop.0+0x1205>
   110e5:	4c 89 b5 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],r14
   110ec:	48 89 85 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],rax
   110f3:	48 8b 85 18 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1e8]
   110fa:	44 89 65 98          	mov    DWORD PTR [rbp-0x68],r12d
   110fe:	48 89 85 60 ff ff ff 	mov    QWORD PTR [rbp-0xa0],rax
   11105:	c5 f9 7f 6d 80       	vmovdqa XMMWORD PTR [rbp-0x80],xmm5
   1110a:	c5 f9 29 b5 70 ff ff 	vmovapd XMMWORD PTR [rbp-0x90],xmm6
   11111:	ff 
   11112:	c5 f9 7f bd 40 ff ff 	vmovdqa XMMWORD PTR [rbp-0xc0],xmm7
   11119:	ff 
   1111a:	e8 00 00 00 00       	call   1111f <try_secant_tail.constprop.0+0x123f>
   1111f:	44 8b 8d 4c fe ff ff 	mov    r9d,DWORD PTR [rbp-0x1b4]
   11126:	45 85 c9             	test   r9d,r9d
   11129:	4c 8b 8d d0 fe ff ff 	mov    r9,QWORD PTR [rbp-0x130]
   11130:	0f 8e 9b 01 00 00    	jle    112d1 <try_secant_tail.constprop.0+0x13f1>
   11136:	45 85 e4             	test   r12d,r12d
   11139:	c5 fb 10 55 b8       	vmovsd xmm2,QWORD PTR [rbp-0x48]
   1113e:	c5 fb 10 45 b0       	vmovsd xmm0,QWORD PTR [rbp-0x50]
   11143:	0f 8e 1c 01 00 00    	jle    11265 <try_secant_tail.constprop.0+0x1385>
   11149:	8b bd c0 fd ff ff    	mov    edi,DWORD PTR [rbp-0x240]
   1114f:	4c 89 ad 70 fe ff ff 	mov    QWORD PTR [rbp-0x190],r13
   11156:	31 f6                	xor    esi,esi
   11158:	45 31 d2             	xor    r10d,r10d
   1115b:	44 89 bd a8 fe ff ff 	mov    DWORD PTR [rbp-0x158],r15d
   11162:	4c 8b 9d 10 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1f0]
   11169:	89 f8                	mov    eax,edi
   1116b:	44 89 a5 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r12d
   11172:	4c 8b bd 88 fd ff ff 	mov    r15,QWORD PTR [rbp-0x278]
   11179:	4c 89 b5 30 fe ff ff 	mov    QWORD PTR [rbp-0x1d0],r14
   11180:	c1 e8 02             	shr    eax,0x2
   11183:	44 8b a5 84 fd ff ff 	mov    r12d,DWORD PTR [rbp-0x27c]
   1118a:	44 8b b5 4c fe ff ff 	mov    r14d,DWORD PTR [rbp-0x1b4]
   11191:	4c 89 8d d0 fe ff ff 	mov    QWORD PTR [rbp-0x130],r9
   11198:	48 c1 e0 05          	shl    rax,0x5
   1119c:	41 89 f9             	mov    r9d,edi
   1119f:	90                   	nop
   111a0:	41 81 fc fb ff ff 7f 	cmp    r12d,0x7ffffffb
   111a7:	4c 8d 04 f5 00 00 00 	lea    r8,[rsi*8+0x0]
   111ae:	00 
   111af:	0f 87 53 03 00 00    	ja     11508 <try_secant_tail.constprop.0+0x1628>
   111b5:	4b 8d 0c 03          	lea    rcx,[r11+r8*1]
   111b9:	31 d2                	xor    edx,edx
   111bb:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   111c0:	c5 fd 10 0c 11       	vmovupd ymm1,YMMWORD PTR [rcx+rdx*1]
   111c5:	c5 f5 58 0c 13       	vaddpd ymm1,ymm1,YMMWORD PTR [rbx+rdx*1]
   111ca:	c5 fd 11 0c 13       	vmovupd YMMWORD PTR [rbx+rdx*1],ymm1
   111cf:	48 83 c2 20          	add    rdx,0x20
   111d3:	48 39 d0             	cmp    rax,rdx
   111d6:	75 e8                	jne    111c0 <try_secant_tail.constprop.0+0x12e0>
   111d8:	41 f6 c1 03          	test   r9b,0x3
   111dc:	0f 84 9e 01 00 00    	je     11380 <try_secant_tail.constprop.0+0x14a0>
   111e2:	44 89 ca             	mov    edx,r9d
   111e5:	83 e2 fc             	and    edx,0xfffffffc
   111e8:	89 d1                	mov    ecx,edx
   111ea:	44 89 cf             	mov    edi,r9d
   111ed:	29 d7                	sub    edi,edx
   111ef:	83 ff 01             	cmp    edi,0x1
   111f2:	74 24                	je     11218 <try_secant_tail.constprop.0+0x1338>
   111f4:	4c 8d 2c d3          	lea    r13,[rbx+rdx*8]
   111f8:	48 01 f2             	add    rdx,rsi
   111fb:	40 f6 c7 01          	test   dil,0x1
   111ff:	c4 c1 79 10 4d 00    	vmovupd xmm1,XMMWORD PTR [r13+0x0]
   11205:	c4 c1 71 58 0c d3    	vaddpd xmm1,xmm1,XMMWORD PTR [r11+rdx*8]
   1120b:	c4 c1 79 11 4d 00    	vmovupd XMMWORD PTR [r13+0x0],xmm1
   11211:	74 1f                	je     11232 <try_secant_tail.constprop.0+0x1352>
   11213:	83 e7 fe             	and    edi,0xfffffffe
   11216:	01 f9                	add    ecx,edi
   11218:	48 63 c9             	movsxd rcx,ecx
   1121b:	4d 01 d8             	add    r8,r11
   1121e:	48 c1 e1 03          	shl    rcx,0x3
   11222:	c5 fb 10 0c 0b       	vmovsd xmm1,QWORD PTR [rbx+rcx*1]
   11227:	c4 c1 73 58 0c 08    	vaddsd xmm1,xmm1,QWORD PTR [r8+rcx*1]
   1122d:	c5 fb 11 0c 0b       	vmovsd QWORD PTR [rbx+rcx*1],xmm1
   11232:	41 83 c2 01          	add    r10d,0x1
   11236:	4c 01 fe             	add    rsi,r15
   11239:	45 39 d6             	cmp    r14d,r10d
   1123c:	0f 85 5e ff ff ff    	jne    111a0 <try_secant_tail.constprop.0+0x12c0>
   11242:	4c 8b 8d d0 fe ff ff 	mov    r9,QWORD PTR [rbp-0x130]
   11249:	44 8b bd a8 fe ff ff 	mov    r15d,DWORD PTR [rbp-0x158]
   11250:	4c 8b ad 70 fe ff ff 	mov    r13,QWORD PTR [rbp-0x190]
   11257:	44 8b a5 38 fe ff ff 	mov    r12d,DWORD PTR [rbp-0x1c8]
   1125e:	4c 8b b5 30 fe ff ff 	mov    r14,QWORD PTR [rbp-0x1d0]
   11265:	8b 95 4c fe ff ff    	mov    edx,DWORD PTR [rbp-0x1b4]
   1126b:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   11272:	c5 f9 14 c2          	vunpcklpd xmm0,xmm0,xmm2
   11276:	c5 f9 28 c0          	vmovapd xmm0,xmm0
   1127a:	d1 ea                	shr    edx,1
   1127c:	48 89 f8             	mov    rax,rdi
   1127f:	48 c1 e2 05          	shl    rdx,0x5
   11283:	48 01 fa             	add    rdx,rdi
   11286:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
   1128d:	00 00 00 
   11290:	c5 fd 58 00          	vaddpd ymm0,ymm0,YMMWORD PTR [rax]
   11294:	48 83 c0 20          	add    rax,0x20
   11298:	48 39 d0             	cmp    rax,rdx
   1129b:	75 f3                	jne    11290 <try_secant_tail.constprop.0+0x13b0>
   1129d:	8b bd 4c fe ff ff    	mov    edi,DWORD PTR [rbp-0x1b4]
   112a3:	c5 f9 28 c8          	vmovapd xmm1,xmm0
   112a7:	c4 e3 7d 19 c0 01    	vextractf128 xmm0,ymm0,0x1
   112ad:	c5 f1 58 c0          	vaddpd xmm0,xmm1,xmm0
   112b1:	40 f6 c7 01          	test   dil,0x1
   112b5:	74 15                	je     112cc <try_secant_tail.constprop.0+0x13ec>
   112b7:	89 f8                	mov    eax,edi
   112b9:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   112c0:	83 e0 fe             	and    eax,0xfffffffe
   112c3:	48 c1 e0 04          	shl    rax,0x4
   112c7:	c5 f9 58 04 06       	vaddpd xmm0,xmm0,XMMWORD PTR [rsi+rax*1]
   112cc:	c5 f9 29 45 b0       	vmovapd XMMWORD PTR [rbp-0x50],xmm0
   112d1:	45 85 ff             	test   r15d,r15d
   112d4:	0f 8e dd 07 00 00    	jle    11ab7 <try_secant_tail.constprop.0+0x1bd7>
   112da:	8b b5 e4 fd ff ff    	mov    esi,DWORD PTR [rbp-0x21c]
   112e0:	ba 2f 00 00 00       	mov    edx,0x2f
   112e5:	41 8d 4f ff          	lea    ecx,[r15-0x1]
   112e9:	8d 46 20             	lea    eax,[rsi+0x20]
   112ec:	39 d0                	cmp    eax,edx
   112ee:	0f 42 c2             	cmovb  eax,edx
   112f1:	39 c1                	cmp    ecx,eax
   112f3:	0f 82 3f 15 00 00    	jb     12838 <try_secant_tail.constprop.0+0x2958>
   112f9:	85 f6                	test   esi,esi
   112fb:	0f 84 76 01 00 00    	je     11477 <try_secant_tail.constprop.0+0x1597>
   11301:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   11308:	89 f1                	mov    ecx,esi
   1130a:	31 c0                	xor    eax,eax
   1130c:	eb 11                	jmp    1131f <try_secant_tail.constprop.0+0x143f>
   1130e:	66 90                	xchg   ax,ax
   11310:	83 c0 01             	add    eax,0x1
   11313:	48 83 c2 01          	add    rdx,0x1
   11317:	39 c6                	cmp    esi,eax
   11319:	0f 84 5a 01 00 00    	je     11479 <try_secant_tail.constprop.0+0x1599>
   1131f:	80 3a 00             	cmp    BYTE PTR [rdx],0x0
   11322:	74 ec                	je     11310 <try_secant_tail.constprop.0+0x1430>
   11324:	8b 95 0c ff ff ff    	mov    edx,DWORD PTR [rbp-0xf4]
   1132a:	8b bd 04 ff ff ff    	mov    edi,DWORD PTR [rbp-0xfc]
   11330:	85 d2                	test   edx,edx
   11332:	89 bd d0 fe ff ff    	mov    DWORD PTR [rbp-0x130],edi
   11338:	0f 85 2f 18 00 00    	jne    12b6d <try_secant_tail.constprop.0+0x2c8d>
   1133e:	01 85 f8 fe ff ff    	add    DWORD PTR [rbp-0x108],eax
   11344:	48 8b bd f0 fd ff ff 	mov    rdi,QWORD PTR [rbp-0x210]
   1134b:	48 63 85 f8 fe ff ff 	movsxd rax,DWORD PTR [rbp-0x108]
   11352:	48 8b b5 98 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x168]
   11359:	44 8b ad 00 ff ff ff 	mov    r13d,DWORD PTR [rbp-0x100]
   11360:	48 0f af f8          	imul   rdi,rax
   11364:	48 03 bd b8 fe ff ff 	add    rdi,QWORD PTR [rbp-0x148]
   1136b:	c5 fb 10 1c c6       	vmovsd xmm3,QWORD PTR [rsi+rax*8]
   11370:	c5 f8 77             	vzeroupper
   11373:	e9 70 f2 ff ff       	jmp    105e8 <try_secant_tail.constprop.0+0x708>
   11378:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
   1137f:	00 
   11380:	41 83 c2 01          	add    r10d,0x1
   11384:	45 39 d6             	cmp    r14d,r10d
   11387:	0f 84 b5 fe ff ff    	je     11242 <try_secant_tail.constprop.0+0x1362>
   1138d:	4c 01 fe             	add    rsi,r15
   11390:	4c 8d 04 f5 00 00 00 	lea    r8,[rsi*8+0x0]
   11397:	00 
   11398:	e9 18 fe ff ff       	jmp    111b5 <try_secant_tail.constprop.0+0x12d5>
   1139d:	0f 1f 00             	nop    DWORD PTR [rax]
   113a0:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   113a4:	c5 f9 2f c1          	vcomisd xmm0,xmm1
   113a8:	76 0b                	jbe    113b5 <try_secant_tail.constprop.0+0x14d5>
   113aa:	48 c7 80 00 00 00 00 	mov    QWORD PTR [rax+0x0],0x0
   113b1:	00 00 00 00 
   113b5:	c5 fb 10 25 00 00 00 	vmovsd xmm4,QWORD PTR [rip+0x0]        # 113bd <try_secant_tail.constprop.0+0x14dd>
   113bc:	00 
   113bd:	c5 f9 2f d4          	vcomisd xmm2,xmm4
   113c1:	0f 86 8b 01 00 00    	jbe    11552 <try_secant_tail.constprop.0+0x1672>
   113c7:	c5 f9 28 c4          	vmovapd xmm0,xmm4
   113cb:	c5 eb 5c c8          	vsubsd xmm1,xmm2,xmm0
   113cf:	c5 f9 2f 0d 00 00 00 	vcomisd xmm1,QWORD PTR [rip+0x0]        # 113d7 <try_secant_tail.constprop.0+0x14f7>
   113d6:	00 
   113d7:	0f 86 5b 01 00 00    	jbe    11538 <try_secant_tail.constprop.0+0x1658>
   113dd:	44 8b 9d 04 ff ff ff 	mov    r11d,DWORD PTR [rbp-0xfc]
   113e4:	45 39 dd             	cmp    r13d,r11d
   113e7:	0f 8e dd f8 ff ff    	jle    10cca <try_secant_tail.constprop.0+0xdea>
   113ed:	8b 85 08 ff ff ff    	mov    eax,DWORD PTR [rbp-0xf8]
   113f3:	41 39 c3             	cmp    r11d,eax
   113f6:	0f 8c e4 07 00 00    	jl     11be0 <try_secant_tail.constprop.0+0x1d00>
   113fc:	dd d8                	fstp   st(0)
   113fe:	83 f8 07             	cmp    eax,0x7
   11401:	48 63 8d 00 ff ff ff 	movsxd rcx,DWORD PTR [rbp-0x100]
   11408:	0f 8f d1 0e 00 00    	jg     122df <try_secant_tail.constprop.0+0x23ff>
   1140e:	41 b8 08 00 00 00    	mov    r8d,0x8
   11414:	44 39 c1             	cmp    ecx,r8d
   11417:	44 0f 4e c1          	cmovle r8d,ecx
   1141b:	44 39 c0             	cmp    eax,r8d
   1141e:	7d 1b                	jge    1143b <try_secant_tail.constprop.0+0x155b>
   11420:	48 b8 ff ff ff ff ff 	movabs rax,0x1fffffffffffffff
   11427:	ff ff 1f 
   1142a:	31 d2                	xor    edx,edx
   1142c:	49 63 f0             	movsxd rsi,r8d
   1142f:	48 f7 f1             	div    rcx
   11432:	48 39 f0             	cmp    rax,rsi
   11435:	0f 83 df 0e 00 00    	jae    1231a <try_secant_tail.constprop.0+0x243a>
   1143b:	44 8b 85 0c ff ff ff 	mov    r8d,DWORD PTR [rbp-0xf4]
   11442:	45 85 c0             	test   r8d,r8d
   11445:	0f 85 c9 18 00 00    	jne    12d14 <try_secant_tail.constprop.0+0x2e34>
   1144b:	83 85 f8 fe ff ff 01 	add    DWORD PTR [rbp-0x108],0x1
   11452:	8b 85 f8 fe ff ff    	mov    eax,DWORD PTR [rbp-0x108]
   11458:	39 85 cc fe ff ff    	cmp    DWORD PTR [rbp-0x134],eax
   1145e:	0f 8e a1 18 00 00    	jle    12d05 <try_secant_tail.constprop.0+0x2e25>
   11464:	83 85 c0 fe ff ff 01 	add    DWORD PTR [rbp-0x140],0x1
   1146b:	44 89 9d d0 fe ff ff 	mov    DWORD PTR [rbp-0x130],r11d
   11472:	e9 d1 ee ff ff       	jmp    10348 <try_secant_tail.constprop.0+0x468>
   11477:	31 c9                	xor    ecx,ecx
   11479:	44 89 f8             	mov    eax,r15d
   1147c:	c5 f9 6e c9          	vmovd  xmm1,ecx
   11480:	c5 e9 ef d2          	vpxor  xmm2,xmm2,xmm2
   11484:	bf 20 00 00 00       	mov    edi,0x20
   11489:	8b 95 e4 fd ff ff    	mov    edx,DWORD PTR [rbp-0x21c]
   1148f:	c5 f9 6e df          	vmovd  xmm3,edi
   11493:	c4 e2 7d 58 c9       	vpbroadcastd ymm1,xmm1
   11498:	c5 f5 fe 0d 00 00 00 	vpaddd ymm1,ymm1,YMMWORD PTR [rip+0x0]        # 114a0 <try_secant_tail.constprop.0+0x15c0>
   1149f:	00 
   114a0:	c4 e2 7d 58 db       	vpbroadcastd ymm3,xmm3
   114a5:	29 d0                	sub    eax,edx
   114a7:	48 03 95 58 fe ff ff 	add    rdx,QWORD PTR [rbp-0x1a8]
   114ae:	89 c6                	mov    esi,eax
   114b0:	c1 ee 05             	shr    esi,0x5
   114b3:	48 c1 e6 05          	shl    rsi,0x5
   114b7:	48 01 d6             	add    rsi,rdx
   114ba:	eb 15                	jmp    114d1 <try_secant_tail.constprop.0+0x15f1>
   114bc:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   114c0:	48 83 c2 20          	add    rdx,0x20
   114c4:	c5 f5 fe cb          	vpaddd ymm1,ymm1,ymm3
   114c8:	48 39 f2             	cmp    rdx,rsi
   114cb:	0f 84 40 06 00 00    	je     11b11 <try_secant_tail.constprop.0+0x1c31>
   114d1:	c5 ed 74 02          	vpcmpeqb ymm0,ymm2,YMMWORD PTR [rdx]
   114d5:	c5 fd 74 c2          	vpcmpeqb ymm0,ymm0,ymm2
   114d9:	c4 e2 7d 17 c0       	vptest ymm0,ymm0
   114de:	74 e0                	je     114c0 <try_secant_tail.constprop.0+0x15e0>
   114e0:	c5 f9 7e c8          	vmovd  eax,xmm1
   114e4:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   114eb:	48 98                	cdqe
   114ed:	eb 0e                	jmp    114fd <try_secant_tail.constprop.0+0x161d>
   114ef:	90                   	nop
   114f0:	48 83 c0 01          	add    rax,0x1
   114f4:	41 39 c7             	cmp    r15d,eax
   114f7:	0f 8e ba 05 00 00    	jle    11ab7 <try_secant_tail.constprop.0+0x1bd7>
   114fd:	80 3c 02 00          	cmp    BYTE PTR [rdx+rax*1],0x0
   11501:	74 ed                	je     114f0 <try_secant_tail.constprop.0+0x1610>
   11503:	e9 1c fe ff ff       	jmp    11324 <try_secant_tail.constprop.0+0x1444>
   11508:	31 c9                	xor    ecx,ecx
   1150a:	31 d2                	xor    edx,edx
   1150c:	e9 d9 fc ff ff       	jmp    111ea <try_secant_tail.constprop.0+0x130a>
   11511:	c5 fb 58 8d b0 fe ff 	vaddsd xmm1,xmm0,QWORD PTR [rbp-0x150]
   11518:	ff 
   11519:	c5 fb 10 25 00 00 00 	vmovsd xmm4,QWORD PTR [rip+0x0]        # 11521 <try_secant_tail.constprop.0+0x1641>
   11520:	00 
   11521:	c5 f3 59 cc          	vmulsd xmm1,xmm1,xmm4
   11525:	c4 e2 f1 99 c0       	vfmadd132sd xmm0,xmm1,xmm0
   1152a:	c5 f9 2f d0          	vcomisd xmm2,xmm0
   1152e:	0f 87 97 fe ff ff    	ja     113cb <try_secant_tail.constprop.0+0x14eb>
   11534:	dd d8                	fstp   st(0)
   11536:	eb 02                	jmp    1153a <try_secant_tail.constprop.0+0x165a>
   11538:	dd d8                	fstp   st(0)
   1153a:	c5 fb 58 c2          	vaddsd xmm0,xmm0,xmm2
   1153e:	c5 fb 10 0d 00 00 00 	vmovsd xmm1,QWORD PTR [rip+0x0]        # 11546 <try_secant_tail.constprop.0+0x1666>
   11545:	00 
   11546:	c5 f9 2f c8          	vcomisd xmm1,xmm0
   1154a:	0f 86 7c f7 ff ff    	jbe    10ccc <try_secant_tail.constprop.0+0xdec>
   11550:	eb 02                	jmp    11554 <try_secant_tail.constprop.0+0x1674>
   11552:	dd d8                	fstp   st(0)
   11554:	c5 fb 10 ad a8 fe ff 	vmovsd xmm5,QWORD PTR [rbp-0x158]
   1155b:	ff 
   1155c:	c5 d1 54 05 00 00 00 	vandpd xmm0,xmm5,XMMWORD PTR [rip+0x0]        # 11564 <try_secant_tail.constprop.0+0x1684>
   11563:	00 
   11564:	c5 fb 58 85 b0 fe ff 	vaddsd xmm0,xmm0,QWORD PTR [rbp-0x150]
   1156b:	ff 
   1156c:	c5 fb 58 85 f8 fd ff 	vaddsd xmm0,xmm0,QWORD PTR [rbp-0x208]
   11573:	ff 
   11574:	c5 fb 59 05 00 00 00 	vmulsd xmm0,xmm0,QWORD PTR [rip+0x0]        # 1157c <try_secant_tail.constprop.0+0x169c>
   1157b:	00 
   1157c:	c5 fb 10 ad 00 fe ff 	vmovsd xmm5,QWORD PTR [rbp-0x200]
   11583:	ff 
   11584:	c5 d1 54 0d 00 00 00 	vandpd xmm1,xmm5,XMMWORD PTR [rip+0x0]        # 1158c <try_secant_tail.constprop.0+0x16ac>
   1158b:	00 
   1158c:	8b 85 04 ff ff ff    	mov    eax,DWORD PTR [rbp-0xfc]
   11592:	89 85 d0 fe ff ff    	mov    DWORD PTR [rbp-0x130],eax
   11598:	c5 f9 2f c8          	vcomisd xmm1,xmm0
   1159c:	0f 86 aa 05 00 00    	jbe    11b4c <try_secant_tail.constprop.0+0x1c6c>
   115a2:	8b 85 88 fe ff ff    	mov    eax,DWORD PTR [rbp-0x178]
   115a8:	44 3b ad d0 fe ff ff 	cmp    r13d,DWORD PTR [rbp-0x130]
   115af:	4c 89 ff             	mov    rdi,r15
   115b2:	89 85 c0 fe ff ff    	mov    DWORD PTR [rbp-0x140],eax
   115b8:	0f 84 03 17 00 00    	je     12cc1 <try_secant_tail.constprop.0+0x2de1>
   115be:	48 89 fe             	mov    rsi,rdi
   115c1:	48 8b bd 18 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1e8]
   115c8:	48 89 9d d0 fe ff ff 	mov    QWORD PTR [rbp-0x130],rbx
   115cf:	e8 9c 26 ff ff       	call   3c70 <local_dependency_svd>
   115d4:	4c 8b 95 d0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x130]
   115db:	83 f8 01             	cmp    eax,0x1
   115de:	0f 85 f7 f6 ff ff    	jne    10cdb <try_secant_tail.constprop.0+0xdfb>
   115e4:	8b 85 04 ff ff ff    	mov    eax,DWORD PTR [rbp-0xfc]
   115ea:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   115f1:	c7 85 0c ff ff ff 01 	mov    DWORD PTR [rbp-0xf4],0x1
   115f8:	00 00 00 
   115fb:	89 85 d0 fe ff ff    	mov    DWORD PTR [rbp-0x130],eax
   11601:	48 8b bd 58 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1a8]
   11608:	4c 8d ad 40 ff ff ff 	lea    r13,[rbp-0xc0]
   1160f:	e8 00 00 00 00       	call   11614 <try_secant_tail.constprop.0+0x1734>
   11614:	48 8b bd 10 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f0]
   1161b:	e8 00 00 00 00       	call   11620 <try_secant_tail.constprop.0+0x1740>
   11620:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   11627:	e8 00 00 00 00       	call   1162c <try_secant_tail.constprop.0+0x174c>
   1162c:	4c 8b 95 f8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x108]
   11633:	48 8b 85 d0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x230]
   1163a:	8b 9d d0 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x130]
   11640:	4c 89 ee             	mov    rsi,r13
   11643:	48 8d 3d e6 ef fe ff 	lea    rdi,[rip+0xfffffffffffeefe6]        # 630 <relres._omp_fn.0>
   1164a:	c5 f9 6e bd cc fe ff 	vmovd  xmm7,DWORD PTR [rbp-0x134]
   11651:	ff 
   11652:	c5 f9 6f ad b0 fd ff 	vmovdqa xmm5,XMMWORD PTR [rbp-0x250]
   11659:	ff 
   1165a:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   11661:	89 58 04             	mov    DWORD PTR [rax+0x4],ebx
   11664:	8b 9d 48 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x1b8]
   1166a:	c7 00 03 00 00 00    	mov    DWORD PTR [rax],0x3
   11670:	48 8b 85 18 ff ff ff 	mov    rax,QWORD PTR [rbp-0xe8]
   11677:	c4 e3 41 22 c3 01    	vpinsrd xmm0,xmm7,ebx,0x1
   1167d:	48 c7 85 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],0x0
   11684:	00 00 00 00 
   11688:	48 89 85 70 ff ff ff 	mov    QWORD PTR [rbp-0x90],rax
   1168f:	48 63 85 cc fe ff ff 	movsxd rax,DWORD PTR [rbp-0x134]
   11696:	48 0f af 85 f0 fe ff 	imul   rax,QWORD PTR [rbp-0x110]
   1169d:	ff 
   1169e:	c7 85 58 ff ff ff 00 	mov    DWORD PTR [rbp-0xa8],0x0
   116a5:	00 00 00 
   116a8:	48 c7 85 40 ff ff ff 	mov    QWORD PTR [rbp-0xc0],0x0
   116af:	00 00 00 00 
   116b3:	c7 85 48 ff ff ff 00 	mov    DWORD PTR [rbp-0xb8],0x0
   116ba:	00 00 00 
   116bd:	48 3d 3f 42 0f 00    	cmp    rax,0xf423f
   116c3:	c5 f9 d6 85 78 ff ff 	vmovq  QWORD PTR [rbp-0x88],xmm0
   116ca:	ff 
   116cb:	0f 9f c2             	setg   dl
   116ce:	81 fb 7f 01 00 00    	cmp    ebx,0x17f
   116d4:	c5 f9 7f ad 60 ff ff 	vmovdqa XMMWORD PTR [rbp-0xa0],xmm5
   116db:	ff 
   116dc:	0f 9e c0             	setle  al
   116df:	31 c9                	xor    ecx,ecx
   116e1:	21 c2                	and    edx,eax
   116e3:	83 f2 01             	xor    edx,0x1
   116e6:	0f b6 d2             	movzx  edx,dl
   116e9:	e8 00 00 00 00       	call   116ee <try_secant_tail.constprop.0+0x180e>
   116ee:	db ad 50 ff ff ff    	fld    TBYTE PTR [rbp-0xb0]
   116f4:	4c 8b 95 f8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x108]
   116fb:	db ad 40 ff ff ff    	fld    TBYTE PTR [rbp-0xc0]
   11701:	d9 ee                	fldz
   11703:	df f1                	fcomip st,st(1)
   11705:	0f 84 ea 11 00 00    	je     128f5 <try_secant_tail.constprop.0+0x2a15>
   1170b:	d9 fa                	fsqrt
   1170d:	d9 c9                	fxch   st(1)
   1170f:	48 8b b5 c8 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x238]
   11716:	48 8b 85 d0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x230]
   1171d:	48 85 f6             	test   rsi,rsi
   11720:	d9 fa                	fsqrt
   11722:	de f1                	fdivrp st(1),st
   11724:	dd 58 18             	fstp   QWORD PTR [rax+0x18]
   11727:	0f 84 f2 14 00 00    	je     12c1f <try_secant_tail.constprop.0+0x2d3f>
   1172d:	8b 9d 48 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x1b8]
   11733:	85 db                	test   ebx,ebx
   11735:	0f 8e 5f 15 00 00    	jle    12c9a <try_secant_tail.constprop.0+0x2dba>
   1173b:	8d 43 ff             	lea    eax,[rbx-0x1]
   1173e:	48 8b 95 18 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xe8]
   11745:	83 f8 02             	cmp    eax,0x2
   11748:	0f 86 35 15 00 00    	jbe    12c83 <try_secant_tail.constprop.0+0x2da3>
   1174e:	89 d9                	mov    ecx,ebx
   11750:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   11754:	31 c0                	xor    eax,eax
   11756:	c1 e9 02             	shr    ecx,0x2
   11759:	c5 fd 28 d3          	vmovapd ymm2,ymm3
   1175d:	48 c1 e1 05          	shl    rcx,0x5
   11761:	c5 fd 10 0c 06       	vmovupd ymm1,YMMWORD PTR [rsi+rax*1]
   11766:	c5 fd 10 04 02       	vmovupd ymm0,YMMWORD PTR [rdx+rax*1]
   1176b:	48 83 c0 20          	add    rax,0x20
   1176f:	48 39 c8             	cmp    rax,rcx
   11772:	c5 fd 5c c1          	vsubpd ymm0,ymm0,ymm1
   11776:	c4 e2 f5 b8 d1       	vfmadd231pd ymm2,ymm1,ymm1
   1177b:	c4 e2 fd b8 d8       	vfmadd231pd ymm3,ymm0,ymm0
   11780:	75 df                	jne    11761 <try_secant_tail.constprop.0+0x1881>
   11782:	c4 e3 7d 19 d8 01    	vextractf128 xmm0,ymm3,0x1
   11788:	c4 e3 7d 19 d1 01    	vextractf128 xmm1,ymm2,0x1
   1178e:	8b b5 48 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b8]
   11794:	8b bd 48 fe ff ff    	mov    edi,DWORD PTR [rbp-0x1b8]
   1179a:	c5 f9 58 db          	vaddpd xmm3,xmm0,xmm3
   1179e:	c5 f1 58 d2          	vaddpd xmm2,xmm1,xmm2
   117a2:	83 e6 fc             	and    esi,0xfffffffc
   117a5:	39 f7                	cmp    edi,esi
   117a7:	89 b5 c4 fd ff ff    	mov    DWORD PTR [rbp-0x23c],esi
   117ad:	89 f0                	mov    eax,esi
   117af:	c5 e1 15 c3          	vunpckhpd xmm0,xmm3,xmm3
   117b3:	c5 e9 15 ca          	vunpckhpd xmm1,xmm2,xmm2
   117b7:	c5 f9 58 c3          	vaddpd xmm0,xmm0,xmm3
   117bb:	c5 f1 58 ca          	vaddpd xmm1,xmm1,xmm2
   117bf:	0f 84 52 14 00 00    	je     12c17 <try_secant_tail.constprop.0+0x2d37>
   117c5:	c5 f8 77             	vzeroupper
   117c8:	8b 8d 48 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b8]
   117ce:	29 c1                	sub    ecx,eax
   117d0:	83 f9 01             	cmp    ecx,0x1
   117d3:	74 3d                	je     11812 <try_secant_tail.constprop.0+0x1932>
   117d5:	48 8b 9d c8 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x238]
   117dc:	c5 f9 10 04 c2       	vmovupd xmm0,XMMWORD PTR [rdx+rax*8]
   117e1:	f6 c1 01             	test   cl,0x1
   117e4:	c5 f9 10 0c c3       	vmovupd xmm1,XMMWORD PTR [rbx+rax*8]
   117e9:	c5 f9 5c c1          	vsubpd xmm0,xmm0,xmm1
   117ed:	c4 e2 f1 b8 d1       	vfmadd231pd xmm2,xmm1,xmm1
   117f2:	c4 e2 e1 98 c0       	vfmadd132pd xmm0,xmm3,xmm0
   117f7:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   117fb:	c5 f1 58 c0          	vaddpd xmm0,xmm1,xmm0
   117ff:	c5 e9 15 ca          	vunpckhpd xmm1,xmm2,xmm2
   11803:	c5 f1 58 ca          	vaddpd xmm1,xmm1,xmm2
   11807:	74 2f                	je     11838 <try_secant_tail.constprop.0+0x1958>
   11809:	83 e1 fe             	and    ecx,0xfffffffe
   1180c:	01 8d c4 fd ff ff    	add    DWORD PTR [rbp-0x23c],ecx
   11812:	48 63 85 c4 fd ff ff 	movsxd rax,DWORD PTR [rbp-0x23c]
   11819:	48 8b 9d c8 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x238]
   11820:	c5 fb 10 14 c2       	vmovsd xmm2,QWORD PTR [rdx+rax*8]
   11825:	c5 fb 10 1c c3       	vmovsd xmm3,QWORD PTR [rbx+rax*8]
   1182a:	c5 eb 5c d3          	vsubsd xmm2,xmm2,xmm3
   1182e:	c4 e2 e1 b9 cb       	vfmadd231sd xmm1,xmm3,xmm3
   11833:	c4 e2 e9 b9 c2       	vfmadd231sd xmm0,xmm2,xmm2
   11838:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
   1183c:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
   11840:	c5 f3 58 0d 00 00 00 	vaddsd xmm1,xmm1,QWORD PTR [rip+0x0]        # 11848 <try_secant_tail.constprop.0+0x1968>
   11847:	00 
   11848:	c5 fb 5e c1          	vdivsd xmm0,xmm0,xmm1
   1184c:	48 8b 85 d0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x230]
   11853:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   1185a:	c5 fb 11 40 20       	vmovsd QWORD PTR [rax+0x20],xmm0
   1185f:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
   11866:	41 bc 01 00 00 00    	mov    r12d,0x1
   1186c:	e8 00 00 00 00       	call   11871 <try_secant_tail.constprop.0+0x1991>
   11871:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   11878:	e8 00 00 00 00       	call   1187d <try_secant_tail.constprop.0+0x199d>
   1187d:	48 8b bd 20 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe0]
   11884:	e8 00 00 00 00       	call   11889 <try_secant_tail.constprop.0+0x19a9>
   11889:	4c 89 f7             	mov    rdi,r14
   1188c:	e8 00 00 00 00       	call   11891 <try_secant_tail.constprop.0+0x19b1>
   11891:	48 8b bd f8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x108]
   11898:	e8 00 00 00 00       	call   1189d <try_secant_tail.constprop.0+0x19bd>
   1189d:	e9 d5 e6 ff ff       	jmp    ff77 <try_secant_tail.constprop.0+0x97>
   118a2:	8b 85 f8 fe ff ff    	mov    eax,DWORD PTR [rbp-0x108]
   118a8:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
   118ac:	49 b8 eb 11 31 13 bb 	movabs r8,0x94d049bb133111eb
   118b3:	49 d0 94 
   118b6:	48 be 15 7c 4a 7f b9 	movabs rsi,0x9e3779b97f4a7c15
   118bd:	79 37 9e 
   118c0:	48 03 b5 d8 fd ff ff 	add    rsi,QWORD PTR [rbp-0x228]
   118c7:	c5 7b 12 c4          	vmovddup xmm8,xmm4
   118cb:	49 bb b9 e5 e4 1c 6d 	movabs r11,0xbf58476d1ce4e5b9
   118d2:	47 58 bf 
   118d5:	83 c0 01             	add    eax,0x1
   118d8:	48 63 d0             	movsxd rdx,eax
   118db:	89 85 c8 fe ff ff    	mov    DWORD PTR [rbp-0x138],eax
   118e1:	48 89 d0             	mov    rax,rdx
   118e4:	49 0f af d3          	imul   rdx,r11
   118e8:	49 0f af c0          	imul   rax,r8
   118ec:	48 01 f0             	add    rax,rsi
   118ef:	48 89 c1             	mov    rcx,rax
   118f2:	48 c1 e9 1e          	shr    rcx,0x1e
   118f6:	48 31 c8             	xor    rax,rcx
   118f9:	49 0f af c3          	imul   rax,r11
   118fd:	48 89 c1             	mov    rcx,rax
   11900:	48 c1 e9 1b          	shr    rcx,0x1b
   11904:	48 31 c1             	xor    rcx,rax
   11907:	48 8d 04 32          	lea    rax,[rdx+rsi*1]
   1190b:	48 89 c2             	mov    rdx,rax
   1190e:	49 0f af c8          	imul   rcx,r8
   11912:	48 c1 ea 1e          	shr    rdx,0x1e
   11916:	48 31 c2             	xor    rdx,rax
   11919:	49 0f af d3          	imul   rdx,r11
   1191d:	48 89 d0             	mov    rax,rdx
   11920:	48 c1 e8 1b          	shr    rax,0x1b
   11924:	48 31 d0             	xor    rax,rdx
   11927:	48 89 ca             	mov    rdx,rcx
   1192a:	49 0f af c0          	imul   rax,r8
   1192e:	48 c1 ea 1f          	shr    rdx,0x1f
   11932:	48 31 ca             	xor    rdx,rcx
   11935:	48 c1 ea 0b          	shr    rdx,0xb
   11939:	c4 e1 cb 2a d2       	vcvtsi2sd xmm2,xmm6,rdx
   1193e:	48 89 c2             	mov    rdx,rax
   11941:	48 c1 ea 1f          	shr    rdx,0x1f
   11945:	48 31 d0             	xor    rax,rdx
   11948:	48 c1 e8 0b          	shr    rax,0xb
   1194c:	45 85 e4             	test   r12d,r12d
   1194f:	c4 e1 cb 2a c8       	vcvtsi2sd xmm1,xmm6,rax
   11954:	c5 fb 12 35 00 00 00 	vmovddup xmm6,QWORD PTR [rip+0x0]        # 1195c <try_secant_tail.constprop.0+0x1a7c>
   1195b:	00 
   1195c:	c5 e9 14 d1          	vunpcklpd xmm2,xmm2,xmm1
   11960:	c5 fb 12 0d 00 00 00 	vmovddup xmm1,QWORD PTR [rip+0x0]        # 11968 <try_secant_tail.constprop.0+0x1a88>
   11967:	00 
   11968:	c4 e2 f1 98 d6       	vfmadd132pd xmm2,xmm1,xmm6
   1196d:	c5 e9 59 95 70 fd ff 	vmulpd xmm2,xmm2,XMMWORD PTR [rbp-0x290]
   11974:	ff 
   11975:	c5 39 59 c2          	vmulpd xmm8,xmm8,xmm2
   11979:	0f 8e 29 01 00 00    	jle    11aa8 <try_secant_tail.constprop.0+0x1bc8>
   1197f:	48 8b 85 f0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x210]
   11986:	c5 6b 59 d0          	vmulsd xmm10,xmm2,xmm0
   1198a:	41 83 fc 01          	cmp    r12d,0x1
   1198e:	c5 e9 15 d2          	vunpckhpd xmm2,xmm2,xmm2
   11992:	c5 eb 59 f0          	vmulsd xmm6,xmm2,xmm0
   11996:	48 8d 14 03          	lea    rdx,[rbx+rax*1]
   1199a:	0f 84 de 0d 00 00    	je     1277e <try_secant_tail.constprop.0+0x289e>
   119a0:	48 8d 43 20          	lea    rax,[rbx+0x20]
   119a4:	48 39 c2             	cmp    rdx,rax
   119a7:	0f 82 d1 0d 00 00    	jb     1277e <try_secant_tail.constprop.0+0x289e>
   119ad:	83 bd a4 fe ff ff 02 	cmp    DWORD PTR [rbp-0x15c],0x2
   119b4:	0f 86 be 11 00 00    	jbe    12b78 <try_secant_tail.constprop.0+0x2c98>
   119ba:	44 89 e1             	mov    ecx,r12d
   119bd:	c4 42 7d 19 da       	vbroadcastsd ymm11,xmm10
   119c2:	c4 62 7d 19 ce       	vbroadcastsd ymm9,xmm6
   119c7:	31 c0                	xor    eax,eax
   119c9:	c1 e9 02             	shr    ecx,0x2
   119cc:	48 c1 e1 05          	shl    rcx,0x5
   119d0:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   119d4:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   119db:	00 00 00 00 
   119df:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   119e6:	00 00 00 00 
   119ea:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   119f1:	00 00 00 00 
   119f5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   119fc:	00 00 00 00 
   11a00:	c5 fd 10 0c 07       	vmovupd ymm1,YMMWORD PTR [rdi+rax*1]
   11a05:	c5 7d 29 da          	vmovapd ymm2,ymm11
   11a09:	c4 e2 f5 a8 14 03    	vfmadd213pd ymm2,ymm1,YMMWORD PTR [rbx+rax*1]
   11a0f:	c5 fd 11 14 03       	vmovupd YMMWORD PTR [rbx+rax*1],ymm2
   11a14:	c4 e2 b5 a8 0c 02    	vfmadd213pd ymm1,ymm9,YMMWORD PTR [rdx+rax*1]
   11a1a:	c5 fd 11 0c 02       	vmovupd YMMWORD PTR [rdx+rax*1],ymm1
   11a1f:	48 83 c0 20          	add    rax,0x20
   11a23:	48 39 c8             	cmp    rax,rcx
   11a26:	75 d8                	jne    11a00 <try_secant_tail.constprop.0+0x1b20>
   11a28:	44 89 e0             	mov    eax,r12d
   11a2b:	83 e0 fc             	and    eax,0xfffffffc
   11a2e:	41 39 c4             	cmp    r12d,eax
   11a31:	89 c2                	mov    edx,eax
   11a33:	74 73                	je     11aa8 <try_secant_tail.constprop.0+0x1bc8>
   11a35:	44 89 e1             	mov    ecx,r12d
   11a38:	29 c1                	sub    ecx,eax
   11a3a:	83 f9 01             	cmp    ecx,0x1
   11a3d:	74 46                	je     11a85 <try_secant_tail.constprop.0+0x1ba5>
   11a3f:	4c 8d 04 d3          	lea    r8,[rbx+rdx*8]
   11a43:	c4 41 7b 12 ca       	vmovddup xmm9,xmm10
   11a48:	c5 fb 12 d6          	vmovddup xmm2,xmm6
   11a4c:	49 01 d2             	add    r10,rdx
   11a4f:	48 8b b5 f0 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x110]
   11a56:	48 01 d6             	add    rsi,rdx
   11a59:	48 8b 95 b8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x148]
   11a60:	f6 c1 01             	test   cl,0x1
   11a63:	c4 a1 79 10 0c d2    	vmovupd xmm1,XMMWORD PTR [rdx+r10*8]
   11a69:	c4 42 f1 a8 08       	vfmadd213pd xmm9,xmm1,XMMWORD PTR [r8]
   11a6e:	c4 41 79 11 08       	vmovupd XMMWORD PTR [r8],xmm9
   11a73:	c4 e2 e9 a8 0c f3    	vfmadd213pd xmm1,xmm2,XMMWORD PTR [rbx+rsi*8]
   11a79:	c5 f9 11 0c f3       	vmovupd XMMWORD PTR [rbx+rsi*8],xmm1
   11a7e:	74 28                	je     11aa8 <try_secant_tail.constprop.0+0x1bc8>
   11a80:	83 e1 fe             	and    ecx,0xfffffffe
   11a83:	01 c8                	add    eax,ecx
   11a85:	48 63 d0             	movsxd rdx,eax
   11a88:	44 01 e0             	add    eax,r12d
   11a8b:	c5 fb 10 0c d7       	vmovsd xmm1,QWORD PTR [rdi+rdx*8]
   11a90:	c4 62 f1 a9 14 d3    	vfmadd213sd xmm10,xmm1,QWORD PTR [rbx+rdx*8]
   11a96:	48 98                	cdqe
   11a98:	c5 7b 11 14 d3       	vmovsd QWORD PTR [rbx+rdx*8],xmm10
   11a9d:	c4 e2 c9 a9 0c c3    	vfmadd213sd xmm1,xmm6,QWORD PTR [rbx+rax*8]
   11aa3:	c5 fb 11 0c c3       	vmovsd QWORD PTR [rbx+rax*8],xmm1
   11aa8:	c5 39 58 45 b0       	vaddpd xmm8,xmm8,XMMWORD PTR [rbp-0x50]
   11aad:	c5 79 29 45 b0       	vmovapd XMMWORD PTR [rbp-0x50],xmm8
   11ab2:	e9 cf ea ff ff       	jmp    10586 <try_secant_tail.constprop.0+0x6a6>
   11ab7:	8b 85 04 ff ff ff    	mov    eax,DWORD PTR [rbp-0xfc]
   11abd:	44 01 bd c0 fe ff ff 	add    DWORD PTR [rbp-0x140],r15d
   11ac4:	4d 89 cd             	mov    r13,r9
   11ac7:	8b 9d 0c ff ff ff    	mov    ebx,DWORD PTR [rbp-0xf4]
   11acd:	89 85 d0 fe ff ff    	mov    DWORD PTR [rbp-0x130],eax
   11ad3:	8b 85 c8 fe ff ff    	mov    eax,DWORD PTR [rbp-0x138]
   11ad9:	89 85 f8 fe ff ff    	mov    DWORD PTR [rbp-0x108],eax
   11adf:	e9 57 eb ff ff       	jmp    1063b <try_secant_tail.constprop.0+0x75b>
   11ae4:	c5 f8 77             	vzeroupper
   11ae7:	e9 2a f1 ff ff       	jmp    10c16 <try_secant_tail.constprop.0+0xd36>
   11aec:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
   11af0:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
   11af4:	31 d2                	xor    edx,edx
   11af6:	31 c9                	xor    ecx,ecx
   11af8:	c5 f9 28 e7          	vmovapd xmm4,xmm7
   11afc:	c5 f9 28 df          	vmovapd xmm3,xmm7
   11b00:	c5 f9 28 d7          	vmovapd xmm2,xmm7
   11b04:	c5 f9 28 f7          	vmovapd xmm6,xmm7
   11b08:	c5 f9 28 c5          	vmovapd xmm0,xmm5
   11b0c:	e9 71 e9 ff ff       	jmp    10482 <try_secant_tail.constprop.0+0x5a2>
   11b11:	a8 1f                	test   al,0x1f
   11b13:	74 a2                	je     11ab7 <try_secant_tail.constprop.0+0x1bd7>
   11b15:	83 e0 e0             	and    eax,0xffffffe0
   11b18:	01 c8                	add    eax,ecx
   11b1a:	e9 c5 f9 ff ff       	jmp    114e4 <try_secant_tail.constprop.0+0x1604>
   11b1f:	83 85 f8 fe ff ff 01 	add    DWORD PTR [rbp-0x108],0x1
   11b26:	8b 85 f8 fe ff ff    	mov    eax,DWORD PTR [rbp-0x108]
   11b2c:	39 85 cc fe ff ff    	cmp    DWORD PTR [rbp-0x134],eax
   11b32:	0f 8e 9f 11 00 00    	jle    12cd7 <try_secant_tail.constprop.0+0x2df7>
   11b38:	83 85 c0 fe ff ff 01 	add    DWORD PTR [rbp-0x140],0x1
   11b3f:	e9 04 e8 ff ff       	jmp    10348 <try_secant_tail.constprop.0+0x468>
   11b44:	c5 f8 77             	vzeroupper
   11b47:	e9 de ef ff ff       	jmp    10b2a <try_secant_tail.constprop.0+0xc4a>
   11b4c:	8b b5 0c ff ff ff    	mov    esi,DWORD PTR [rbp-0xf4]
   11b52:	85 f6                	test   esi,esi
   11b54:	0f 85 1a 11 00 00    	jne    12c74 <try_secant_tail.constprop.0+0x2d94>
   11b5a:	83 85 f8 fe ff ff 01 	add    DWORD PTR [rbp-0x108],0x1
   11b61:	8b 85 f8 fe ff ff    	mov    eax,DWORD PTR [rbp-0x108]
   11b67:	39 85 cc fe ff ff    	cmp    DWORD PTR [rbp-0x134],eax
   11b6d:	7f c9                	jg     11b38 <try_secant_tail.constprop.0+0x1c58>
   11b6f:	49 89 da             	mov    r10,rbx
   11b72:	e9 23 ee ff ff       	jmp    1099a <try_secant_tail.constprop.0+0xaba>
   11b77:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
   11b7e:	00 00 
   11b80:	8b 95 d0 fe ff ff    	mov    edx,DWORD PTR [rbp-0x130]
   11b86:	4c 89 d7             	mov    rdi,r10
   11b89:	44 89 e9             	mov    ecx,r13d
   11b8c:	4c 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r9
   11b93:	4c 89 95 70 fe ff ff 	mov    QWORD PTR [rbp-0x190],r10
   11b9a:	e8 f1 17 ff ff       	call   3390 <project_cgs2>
   11b9f:	4c 8b 95 70 fe ff ff 	mov    r10,QWORD PTR [rbp-0x190]
   11ba6:	44 89 ee             	mov    esi,r13d
   11ba9:	c5 fb 11 85 e8 fd ff 	vmovsd QWORD PTR [rbp-0x218],xmm0
   11bb0:	ff 
   11bb1:	4c 89 d7             	mov    rdi,r10
   11bb4:	e8 87 e6 fe ff       	call   240 <norm2>
   11bb9:	c5 fb 10 b5 a8 fe ff 	vmovsd xmm6,QWORD PTR [rbp-0x158]
   11bc0:	ff 
   11bc1:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   11bc8:	4c 8b 8d 38 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c8]
   11bcf:	c5 f9 28 d0          	vmovapd xmm2,xmm0
   11bd3:	c5 fb 11 b5 00 fe ff 	vmovsd QWORD PTR [rbp-0x200],xmm6
   11bda:	ff 
   11bdb:	e9 4a f0 ff ff       	jmp    10c2a <try_secant_tail.constprop.0+0xd4a>
   11be0:	4c 89 f8             	mov    rax,r15
   11be3:	45 89 ef             	mov    r15d,r13d
   11be6:	4d 89 cd             	mov    r13,r9
   11be9:	c5 fb 10 8d 00 fe ff 	vmovsd xmm1,QWORD PTR [rbp-0x200]
   11bf0:	ff 
   11bf1:	49 89 c1             	mov    r9,rax
   11bf4:	48 8b 85 10 ff ff ff 	mov    rax,QWORD PTR [rbp-0xf0]
   11bfb:	8b 9d 88 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x178]
   11c01:	48 89 85 a8 fe ff ff 	mov    QWORD PTR [rbp-0x158],rax
   11c08:	48 89 c7             	mov    rdi,rax
   11c0b:	49 63 c3             	movsxd rax,r11d
   11c0e:	48 0f af 85 20 fe ff 	imul   rax,QWORD PTR [rbp-0x1e0]
   11c15:	ff 
   11c16:	48 89 85 90 fe ff ff 	mov    QWORD PTR [rbp-0x170],rax
   11c1d:	48 c1 e0 03          	shl    rax,0x3
   11c21:	48 89 85 88 fe ff ff 	mov    QWORD PTR [rbp-0x178],rax
   11c28:	48 01 f8             	add    rax,rdi
   11c2b:	45 85 ff             	test   r15d,r15d
   11c2e:	0f 8e d7 00 00 00    	jle    11d0b <try_secant_tail.constprop.0+0x1e2b>
   11c34:	c5 fb 10 ad b0 fe ff 	vmovsd xmm5,QWORD PTR [rbp-0x150]
   11c3b:	ff 
   11c3c:	41 83 ff 01          	cmp    r15d,0x1
   11c40:	c5 d3 5e ea          	vdivsd xmm5,xmm5,xmm2
   11c44:	0f 84 66 0c 00 00    	je     128b0 <try_secant_tail.constprop.0+0x29d0>
   11c4a:	48 8b bd 08 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f8]
   11c51:	48 89 c2             	mov    rdx,rax
   11c54:	49 8d 4c 39 08       	lea    rcx,[r9+rdi*1+0x8]
   11c59:	48 29 ca             	sub    rdx,rcx
   11c5c:	48 83 fa 10          	cmp    rdx,0x10
   11c60:	0f 86 73 0c 00 00    	jbe    128d9 <try_secant_tail.constprop.0+0x29f9>
   11c66:	41 8d 57 ff          	lea    edx,[r15-0x1]
   11c6a:	44 89 ff             	mov    edi,r15d
   11c6d:	83 fa 02             	cmp    edx,0x2
   11c70:	0f 86 22 0f 00 00    	jbe    12b98 <try_secant_tail.constprop.0+0x2cb8>
   11c76:	44 89 f9             	mov    ecx,r15d
   11c79:	c4 e2 7d 19 dd       	vbroadcastsd ymm3,xmm5
   11c7e:	31 d2                	xor    edx,edx
   11c80:	c1 e9 02             	shr    ecx,0x2
   11c83:	48 c1 e1 05          	shl    rcx,0x5
   11c87:	0f 1f 00             	nop    DWORD PTR [rax]
   11c8a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   11c91:	00 00 00 00 
   11c95:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   11c9c:	00 00 00 00 
   11ca0:	c4 c1 65 59 04 12    	vmulpd ymm0,ymm3,YMMWORD PTR [r10+rdx*1]
   11ca6:	c5 fd 11 04 10       	vmovupd YMMWORD PTR [rax+rdx*1],ymm0
   11cab:	48 83 c2 20          	add    rdx,0x20
   11caf:	48 39 d1             	cmp    rcx,rdx
   11cb2:	75 ec                	jne    11ca0 <try_secant_tail.constprop.0+0x1dc0>
   11cb4:	44 89 f9             	mov    ecx,r15d
   11cb7:	83 e1 fc             	and    ecx,0xfffffffc
   11cba:	41 39 cf             	cmp    r15d,ecx
   11cbd:	89 ce                	mov    esi,ecx
   11cbf:	74 4a                	je     11d0b <try_secant_tail.constprop.0+0x1e2b>
   11cc1:	44 89 ff             	mov    edi,r15d
   11cc4:	29 cf                	sub    edi,ecx
   11cc6:	83 ff 01             	cmp    edi,0x1
   11cc9:	74 32                	je     11cfd <try_secant_tail.constprop.0+0x1e1d>
   11ccb:	48 8b 95 20 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1e0]
   11cd2:	c5 fb 12 c5          	vmovddup xmm0,xmm5
   11cd6:	48 01 f2             	add    rdx,rsi
   11cd9:	48 03 b5 90 fe ff ff 	add    rsi,QWORD PTR [rbp-0x170]
   11ce0:	40 f6 c7 01          	test   dil,0x1
   11ce4:	c4 c1 79 59 04 d1    	vmulpd xmm0,xmm0,XMMWORD PTR [r9+rdx*8]
   11cea:	48 8b 95 a8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x158]
   11cf1:	c5 f9 11 04 f2       	vmovupd XMMWORD PTR [rdx+rsi*8],xmm0
   11cf6:	74 13                	je     11d0b <try_secant_tail.constprop.0+0x1e2b>
   11cf8:	83 e7 fe             	and    edi,0xfffffffe
   11cfb:	01 f9                	add    ecx,edi
   11cfd:	48 63 c9             	movsxd rcx,ecx
   11d00:	c4 c1 53 59 2c ca    	vmulsd xmm5,xmm5,QWORD PTR [r10+rcx*8]
   11d06:	c5 fb 11 2c c8       	vmovsd QWORD PTR [rax+rcx*8],xmm5
   11d0b:	41 83 fb 5f          	cmp    r11d,0x5f
   11d0f:	8b 8d 00 ff ff ff    	mov    ecx,DWORD PTR [rbp-0x100]
   11d15:	0f 8e cc 07 00 00    	jle    124e7 <try_secant_tail.constprop.0+0x2607>
   11d1b:	d9 ee                	fldz
   11d1d:	d9 c9                	fxch   st(1)
   11d1f:	db f1                	fcomi  st,st(1)
   11d21:	dd d9                	fstp   st(1)
   11d23:	0f 86 d2 06 00 00    	jbe    123fb <try_secant_tail.constprop.0+0x251b>
   11d29:	d9 c0                	fld    st(0)
   11d2b:	c5 eb 58 05 00 00 00 	vaddsd xmm0,xmm2,QWORD PTR [rip+0x0]        # 11d33 <try_secant_tail.constprop.0+0x1e53>
   11d32:	00 
   11d33:	c5 fb 10 ad e8 fd ff 	vmovsd xmm5,QWORD PTR [rbp-0x218]
   11d3a:	ff 
   11d3b:	d9 fa                	fsqrt
   11d3d:	c5 d3 5e c0          	vdivsd xmm0,xmm5,xmm0
   11d41:	dd 9d c0 fe ff ff    	fstp   QWORD PTR [rbp-0x140]
   11d47:	c5 fb 10 9d c0 fe ff 	vmovsd xmm3,QWORD PTR [rbp-0x140]
   11d4e:	ff 
   11d4f:	c4 e2 d9 99 d8       	vfmadd132sd xmm3,xmm4,xmm0
   11d54:	c5 fb 11 9d c0 fe ff 	vmovsd QWORD PTR [rbp-0x140],xmm3
   11d5b:	ff 
   11d5c:	dd 85 c0 fe ff ff    	fld    QWORD PTR [rbp-0x140]
   11d62:	d8 c8                	fmul   st,st(0)
   11d64:	d8 c0                	fadd   st,st(0)
   11d66:	85 c9                	test   ecx,ecx
   11d68:	0f 8e 7a 0b 00 00    	jle    128e8 <try_secant_tail.constprop.0+0x2a08>
   11d6e:	8d 51 ff             	lea    edx,[rcx-0x1]
   11d71:	83 fa 02             	cmp    edx,0x2
   11d74:	0f 86 f8 0b 00 00    	jbe    12972 <try_secant_tail.constprop.0+0x2a92>
   11d7a:	89 ce                	mov    esi,ecx
   11d7c:	48 89 c2             	mov    rdx,rax
   11d7f:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   11d83:	c1 ee 02             	shr    esi,0x2
   11d86:	48 c1 e6 05          	shl    rsi,0x5
   11d8a:	48 01 c6             	add    rsi,rax
   11d8d:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
   11d94:	00 
   11d95:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   11d9c:	00 00 00 00 
   11da0:	c5 fd 10 02          	vmovupd ymm0,YMMWORD PTR [rdx]
   11da4:	48 83 c2 20          	add    rdx,0x20
   11da8:	48 39 f2             	cmp    rdx,rsi
   11dab:	c5 fd 59 c0          	vmulpd ymm0,ymm0,ymm0
   11daf:	c5 e5 58 d8          	vaddpd ymm3,ymm3,ymm0
   11db3:	75 eb                	jne    11da0 <try_secant_tail.constprop.0+0x1ec0>
   11db5:	c4 e3 7d 19 d8 01    	vextractf128 xmm0,ymm3,0x1
   11dbb:	89 ca                	mov    edx,ecx
   11dbd:	c5 f9 58 db          	vaddpd xmm3,xmm0,xmm3
   11dc1:	83 e2 fc             	and    edx,0xfffffffc
   11dc4:	39 d1                	cmp    ecx,edx
   11dc6:	89 d6                	mov    esi,edx
   11dc8:	c5 e1 15 c3          	vunpckhpd xmm0,xmm3,xmm3
   11dcc:	c5 f9 58 c3          	vaddpd xmm0,xmm0,xmm3
   11dd0:	74 3e                	je     11e10 <try_secant_tail.constprop.0+0x1f30>
   11dd2:	29 f1                	sub    ecx,esi
   11dd4:	83 f9 01             	cmp    ecx,0x1
   11dd7:	74 2a                	je     11e03 <try_secant_tail.constprop.0+0x1f23>
   11dd9:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
   11de0:	48 03 b5 90 fe ff ff 	add    rsi,QWORD PTR [rbp-0x170]
   11de7:	f6 c1 01             	test   cl,0x1
   11dea:	c5 f9 10 04 f7       	vmovupd xmm0,XMMWORD PTR [rdi+rsi*8]
   11def:	c4 e2 f9 b8 d8       	vfmadd231pd xmm3,xmm0,xmm0
   11df4:	c5 e1 15 c3          	vunpckhpd xmm0,xmm3,xmm3
   11df8:	c5 f9 58 c3          	vaddpd xmm0,xmm0,xmm3
   11dfc:	74 12                	je     11e10 <try_secant_tail.constprop.0+0x1f30>
   11dfe:	83 e1 fe             	and    ecx,0xfffffffe
   11e01:	01 ca                	add    edx,ecx
   11e03:	48 63 d2             	movsxd rdx,edx
   11e06:	c5 fb 10 1c d0       	vmovsd xmm3,QWORD PTR [rax+rdx*8]
   11e0b:	c4 e2 e1 b9 c3       	vfmadd231sd xmm0,xmm3,xmm3
   11e10:	c5 fb 5c 85 b0 fe ff 	vsubsd xmm0,xmm0,QWORD PTR [rbp-0x150]
   11e17:	ff 
   11e18:	c5 f9 54 05 00 00 00 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x0]        # 11e20 <try_secant_tail.constprop.0+0x1f40>
   11e1f:	00 
   11e20:	c5 fb 58 fc          	vaddsd xmm7,xmm0,xmm4
   11e24:	c5 fb 11 bd c0 fe ff 	vmovsd QWORD PTR [rbp-0x140],xmm7
   11e2b:	ff 
   11e2c:	dd 85 c0 fe ff ff    	fld    QWORD PTR [rbp-0x140]
   11e32:	d8 c8                	fmul   st,st(0)
   11e34:	d9 c9                	fxch   st(1)
   11e36:	de c2                	faddp  st(2),st
   11e38:	de c1                	faddp  st(1),st
   11e3a:	45 85 ff             	test   r15d,r15d
   11e3d:	db bd 30 ff ff ff    	fstp   TBYTE PTR [rbp-0xd0]
   11e43:	0f 8e cc 00 00 00    	jle    11f15 <try_secant_tail.constprop.0+0x2035>
   11e49:	c5 f3 5e ca          	vdivsd xmm1,xmm1,xmm2
   11e4d:	41 83 ff 01          	cmp    r15d,0x1
   11e51:	48 8b 95 18 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xe8]
   11e58:	0f 84 f7 08 00 00    	je     12755 <try_secant_tail.constprop.0+0x2875>
   11e5e:	48 8b b5 a8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x158]
   11e65:	48 8b bd 88 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x178]
   11e6c:	48 89 d1             	mov    rcx,rdx
   11e6f:	48 8d 74 3e 08       	lea    rsi,[rsi+rdi*1+0x8]
   11e74:	48 29 f1             	sub    rcx,rsi
   11e77:	48 83 f9 10          	cmp    rcx,0x10
   11e7b:	0f 86 d4 08 00 00    	jbe    12755 <try_secant_tail.constprop.0+0x2875>
   11e81:	41 8d 4f ff          	lea    ecx,[r15-0x1]
   11e85:	44 89 fe             	mov    esi,r15d
   11e88:	83 f9 02             	cmp    ecx,0x2
   11e8b:	0f 86 f3 0c 00 00    	jbe    12b84 <try_secant_tail.constprop.0+0x2ca4>
   11e91:	c1 ee 02             	shr    esi,0x2
   11e94:	c4 e2 7d 19 d1       	vbroadcastsd ymm2,xmm1
   11e99:	31 c9                	xor    ecx,ecx
   11e9b:	48 c1 e6 05          	shl    rsi,0x5
   11e9f:	90                   	nop
   11ea0:	c5 fd 10 04 08       	vmovupd ymm0,YMMWORD PTR [rax+rcx*1]
   11ea5:	c4 e2 ed a8 04 0a    	vfmadd213pd ymm0,ymm2,YMMWORD PTR [rdx+rcx*1]
   11eab:	c5 fd 11 04 0a       	vmovupd YMMWORD PTR [rdx+rcx*1],ymm0
   11eb0:	48 83 c1 20          	add    rcx,0x20
   11eb4:	48 39 ce             	cmp    rsi,rcx
   11eb7:	75 e7                	jne    11ea0 <try_secant_tail.constprop.0+0x1fc0>
   11eb9:	44 89 fb             	mov    ebx,r15d
   11ebc:	83 e3 fc             	and    ebx,0xfffffffc
   11ebf:	41 39 df             	cmp    r15d,ebx
   11ec2:	89 d9                	mov    ecx,ebx
   11ec4:	74 4f                	je     11f15 <try_secant_tail.constprop.0+0x2035>
   11ec6:	44 89 fe             	mov    esi,r15d
   11ec9:	29 de                	sub    esi,ebx
   11ecb:	83 fe 01             	cmp    esi,0x1
   11ece:	74 32                	je     11f02 <try_secant_tail.constprop.0+0x2022>
   11ed0:	4c 8b 85 90 fe ff ff 	mov    r8,QWORD PTR [rbp-0x170]
   11ed7:	48 8d 3c ca          	lea    rdi,[rdx+rcx*8]
   11edb:	c5 fb 12 c1          	vmovddup xmm0,xmm1
   11edf:	c5 f9 10 37          	vmovupd xmm6,XMMWORD PTR [rdi]
   11ee3:	4c 01 c1             	add    rcx,r8
   11ee6:	4c 8b 85 a8 fe ff ff 	mov    r8,QWORD PTR [rbp-0x158]
   11eed:	40 f6 c6 01          	test   sil,0x1
   11ef1:	c4 c2 c9 98 04 c8    	vfmadd132pd xmm0,xmm6,XMMWORD PTR [r8+rcx*8]
   11ef7:	c5 f9 11 07          	vmovupd XMMWORD PTR [rdi],xmm0
   11efb:	74 18                	je     11f15 <try_secant_tail.constprop.0+0x2035>
   11efd:	83 e6 fe             	and    esi,0xfffffffe
   11f00:	01 f3                	add    ebx,esi
   11f02:	48 63 cb             	movsxd rcx,ebx
   11f05:	c5 fb 10 2c ca       	vmovsd xmm5,QWORD PTR [rdx+rcx*8]
   11f0a:	c4 e2 d1 99 0c c8    	vfmadd132sd xmm1,xmm5,QWORD PTR [rax+rcx*8]
   11f10:	c5 fb 11 0c ca       	vmovsd QWORD PTR [rdx+rcx*8],xmm1
   11f15:	8b 9d 0c ff ff ff    	mov    ebx,DWORD PTR [rbp-0xf4]
   11f1b:	41 8d 43 01          	lea    eax,[r11+0x1]
   11f1f:	89 85 04 ff ff ff    	mov    DWORD PTR [rbp-0xfc],eax
   11f25:	85 db                	test   ebx,ebx
   11f27:	89 9d c0 fe ff ff    	mov    DWORD PTR [rbp-0x140],ebx
   11f2d:	0f 85 f9 0c 00 00    	jne    12c2c <try_secant_tail.constprop.0+0x2d4c>
   11f33:	41 39 c4             	cmp    r12d,eax
   11f36:	0f 84 47 0a 00 00    	je     12983 <try_secant_tail.constprop.0+0x2aa3>
   11f3c:	8b 85 e0 fd ff ff    	mov    eax,DWORD PTR [rbp-0x220]
   11f42:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   11f49:	44 89 e6             	mov    esi,r12d
   11f4c:	4d 89 e9             	mov    r9,r13
   11f4f:	83 c0 01             	add    eax,0x1
   11f52:	89 85 60 fe ff ff    	mov    DWORD PTR [rbp-0x1a0],eax
   11f58:	c5 f8 77             	vzeroupper
   11f5b:	e8 e0 e2 fe ff       	call   240 <norm2>
   11f60:	48 63 85 d0 fe ff ff 	movsxd rax,DWORD PTR [rbp-0x130]
   11f67:	4c 8b 9d f0 fe ff ff 	mov    r11,QWORD PTR [rbp-0x110]
   11f6e:	48 8b 9d a8 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x158]
   11f75:	c5 fb 10 3d 00 00 00 	vmovsd xmm7,QWORD PTR [rip+0x0]        # 11f7d <try_secant_tail.constprop.0+0x209d>
   11f7c:	00 
   11f7d:	45 31 ed             	xor    r13d,r13d
   11f80:	c7 85 d0 fe ff ff 02 	mov    DWORD PTR [rbp-0x130],0x2
   11f87:	00 00 00 
   11f8a:	4c 0f af d8          	imul   r11,rax
   11f8e:	49 8d 46 f8          	lea    rax,[r14-0x8]
   11f92:	c5 fb 11 85 90 fe ff 	vmovsd QWORD PTR [rbp-0x170],xmm0
   11f99:	ff 
   11f9a:	48 29 d8             	sub    rax,rbx
   11f9d:	c5 fb 11 bd 88 fe ff 	vmovsd QWORD PTR [rbp-0x178],xmm7
   11fa4:	ff 
   11fa5:	48 89 85 70 fe ff ff 	mov    QWORD PTR [rbp-0x190],rax
   11fac:	4e 8d 3c db          	lea    r15,[rbx+r11*8]
   11fb0:	4c 89 db             	mov    rbx,r11
   11fb3:	4b 8d 3c ee          	lea    rdi,[r14+r13*8]
   11fb7:	45 85 e4             	test   r12d,r12d
   11fba:	49 89 fa             	mov    r10,rdi
   11fbd:	0f 8e 0d 04 00 00    	jle    123d0 <try_secant_tail.constprop.0+0x24f0>
   11fc3:	45 89 e0             	mov    r8d,r12d
   11fc6:	4c 8b 9d a8 fe ff ff 	mov    r11,QWORD PTR [rbp-0x158]
   11fcd:	41 c1 e8 02          	shr    r8d,0x2
   11fd1:	49 c1 e0 05          	shl    r8,0x5
   11fd5:	83 bd a4 fe ff ff 02 	cmp    DWORD PTR [rbp-0x15c],0x2
   11fdc:	0f 86 1b 02 00 00    	jbe    121fd <try_secant_tail.constprop.0+0x231d>
   11fe2:	31 c0                	xor    eax,eax
   11fe4:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   11fe8:	66 90                	xchg   ax,ax
   11fea:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   11ff1:	00 00 00 00 
   11ff5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   11ffc:	00 00 00 00 
   12000:	c5 fd 10 04 07       	vmovupd ymm0,YMMWORD PTR [rdi+rax*1]
   12005:	c4 c1 7d 59 04 07    	vmulpd ymm0,ymm0,YMMWORD PTR [r15+rax*1]
   1200b:	48 83 c0 20          	add    rax,0x20
   1200f:	4c 39 c0             	cmp    rax,r8
   12012:	c5 f5 58 c8          	vaddpd ymm1,ymm1,ymm0
   12016:	75 e8                	jne    12000 <try_secant_tail.constprop.0+0x2120>
   12018:	c4 e3 7d 19 c8 01    	vextractf128 xmm0,ymm1,0x1
   1201e:	44 89 e2             	mov    edx,r12d
   12021:	c5 f9 58 c9          	vaddpd xmm1,xmm0,xmm1
   12025:	83 e2 fc             	and    edx,0xfffffffc
   12028:	41 39 d4             	cmp    r12d,edx
   1202b:	89 d0                	mov    eax,edx
   1202d:	c5 f1 15 c1          	vunpckhpd xmm0,xmm1,xmm1
   12031:	c5 f9 58 c1          	vaddpd xmm0,xmm0,xmm1
   12035:	0f 84 5a 02 00 00    	je     12295 <try_secant_tail.constprop.0+0x23b5>
   1203b:	44 89 e1             	mov    ecx,r12d
   1203e:	29 c1                	sub    ecx,eax
   12040:	83 f9 01             	cmp    ecx,0x1
   12043:	74 25                	je     1206a <try_secant_tail.constprop.0+0x218a>
   12045:	48 8d 34 03          	lea    rsi,[rbx+rax*1]
   12049:	4c 01 e8             	add    rax,r13
   1204c:	f6 c1 01             	test   cl,0x1
   1204f:	c4 c1 79 10 3c f3    	vmovupd xmm7,XMMWORD PTR [r11+rsi*8]
   12055:	c4 c2 c1 b8 0c c6    	vfmadd231pd xmm1,xmm7,XMMWORD PTR [r14+rax*8]
   1205b:	c5 f1 15 c1          	vunpckhpd xmm0,xmm1,xmm1
   1205f:	c5 f9 58 c1          	vaddpd xmm0,xmm0,xmm1
   12063:	74 14                	je     12079 <try_secant_tail.constprop.0+0x2199>
   12065:	83 e1 fe             	and    ecx,0xfffffffe
   12068:	01 ca                	add    edx,ecx
   1206a:	48 63 d2             	movsxd rdx,edx
   1206d:	c4 c1 7b 10 34 d7    	vmovsd xmm6,QWORD PTR [r15+rdx*8]
   12073:	c4 e2 c9 b9 04 d7    	vfmadd231sd xmm0,xmm6,QWORD PTR [rdi+rdx*8]
   12079:	41 83 fc 01          	cmp    r12d,0x1
   1207d:	0f 84 2d 02 00 00    	je     122b0 <try_secant_tail.constprop.0+0x23d0>
   12083:	48 8b b5 70 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x190]
   1208a:	4c 89 e8             	mov    rax,r13
   1208d:	48 29 d8             	sub    rax,rbx
   12090:	48 8d 04 c6          	lea    rax,[rsi+rax*8]
   12094:	48 83 f8 10          	cmp    rax,0x10
   12098:	0f 86 12 02 00 00    	jbe    122b0 <try_secant_tail.constprop.0+0x23d0>
   1209e:	83 bd a4 fe ff ff 02 	cmp    DWORD PTR [rbp-0x15c],0x2
   120a5:	0f 86 ac 07 00 00    	jbe    12857 <try_secant_tail.constprop.0+0x2977>
   120ab:	c4 e2 7d 19 d0       	vbroadcastsd ymm2,xmm0
   120b0:	31 c0                	xor    eax,eax
   120b2:	0f 1f 00             	nop    DWORD PTR [rax]
   120b5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   120bc:	00 00 00 00 
   120c0:	c4 c1 7d 10 0c 07    	vmovupd ymm1,YMMWORD PTR [r15+rax*1]
   120c6:	c4 e2 ed ac 0c 07    	vfnmadd213pd ymm1,ymm2,YMMWORD PTR [rdi+rax*1]
   120cc:	c5 fd 11 0c 07       	vmovupd YMMWORD PTR [rdi+rax*1],ymm1
   120d1:	48 83 c0 20          	add    rax,0x20
   120d5:	4c 39 c0             	cmp    rax,r8
   120d8:	75 e6                	jne    120c0 <try_secant_tail.constprop.0+0x21e0>
   120da:	44 89 e0             	mov    eax,r12d
   120dd:	83 e0 fc             	and    eax,0xfffffffc
   120e0:	41 39 c4             	cmp    r12d,eax
   120e3:	89 c2                	mov    edx,eax
   120e5:	0f 84 1b 03 00 00    	je     12406 <try_secant_tail.constprop.0+0x2526>
   120eb:	44 89 e1             	mov    ecx,r12d
   120ee:	29 c1                	sub    ecx,eax
   120f0:	83 f9 01             	cmp    ecx,0x1
   120f3:	74 27                	je     1211c <try_secant_tail.constprop.0+0x223c>
   120f5:	4a 8d 34 2a          	lea    rsi,[rdx+r13*1]
   120f9:	48 01 da             	add    rdx,rbx
   120fc:	c5 fb 12 c8          	vmovddup xmm1,xmm0
   12100:	f6 c1 01             	test   cl,0x1
   12103:	c4 c1 79 10 2c f6    	vmovupd xmm5,XMMWORD PTR [r14+rsi*8]
   12109:	c4 c2 d1 9c 0c d3    	vfnmadd132pd xmm1,xmm5,XMMWORD PTR [r11+rdx*8]
   1210f:	c4 c1 79 11 0c f6    	vmovupd XMMWORD PTR [r14+rsi*8],xmm1
   12115:	74 17                	je     1212e <try_secant_tail.constprop.0+0x224e>
   12117:	83 e1 fe             	and    ecx,0xfffffffe
   1211a:	01 c8                	add    eax,ecx
   1211c:	48 98                	cdqe
   1211e:	c5 fb 10 34 c7       	vmovsd xmm6,QWORD PTR [rdi+rax*8]
   12123:	c4 c2 c9 9d 04 c7    	vfnmadd132sd xmm0,xmm6,QWORD PTR [r15+rax*8]
   12129:	c5 fb 11 04 c7       	vmovsd QWORD PTR [rdi+rax*8],xmm0
   1212e:	44 89 e6             	mov    esi,r12d
   12131:	c5 f8 77             	vzeroupper
   12134:	e8 07 e1 fe ff       	call   240 <norm2>
   12139:	c5 fb 10 ad 88 fe ff 	vmovsd xmm5,QWORD PTR [rbp-0x178]
   12140:	ff 
   12141:	c5 f9 2f e8          	vcomisd xmm5,xmm0
   12145:	0f 87 c3 00 00 00    	ja     1220e <try_secant_tail.constprop.0+0x232e>
   1214b:	c5 fb 10 bd b0 fe ff 	vmovsd xmm7,QWORD PTR [rbp-0x150]
   12152:	ff 
   12153:	83 bd a4 fe ff ff 02 	cmp    DWORD PTR [rbp-0x15c],0x2
   1215a:	c5 c3 5e d0          	vdivsd xmm2,xmm7,xmm0
   1215e:	0f 86 43 07 00 00    	jbe    128a7 <try_secant_tail.constprop.0+0x29c7>
   12164:	44 89 e0             	mov    eax,r12d
   12167:	c4 e2 7d 19 ca       	vbroadcastsd ymm1,xmm2
   1216c:	c1 e8 02             	shr    eax,0x2
   1216f:	48 c1 e0 05          	shl    rax,0x5
   12173:	48 01 f8             	add    rax,rdi
   12176:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
   1217d:	00 00 00 
   12180:	c5 f5 59 07          	vmulpd ymm0,ymm1,YMMWORD PTR [rdi]
   12184:	48 83 c7 20          	add    rdi,0x20
   12188:	c5 fd 11 47 e0       	vmovupd YMMWORD PTR [rdi-0x20],ymm0
   1218d:	48 39 c7             	cmp    rdi,rax
   12190:	75 ee                	jne    12180 <try_secant_tail.constprop.0+0x22a0>
   12192:	44 89 e2             	mov    edx,r12d
   12195:	83 e2 fc             	and    edx,0xfffffffc
   12198:	41 39 d4             	cmp    r12d,edx
   1219b:	89 d0                	mov    eax,edx
   1219d:	74 36                	je     121d5 <try_secant_tail.constprop.0+0x22f5>
   1219f:	44 89 e1             	mov    ecx,r12d
   121a2:	29 c1                	sub    ecx,eax
   121a4:	83 f9 01             	cmp    ecx,0x1
   121a7:	74 1d                	je     121c6 <try_secant_tail.constprop.0+0x22e6>
   121a9:	4c 01 e8             	add    rax,r13
   121ac:	c5 fb 12 c2          	vmovddup xmm0,xmm2
   121b0:	f6 c1 01             	test   cl,0x1
   121b3:	c4 c1 79 59 04 c6    	vmulpd xmm0,xmm0,XMMWORD PTR [r14+rax*8]
   121b9:	c4 c1 79 11 04 c6    	vmovupd XMMWORD PTR [r14+rax*8],xmm0
   121bf:	74 14                	je     121d5 <try_secant_tail.constprop.0+0x22f5>
   121c1:	83 e1 fe             	and    ecx,0xfffffffe
   121c4:	01 ca                	add    edx,ecx
   121c6:	48 63 d2             	movsxd rdx,edx
   121c9:	c4 c1 6b 59 14 d2    	vmulsd xmm2,xmm2,QWORD PTR [r10+rdx*8]
   121cf:	c4 c1 7b 11 14 d2    	vmovsd QWORD PTR [r10+rdx*8],xmm2
   121d5:	83 ad d0 fe ff ff 01 	sub    DWORD PTR [rbp-0x130],0x1
   121dc:	0f 84 8d 00 00 00    	je     1226f <try_secant_tail.constprop.0+0x238f>
   121e2:	4c 03 ad f0 fe ff ff 	add    r13,QWORD PTR [rbp-0x110]
   121e9:	83 bd a4 fe ff ff 02 	cmp    DWORD PTR [rbp-0x15c],0x2
   121f0:	4b 8d 3c ee          	lea    rdi,[r14+r13*8]
   121f4:	49 89 fa             	mov    r10,rdi
   121f7:	0f 87 e5 fd ff ff    	ja     11fe2 <try_secant_tail.constprop.0+0x2102>
   121fd:	31 d2                	xor    edx,edx
   121ff:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   12203:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   12207:	31 c0                	xor    eax,eax
   12209:	e9 2d fe ff ff       	jmp    1203b <try_secant_tail.constprop.0+0x215b>
   1220e:	8b 85 e0 fd ff ff    	mov    eax,DWORD PTR [rbp-0x220]
   12214:	48 8b b5 18 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1e8]
   1221b:	4c 89 d7             	mov    rdi,r10
   1221e:	4c 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r9
   12225:	8d 14 c5 00 00 00 00 	lea    edx,[rax*8+0x0]
   1222c:	29 c2                	sub    edx,eax
   1222e:	48 b8 03 ed 92 d1 32 	movabs rax,0xd1b54a32d192ed03
   12235:	4a b5 d1 
   12238:	83 c2 0a             	add    edx,0xa
   1223b:	2b 95 d0 fe ff ff    	sub    edx,DWORD PTR [rbp-0x130]
   12241:	48 63 d2             	movsxd rdx,edx
   12244:	48 0f af d0          	imul   rdx,rax
   12248:	48 03 95 68 fd ff ff 	add    rdx,QWORD PTR [rbp-0x298]
   1224f:	e8 4c 18 ff ff       	call   3aa0 <secant_refresh>
   12254:	4c 03 ad f0 fe ff ff 	add    r13,QWORD PTR [rbp-0x110]
   1225b:	83 ad d0 fe ff ff 01 	sub    DWORD PTR [rbp-0x130],0x1
   12262:	4c 8b 8d 38 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c8]
   12269:	0f 85 44 fd ff ff    	jne    11fb3 <try_secant_tail.constprop.0+0x20d3>
   1226f:	8b 85 04 ff ff ff    	mov    eax,DWORD PTR [rbp-0xfc]
   12275:	8b 9d 0c ff ff ff    	mov    ebx,DWORD PTR [rbp-0xf4]
   1227b:	4d 89 cd             	mov    r13,r9
   1227e:	89 85 d0 fe ff ff    	mov    DWORD PTR [rbp-0x130],eax
   12284:	8b 85 60 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1a0]
   1228a:	89 85 e0 fd ff ff    	mov    DWORD PTR [rbp-0x220],eax
   12290:	e9 9f e3 ff ff       	jmp    10634 <try_secant_tail.constprop.0+0x754>
   12295:	4c 89 ea             	mov    rdx,r13
   12298:	49 8d 46 f8          	lea    rax,[r14-0x8]
   1229c:	48 29 da             	sub    rdx,rbx
   1229f:	4c 29 d8             	sub    rax,r11
   122a2:	48 8d 04 d0          	lea    rax,[rax+rdx*8]
   122a6:	48 83 f8 10          	cmp    rax,0x10
   122aa:	0f 87 fb fd ff ff    	ja     120ab <try_secant_tail.constprop.0+0x21cb>
   122b0:	48 8b 95 f0 fd ff ff 	mov    rdx,QWORD PTR [rbp-0x210]
   122b7:	31 c0                	xor    eax,eax
   122b9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   122c0:	c4 c1 7b 10 0c 07    	vmovsd xmm1,QWORD PTR [r15+rax*1]
   122c6:	c4 e2 f9 ad 0c 07    	vfnmadd213sd xmm1,xmm0,QWORD PTR [rdi+rax*1]
   122cc:	c5 fb 11 0c 07       	vmovsd QWORD PTR [rdi+rax*1],xmm1
   122d1:	48 83 c0 08          	add    rax,0x8
   122d5:	48 39 c2             	cmp    rdx,rax
   122d8:	75 e6                	jne    122c0 <try_secant_tail.constprop.0+0x23e0>
   122da:	e9 4f fe ff ff       	jmp    1212e <try_secant_tail.constprop.0+0x224e>
   122df:	85 c9                	test   ecx,ecx
   122e1:	8d 51 03             	lea    edx,[rcx+0x3]
   122e4:	44 8d 04 85 00 00 00 	lea    r8d,[rax*4+0x0]
   122eb:	00 
   122ec:	0f 49 d1             	cmovns edx,ecx
   122ef:	c1 fa 02             	sar    edx,0x2
   122f2:	39 d0                	cmp    eax,edx
   122f4:	44 0f 4f c1          	cmovg  r8d,ecx
   122f8:	e9 1e f1 ff ff       	jmp    1141b <try_secant_tail.constprop.0+0x153b>
   122fd:	c5 fb 10 3d 00 00 00 	vmovsd xmm7,QWORD PTR [rip+0x0]        # 12305 <try_secant_tail.constprop.0+0x2425>
   12304:	00 
   12305:	c5 fb 11 bd b0 fe ff 	vmovsd QWORD PTR [rbp-0x150],xmm7
   1230c:	ff 
   1230d:	c5 fb 11 bd 80 fe ff 	vmovsd QWORD PTR [rbp-0x180],xmm7
   12314:	ff 
   12315:	e9 e9 dd ff ff       	jmp    10103 <try_secant_tail.constprop.0+0x223>
   1231a:	48 0f af f1          	imul   rsi,rcx
   1231e:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
   12325:	4c 89 8d a8 fe ff ff 	mov    QWORD PTR [rbp-0x158],r9
   1232c:	44 89 85 70 fe ff ff 	mov    DWORD PTR [rbp-0x190],r8d
   12333:	4c 89 95 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r10
   1233a:	48 c1 e6 03          	shl    rsi,0x3
   1233e:	c5 fb 11 95 30 fe ff 	vmovsd QWORD PTR [rbp-0x1d0],xmm2
   12345:	ff 
   12346:	c5 fb 11 a5 28 fe ff 	vmovsd QWORD PTR [rbp-0x1d8],xmm4
   1234d:	ff 
   1234e:	e8 00 00 00 00       	call   12353 <try_secant_tail.constprop.0+0x2473>
   12353:	44 8b 9d 04 ff ff ff 	mov    r11d,DWORD PTR [rbp-0xfc]
   1235a:	4c 8b 8d a8 fe ff ff 	mov    r9,QWORD PTR [rbp-0x158]
   12361:	48 85 c0             	test   rax,rax
   12364:	0f 84 d1 f0 ff ff    	je     1143b <try_secant_tail.constprop.0+0x155b>
   1236a:	44 8b 85 70 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x190]
   12371:	4c 89 fe             	mov    rsi,r15
   12374:	48 89 c7             	mov    rdi,rax
   12377:	45 89 ef             	mov    r15d,r13d
   1237a:	48 89 85 a8 fe ff ff 	mov    QWORD PTR [rbp-0x158],rax
   12381:	4d 89 cd             	mov    r13,r9
   12384:	4c 8b 95 38 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c8]
   1238b:	49 89 f1             	mov    r9,rsi
   1238e:	48 89 85 10 ff ff ff 	mov    QWORD PTR [rbp-0xf0],rax
   12395:	db ad 30 ff ff ff    	fld    TBYTE PTR [rbp-0xd0]
   1239b:	c5 fb 10 95 30 fe ff 	vmovsd xmm2,QWORD PTR [rbp-0x1d0]
   123a2:	ff 
   123a3:	44 89 85 08 ff ff ff 	mov    DWORD PTR [rbp-0xf8],r8d
   123aa:	c5 fb 10 8d 00 fe ff 	vmovsd xmm1,QWORD PTR [rbp-0x200]
   123b1:	ff 
   123b2:	8b 9d 88 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x178]
   123b8:	c5 fb 10 a5 28 fe ff 	vmovsd xmm4,QWORD PTR [rbp-0x1d8]
   123bf:	ff 
   123c0:	e9 46 f8 ff ff       	jmp    11c0b <try_secant_tail.constprop.0+0x1d2b>
   123c5:	4c 03 ad f0 fe ff ff 	add    r13,QWORD PTR [rbp-0x110]
   123cc:	4f 8d 14 ee          	lea    r10,[r14+r13*8]
   123d0:	44 89 e6             	mov    esi,r12d
   123d3:	4c 89 d7             	mov    rdi,r10
   123d6:	e8 65 de fe ff       	call   240 <norm2>
   123db:	c5 fb 10 ad 88 fe ff 	vmovsd xmm5,QWORD PTR [rbp-0x178]
   123e2:	ff 
   123e3:	c5 f9 2f e8          	vcomisd xmm5,xmm0
   123e7:	0f 87 21 fe ff ff    	ja     1220e <try_secant_tail.constprop.0+0x232e>
   123ed:	83 ad d0 fe ff ff 01 	sub    DWORD PTR [rbp-0x130],0x1
   123f4:	75 cf                	jne    123c5 <try_secant_tail.constprop.0+0x24e5>
   123f6:	e9 74 fe ff ff       	jmp    1226f <try_secant_tail.constprop.0+0x238f>
   123fb:	d9 05 00 00 00 00    	fld    DWORD PTR [rip+0x0]        # 12401 <try_secant_tail.constprop.0+0x2521>
   12401:	e9 60 f9 ff ff       	jmp    11d66 <try_secant_tail.constprop.0+0x1e86>
   12406:	44 89 e6             	mov    esi,r12d
   12409:	c5 f8 77             	vzeroupper
   1240c:	e8 2f de fe ff       	call   240 <norm2>
   12411:	c5 fb 10 bd 88 fe ff 	vmovsd xmm7,QWORD PTR [rbp-0x178]
   12418:	ff 
   12419:	c5 f9 2f f8          	vcomisd xmm7,xmm0
   1241d:	0f 87 eb fd ff ff    	ja     1220e <try_secant_tail.constprop.0+0x232e>
   12423:	c5 fb 10 b5 b0 fe ff 	vmovsd xmm6,QWORD PTR [rbp-0x150]
   1242a:	ff 
   1242b:	c5 cb 5e d0          	vdivsd xmm2,xmm6,xmm0
   1242f:	e9 30 fd ff ff       	jmp    12164 <try_secant_tail.constprop.0+0x2284>
   12434:	48 89 c2             	mov    rdx,rax
   12437:	31 c0                	xor    eax,eax
   12439:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   12440:	c5 fb 59 0c 07       	vmulsd xmm1,xmm0,QWORD PTR [rdi+rax*1]
   12445:	c4 c1 7b 11 0c 07    	vmovsd QWORD PTR [r15+rax*1],xmm1
   1244b:	c4 c1 7b 11 0c 02    	vmovsd QWORD PTR [r10+rax*1],xmm1
   12451:	48 83 c0 08          	add    rax,0x8
   12455:	48 39 c2             	cmp    rdx,rax
   12458:	75 e6                	jne    12440 <try_secant_tail.constprop.0+0x2560>
   1245a:	8b 95 d0 fe ff ff    	mov    edx,DWORD PTR [rbp-0x130]
   12460:	4c 89 d7             	mov    rdi,r10
   12463:	44 89 e9             	mov    ecx,r13d
   12466:	4c 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r9
   1246d:	4c 89 95 70 fe ff ff 	mov    QWORD PTR [rbp-0x190],r10
   12474:	e8 17 0f ff ff       	call   3390 <project_cgs2>
   12479:	4c 8b 95 70 fe ff ff 	mov    r10,QWORD PTR [rbp-0x190]
   12480:	44 89 ee             	mov    esi,r13d
   12483:	c5 fb 11 85 e8 fd ff 	vmovsd QWORD PTR [rbp-0x218],xmm0
   1248a:	ff 
   1248b:	4c 89 d7             	mov    rdi,r10
   1248e:	e8 ad dd fe ff       	call   240 <norm2>
   12493:	41 8d 45 ff          	lea    eax,[r13-0x1]
   12497:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   1249e:	4c 8b 8d 38 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c8]
   124a5:	83 f8 02             	cmp    eax,0x2
   124a8:	c5 f9 28 d0          	vmovapd xmm2,xmm0
   124ac:	0f 87 d9 e6 ff ff    	ja     10b8b <try_secant_tail.constprop.0+0xcab>
   124b2:	31 c9                	xor    ecx,ecx
   124b4:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   124b8:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   124bc:	31 c0                	xor    eax,eax
   124be:	e9 1c e7 ff ff       	jmp    10bdf <try_secant_tail.constprop.0+0xcff>
   124c3:	48 8b 95 08 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1f8]
   124ca:	31 c0                	xor    eax,eax
   124cc:	e9 6f ff ff ff       	jmp    12440 <try_secant_tail.constprop.0+0x2560>
   124d1:	31 d2                	xor    edx,edx
   124d3:	31 c9                	xor    ecx,ecx
   124d5:	e9 0b e6 ff ff       	jmp    10ae5 <try_secant_tail.constprop.0+0xc05>
   124da:	31 c9                	xor    ecx,ecx
   124dc:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   124e0:	31 c0                	xor    eax,eax
   124e2:	e9 02 e7 ff ff       	jmp    10be9 <try_secant_tail.constprop.0+0xd09>
   124e7:	85 c9                	test   ecx,ecx
   124e9:	0f 8e 7e 07 00 00    	jle    12c6d <try_secant_tail.constprop.0+0x2d8d>
   124ef:	8d 51 ff             	lea    edx,[rcx-0x1]
   124f2:	83 fa 02             	cmp    edx,0x2
   124f5:	0f 86 61 07 00 00    	jbe    12c5c <try_secant_tail.constprop.0+0x2d7c>
   124fb:	89 ce                	mov    esi,ecx
   124fd:	48 89 c2             	mov    rdx,rax
   12500:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   12504:	c1 ee 02             	shr    esi,0x2
   12507:	48 c1 e6 05          	shl    rsi,0x5
   1250b:	48 01 c6             	add    rsi,rax
   1250e:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   12515:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   1251c:	00 00 00 00 
   12520:	c5 fd 10 02          	vmovupd ymm0,YMMWORD PTR [rdx]
   12524:	48 83 c2 20          	add    rdx,0x20
   12528:	48 39 f2             	cmp    rdx,rsi
   1252b:	c5 fd 59 c0          	vmulpd ymm0,ymm0,ymm0
   1252f:	c5 e5 58 d8          	vaddpd ymm3,ymm3,ymm0
   12533:	75 eb                	jne    12520 <try_secant_tail.constprop.0+0x2640>
   12535:	c4 e3 7d 19 d8 01    	vextractf128 xmm0,ymm3,0x1
   1253b:	89 ce                	mov    esi,ecx
   1253d:	c5 f9 58 db          	vaddpd xmm3,xmm0,xmm3
   12541:	83 e6 fc             	and    esi,0xfffffffc
   12544:	39 f1                	cmp    ecx,esi
   12546:	89 f2                	mov    edx,esi
   12548:	c5 e1 15 c3          	vunpckhpd xmm0,xmm3,xmm3
   1254c:	c5 f9 58 c3          	vaddpd xmm0,xmm0,xmm3
   12550:	74 42                	je     12594 <try_secant_tail.constprop.0+0x26b4>
   12552:	89 cf                	mov    edi,ecx
   12554:	29 d7                	sub    edi,edx
   12556:	83 ff 01             	cmp    edi,0x1
   12559:	74 2c                	je     12587 <try_secant_tail.constprop.0+0x26a7>
   1255b:	4c 8b 85 a8 fe ff ff 	mov    r8,QWORD PTR [rbp-0x158]
   12562:	48 03 95 90 fe ff ff 	add    rdx,QWORD PTR [rbp-0x170]
   12569:	40 f6 c7 01          	test   dil,0x1
   1256d:	c4 c1 79 10 04 d0    	vmovupd xmm0,XMMWORD PTR [r8+rdx*8]
   12573:	c4 e2 f9 b8 d8       	vfmadd231pd xmm3,xmm0,xmm0
   12578:	c5 e1 15 c3          	vunpckhpd xmm0,xmm3,xmm3
   1257c:	c5 f9 58 c3          	vaddpd xmm0,xmm0,xmm3
   12580:	74 12                	je     12594 <try_secant_tail.constprop.0+0x26b4>
   12582:	83 e7 fe             	and    edi,0xfffffffe
   12585:	01 fe                	add    esi,edi
   12587:	48 63 d6             	movsxd rdx,esi
   1258a:	c5 fb 10 1c d0       	vmovsd xmm3,QWORD PTR [rax+rdx*8]
   1258f:	c4 e2 e1 b9 c3       	vfmadd231sd xmm0,xmm3,xmm3
   12594:	c5 fb 5c ad b0 fe ff 	vsubsd xmm5,xmm0,QWORD PTR [rbp-0x150]
   1259b:	ff 
   1259c:	c5 fb 11 ad c0 fe ff 	vmovsd QWORD PTR [rbp-0x140],xmm5
   125a3:	ff 
   125a4:	dd 85 c0 fe ff ff    	fld    QWORD PTR [rbp-0x140]
   125aa:	d8 c8                	fmul   st,st(0)
   125ac:	45 85 db             	test   r11d,r11d
   125af:	0f 8e 49 01 00 00    	jle    126fe <try_secant_tail.constprop.0+0x281e>
   125b5:	85 c9                	test   ecx,ecx
   125b7:	0f 8e 41 01 00 00    	jle    126fe <try_secant_tail.constprop.0+0x281e>
   125bd:	89 ca                	mov    edx,ecx
   125bf:	4c 89 ad 70 fe ff ff 	mov    QWORD PTR [rbp-0x190],r13
   125c6:	45 31 d2             	xor    r10d,r10d
   125c9:	45 31 c0             	xor    r8d,r8d
   125cc:	44 89 a5 30 fe ff ff 	mov    DWORD PTR [rbp-0x1d0],r12d
   125d3:	c1 ea 02             	shr    edx,0x2
   125d6:	89 9d 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],ebx
   125dc:	48 8b 9d a8 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x158]
   125e3:	48 c1 e2 05          	shl    rdx,0x5
   125e7:	44 89 bd 60 fe ff ff 	mov    DWORD PTR [rbp-0x1a0],r15d
   125ee:	44 8d 79 ff          	lea    r15d,[rcx-0x1]
   125f2:	4c 89 b5 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],r14
   125f9:	4c 63 f1             	movsxd r14,ecx
   125fc:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   12600:	41 83 ff 02          	cmp    r15d,0x2
   12604:	4e 8d 24 c5 00 00 00 	lea    r12,[r8*8+0x0]
   1260b:	00 
   1260c:	0f 86 2d 02 00 00    	jbe    1283f <try_secant_tail.constprop.0+0x295f>
   12612:	4a 8d 3c 23          	lea    rdi,[rbx+r12*1]
   12616:	31 f6                	xor    esi,esi
   12618:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   1261c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   12620:	c5 fd 10 04 37       	vmovupd ymm0,YMMWORD PTR [rdi+rsi*1]
   12625:	c5 fd 59 04 30       	vmulpd ymm0,ymm0,YMMWORD PTR [rax+rsi*1]
   1262a:	48 83 c6 20          	add    rsi,0x20
   1262e:	48 39 d6             	cmp    rsi,rdx
   12631:	c5 e5 58 d8          	vaddpd ymm3,ymm3,ymm0
   12635:	75 e9                	jne    12620 <try_secant_tail.constprop.0+0x2740>
   12637:	c4 e3 7d 19 d8 01    	vextractf128 xmm0,ymm3,0x1
   1263d:	89 ce                	mov    esi,ecx
   1263f:	c5 f9 58 c3          	vaddpd xmm0,xmm0,xmm3
   12643:	83 e6 fc             	and    esi,0xfffffffc
   12646:	39 ce                	cmp    esi,ecx
   12648:	89 f7                	mov    edi,esi
   1264a:	c5 f9 15 d8          	vunpckhpd xmm3,xmm0,xmm0
   1264e:	c5 e1 58 d8          	vaddpd xmm3,xmm3,xmm0
   12652:	c5 f9 13 9d c0 fe ff 	vmovlpd QWORD PTR [rbp-0x140],xmm3
   12659:	ff 
   1265a:	74 64                	je     126c0 <try_secant_tail.constprop.0+0x27e0>
   1265c:	41 89 c9             	mov    r9d,ecx
   1265f:	41 29 f9             	sub    r9d,edi
   12662:	41 83 f9 01          	cmp    r9d,0x1
   12666:	74 36                	je     1269e <try_secant_tail.constprop.0+0x27be>
   12668:	4c 8b ad 90 fe ff ff 	mov    r13,QWORD PTR [rbp-0x170]
   1266f:	49 01 fd             	add    r13,rdi
   12672:	4c 01 c7             	add    rdi,r8
   12675:	41 f6 c1 01          	test   r9b,0x1
   12679:	c4 a1 79 10 3c eb    	vmovupd xmm7,XMMWORD PTR [rbx+r13*8]
   1267f:	c4 e2 c1 b8 04 fb    	vfmadd231pd xmm0,xmm7,XMMWORD PTR [rbx+rdi*8]
   12685:	c5 f9 15 d8          	vunpckhpd xmm3,xmm0,xmm0
   12689:	c5 e1 58 c0          	vaddpd xmm0,xmm3,xmm0
   1268d:	c5 f9 13 85 c0 fe ff 	vmovlpd QWORD PTR [rbp-0x140],xmm0
   12694:	ff 
   12695:	74 29                	je     126c0 <try_secant_tail.constprop.0+0x27e0>
   12697:	41 83 e1 fe          	and    r9d,0xfffffffe
   1269b:	44 01 ce             	add    esi,r9d
   1269e:	48 63 f6             	movsxd rsi,esi
   126a1:	c5 fb 10 ad c0 fe ff 	vmovsd xmm5,QWORD PTR [rbp-0x140]
   126a8:	ff 
   126a9:	48 8d 3c f3          	lea    rdi,[rbx+rsi*8]
   126ad:	c5 fb 10 3c f0       	vmovsd xmm7,QWORD PTR [rax+rsi*8]
   126b2:	c4 a2 c1 b9 2c 27    	vfmadd231sd xmm5,xmm7,QWORD PTR [rdi+r12*1]
   126b8:	c5 fb 11 ad c0 fe ff 	vmovsd QWORD PTR [rbp-0x140],xmm5
   126bf:	ff 
   126c0:	dd 85 c0 fe ff ff    	fld    QWORD PTR [rbp-0x140]
   126c6:	41 83 c2 01          	add    r10d,0x1
   126ca:	4d 01 f0             	add    r8,r14
   126cd:	45 39 da             	cmp    r10d,r11d
   126d0:	d8 c8                	fmul   st,st(0)
   126d2:	d8 c0                	fadd   st,st(0)
   126d4:	de c1                	faddp  st(1),st
   126d6:	0f 85 24 ff ff ff    	jne    12600 <try_secant_tail.constprop.0+0x2720>
   126dc:	4c 8b ad 70 fe ff ff 	mov    r13,QWORD PTR [rbp-0x190]
   126e3:	44 8b bd 60 fe ff ff 	mov    r15d,DWORD PTR [rbp-0x1a0]
   126ea:	8b 9d 38 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x1c8]
   126f0:	44 8b a5 30 fe ff ff 	mov    r12d,DWORD PTR [rbp-0x1d0]
   126f7:	4c 8b b5 28 fe ff ff 	mov    r14,QWORD PTR [rbp-0x1d8]
   126fe:	de c1                	faddp  st(1),st
   12700:	e9 35 f7 ff ff       	jmp    11e3a <try_secant_tail.constprop.0+0x1f5a>
   12705:	c5 f8 77             	vzeroupper
   12708:	e9 09 e4 ff ff       	jmp    10b16 <try_secant_tail.constprop.0+0xc36>
   1270d:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   12714:	4c 8d ad 40 ff ff ff 	lea    r13,[rbp-0xc0]
   1271b:	c5 f8 77             	vzeroupper
   1271e:	48 8b bd 58 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1a8]
   12725:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   1272c:	e8 00 00 00 00       	call   12731 <try_secant_tail.constprop.0+0x2851>
   12731:	48 8b bd 10 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f0]
   12738:	e8 00 00 00 00       	call   1273d <try_secant_tail.constprop.0+0x285d>
   1273d:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   12744:	e8 00 00 00 00       	call   12749 <try_secant_tail.constprop.0+0x2869>
   12749:	4c 8b 95 f8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x108]
   12750:	e9 de ee ff ff       	jmp    11633 <try_secant_tail.constprop.0+0x1753>
   12755:	48 8b b5 08 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1f8]
   1275c:	31 c9                	xor    ecx,ecx
   1275e:	66 90                	xchg   ax,ax
   12760:	c5 fb 10 04 08       	vmovsd xmm0,QWORD PTR [rax+rcx*1]
   12765:	c4 e2 f1 a9 04 0a    	vfmadd213sd xmm0,xmm1,QWORD PTR [rdx+rcx*1]
   1276b:	c5 fb 11 04 0a       	vmovsd QWORD PTR [rdx+rcx*1],xmm0
   12770:	48 83 c1 08          	add    rcx,0x8
   12774:	48 39 ce             	cmp    rsi,rcx
   12777:	75 e7                	jne    12760 <try_secant_tail.constprop.0+0x2880>
   12779:	e9 97 f7 ff ff       	jmp    11f15 <try_secant_tail.constprop.0+0x2035>
   1277e:	48 8b 8d f0 fd ff ff 	mov    rcx,QWORD PTR [rbp-0x210]
   12785:	31 c0                	xor    eax,eax
   12787:	66 90                	xchg   ax,ax
   12789:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   12790:	00 00 00 00 
   12794:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   1279b:	00 00 00 00 
   1279f:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   127a6:	00 00 00 00 
   127aa:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   127b1:	00 00 00 00 
   127b5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   127bc:	00 00 00 00 
   127c0:	c5 fb 10 0c 07       	vmovsd xmm1,QWORD PTR [rdi+rax*1]
   127c5:	c5 79 29 d2          	vmovapd xmm2,xmm10
   127c9:	c4 e2 f1 a9 14 03    	vfmadd213sd xmm2,xmm1,QWORD PTR [rbx+rax*1]
   127cf:	c5 fb 11 14 03       	vmovsd QWORD PTR [rbx+rax*1],xmm2
   127d4:	c4 e2 c9 a9 0c 02    	vfmadd213sd xmm1,xmm6,QWORD PTR [rdx+rax*1]
   127da:	c5 fb 11 0c 02       	vmovsd QWORD PTR [rdx+rax*1],xmm1
   127df:	48 83 c0 08          	add    rax,0x8
   127e3:	48 39 c1             	cmp    rcx,rax
   127e6:	75 d8                	jne    127c0 <try_secant_tail.constprop.0+0x28e0>
   127e8:	c5 39 58 45 b0       	vaddpd xmm8,xmm8,XMMWORD PTR [rbp-0x50]
   127ed:	c5 79 29 45 b0       	vmovapd XMMWORD PTR [rbp-0x50],xmm8
   127f2:	e9 8f dd ff ff       	jmp    10586 <try_secant_tail.constprop.0+0x6a6>
   127f7:	8b b5 f8 fe ff ff    	mov    esi,DWORD PTR [rbp-0x108]
   127fd:	3b b0 00 00 00 00    	cmp    esi,DWORD PTR [rax+0x0]
   12803:	0f 84 a4 e7 ff ff    	je     10fad <try_secant_tail.constprop.0+0x10cd>
   12809:	83 fb 01             	cmp    ebx,0x1
   1280c:	0f 84 6b e7 ff ff    	je     10f7d <try_secant_tail.constprop.0+0x109d>
   12812:	3b b0 00 00 00 00    	cmp    esi,DWORD PTR [rax+0x0]
   12818:	0f 84 8f e7 ff ff    	je     10fad <try_secant_tail.constprop.0+0x10cd>
   1281e:	83 fb 02             	cmp    ebx,0x2
   12821:	41 bc 02 00 00 00    	mov    r12d,0x2
   12827:	0f 85 a3 e6 ff ff    	jne    10ed0 <try_secant_tail.constprop.0+0xff0>
   1282d:	e9 4b e7 ff ff       	jmp    10f7d <try_secant_tail.constprop.0+0x109d>
   12832:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   12838:	31 c0                	xor    eax,eax
   1283a:	e9 a5 ec ff ff       	jmp    114e4 <try_secant_tail.constprop.0+0x1604>
   1283f:	48 c7 85 c0 fe ff ff 	mov    QWORD PTR [rbp-0x140],0x0
   12846:	00 00 00 00 
   1284a:	31 f6                	xor    esi,esi
   1284c:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   12850:	31 ff                	xor    edi,edi
   12852:	e9 05 fe ff ff       	jmp    1265c <try_secant_tail.constprop.0+0x277c>
   12857:	31 c0                	xor    eax,eax
   12859:	44 89 e1             	mov    ecx,r12d
   1285c:	31 d2                	xor    edx,edx
   1285e:	e9 92 f8 ff ff       	jmp    120f5 <try_secant_tail.constprop.0+0x2215>
   12863:	4c 89 bd f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r15
   1286a:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
   12871:	e8 00 00 00 00       	call   12876 <try_secant_tail.constprop.0+0x2996>
   12876:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   1287d:	e8 00 00 00 00       	call   12882 <try_secant_tail.constprop.0+0x29a2>
   12882:	48 8b bd 20 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe0]
   12889:	e8 00 00 00 00       	call   1288e <try_secant_tail.constprop.0+0x29ae>
   1288e:	4c 89 f7             	mov    rdi,r14
   12891:	e8 00 00 00 00       	call   12896 <try_secant_tail.constprop.0+0x29b6>
   12896:	48 8b bd f8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x108]
   1289d:	e8 00 00 00 00       	call   128a2 <try_secant_tail.constprop.0+0x29c2>
   128a2:	e9 69 e7 ff ff       	jmp    11010 <try_secant_tail.constprop.0+0x1130>
   128a7:	31 d2                	xor    edx,edx
   128a9:	31 c0                	xor    eax,eax
   128ab:	e9 ef f8 ff ff       	jmp    1219f <try_secant_tail.constprop.0+0x22bf>
   128b0:	48 8b 8d 08 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1f8]
   128b7:	31 d2                	xor    edx,edx
   128b9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   128c0:	c4 c1 53 59 04 12    	vmulsd xmm0,xmm5,QWORD PTR [r10+rdx*1]
   128c6:	c5 fb 11 04 10       	vmovsd QWORD PTR [rax+rdx*1],xmm0
   128cb:	48 83 c2 08          	add    rdx,0x8
   128cf:	48 39 d1             	cmp    rcx,rdx
   128d2:	75 ec                	jne    128c0 <try_secant_tail.constprop.0+0x29e0>
   128d4:	e9 32 f4 ff ff       	jmp    11d0b <try_secant_tail.constprop.0+0x1e2b>
   128d9:	48 89 f9             	mov    rcx,rdi
   128dc:	31 d2                	xor    edx,edx
   128de:	eb e0                	jmp    128c0 <try_secant_tail.constprop.0+0x29e0>
   128e0:	c5 f8 77             	vzeroupper
   128e3:	e9 90 e6 ff ff       	jmp    10f78 <try_secant_tail.constprop.0+0x1098>
   128e8:	dd 05 00 00 00 00    	fld    QWORD PTR [rip+0x0]        # 128ee <try_secant_tail.constprop.0+0x2a0e>
   128ee:	d9 c9                	fxch   st(1)
   128f0:	e9 41 f5 ff ff       	jmp    11e36 <try_secant_tail.constprop.0+0x1f56>
   128f5:	dd d8                	fstp   st(0)
   128f7:	d9 e8                	fld1
   128f9:	d9 c9                	fxch   st(1)
   128fb:	e9 0f ee ff ff       	jmp    1170f <try_secant_tail.constprop.0+0x182f>
   12900:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 12908 <try_secant_tail.constprop.0+0x2a28>
   12907:	00 
   12908:	e9 8c df ff ff       	jmp    10899 <try_secant_tail.constprop.0+0x9b9>
   1290d:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 12915 <try_secant_tail.constprop.0+0x2a35>
   12914:	00 
   12915:	c5 f9 7e 85 c0 fe ff 	vmovd  DWORD PTR [rbp-0x140],xmm0
   1291c:	ff 
   1291d:	e9 26 e5 ff ff       	jmp    10e48 <try_secant_tail.constprop.0+0xf68>
   12922:	8b bd f8 fe ff ff    	mov    edi,DWORD PTR [rbp-0x108]
   12928:	3b b8 00 00 00 00    	cmp    edi,DWORD PTR [rax+0x0]
   1292e:	0f 84 68 04 00 00    	je     12d9c <try_secant_tail.constprop.0+0x2ebc>
   12934:	83 fb 09             	cmp    ebx,0x9
   12937:	41 bc 09 00 00 00    	mov    r12d,0x9
   1293d:	c7 85 c0 fe ff ff 08 	mov    DWORD PTR [rbp-0x140],0x8
   12944:	00 00 00 
   12947:	0f 84 47 04 00 00    	je     12d94 <try_secant_tail.constprop.0+0x2eb4>
   1294d:	c5 f8 77             	vzeroupper
   12950:	e9 37 e5 ff ff       	jmp    10e8c <try_secant_tail.constprop.0+0xfac>
   12955:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   1295c:	c7 85 0c ff ff ff 01 	mov    DWORD PTR [rbp-0xf4],0x1
   12963:	00 00 00 
   12966:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   1296d:	e9 8f ec ff ff       	jmp    11601 <try_secant_tail.constprop.0+0x1721>
   12972:	31 d2                	xor    edx,edx
   12974:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   12978:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   1297c:	31 f6                	xor    esi,esi
   1297e:	e9 4f f4 ff ff       	jmp    11dd2 <try_secant_tail.constprop.0+0x1ef2>
   12983:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   1298a:	48 8b bd 58 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1a8]
   12991:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   12998:	c5 f8 77             	vzeroupper
   1299b:	e8 00 00 00 00       	call   129a0 <try_secant_tail.constprop.0+0x2ac0>
   129a0:	48 8b bd 10 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f0]
   129a7:	e8 00 00 00 00       	call   129ac <try_secant_tail.constprop.0+0x2acc>
   129ac:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   129b3:	e8 00 00 00 00       	call   129b8 <try_secant_tail.constprop.0+0x2ad8>
   129b8:	4c 8b 95 f8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x108]
   129bf:	8b 9d 48 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x1b8]
   129c5:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 129cd <try_secant_tail.constprop.0+0x2aed>
   129cc:	00 
   129cd:	4c 8d 8d 40 ff ff ff 	lea    r9,[rbp-0xc0]
   129d4:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   129db:	48 8b b5 98 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x168]
   129e2:	48 8b bd b8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x148]
   129e9:	8b 8d cc fe ff ff    	mov    ecx,DWORD PTR [rbp-0x134]
   129ef:	48 8b 95 18 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xe8]
   129f6:	41 89 d8             	mov    r8d,ebx
   129f9:	e8 f2 de fe ff       	call   8f0 <compat_scan_fused>
   129fe:	48 8b b5 c8 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x238]
   12a05:	48 8b bd d0 fd ff ff 	mov    rdi,QWORD PTR [rbp-0x230]
   12a0c:	83 f8 01             	cmp    eax,0x1
   12a0f:	c5 fb 10 85 40 ff ff 	vmovsd xmm0,QWORD PTR [rbp-0xc0]
   12a16:	ff 
   12a17:	4c 8b 95 f8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x108]
   12a1e:	19 c0                	sbb    eax,eax
   12a20:	89 5f 04             	mov    DWORD PTR [rdi+0x4],ebx
   12a23:	83 e0 fe             	and    eax,0xfffffffe
   12a26:	c5 fb 11 47 18       	vmovsd QWORD PTR [rdi+0x18],xmm0
   12a2b:	83 c0 03             	add    eax,0x3
   12a2e:	48 85 f6             	test   rsi,rsi
   12a31:	89 07                	mov    DWORD PTR [rdi],eax
   12a33:	0f 84 7b 02 00 00    	je     12cb4 <try_secant_tail.constprop.0+0x2dd4>
   12a39:	85 db                	test   ebx,ebx
   12a3b:	0f 8e 6a 02 00 00    	jle    12cab <try_secant_tail.constprop.0+0x2dcb>
   12a41:	8d 43 ff             	lea    eax,[rbx-0x1]
   12a44:	48 8b 95 18 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xe8]
   12a4b:	83 f8 02             	cmp    eax,0x2
   12a4e:	0f 86 9a 02 00 00    	jbe    12cee <try_secant_tail.constprop.0+0x2e0e>
   12a54:	89 d9                	mov    ecx,ebx
   12a56:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   12a5a:	31 c0                	xor    eax,eax
   12a5c:	c1 e9 02             	shr    ecx,0x2
   12a5f:	c5 fd 28 d3          	vmovapd ymm2,ymm3
   12a63:	48 c1 e1 05          	shl    rcx,0x5
   12a67:	c5 fd 10 0c 06       	vmovupd ymm1,YMMWORD PTR [rsi+rax*1]
   12a6c:	c5 fd 10 04 02       	vmovupd ymm0,YMMWORD PTR [rdx+rax*1]
   12a71:	48 83 c0 20          	add    rax,0x20
   12a75:	48 39 c8             	cmp    rax,rcx
   12a78:	c5 fd 5c c1          	vsubpd ymm0,ymm0,ymm1
   12a7c:	c4 e2 f5 b8 d1       	vfmadd231pd ymm2,ymm1,ymm1
   12a81:	c4 e2 fd b8 d8       	vfmadd231pd ymm3,ymm0,ymm0
   12a86:	75 df                	jne    12a67 <try_secant_tail.constprop.0+0x2b87>
   12a88:	8b 9d 48 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x1b8]
   12a8e:	c4 e3 7d 19 d8 01    	vextractf128 xmm0,ymm3,0x1
   12a94:	c4 e3 7d 19 d1 01    	vextractf128 xmm1,ymm2,0x1
   12a9a:	c5 f9 58 db          	vaddpd xmm3,xmm0,xmm3
   12a9e:	c5 f1 58 d2          	vaddpd xmm2,xmm1,xmm2
   12aa2:	89 df                	mov    edi,ebx
   12aa4:	83 e7 fc             	and    edi,0xfffffffc
   12aa7:	c5 e1 15 c3          	vunpckhpd xmm0,xmm3,xmm3
   12aab:	c5 e9 15 ca          	vunpckhpd xmm1,xmm2,xmm2
   12aaf:	39 df                	cmp    edi,ebx
   12ab1:	89 bd c4 fd ff ff    	mov    DWORD PTR [rbp-0x23c],edi
   12ab7:	c5 f9 58 c3          	vaddpd xmm0,xmm0,xmm3
   12abb:	c5 f1 58 ca          	vaddpd xmm1,xmm1,xmm2
   12abf:	89 f8                	mov    eax,edi
   12ac1:	0f 84 dc 01 00 00    	je     12ca3 <try_secant_tail.constprop.0+0x2dc3>
   12ac7:	c5 f8 77             	vzeroupper
   12aca:	8b 8d 48 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b8]
   12ad0:	29 c1                	sub    ecx,eax
   12ad2:	83 f9 01             	cmp    ecx,0x1
   12ad5:	74 3d                	je     12b14 <try_secant_tail.constprop.0+0x2c34>
   12ad7:	48 8b 9d c8 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x238]
   12ade:	c5 f9 10 04 c2       	vmovupd xmm0,XMMWORD PTR [rdx+rax*8]
   12ae3:	f6 c1 01             	test   cl,0x1
   12ae6:	c5 f9 10 0c c3       	vmovupd xmm1,XMMWORD PTR [rbx+rax*8]
   12aeb:	c5 f9 5c c1          	vsubpd xmm0,xmm0,xmm1
   12aef:	c4 e2 f1 b8 d1       	vfmadd231pd xmm2,xmm1,xmm1
   12af4:	c4 e2 e1 98 c0       	vfmadd132pd xmm0,xmm3,xmm0
   12af9:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   12afd:	c5 f1 58 c0          	vaddpd xmm0,xmm1,xmm0
   12b01:	c5 e9 15 ca          	vunpckhpd xmm1,xmm2,xmm2
   12b05:	c5 f1 58 ca          	vaddpd xmm1,xmm1,xmm2
   12b09:	74 2f                	je     12b3a <try_secant_tail.constprop.0+0x2c5a>
   12b0b:	83 e1 fe             	and    ecx,0xfffffffe
   12b0e:	01 8d c4 fd ff ff    	add    DWORD PTR [rbp-0x23c],ecx
   12b14:	48 63 85 c4 fd ff ff 	movsxd rax,DWORD PTR [rbp-0x23c]
   12b1b:	48 8b 9d c8 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x238]
   12b22:	c5 fb 10 14 c2       	vmovsd xmm2,QWORD PTR [rdx+rax*8]
   12b27:	c5 fb 10 1c c3       	vmovsd xmm3,QWORD PTR [rbx+rax*8]
   12b2c:	c5 eb 5c d3          	vsubsd xmm2,xmm2,xmm3
   12b30:	c4 e2 e1 b9 cb       	vfmadd231sd xmm1,xmm3,xmm3
   12b35:	c4 e2 e9 b9 c2       	vfmadd231sd xmm0,xmm2,xmm2
   12b3a:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
   12b3e:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
   12b42:	c5 f3 58 0d 00 00 00 	vaddsd xmm1,xmm1,QWORD PTR [rip+0x0]        # 12b4a <try_secant_tail.constprop.0+0x2c6a>
   12b49:	00 
   12b4a:	c5 fb 5e c1          	vdivsd xmm0,xmm0,xmm1
   12b4e:	48 8b 85 d0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x230]
   12b55:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   12b5c:	c7 40 0c 00 00 00 00 	mov    DWORD PTR [rax+0xc],0x0
   12b63:	c5 fb 11 40 20       	vmovsd QWORD PTR [rax+0x20],xmm0
   12b68:	e9 f2 ec ff ff       	jmp    1185f <try_secant_tail.constprop.0+0x197f>
   12b6d:	49 89 da             	mov    r10,rbx
   12b70:	c5 f8 77             	vzeroupper
   12b73:	e9 a6 fb ff ff       	jmp    1271e <try_secant_tail.constprop.0+0x283e>
   12b78:	44 89 e1             	mov    ecx,r12d
   12b7b:	31 c0                	xor    eax,eax
   12b7d:	31 d2                	xor    edx,edx
   12b7f:	e9 bb ee ff ff       	jmp    11a3f <try_secant_tail.constprop.0+0x1b5f>
   12b84:	31 c9                	xor    ecx,ecx
   12b86:	e9 45 f3 ff ff       	jmp    11ed0 <try_secant_tail.constprop.0+0x1ff0>
   12b8b:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 12b93 <try_secant_tail.constprop.0+0x2cb3>
   12b92:	00 
   12b93:	e9 7d fd ff ff       	jmp    12915 <try_secant_tail.constprop.0+0x2a35>
   12b98:	31 c9                	xor    ecx,ecx
   12b9a:	31 f6                	xor    esi,esi
   12b9c:	e9 2a f1 ff ff       	jmp    11ccb <try_secant_tail.constprop.0+0x1deb>
   12ba1:	c5 f8 77             	vzeroupper
   12ba4:	e9 dc dc ff ff       	jmp    10885 <try_secant_tail.constprop.0+0x9a5>
   12ba9:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 12bb1 <try_secant_tail.constprop.0+0x2cd1>
   12bb0:	00 
   12bb1:	e9 5f fd ff ff       	jmp    12915 <try_secant_tail.constprop.0+0x2a35>
   12bb6:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 12bbe <try_secant_tail.constprop.0+0x2cde>
   12bbd:	00 
   12bbe:	e9 52 fd ff ff       	jmp    12915 <try_secant_tail.constprop.0+0x2a35>
   12bc3:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 12bcb <try_secant_tail.constprop.0+0x2ceb>
   12bca:	00 
   12bcb:	e9 45 fd ff ff       	jmp    12915 <try_secant_tail.constprop.0+0x2a35>
   12bd0:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 12bd8 <try_secant_tail.constprop.0+0x2cf8>
   12bd7:	00 
   12bd8:	e9 38 fd ff ff       	jmp    12915 <try_secant_tail.constprop.0+0x2a35>
   12bdd:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   12be1:	e9 b3 dc ff ff       	jmp    10899 <try_secant_tail.constprop.0+0x9b9>
   12be6:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 12bee <try_secant_tail.constprop.0+0x2d0e>
   12bed:	00 
   12bee:	e9 22 fd ff ff       	jmp    12915 <try_secant_tail.constprop.0+0x2a35>
   12bf3:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 12bfb <try_secant_tail.constprop.0+0x2d1b>
   12bfa:	00 
   12bfb:	e9 15 fd ff ff       	jmp    12915 <try_secant_tail.constprop.0+0x2a35>
   12c00:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   12c04:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   12c08:	31 d2                	xor    edx,edx
   12c0a:	c5 f9 28 d3          	vmovapd xmm2,xmm3
   12c0e:	c5 f9 28 c1          	vmovapd xmm0,xmm1
   12c12:	e9 06 dc ff ff       	jmp    1081d <try_secant_tail.constprop.0+0x93d>
   12c17:	c5 f8 77             	vzeroupper
   12c1a:	e9 19 ec ff ff       	jmp    11838 <try_secant_tail.constprop.0+0x1958>
   12c1f:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 12c27 <try_secant_tail.constprop.0+0x2d47>
   12c26:	00 
   12c27:	e9 20 ec ff ff       	jmp    1184c <try_secant_tail.constprop.0+0x196c>
   12c2c:	89 85 d0 fe ff ff    	mov    DWORD PTR [rbp-0x130],eax
   12c32:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   12c39:	4c 8d ad 40 ff ff ff 	lea    r13,[rbp-0xc0]
   12c40:	c5 f8 77             	vzeroupper
   12c43:	e9 d6 fa ff ff       	jmp    1271e <try_secant_tail.constprop.0+0x283e>
   12c48:	8b 85 88 fe ff ff    	mov    eax,DWORD PTR [rbp-0x178]
   12c4e:	49 89 da             	mov    r10,rbx
   12c51:	89 85 c0 fe ff ff    	mov    DWORD PTR [rbp-0x140],eax
   12c57:	e9 01 da ff ff       	jmp    1065d <try_secant_tail.constprop.0+0x77d>
   12c5c:	31 f6                	xor    esi,esi
   12c5e:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   12c62:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   12c66:	31 d2                	xor    edx,edx
   12c68:	e9 e5 f8 ff ff       	jmp    12552 <try_secant_tail.constprop.0+0x2672>
   12c6d:	d9 e8                	fld1
   12c6f:	e9 38 f9 ff ff       	jmp    125ac <try_secant_tail.constprop.0+0x26cc>
   12c74:	49 89 da             	mov    r10,rbx
   12c77:	4c 8d ad 40 ff ff ff 	lea    r13,[rbp-0xc0]
   12c7e:	e9 9b fa ff ff       	jmp    1271e <try_secant_tail.constprop.0+0x283e>
   12c83:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   12c87:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   12c8b:	31 c0                	xor    eax,eax
   12c8d:	c5 f9 28 d3          	vmovapd xmm2,xmm3
   12c91:	c5 f9 28 c1          	vmovapd xmm0,xmm1
   12c95:	e9 2e eb ff ff       	jmp    117c8 <try_secant_tail.constprop.0+0x18e8>
   12c9a:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   12c9e:	e9 a9 eb ff ff       	jmp    1184c <try_secant_tail.constprop.0+0x196c>
   12ca3:	c5 f8 77             	vzeroupper
   12ca6:	e9 8f fe ff ff       	jmp    12b3a <try_secant_tail.constprop.0+0x2c5a>
   12cab:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   12caf:	e9 9a fe ff ff       	jmp    12b4e <try_secant_tail.constprop.0+0x2c6e>
   12cb4:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 12cbc <try_secant_tail.constprop.0+0x2ddc>
   12cbb:	00 
   12cbc:	e9 8d fe ff ff       	jmp    12b4e <try_secant_tail.constprop.0+0x2c6e>
   12cc1:	48 89 9d f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],rbx
   12cc8:	c7 85 0c ff ff ff 01 	mov    DWORD PTR [rbp-0xf4],0x1
   12ccf:	00 00 00 
   12cd2:	e9 2a e9 ff ff       	jmp    11601 <try_secant_tail.constprop.0+0x1721>
   12cd7:	8b 85 88 fe ff ff    	mov    eax,DWORD PTR [rbp-0x178]
   12cdd:	49 89 da             	mov    r10,rbx
   12ce0:	89 85 c0 fe ff ff    	mov    DWORD PTR [rbp-0x140],eax
   12ce6:	c5 f8 77             	vzeroupper
   12ce9:	e9 6f d9 ff ff       	jmp    1065d <try_secant_tail.constprop.0+0x77d>
   12cee:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   12cf2:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   12cf6:	31 c0                	xor    eax,eax
   12cf8:	c5 f9 28 d3          	vmovapd xmm2,xmm3
   12cfc:	c5 f9 28 c1          	vmovapd xmm0,xmm1
   12d00:	e9 c5 fd ff ff       	jmp    12aca <try_secant_tail.constprop.0+0x2bea>
   12d05:	44 89 9d d0 fe ff ff 	mov    DWORD PTR [rbp-0x130],r11d
   12d0c:	49 89 da             	mov    r10,rbx
   12d0f:	e9 86 dc ff ff       	jmp    1099a <try_secant_tail.constprop.0+0xaba>
   12d14:	44 89 9d d0 fe ff ff 	mov    DWORD PTR [rbp-0x130],r11d
   12d1b:	49 89 da             	mov    r10,rbx
   12d1e:	4c 8d ad 40 ff ff ff 	lea    r13,[rbp-0xc0]
   12d25:	e9 f4 f9 ff ff       	jmp    1271e <try_secant_tail.constprop.0+0x283e>
   12d2a:	e8 00 00 00 00       	call   12d2f <try_secant_tail.constprop.0+0x2e4f>
   12d2f:	4c 8d ad 40 ff ff ff 	lea    r13,[rbp-0xc0]
   12d36:	e9 f8 e8 ff ff       	jmp    11633 <try_secant_tail.constprop.0+0x1753>
   12d3b:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   12d42:	4c 89 f7             	mov    rdi,r14
   12d45:	e8 00 00 00 00       	call   12d4a <try_secant_tail.constprop.0+0x2e6a>
   12d4a:	48 8b bd f8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x108]
   12d51:	e8 00 00 00 00       	call   12d56 <try_secant_tail.constprop.0+0x2e76>
   12d56:	48 8b bd 18 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1e8]
   12d5d:	e8 be d4 fe ff       	call   220 <bs_free>
   12d62:	e9 0a d2 ff ff       	jmp    ff71 <try_secant_tail.constprop.0+0x91>
   12d67:	48 8b bd 58 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1a8]
   12d6e:	4c 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r10
   12d75:	e8 00 00 00 00       	call   12d7a <try_secant_tail.constprop.0+0x2e9a>
   12d7a:	48 8b bd 10 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f0]
   12d81:	e8 00 00 00 00       	call   12d86 <try_secant_tail.constprop.0+0x2ea6>
   12d86:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   12d8d:	e8 00 00 00 00       	call   12d92 <try_secant_tail.constprop.0+0x2eb2>
   12d92:	eb ae                	jmp    12d42 <try_secant_tail.constprop.0+0x2e62>
   12d94:	c5 f8 77             	vzeroupper
   12d97:	e9 e1 e1 ff ff       	jmp    10f7d <try_secant_tail.constprop.0+0x109d>
   12d9c:	c5 f8 77             	vzeroupper
   12d9f:	e9 09 e2 ff ff       	jmp    10fad <try_secant_tail.constprop.0+0x10cd>
