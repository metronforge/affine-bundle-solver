/tmp/abs-stage2b-measured-normal/trace.o:     file format elf64-x86-64


Disassembly of section .text:

00000000000300f0 <abs_tail_replay>:
   300f0:	f3 0f 1e fa          	endbr64
   300f4:	4c 8d 54 24 08       	lea    r10,[rsp+0x8]
   300f9:	48 83 e4 e0          	and    rsp,0xffffffffffffffe0
   300fd:	c5 f9 ef c0          	vpxor  xmm0,xmm0,xmm0
   30101:	41 ff 72 f8          	push   QWORD PTR [r10-0x8]
   30105:	55                   	push   rbp
   30106:	48 89 e5             	mov    rbp,rsp
   30109:	41 52                	push   r10
   3010b:	53                   	push   rbx
   3010c:	48 83 ec 48          	sub    rsp,0x48
   30110:	49 8b 02             	mov    rax,QWORD PTR [r10]
   30113:	64 48 8b 1c 25 28 00 	mov    rbx,QWORD PTR fs:0x28
   3011a:	00 00 
   3011c:	48 89 5d e8          	mov    QWORD PTR [rbp-0x18],rbx
   30120:	49 8b 5a 08          	mov    rbx,QWORD PTR [r10+0x8]
   30124:	c5 f9 7f 45 c0       	vmovdqa XMMWORD PTR [rbp-0x40],xmm0
   30129:	4c 8d 55 c0          	lea    r10,[rbp-0x40]
   3012d:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   30131:	c5 f9 29 45 d0       	vmovapd XMMWORD PTR [rbp-0x30],xmm0
   30136:	48 c7 45 e0 00 00 00 	mov    QWORD PTR [rbp-0x20],0x0
   3013d:	00 
   3013e:	41 52                	push   r10
   30140:	50                   	push   rax
   30141:	41 51                	push   r9
   30143:	45 89 c1             	mov    r9d,r8d
   30146:	41 89 c8             	mov    r8d,ecx
   30149:	89 d1                	mov    ecx,edx
   3014b:	31 d2                	xor    edx,edx
   3014d:	e8 3e 23 fe ff       	call   12490 <try_secant_tail.constprop.0>
   30152:	c5 fb 10 55 e0       	vmovsd xmm2,QWORD PTR [rbp-0x20]
   30157:	c5 fe e6 45 c0       	vcvtdq2pd ymm0,XMMWORD PTR [rbp-0x40]
   3015c:	c5 fd 11 03          	vmovupd YMMWORD PTR [rbx],ymm0
   30160:	c5 f8 57 c0          	vxorps xmm0,xmm0,xmm0
   30164:	c5 fb 10 5d d0       	vmovsd xmm3,QWORD PTR [rbp-0x30]
   30169:	c5 e1 16 4d d8       	vmovhpd xmm1,xmm3,QWORD PTR [rbp-0x28]
   3016e:	48 83 c4 20          	add    rsp,0x20
   30172:	c5 fb 2a c0          	vcvtsi2sd xmm0,xmm0,eax
   30176:	c5 e9 14 c0          	vunpcklpd xmm0,xmm2,xmm0
   3017a:	c4 e3 75 18 c0 01    	vinsertf128 ymm0,ymm1,xmm0,0x1
   30180:	c5 fd 11 43 20       	vmovupd YMMWORD PTR [rbx+0x20],ymm0
   30185:	48 8b 45 e8          	mov    rax,QWORD PTR [rbp-0x18]
   30189:	64 48 2b 04 25 28 00 	sub    rax,QWORD PTR fs:0x28
   30190:	00 00 
   30192:	75 10                	jne    301a4 <abs_tail_replay+0xb4>
   30194:	c5 f8 77             	vzeroupper
   30197:	48 8d 65 f0          	lea    rsp,[rbp-0x10]
   3019b:	5b                   	pop    rbx
   3019c:	41 5a                	pop    r10
   3019e:	5d                   	pop    rbp
   3019f:	49 8d 62 f8          	lea    rsp,[r10-0x8]
   301a3:	c3                   	ret
   301a4:	c5 f8 77             	vzeroupper
   301a7:	e8 00 00 00 00       	call   301ac <abs_tail_replay+0xbc>
