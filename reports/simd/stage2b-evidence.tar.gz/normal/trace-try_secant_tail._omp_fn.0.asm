/tmp/abs-stage2b-measured-normal/trace.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000004ad0 <try_secant_tail._omp_fn.0>:
    4ad0:	f3 0f 1e fa          	endbr64
    4ad4:	55                   	push   rbp
    4ad5:	48 89 e5             	mov    rbp,rsp
    4ad8:	41 57                	push   r15
    4ada:	41 56                	push   r14
    4adc:	41 55                	push   r13
    4ade:	41 54                	push   r12
    4ae0:	49 89 fc             	mov    r12,rdi
    4ae3:	53                   	push   rbx
    4ae4:	48 83 e4 e0          	and    rsp,0xffffffffffffffe0
    4ae8:	48 81 ec c0 00 00 00 	sub    rsp,0xc0
    4aef:	e8 00 00 00 00       	call   4af4 <try_secant_tail._omp_fn.0+0x24>
    4af4:	48 63 d8             	movsxd rbx,eax
    4af7:	e8 00 00 00 00       	call   4afc <try_secant_tail._omp_fn.0+0x2c>
    4afc:	89 c1                	mov    ecx,eax
    4afe:	41 8b 44 24 60       	mov    eax,DWORD PTR [r12+0x60]
    4b03:	99                   	cdq
    4b04:	f7 f9                	idiv   ecx
    4b06:	39 d3                	cmp    ebx,edx
    4b08:	8d 48 01             	lea    ecx,[rax+0x1]
    4b0b:	0f 4c c1             	cmovl  eax,ecx
    4b0e:	b9 00 00 00 00       	mov    ecx,0x0
    4b13:	0f 4c d1             	cmovl  edx,ecx
    4b16:	89 c1                	mov    ecx,eax
    4b18:	0f af cb             	imul   ecx,ebx
    4b1b:	01 ca                	add    edx,ecx
    4b1d:	8d 0c 10             	lea    ecx,[rax+rdx*1]
    4b20:	39 ca                	cmp    edx,ecx
    4b22:	0f 8d 69 06 00 00    	jge    5191 <try_secant_tail._omp_fn.0+0x6c1>
    4b28:	4d 63 74 24 58       	movsxd r14,DWORD PTR [r12+0x58]
    4b2d:	49 8b 3c 24          	mov    rdi,QWORD PTR [r12]
    4b31:	89 c0                	mov    eax,eax
    4b33:	4d 8b 6c 24 40       	mov    r13,QWORD PTR [r12+0x40]
    4b38:	49 8b 74 24 48       	mov    rsi,QWORD PTR [r12+0x48]
    4b3d:	48 89 bc 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rdi
    4b44:	00 
    4b45:	4c 89 f7             	mov    rdi,r14
    4b48:	45 8b 7c 24 5c       	mov    r15d,DWORD PTR [r12+0x5c]
    4b4d:	4e 8d 0c f5 00 00 00 	lea    r9,[r14*8+0x0]
    4b54:	00 
    4b55:	48 0f af fb          	imul   rdi,rbx
    4b59:	48 c1 e3 04          	shl    rbx,0x4
    4b5d:	49 03 5c 24 50       	add    rbx,QWORD PTR [r12+0x50]
    4b62:	48 89 74 24 60       	mov    QWORD PTR [rsp+0x60],rsi
    4b67:	48 89 5c 24 50       	mov    QWORD PTR [rsp+0x50],rbx
    4b6c:	48 63 da             	movsxd rbx,edx
    4b6f:	4d 89 f2             	mov    r10,r14
    4b72:	4d 8b 44 24 28       	mov    r8,QWORD PTR [r12+0x28]
    4b77:	49 01 dd             	add    r13,rbx
    4b7a:	4c 89 4c 24 40       	mov    QWORD PTR [rsp+0x40],r9
    4b7f:	4d 63 cf             	movsxd r9,r15d
    4b82:	c4 c1 7b 10 6c 24 30 	vmovsd xmm5,QWORD PTR [r12+0x30]
    4b89:	48 89 f9             	mov    rcx,rdi
    4b8c:	49 01 d9             	add    r9,rbx
    4b8f:	49 8b 5c 24 08       	mov    rbx,QWORD PTR [r12+0x8]
    4b94:	4c 89 b4 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],r14
    4b9b:	00 
    4b9c:	48 c1 e1 04          	shl    rcx,0x4
    4ba0:	c5 fb 11 6c 24 58    	vmovsd QWORD PTR [rsp+0x58],xmm5
    4ba6:	c4 c1 7b 10 6c 24 10 	vmovsd xmm5,QWORD PTR [r12+0x10]
    4bad:	4c 8d 1c 0e          	lea    r11,[rsi+rcx*1]
    4bb1:	4c 89 ee             	mov    rsi,r13
    4bb4:	4a 8d 1c cb          	lea    rbx,[rbx+r9*8]
    4bb8:	4d 89 f5             	mov    r13,r14
    4bbb:	48 01 f0             	add    rax,rsi
    4bbe:	4d 0f af e9          	imul   r13,r9
    4bc2:	4c 8b 4c 24 40       	mov    r9,QWORD PTR [rsp+0x40]
    4bc7:	c5 fb 11 6c 24 68    	vmovsd QWORD PTR [rsp+0x68],xmm5
    4bcd:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    4bd2:	41 8d 46 ff          	lea    eax,[r14-0x1]
    4bd6:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    4bdd:	48 8d 04 3f          	lea    rax,[rdi+rdi*1]
    4be1:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    4be6:	4d 01 c1             	add    r9,r8
    4be9:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
    4bee:	4c 01 f0             	add    rax,r14
    4bf1:	48 89 44 24 20       	mov    QWORD PTR [rsp+0x20],rax
    4bf6:	48 c1 e0 03          	shl    rax,0x3
    4bfa:	4c 8d 34 07          	lea    r14,[rdi+rax*1]
    4bfe:	48 2b bc 24 b0 00 00 	sub    rdi,QWORD PTR [rsp+0xb0]
    4c05:	00 
    4c06:	4c 89 b4 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],r14
    4c0d:	00 
    4c0e:	4c 8d 34 07          	lea    r14,[rdi+rax*1]
    4c12:	4c 89 74 24 38       	mov    QWORD PTR [rsp+0x38],r14
    4c17:	4c 8d 70 20          	lea    r14,[rax+0x20]
    4c1b:	4c 39 f1             	cmp    rcx,r14
    4c1e:	4c 8d 71 20          	lea    r14,[rcx+0x20]
    4c22:	0f 9d 84 24 b8 00 00 	setge  BYTE PTR [rsp+0xb8]
    4c29:	00 
    4c2a:	4c 39 f0             	cmp    rax,r14
    4c2d:	49 89 f6             	mov    r14,rsi
    4c30:	0f 9d c0             	setge  al
    4c33:	0a 84 24 b8 00 00 00 	or     al,BYTE PTR [rsp+0xb8]
    4c3a:	88 44 24 37          	mov    BYTE PTR [rsp+0x37],al
    4c3e:	48 8d 04 39          	lea    rax,[rcx+rdi*1]
    4c42:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    4c47:	41 8d 44 17 01       	lea    eax,[r15+rdx*1+0x1]
    4c4c:	29 f0                	sub    eax,esi
    4c4e:	89 84 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],eax
    4c55:	48 b8 15 7c 4a 7f b9 	movabs rax,0x9e3779b97f4a7c15
    4c5c:	79 37 9e 
    4c5f:	49 03 44 24 18       	add    rax,QWORD PTR [r12+0x18]
    4c64:	48 89 44 24 48       	mov    QWORD PTR [rsp+0x48],rax
    4c69:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # 4c71 <try_secant_tail._omp_fn.0+0x1a1>
    4c70:	00 
    4c71:	c4 c1 53 58 6c 24 38 	vaddsd xmm5,xmm5,QWORD PTR [r12+0x38]
    4c78:	4c 89 8c 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],r9
    4c7f:	00 
    4c80:	4c 89 64 24 70       	mov    QWORD PTR [rsp+0x70],r12
    4c85:	4c 8b a4 24 a0 00 00 	mov    r12,QWORD PTR [rsp+0xa0]
    4c8c:	00 
    4c8d:	c5 fb 11 6c 24 10    	vmovsd QWORD PTR [rsp+0x10],xmm5
    4c93:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    4c98:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
    4c9f:	00 
    4ca0:	45 85 d2             	test   r10d,r10d
    4ca3:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
    4ca7:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
    4cab:	4a 8d 04 ed 00 00 00 	lea    rax,[r13*8+0x0]
    4cb2:	00 
    4cb3:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    4cba:	00 
    4cbb:	48 8d 3c 06          	lea    rdi,[rsi+rax*1]
    4cbf:	0f 8e e3 04 00 00    	jle    51a8 <try_secant_tail._omp_fn.0+0x6d8>
    4cc5:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    4cca:	83 bc 24 84 00 00 00 	cmp    DWORD PTR [rsp+0x84],0x2
    4cd1:	02 
    4cd2:	48 8b 40 20          	mov    rax,QWORD PTR [rax+0x20]
    4cd6:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
    4cda:	0f 86 26 05 00 00    	jbe    5206 <try_secant_tail._omp_fn.0+0x736>
    4ce0:	44 89 d1             	mov    ecx,r10d
    4ce3:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
    4ce7:	4c 8b 8c 24 b8 00 00 	mov    r9,QWORD PTR [rsp+0xb8]
    4cee:	00 
    4cef:	31 d2                	xor    edx,edx
    4cf1:	c5 fd 28 dc          	vmovapd ymm3,ymm4
    4cf5:	c1 e9 02             	shr    ecx,0x2
    4cf8:	c5 fd 28 cc          	vmovapd ymm1,ymm4
    4cfc:	c5 fd 28 d4          	vmovapd ymm2,ymm4
    4d00:	48 c1 e1 05          	shl    rcx,0x5
    4d04:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    4d09:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    4d10:	00 00 00 00 
    4d14:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    4d1b:	00 00 00 00 
    4d1f:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    4d26:	00 00 00 00 
    4d2a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    4d31:	00 00 00 00 
    4d35:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    4d3c:	00 00 00 00 
    4d40:	c5 fd 10 04 17       	vmovupd ymm0,YMMWORD PTR [rdi+rdx*1]
    4d45:	c4 e2 fd b8 1c 10    	vfmadd231pd ymm3,ymm0,YMMWORD PTR [rax+rdx*1]
    4d4b:	c4 c2 fd b8 0c 10    	vfmadd231pd ymm1,ymm0,YMMWORD PTR [r8+rdx*1]
    4d51:	c4 c2 fd b8 14 11    	vfmadd231pd ymm2,ymm0,YMMWORD PTR [r9+rdx*1]
    4d57:	48 83 c2 20          	add    rdx,0x20
    4d5b:	48 39 d1             	cmp    rcx,rdx
    4d5e:	c4 e2 fd b8 e0       	vfmadd231pd ymm4,ymm0,ymm0
    4d63:	75 db                	jne    4d40 <try_secant_tail._omp_fn.0+0x270>
    4d65:	c4 e3 7d 19 d6 01    	vextractf128 xmm6,ymm2,0x1
    4d6b:	c4 e3 7d 19 e5 01    	vextractf128 xmm5,ymm4,0x1
    4d71:	44 89 d2             	mov    edx,r10d
    4d74:	4c 89 8c 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],r9
    4d7b:	00 
    4d7c:	c5 c9 58 f2          	vaddpd xmm6,xmm6,xmm2
    4d80:	c4 e3 7d 19 ca 01    	vextractf128 xmm2,ymm1,0x1
    4d86:	c5 d1 58 ec          	vaddpd xmm5,xmm5,xmm4
    4d8a:	83 e2 fc             	and    edx,0xfffffffc
    4d8d:	c5 e9 58 d1          	vaddpd xmm2,xmm2,xmm1
    4d91:	c4 e3 7d 19 dc 01    	vextractf128 xmm4,ymm3,0x1
    4d97:	41 39 d2             	cmp    r10d,edx
    4d9a:	89 d1                	mov    ecx,edx
    4d9c:	c5 d9 58 db          	vaddpd xmm3,xmm4,xmm3
    4da0:	c5 49 15 c6          	vunpckhpd xmm8,xmm6,xmm6
    4da4:	c5 d1 15 c5          	vunpckhpd xmm0,xmm5,xmm5
    4da8:	c5 e9 15 fa          	vunpckhpd xmm7,xmm2,xmm2
    4dac:	c5 39 58 c6          	vaddpd xmm8,xmm8,xmm6
    4db0:	c5 f9 58 c5          	vaddpd xmm0,xmm0,xmm5
    4db4:	c5 c1 58 fa          	vaddpd xmm7,xmm7,xmm2
    4db8:	c5 e1 15 e3          	vunpckhpd xmm4,xmm3,xmm3
    4dbc:	c5 d9 58 e3          	vaddpd xmm4,xmm4,xmm3
    4dc0:	c5 b9 14 ff          	vunpcklpd xmm7,xmm8,xmm7
    4dc4:	0f 84 ac 00 00 00    	je     4e76 <try_secant_tail._omp_fn.0+0x3a6>
    4dca:	44 89 d6             	mov    esi,r10d
    4dcd:	29 ce                	sub    esi,ecx
    4dcf:	83 fe 01             	cmp    esi,0x1
    4dd2:	74 74                	je     4e48 <try_secant_tail._omp_fn.0+0x378>
    4dd4:	4c 8b bc 24 a8 00 00 	mov    r15,QWORD PTR [rsp+0xa8]
    4ddb:	00 
    4ddc:	4c 8b 8c 24 b0 00 00 	mov    r9,QWORD PTR [rsp+0xb0]
    4de3:	00 
    4de4:	49 01 cf             	add    r15,rcx
    4de7:	40 f6 c6 01          	test   sil,0x1
    4deb:	4c 89 bc 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],r15
    4df2:	00 
    4df3:	4d 8d 7c 0d 00       	lea    r15,[r13+rcx*1+0x0]
    4df8:	c4 81 79 10 04 f9    	vmovupd xmm0,XMMWORD PTR [r9+r15*8]
    4dfe:	4c 8b bc 24 a0 00 00 	mov    r15,QWORD PTR [rsp+0xa0]
    4e05:	00 
    4e06:	c4 e2 f9 b8 1c c8    	vfmadd231pd xmm3,xmm0,XMMWORD PTR [rax+rcx*8]
    4e0c:	c4 c2 f9 b8 14 c8    	vfmadd231pd xmm2,xmm0,XMMWORD PTR [r8+rcx*8]
    4e12:	c4 82 f9 b8 34 f8    	vfmadd231pd xmm6,xmm0,XMMWORD PTR [r8+r15*8]
    4e18:	c4 e2 f9 b8 e8       	vfmadd231pd xmm5,xmm0,xmm0
    4e1d:	c5 e1 15 e3          	vunpckhpd xmm4,xmm3,xmm3
    4e21:	c5 d9 58 e3          	vaddpd xmm4,xmm4,xmm3
    4e25:	c5 c9 15 ce          	vunpckhpd xmm1,xmm6,xmm6
    4e29:	c5 e9 15 da          	vunpckhpd xmm3,xmm2,xmm2
    4e2d:	c5 f1 58 ce          	vaddpd xmm1,xmm1,xmm6
    4e31:	c5 e1 58 d2          	vaddpd xmm2,xmm3,xmm2
    4e35:	c5 d1 15 c5          	vunpckhpd xmm0,xmm5,xmm5
    4e39:	c5 f9 58 c5          	vaddpd xmm0,xmm0,xmm5
    4e3d:	c5 f1 14 fa          	vunpcklpd xmm7,xmm1,xmm2
    4e41:	74 33                	je     4e76 <try_secant_tail._omp_fn.0+0x3a6>
    4e43:	83 e6 fe             	and    esi,0xfffffffe
    4e46:	01 f2                	add    edx,esi
    4e48:	48 63 ca             	movsxd rcx,edx
    4e4b:	44 01 d2             	add    edx,r10d
    4e4e:	c5 fb 10 14 cf       	vmovsd xmm2,QWORD PTR [rdi+rcx*8]
    4e53:	48 63 d2             	movsxd rdx,edx
    4e56:	c4 e2 e9 b9 24 c8    	vfmadd231sd xmm4,xmm2,QWORD PTR [rax+rcx*8]
    4e5c:	c5 fb 12 da          	vmovddup xmm3,xmm2
    4e60:	c4 e2 e9 b9 c2       	vfmadd231sd xmm0,xmm2,xmm2
    4e65:	c4 c1 7b 10 14 d0    	vmovsd xmm2,QWORD PTR [r8+rdx*8]
    4e6b:	c4 c1 69 16 14 c8    	vmovhpd xmm2,xmm2,QWORD PTR [r8+rcx*8]
    4e71:	c4 e2 e9 b8 fb       	vfmadd231pd xmm7,xmm2,xmm3
    4e76:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    4e7a:	c5 f9 2f c2          	vcomisd xmm0,xmm2
    4e7e:	0f 86 24 03 00 00    	jbe    51a8 <try_secant_tail._omp_fn.0+0x6d8>
    4e84:	48 b8 00 00 00 00 00 	movabs rax,0x7ff0000000000000
    4e8b:	00 f0 7f 
    4e8e:	c4 e1 f9 7e c6       	vmovq  rsi,xmm0
    4e93:	c4 e2 c8 f2 c0       	andn   rax,rsi,rax
    4e98:	0f 84 0a 03 00 00    	je     51a8 <try_secant_tail._omp_fn.0+0x6d8>
    4e9e:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
    4ea2:	8b 84 24 80 00 00 00 	mov    eax,DWORD PTR [rsp+0x80]
    4ea9:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # 4eb1 <try_secant_tail._omp_fn.0+0x3e1>
    4eb0:	00 
    4eb1:	48 be eb 11 31 13 bb 	movabs rsi,0x94d049bb133111eb
    4eb8:	49 d0 94 
    4ebb:	49 b9 b9 e5 e4 1c 6d 	movabs r9,0xbf58476d1ce4e5b9
    4ec2:	47 58 bf 
    4ec5:	c5 fb 10 15 00 00 00 	vmovsd xmm2,QWORD PTR [rip+0x0]        # 4ecd <try_secant_tail._omp_fn.0+0x3fd>
    4ecc:	00 
    4ecd:	c5 fb 10 0d 00 00 00 	vmovsd xmm1,QWORD PTR [rip+0x0]        # 4ed5 <try_secant_tail._omp_fn.0+0x405>
    4ed4:	00 
    4ed5:	c5 d3 5e c0          	vdivsd xmm0,xmm5,xmm0
    4ed9:	44 01 f0             	add    eax,r14d
    4edc:	c5 41 54 0d 00 00 00 	vandpd xmm9,xmm7,XMMWORD PTR [rip+0x0]        # 4ee4 <try_secant_tail._omp_fn.0+0x414>
    4ee3:	00 
    4ee4:	c5 fb 10 74 24 58    	vmovsd xmm6,QWORD PTR [rsp+0x58]
    4eea:	48 98                	cdqe
    4eec:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
    4ef0:	48 89 c1             	mov    rcx,rax
    4ef3:	48 0f af ce          	imul   rcx,rsi
    4ef7:	48 03 4c 24 48       	add    rcx,QWORD PTR [rsp+0x48]
    4efc:	49 89 cf             	mov    r15,rcx
    4eff:	49 c1 ef 1e          	shr    r15,0x1e
    4f03:	49 31 cf             	xor    r15,rcx
    4f06:	4d 0f af f9          	imul   r15,r9
    4f0a:	4c 89 fa             	mov    rdx,r15
    4f0d:	48 c1 ea 1b          	shr    rdx,0x1b
    4f11:	4c 31 fa             	xor    rdx,r15
    4f14:	48 0f af d6          	imul   rdx,rsi
    4f18:	49 89 d7             	mov    r15,rdx
    4f1b:	49 c1 ef 1f          	shr    r15,0x1f
    4f1f:	49 31 d7             	xor    r15,rdx
    4f22:	48 ba ce d3 b3 09 b2 	movabs rdx,0x2a87fdb209b3d3ce
    4f29:	fd 87 2a 
    4f2c:	48 0f af c2          	imul   rax,rdx
    4f30:	49 c1 ef 0b          	shr    r15,0xb
    4f34:	c4 c1 c3 2a df       	vcvtsi2sd xmm3,xmm7,r15
    4f39:	c4 e2 f1 99 da       	vfmadd132sd xmm3,xmm1,xmm2
    4f3e:	48 01 c8             	add    rax,rcx
    4f41:	48 89 c2             	mov    rdx,rax
    4f44:	c5 7b 59 03          	vmulsd xmm8,xmm0,QWORD PTR [rbx]
    4f48:	48 c1 ea 1e          	shr    rdx,0x1e
    4f4c:	c5 e3 59 de          	vmulsd xmm3,xmm3,xmm6
    4f50:	48 31 c2             	xor    rdx,rax
    4f53:	49 0f af d1          	imul   rdx,r9
    4f57:	48 89 d0             	mov    rax,rdx
    4f5a:	48 c1 e8 1b          	shr    rax,0x1b
    4f5e:	48 31 d0             	xor    rax,rdx
    4f61:	48 0f af c6          	imul   rax,rsi
    4f65:	48 89 c2             	mov    rdx,rax
    4f68:	48 c1 ea 1f          	shr    rdx,0x1f
    4f6c:	48 31 c2             	xor    rdx,rax
    4f6f:	48 c1 ea 0b          	shr    rdx,0xb
    4f73:	c4 e1 c3 2a ea       	vcvtsi2sd xmm5,xmm7,rdx
    4f78:	c4 e2 f1 99 ea       	vfmadd132sd xmm5,xmm1,xmm2
    4f7d:	48 8b 15 00 00 00 00 	mov    rdx,QWORD PTR [rip+0x0]        # 4f84 <try_secant_tail._omp_fn.0+0x4b4>
    4f84:	4c 8b 8c 24 b8 00 00 	mov    r9,QWORD PTR [rsp+0xb8]
    4f8b:	00 
    4f8c:	c5 d3 59 ee          	vmulsd xmm5,xmm5,xmm6
    4f90:	c4 e1 f9 6e f2       	vmovq  xmm6,rdx
    4f95:	c5 cb 58 3d 00 00 00 	vaddsd xmm7,xmm6,QWORD PTR [rip+0x0]        # 4f9d <try_secant_tail._omp_fn.0+0x4cd>
    4f9c:	00 
    4f9d:	48 89 d0             	mov    rax,rdx
    4fa0:	c4 e1 f9 7e f9       	vmovq  rcx,xmm7
    4fa5:	f0 48 0f b1 0d 00 00 	lock cmpxchg QWORD PTR [rip+0x0],rcx        # 4fae <try_secant_tail._omp_fn.0+0x4de>
    4fac:	00 00 
    4fae:	0f 85 ce 02 00 00    	jne    5282 <try_secant_tail._omp_fn.0+0x7b2>
    4fb4:	45 85 d2             	test   r10d,r10d
    4fb7:	4c 89 8c 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],r9
    4fbe:	00 
    4fbf:	0f 8e 4b 01 00 00    	jle    5110 <try_secant_tail._omp_fn.0+0x640>
    4fc5:	c5 fb 59 cb          	vmulsd xmm1,xmm0,xmm3
    4fc9:	41 83 fa 01          	cmp    r10d,0x1
    4fcd:	c5 7b 59 d5          	vmulsd xmm10,xmm0,xmm5
    4fd1:	0f 84 54 02 00 00    	je     522b <try_secant_tail._omp_fn.0+0x75b>
    4fd7:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    4fdc:	48 8b b4 24 88 00 00 	mov    rsi,QWORD PTR [rsp+0x88]
    4fe3:	00 
    4fe4:	48 83 e8 08          	sub    rax,0x8
    4fe8:	48 29 f0             	sub    rax,rsi
    4feb:	48 83 f8 10          	cmp    rax,0x10
    4fef:	0f 97 c0             	seta   al
    4ff2:	84 44 24 37          	test   BYTE PTR [rsp+0x37],al
    4ff6:	0f 84 2f 02 00 00    	je     522b <try_secant_tail._omp_fn.0+0x75b>
    4ffc:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    5001:	48 83 e8 08          	sub    rax,0x8
    5005:	48 29 f0             	sub    rax,rsi
    5008:	48 83 f8 10          	cmp    rax,0x10
    500c:	0f 86 19 02 00 00    	jbe    522b <try_secant_tail._omp_fn.0+0x75b>
    5012:	83 bc 24 84 00 00 00 	cmp    DWORD PTR [rsp+0x84],0x2
    5019:	02 
    501a:	0f 86 56 02 00 00    	jbe    5276 <try_secant_tail._omp_fn.0+0x7a6>
    5020:	44 89 d2             	mov    edx,r10d
    5023:	c4 e2 7d 19 f9       	vbroadcastsd ymm7,xmm1
    5028:	c4 c2 7d 19 f2       	vbroadcastsd ymm6,xmm10
    502d:	31 c0                	xor    eax,eax
    502f:	c1 ea 02             	shr    edx,0x2
    5032:	48 c1 e2 05          	shl    rdx,0x5
    5036:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
    503d:	00 00 00 
    5040:	c5 fd 10 14 07       	vmovupd ymm2,YMMWORD PTR [rdi+rax*1]
    5045:	c5 7d 28 da          	vmovapd ymm11,ymm2
    5049:	c4 42 c5 a8 1c 03    	vfmadd213pd ymm11,ymm7,YMMWORD PTR [r11+rax*1]
    504f:	c4 41 7d 11 1c 03    	vmovupd YMMWORD PTR [r11+rax*1],ymm11
    5055:	c4 c2 cd a8 14 04    	vfmadd213pd ymm2,ymm6,YMMWORD PTR [r12+rax*1]
    505b:	c4 c1 7d 11 14 04    	vmovupd YMMWORD PTR [r12+rax*1],ymm2
    5061:	48 83 c0 20          	add    rax,0x20
    5065:	48 39 c2             	cmp    rdx,rax
    5068:	75 d6                	jne    5040 <try_secant_tail._omp_fn.0+0x570>
    506a:	44 89 d0             	mov    eax,r10d
    506d:	4c 89 8c 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],r9
    5074:	00 
    5075:	83 e0 fc             	and    eax,0xfffffffc
    5078:	44 39 d0             	cmp    eax,r10d
    507b:	89 c2                	mov    edx,eax
    507d:	0f 84 8d 00 00 00    	je     5110 <try_secant_tail._omp_fn.0+0x640>
    5083:	44 89 d1             	mov    ecx,r10d
    5086:	29 c1                	sub    ecx,eax
    5088:	83 f9 01             	cmp    ecx,0x1
    508b:	74 54                	je     50e1 <try_secant_tail._omp_fn.0+0x611>
    508d:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    5092:	4c 8b 4c 24 60       	mov    r9,QWORD PTR [rsp+0x60]
    5097:	c5 fb 12 f1          	vmovddup xmm6,xmm1
    509b:	c4 c1 7b 12 d2       	vmovddup xmm2,xmm10
    50a0:	48 01 d6             	add    rsi,rdx
    50a3:	4d 8d 3c f1          	lea    r15,[r9+rsi*8]
    50a7:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    50ac:	48 01 d6             	add    rsi,rdx
    50af:	4c 01 ea             	add    rdx,r13
    50b2:	f6 c1 01             	test   cl,0x1
    50b5:	49 8d 34 f1          	lea    rsi,[r9+rsi*8]
    50b9:	4c 8b 8c 24 b0 00 00 	mov    r9,QWORD PTR [rsp+0xb0]
    50c0:	00 
    50c1:	c4 c1 79 10 3c d1    	vmovupd xmm7,XMMWORD PTR [r9+rdx*8]
    50c7:	c4 c2 c1 a8 37       	vfmadd213pd xmm6,xmm7,XMMWORD PTR [r15]
    50cc:	c4 c1 79 11 37       	vmovupd XMMWORD PTR [r15],xmm6
    50d1:	c4 e2 c1 a8 16       	vfmadd213pd xmm2,xmm7,XMMWORD PTR [rsi]
    50d6:	c5 f9 11 16          	vmovupd XMMWORD PTR [rsi],xmm2
    50da:	74 34                	je     5110 <try_secant_tail._omp_fn.0+0x640>
    50dc:	83 e1 fe             	and    ecx,0xfffffffe
    50df:	01 c8                	add    eax,ecx
    50e1:	48 98                	cdqe
    50e3:	48 8d 14 c5 00 00 00 	lea    rdx,[rax*8+0x0]
    50ea:	00 
    50eb:	c5 fb 10 14 c7       	vmovsd xmm2,QWORD PTR [rdi+rax*8]
    50f0:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    50f5:	c4 c2 e9 a9 0c 13    	vfmadd213sd xmm1,xmm2,QWORD PTR [r11+rdx*1]
    50fb:	48 01 d0             	add    rax,rdx
    50fe:	c4 c1 7b 11 0c 13    	vmovsd QWORD PTR [r11+rdx*1],xmm1
    5104:	c4 c2 a9 a9 14 03    	vfmadd213sd xmm2,xmm10,QWORD PTR [r11+rax*1]
    510a:	c4 c1 7b 11 14 03    	vmovsd QWORD PTR [r11+rax*1],xmm2
    5110:	c4 c1 31 15 c9       	vunpckhpd xmm1,xmm9,xmm9
    5115:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    511a:	c4 c1 71 5f c9       	vmaxpd xmm1,xmm1,xmm9
    511f:	c4 e2 b9 a9 18       	vfmadd213sd xmm3,xmm8,QWORD PTR [rax]
    5124:	c4 e2 b9 a9 68 08    	vfmadd213sd xmm5,xmm8,QWORD PTR [rax+0x8]
    512a:	c5 f3 59 c8          	vmulsd xmm1,xmm1,xmm0
    512e:	c5 f9 2f 0d 00 00 00 	vcomisd xmm1,QWORD PTR [rip+0x0]        # 5136 <try_secant_tail._omp_fn.0+0x666>
    5135:	00 
    5136:	c5 fb 11 18          	vmovsd QWORD PTR [rax],xmm3
    513a:	c5 fb 11 68 08       	vmovsd QWORD PTR [rax+0x8],xmm5
    513f:	77 2e                	ja     516f <try_secant_tail._omp_fn.0+0x69f>
    5141:	c5 fb 10 0b          	vmovsd xmm1,QWORD PTR [rbx]
    5145:	c5 b9 54 15 00 00 00 	vandpd xmm2,xmm8,XMMWORD PTR [rip+0x0]        # 514d <try_secant_tail._omp_fn.0+0x67d>
    514c:	00 
    514d:	c5 eb 58 54 24 10    	vaddsd xmm2,xmm2,QWORD PTR [rsp+0x10]
    5153:	c5 eb 59 54 24 68    	vmulsd xmm2,xmm2,QWORD PTR [rsp+0x68]
    5159:	c5 f3 5c cc          	vsubsd xmm1,xmm1,xmm4
    515d:	c5 f3 59 c8          	vmulsd xmm1,xmm1,xmm0
    5161:	c5 f1 54 0d 00 00 00 	vandpd xmm1,xmm1,XMMWORD PTR [rip+0x0]        # 5169 <try_secant_tail._omp_fn.0+0x699>
    5168:	00 
    5169:	c5 f9 2f ca          	vcomisd xmm1,xmm2
    516d:	76 04                	jbe    5173 <try_secant_tail._omp_fn.0+0x6a3>
    516f:	41 c6 06 01          	mov    BYTE PTR [r14],0x1
    5173:	49 83 c6 01          	add    r14,0x1
    5177:	48 83 c3 08          	add    rbx,0x8
    517b:	4c 03 ac 24 a8 00 00 	add    r13,QWORD PTR [rsp+0xa8]
    5182:	00 
    5183:	4c 39 74 24 78       	cmp    QWORD PTR [rsp+0x78],r14
    5188:	0f 85 0a fb ff ff    	jne    4c98 <try_secant_tail._omp_fn.0+0x1c8>
    518e:	c5 f8 77             	vzeroupper
    5191:	48 8d 65 d8          	lea    rsp,[rbp-0x28]
    5195:	5b                   	pop    rbx
    5196:	41 5c                	pop    r12
    5198:	41 5d                	pop    r13
    519a:	41 5e                	pop    r14
    519c:	41 5f                	pop    r15
    519e:	5d                   	pop    rbp
    519f:	e9 00 00 00 00       	jmp    51a4 <try_secant_tail._omp_fn.0+0x6d4>
    51a4:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
    51a8:	c5 f9 29 bc 24 90 00 	vmovapd XMMWORD PTR [rsp+0x90],xmm7
    51af:	00 00 
    51b1:	44 89 d6             	mov    esi,r10d
    51b4:	c5 fb 11 a4 24 a0 00 	vmovsd QWORD PTR [rsp+0xa0],xmm4
    51bb:	00 00 
    51bd:	c5 f8 77             	vzeroupper
    51c0:	e8 7b b0 ff ff       	call   240 <norm2>
    51c5:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    51c9:	c5 fb 10 a4 24 a0 00 	vmovsd xmm4,QWORD PTR [rsp+0xa0]
    51d0:	00 00 
    51d2:	c5 f9 28 bc 24 90 00 	vmovapd xmm7,XMMWORD PTR [rsp+0x90]
    51d9:	00 00 
    51db:	c5 f9 2f c2          	vcomisd xmm0,xmm2
    51df:	0f 85 bd fc ff ff    	jne    4ea2 <try_secant_tail._omp_fn.0+0x3d2>
    51e5:	c5 fb 10 03          	vmovsd xmm0,QWORD PTR [rbx]
    51e9:	c5 f9 54 05 00 00 00 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x0]        # 51f1 <try_secant_tail._omp_fn.0+0x721>
    51f0:	00 
    51f1:	c5 f9 2f 44 24 68    	vcomisd xmm0,QWORD PTR [rsp+0x68]
    51f7:	0f 86 76 ff ff ff    	jbe    5173 <try_secant_tail._omp_fn.0+0x6a3>
    51fd:	41 c6 06 01          	mov    BYTE PTR [r14],0x1
    5201:	e9 6d ff ff ff       	jmp    5173 <try_secant_tail._omp_fn.0+0x6a3>
    5206:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
    520a:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
    520e:	31 c9                	xor    ecx,ecx
    5210:	31 d2                	xor    edx,edx
    5212:	c5 f9 28 ef          	vmovapd xmm5,xmm7
    5216:	c5 f9 28 df          	vmovapd xmm3,xmm7
    521a:	c5 f9 28 d7          	vmovapd xmm2,xmm7
    521e:	c5 f9 28 f7          	vmovapd xmm6,xmm7
    5222:	c5 f9 28 c4          	vmovapd xmm0,xmm4
    5226:	e9 9f fb ff ff       	jmp    4dca <try_secant_tail._omp_fn.0+0x2fa>
    522b:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
    5230:	4c 8b 8c 24 b8 00 00 	mov    r9,QWORD PTR [rsp+0xb8]
    5237:	00 
    5238:	31 c0                	xor    eax,eax
    523a:	49 8d 14 0b          	lea    rdx,[r11+rcx*1]
    523e:	66 90                	xchg   ax,ax
    5240:	c5 fb 10 14 07       	vmovsd xmm2,QWORD PTR [rdi+rax*1]
    5245:	c5 f9 28 f1          	vmovapd xmm6,xmm1
    5249:	c4 c2 e9 a9 34 03    	vfmadd213sd xmm6,xmm2,QWORD PTR [r11+rax*1]
    524f:	c4 c1 7b 11 34 03    	vmovsd QWORD PTR [r11+rax*1],xmm6
    5255:	c4 e2 a9 a9 14 02    	vfmadd213sd xmm2,xmm10,QWORD PTR [rdx+rax*1]
    525b:	c5 fb 11 14 02       	vmovsd QWORD PTR [rdx+rax*1],xmm2
    5260:	48 83 c0 08          	add    rax,0x8
    5264:	48 39 c1             	cmp    rcx,rax
    5267:	75 d7                	jne    5240 <try_secant_tail._omp_fn.0+0x770>
    5269:	4c 89 8c 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],r9
    5270:	00 
    5271:	e9 9a fe ff ff       	jmp    5110 <try_secant_tail._omp_fn.0+0x640>
    5276:	44 89 d1             	mov    ecx,r10d
    5279:	31 c0                	xor    eax,eax
    527b:	31 d2                	xor    edx,edx
    527d:	e9 0b fe ff ff       	jmp    508d <try_secant_tail._omp_fn.0+0x5bd>
    5282:	48 89 c2             	mov    rdx,rax
    5285:	e9 06 fd ff ff       	jmp    4f90 <try_secant_tail._omp_fn.0+0x4c0>
