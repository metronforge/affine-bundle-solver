/tmp/abs-stage2b-measured-normal/trace.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000012490 <try_secant_tail.constprop.0>:
   12490:	4c 8d 54 24 08       	lea    r10,[rsp+0x8]
   12495:	48 83 e4 e0          	and    rsp,0xffffffffffffffe0
   12499:	41 ff 72 f8          	push   QWORD PTR [r10-0x8]
   1249d:	55                   	push   rbp
   1249e:	48 89 e5             	mov    rbp,rsp
   124a1:	41 57                	push   r15
   124a3:	41 56                	push   r14
   124a5:	41 55                	push   r13
   124a7:	41 54                	push   r12
   124a9:	41 52                	push   r10
   124ab:	53                   	push   rbx
   124ac:	48 81 ec 60 02 00 00 	sub    rsp,0x260
   124b3:	49 8b 42 10          	mov    rax,QWORD PTR [r10+0x10]
   124b7:	48 89 bd b8 fe ff ff 	mov    QWORD PTR [rbp-0x148],rdi
   124be:	48 89 b5 b0 fe ff ff 	mov    QWORD PTR [rbp-0x150],rsi
   124c5:	49 8b 1a             	mov    rbx,QWORD PTR [r10]
   124c8:	48 89 95 e8 fd ff ff 	mov    QWORD PTR [rbp-0x218],rdx
   124cf:	4d 8b 6a 08          	mov    r13,QWORD PTR [r10+0x8]
   124d3:	89 8d cc fe ff ff    	mov    DWORD PTR [rbp-0x134],ecx
   124d9:	44 89 85 d0 fe ff ff 	mov    DWORD PTR [rbp-0x130],r8d
   124e0:	44 89 8d f8 fe ff ff 	mov    DWORD PTR [rbp-0x108],r9d
   124e7:	48 89 85 e0 fd ff ff 	mov    QWORD PTR [rbp-0x220],rax
   124ee:	64 48 8b 04 25 28 00 	mov    rax,QWORD PTR fs:0x28
   124f5:	00 00 
   124f7:	48 89 45 c8          	mov    QWORD PTR [rbp-0x38],rax
   124fb:	31 c0                	xor    eax,eax
   124fd:	c5 fb 10 3d 00 00 00 	vmovsd xmm7,QWORD PTR [rip+0x0]        # 12505 <try_secant_tail.constprop.0+0x75>
   12504:	00 
   12505:	8b 3d 00 00 00 00    	mov    edi,DWORD PTR [rip+0x0]        # 1250b <try_secant_tail.constprop.0+0x7b>
   1250b:	c5 c3 58 05 00 00 00 	vaddsd xmm0,xmm7,QWORD PTR [rip+0x0]        # 12513 <try_secant_tail.constprop.0+0x83>
   12512:	00 
   12513:	85 ff                	test   edi,edi
   12515:	c5 fb 11 05 00 00 00 	vmovsd QWORD PTR [rip+0x0],xmm0        # 1251d <try_secant_tail.constprop.0+0x8d>
   1251c:	00 
   1251d:	0f 85 28 21 00 00    	jne    1464b <try_secant_tail.constprop.0+0x21bb>
   12523:	48 89 de             	mov    rsi,rbx
   12526:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 1252d <try_secant_tail.constprop.0+0x9d>
   1252d:	e8 9e 92 ff ff       	call   b7d0 <bs_copy>
   12532:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
   12536:	48 89 de             	mov    rsi,rbx
   12539:	c5 c3 2a 43 04       	vcvtsi2sd xmm0,xmm7,DWORD PTR [rbx+0x4]
   1253e:	83 f0 01             	xor    eax,0x1
   12541:	89 05 00 00 00 00    	mov    DWORD PTR [rip+0x0],eax        # 12547 <try_secant_tail.constprop.0+0xb7>
   12547:	8b 85 f8 fe ff ff    	mov    eax,DWORD PTR [rbp-0x108]
   1254d:	c5 c3 2a c8          	vcvtsi2sd xmm1,xmm7,eax
   12551:	89 05 00 00 00 00    	mov    DWORD PTR [rip+0x0],eax        # 12557 <try_secant_tail.constprop.0+0xc7>
   12557:	c5 f9 14 c1          	vunpcklpd xmm0,xmm0,xmm1
   1255b:	48 8d 85 00 ff ff ff 	lea    rax,[rbp-0x100]
   12562:	48 89 c7             	mov    rdi,rax
   12565:	48 89 85 78 fe ff ff 	mov    QWORD PTR [rbp-0x188],rax
   1256c:	c5 f9 11 05 00 00 00 	vmovupd XMMWORD PTR [rip+0x0],xmm0        # 12574 <try_secant_tail.constprop.0+0xe4>
   12573:	00 
   12574:	e8 57 92 ff ff       	call   b7d0 <bs_copy>
   12579:	85 c0                	test   eax,eax
   1257b:	89 85 94 fd ff ff    	mov    DWORD PTR [rbp-0x26c],eax
   12581:	74 34                	je     125b7 <try_secant_tail.constprop.0+0x127>
   12583:	41 bd ff ff ff ff    	mov    r13d,0xffffffff
   12589:	48 8b 45 c8          	mov    rax,QWORD PTR [rbp-0x38]
   1258d:	64 48 2b 04 25 28 00 	sub    rax,QWORD PTR fs:0x28
   12594:	00 00 
   12596:	0f 85 9b 2b 00 00    	jne    15137 <try_secant_tail.constprop.0+0x2ca7>
   1259c:	48 81 c4 60 02 00 00 	add    rsp,0x260
   125a3:	44 89 e8             	mov    eax,r13d
   125a6:	5b                   	pop    rbx
   125a7:	41 5a                	pop    r10
   125a9:	41 5c                	pop    r12
   125ab:	41 5d                	pop    r13
   125ad:	41 5e                	pop    r14
   125af:	41 5f                	pop    r15
   125b1:	5d                   	pop    rbp
   125b2:	49 8d 62 f8          	lea    rsp,[r10-0x8]
   125b6:	c3                   	ret
   125b7:	4c 63 bd d0 fe ff ff 	movsxd r15,DWORD PTR [rbp-0x130]
   125be:	4c 89 ff             	mov    rdi,r15
   125c1:	4c 89 bd f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],r15
   125c8:	48 c1 e7 04          	shl    rdi,0x4
   125cc:	e8 00 00 00 00       	call   125d1 <try_secant_tail.constprop.0+0x141>
   125d1:	be 08 00 00 00       	mov    esi,0x8
   125d6:	49 89 c6             	mov    r14,rax
   125d9:	4b 8d 04 3f          	lea    rax,[r15+r15*1]
   125dd:	48 89 c7             	mov    rdi,rax
   125e0:	48 89 85 b0 fd ff ff 	mov    QWORD PTR [rbp-0x250],rax
   125e7:	e8 00 00 00 00       	call   125ec <try_secant_tail.constprop.0+0x15c>
   125ec:	4d 85 f6             	test   r14,r14
   125ef:	49 89 c7             	mov    r15,rax
   125f2:	0f 84 68 2b 00 00    	je     15160 <try_secant_tail.constprop.0+0x2cd0>
   125f8:	48 85 c0             	test   rax,rax
   125fb:	0f 84 5f 2b 00 00    	je     15160 <try_secant_tail.constprop.0+0x2cd0>
   12601:	48 b8 d0 31 9f 29 22 	movabs rax,0xa4093822299f31d0
   12608:	38 09 a4 
   1260b:	48 8b b5 78 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x188]
   12612:	4c 89 f7             	mov    rdi,r14
   12615:	48 ba 15 7c 4a 7f b9 	movabs rdx,0x9e3779b97f4a7c15
   1261c:	79 37 9e 
   1261f:	4c 31 e8             	xor    rax,r13
   12622:	48 c7 45 b0 00 00 00 	mov    QWORD PTR [rbp-0x50],0x0
   12629:	00 
   1262a:	48 01 d0             	add    rax,rdx
   1262d:	48 c7 45 b8 00 00 00 	mov    QWORD PTR [rbp-0x48],0x0
   12634:	00 
   12635:	48 89 c2             	mov    rdx,rax
   12638:	48 c1 ea 1e          	shr    rdx,0x1e
   1263c:	48 31 c2             	xor    rdx,rax
   1263f:	48 b8 b9 e5 e4 1c 6d 	movabs rax,0xbf58476d1ce4e5b9
   12646:	47 58 bf 
   12649:	48 0f af d0          	imul   rdx,rax
   1264d:	48 89 d0             	mov    rax,rdx
   12650:	48 c1 e8 1b          	shr    rax,0x1b
   12654:	48 31 d0             	xor    rax,rdx
   12657:	48 ba eb 11 31 13 bb 	movabs rdx,0x94d049bb133111eb
   1265e:	49 d0 94 
   12661:	48 0f af c2          	imul   rax,rdx
   12665:	48 89 c2             	mov    rdx,rax
   12668:	48 c1 ea 1f          	shr    rdx,0x1f
   1266c:	48 31 c2             	xor    rdx,rax
   1266f:	49 89 d4             	mov    r12,rdx
   12672:	48 89 95 78 fd ff ff 	mov    QWORD PTR [rbp-0x288],rdx
   12679:	48 ba 03 ed 92 d1 32 	movabs rdx,0xd1b54a32d192ed03
   12680:	4a b5 d1 
   12683:	4c 01 e2             	add    rdx,r12
   12686:	e8 15 14 ff ff       	call   3aa0 <secant_refresh>
   1268b:	48 8b 85 f0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x110]
   12692:	48 8b b5 78 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x188]
   12699:	48 ba 06 da 25 a3 65 	movabs rdx,0xa36a9465a325da06
   126a0:	94 6a a3 
   126a3:	4c 01 e2             	add    rdx,r12
   126a6:	48 c1 e0 03          	shl    rax,0x3
   126aa:	49 8d 3c 06          	lea    rdi,[r14+rax*1]
   126ae:	48 89 85 00 fe ff ff 	mov    QWORD PTR [rbp-0x200],rax
   126b5:	48 89 bd 90 fe ff ff 	mov    QWORD PTR [rbp-0x170],rdi
   126bc:	e8 df 13 ff ff       	call   3aa0 <secant_refresh>
   126c1:	e8 00 00 00 00       	call   126c6 <try_secant_tail.constprop.0+0x236>
   126c6:	89 85 98 fe ff ff    	mov    DWORD PTR [rbp-0x168],eax
   126cc:	8b 43 04             	mov    eax,DWORD PTR [rbx+0x4]
   126cf:	48 8b 1d 00 00 00 00 	mov    rbx,QWORD PTR [rip+0x0]        # 126d6 <try_secant_tail.constprop.0+0x246>
   126d6:	89 85 c0 fe ff ff    	mov    DWORD PTR [rbp-0x140],eax
   126dc:	8b 85 cc fe ff ff    	mov    eax,DWORD PTR [rbp-0x134]
   126e2:	2b 85 f8 fe ff ff    	sub    eax,DWORD PTR [rbp-0x108]
   126e8:	48 89 9d 10 fe ff ff 	mov    QWORD PTR [rbp-0x1f0],rbx
   126ef:	85 c0                	test   eax,eax
   126f1:	7e 1d                	jle    12710 <try_secant_tail.constprop.0+0x280>
   126f3:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
   126f7:	c5 d3 2a c0          	vcvtsi2sd xmm0,xmm5,eax
   126fb:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
   126ff:	c4 e1 f9 6e eb       	vmovq  xmm5,rbx
   12704:	c5 d3 5e f0          	vdivsd xmm6,xmm5,xmm0
   12708:	c5 fb 11 b5 10 fe ff 	vmovsd QWORD PTR [rbp-0x1f0],xmm6
   1270f:	ff 
   12710:	8b b5 d0 fe ff ff    	mov    esi,DWORD PTR [rbp-0x130]
   12716:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   1271d:	e8 1e db fe ff       	call   240 <norm2>
   12722:	be 01 00 00 00       	mov    esi,0x1
   12727:	bf 00 08 00 00       	mov    edi,0x800
   1272c:	c5 fb 11 85 60 fe ff 	vmovsd QWORD PTR [rbp-0x1a0],xmm0
   12733:	ff 
   12734:	e8 00 00 00 00       	call   12739 <try_secant_tail.constprop.0+0x2a9>
   12739:	48 63 9d 98 fe ff ff 	movsxd rbx,DWORD PTR [rbp-0x168]
   12740:	be 08 00 00 00       	mov    esi,0x8
   12745:	4c 8b a5 f0 fe ff ff 	mov    r12,QWORD PTR [rbp-0x110]
   1274c:	48 89 85 a8 fe ff ff 	mov    QWORD PTR [rbp-0x158],rax
   12753:	4c 0f af e3          	imul   r12,rbx
   12757:	4b 8d 3c 24          	lea    rdi,[r12+r12*1]
   1275b:	e8 00 00 00 00       	call   12760 <try_secant_tail.constprop.0+0x2d0>
   12760:	48 8d 3c 1b          	lea    rdi,[rbx+rbx*1]
   12764:	be 08 00 00 00       	mov    esi,0x8
   12769:	48 89 85 70 fe ff ff 	mov    QWORD PTR [rbp-0x190],rax
   12770:	e8 00 00 00 00       	call   12775 <try_secant_tail.constprop.0+0x2e5>
   12775:	48 83 bd a8 fe ff ff 	cmp    QWORD PTR [rbp-0x158],0x0
   1277c:	00 
   1277d:	48 89 85 68 fe ff ff 	mov    QWORD PTR [rbp-0x198],rax
   12784:	48 89 c7             	mov    rdi,rax
   12787:	0f 94 c0             	sete   al
   1278a:	48 83 bd 70 fe ff ff 	cmp    QWORD PTR [rbp-0x190],0x0
   12791:	00 
   12792:	0f 94 c2             	sete   dl
   12795:	08 d0                	or     al,dl
   12797:	0f 85 9f 29 00 00    	jne    1513c <try_secant_tail.constprop.0+0x2cac>
   1279d:	48 85 ff             	test   rdi,rdi
   127a0:	0f 84 96 29 00 00    	je     1513c <try_secant_tail.constprop.0+0x2cac>
   127a6:	48 8d 85 40 ff ff ff 	lea    rax,[rbp-0xc0]
   127ad:	c5 fa 7e ad b8 fe ff 	vmovq  xmm5,QWORD PTR [rbp-0x148]
   127b4:	ff 
   127b5:	bf 01 00 00 00       	mov    edi,0x1
   127ba:	c4 e3 d1 22 ad b0 fe 	vpinsrq xmm5,xmm5,QWORD PTR [rbp-0x150],0x1
   127c1:	ff ff 01 
   127c4:	48 89 c6             	mov    rsi,rax
   127c7:	48 89 85 20 fe ff ff 	mov    QWORD PTR [rbp-0x1e0],rax
   127ce:	c5 f9 7f ad d0 fd ff 	vmovdqa XMMWORD PTR [rbp-0x230],xmm5
   127d5:	ff 
   127d6:	e8 00 00 00 00       	call   127db <try_secant_tail.constprop.0+0x34b>
   127db:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
   127df:	8b b5 f8 fe ff ff    	mov    esi,DWORD PTR [rbp-0x108]
   127e5:	c4 e1 d3 2a 85 48 ff 	vcvtsi2sd xmm0,xmm5,QWORD PTR [rbp-0xb8]
   127ec:	ff ff 
   127ee:	c4 e1 d3 2a 8d 40 ff 	vcvtsi2sd xmm1,xmm5,QWORD PTR [rbp-0xc0]
   127f5:	ff ff 
   127f7:	3b b5 cc fe ff ff    	cmp    esi,DWORD PTR [rbp-0x134]
   127fd:	c4 e2 f1 99 05 00 00 	vfmadd132sd xmm0,xmm1,QWORD PTR [rip+0x0]        # 12806 <try_secant_tail.constprop.0+0x376>
   12804:	00 00 
   12806:	c5 fb 11 05 00 00 00 	vmovsd QWORD PTR [rip+0x0],xmm0        # 1280e <try_secant_tail.constprop.0+0x37e>
   1280d:	00 
   1280e:	0f 8d 34 04 00 00    	jge    12c48 <try_secant_tail.constprop.0+0x7b8>
   12814:	48 b8 89 6c 4e ec 98 	movabs rax,0x82efa98ec4e6c89
   1281b:	fa 2e 08 
   1281e:	4c 89 ea             	mov    rdx,r13
   12821:	8b bd d0 fe ff ff    	mov    edi,DWORD PTR [rbp-0x130]
   12827:	c5 fb 12 bd 10 fe ff 	vmovddup xmm7,QWORD PTR [rbp-0x1f0]
   1282e:	ff 
   1282f:	c7 85 90 fd ff ff 00 	mov    DWORD PTR [rbp-0x270],0x0
   12836:	00 00 00 
   12839:	48 31 c2             	xor    rdx,rax
   1283c:	41 89 f5             	mov    r13d,esi
   1283f:	48 b8 15 7c 4a 7f b9 	movabs rax,0x9e3779b97f4a7c15
   12846:	79 37 9e 
   12849:	48 01 d0             	add    rax,rdx
   1284c:	c5 f9 29 bd 80 fd ff 	vmovapd XMMWORD PTR [rbp-0x280],xmm7
   12853:	ff 
   12854:	c5 fa 7e bd a8 fe ff 	vmovq  xmm7,QWORD PTR [rbp-0x158]
   1285b:	ff 
   1285c:	c4 e3 c1 22 ad 70 fe 	vpinsrq xmm5,xmm7,QWORD PTR [rbp-0x190],0x1
   12863:	ff ff 01 
   12866:	48 89 c2             	mov    rdx,rax
   12869:	48 c1 ea 1e          	shr    rdx,0x1e
   1286d:	c5 f9 7f ad a0 fd ff 	vmovdqa XMMWORD PTR [rbp-0x260],xmm5
   12874:	ff 
   12875:	48 31 c2             	xor    rdx,rax
   12878:	48 b8 b9 e5 e4 1c 6d 	movabs rax,0xbf58476d1ce4e5b9
   1287f:	47 58 bf 
   12882:	48 0f af d0          	imul   rdx,rax
   12886:	48 89 d0             	mov    rax,rdx
   12889:	48 c1 e8 1b          	shr    rax,0x1b
   1288d:	48 31 d0             	xor    rax,rdx
   12890:	48 ba eb 11 31 13 bb 	movabs rdx,0x94d049bb133111eb
   12897:	49 d0 94 
   1289a:	48 0f af c2          	imul   rax,rdx
   1289e:	48 89 c2             	mov    rdx,rax
   128a1:	48 c1 ea 1f          	shr    rdx,0x1f
   128a5:	48 31 c2             	xor    rdx,rax
   128a8:	89 f8                	mov    eax,edi
   128aa:	c1 e8 1f             	shr    eax,0x1f
   128ad:	48 89 95 f8 fd ff ff 	mov    QWORD PTR [rbp-0x208],rdx
   128b4:	01 f8                	add    eax,edi
   128b6:	d1 f8                	sar    eax,1
   128b8:	39 85 c0 fe ff ff    	cmp    DWORD PTR [rbp-0x140],eax
   128be:	c7 85 c0 fe ff ff 00 	mov    DWORD PTR [rbp-0x140],0x0
   128c5:	00 00 00 
   128c8:	0f 9d c2             	setge  dl
   128cb:	83 bd 98 fe ff ff 01 	cmp    DWORD PTR [rbp-0x168],0x1
   128d2:	0f 9f c0             	setg   al
   128d5:	48 c1 e3 04          	shl    rbx,0x4
   128d9:	21 c2                	and    edx,eax
   128db:	8d 04 3f             	lea    eax,[rdi+rdi*1]
   128de:	49 c1 e4 04          	shl    r12,0x4
   128e2:	48 89 9d c0 fd ff ff 	mov    QWORD PTR [rbp-0x240],rbx
   128e9:	85 c0                	test   eax,eax
   128eb:	88 95 cb fe ff ff    	mov    BYTE PTR [rbp-0x135],dl
   128f1:	ba 01 00 00 00       	mov    edx,0x1
   128f6:	8d 5f ff             	lea    ebx,[rdi-0x1]
   128f9:	0f 4f d0             	cmovg  edx,eax
   128fc:	8d 44 3f fc          	lea    eax,[rdi+rdi*1-0x4]
   12900:	4c 89 a5 b8 fd ff ff 	mov    QWORD PTR [rbp-0x248],r12
   12907:	89 85 98 fd ff ff    	mov    DWORD PTR [rbp-0x268],eax
   1290d:	c4 e1 f9 7e f8       	vmovq  rax,xmm7
   12912:	48 f7 d8             	neg    rax
   12915:	89 9d 9c fe ff ff    	mov    DWORD PTR [rbp-0x164],ebx
   1291b:	83 e0 1f             	and    eax,0x1f
   1291e:	89 95 9c fd ff ff    	mov    DWORD PTR [rbp-0x264],edx
   12924:	89 85 58 fe ff ff    	mov    DWORD PTR [rbp-0x1a8],eax
   1292a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   12930:	8b 9d 0c ff ff ff    	mov    ebx,DWORD PTR [rbp-0xf4]
   12936:	85 db                	test   ebx,ebx
   12938:	0f 85 ff 02 00 00    	jne    12c3d <try_secant_tail.constprop.0+0x7ad>
   1293e:	8b 85 d0 fe ff ff    	mov    eax,DWORD PTR [rbp-0x130]
   12944:	3b 85 04 ff ff ff    	cmp    eax,DWORD PTR [rbp-0xfc]
   1294a:	0f 8e ed 02 00 00    	jle    12c3d <try_secant_tail.constprop.0+0x7ad>
   12950:	83 bd c0 fe ff ff 1f 	cmp    DWORD PTR [rbp-0x140],0x1f
   12957:	0f 9f c0             	setg   al
   1295a:	84 85 cb fe ff ff    	test   BYTE PTR [rbp-0x135],al
   12960:	74 28                	je     1298a <try_secant_tail.constprop.0+0x4fa>
   12962:	44 39 ad f8 fe ff ff 	cmp    DWORD PTR [rbp-0x108],r13d
   12969:	7f 1f                	jg     1298a <try_secant_tail.constprop.0+0x4fa>
   1296b:	8b 85 cc fe ff ff    	mov    eax,DWORD PTR [rbp-0x134]
   12971:	44 29 e8             	sub    eax,r13d
   12974:	48 98                	cdqe
   12976:	48 0f af 85 f0 fe ff 	imul   rax,QWORD PTR [rbp-0x110]
   1297d:	ff 
   1297e:	48 3d 3f 42 0f 00    	cmp    rax,0xf423f
   12984:	0f 8f c6 0c 00 00    	jg     13650 <try_secant_tail.constprop.0+0x11c0>
   1298a:	48 8b 15 00 00 00 00 	mov    rdx,QWORD PTR [rip+0x0]        # 12991 <try_secant_tail.constprop.0+0x501>
   12991:	c4 e1 f9 6e fa       	vmovq  xmm7,rdx
   12996:	c5 c3 58 35 00 00 00 	vaddsd xmm6,xmm7,QWORD PTR [rip+0x0]        # 1299e <try_secant_tail.constprop.0+0x50e>
   1299d:	00 
   1299e:	48 89 d0             	mov    rax,rdx
   129a1:	c4 e1 f9 7e f1       	vmovq  rcx,xmm6
   129a6:	f0 48 0f b1 0d 00 00 	lock cmpxchg QWORD PTR [rip+0x0],rcx        # 129af <try_secant_tail.constprop.0+0x51f>
   129ad:	00 00 
   129af:	0f 85 cc 27 00 00    	jne    15181 <try_secant_tail.constprop.0+0x2cf1>
   129b5:	4c 8b 8d f0 fe ff ff 	mov    r9,QWORD PTR [rbp-0x110]
   129bc:	4d 63 c5             	movsxd r8,r13d
   129bf:	8b b5 d0 fe ff ff    	mov    esi,DWORD PTR [rbp-0x130]
   129c5:	48 8b 85 b8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x148]
   129cc:	4d 0f af c8          	imul   r9,r8
   129d0:	85 f6                	test   esi,esi
   129d2:	4a 8d 3c c8          	lea    rdi,[rax+r9*8]
   129d6:	0f 8e 41 05 00 00    	jle    12f1d <try_secant_tail.constprop.0+0xa8d>
   129dc:	83 bd 9c fe ff ff 02 	cmp    DWORD PTR [rbp-0x164],0x2
   129e3:	48 8b 85 18 ff ff ff 	mov    rax,QWORD PTR [rbp-0xe8]
   129ea:	0f 86 e9 19 00 00    	jbe    143d9 <try_secant_tail.constprop.0+0x1f49>
   129f0:	89 f1                	mov    ecx,esi
   129f2:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
   129f6:	48 8b b5 90 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x170]
   129fd:	31 d2                	xor    edx,edx
   129ff:	c5 fd 28 dc          	vmovapd ymm3,ymm4
   12a03:	c1 e9 02             	shr    ecx,0x2
   12a06:	c5 fd 28 cc          	vmovapd ymm1,ymm4
   12a0a:	c5 fd 28 d4          	vmovapd ymm2,ymm4
   12a0e:	48 c1 e1 05          	shl    rcx,0x5
   12a12:	66 90                	xchg   ax,ax
   12a14:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   12a1b:	00 00 00 00 
   12a1f:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   12a26:	00 00 00 00 
   12a2a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   12a31:	00 00 00 00 
   12a35:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   12a3c:	00 00 00 00 
   12a40:	c5 fd 10 04 17       	vmovupd ymm0,YMMWORD PTR [rdi+rdx*1]
   12a45:	c4 e2 fd b8 1c 10    	vfmadd231pd ymm3,ymm0,YMMWORD PTR [rax+rdx*1]
   12a4b:	c4 c2 fd b8 0c 16    	vfmadd231pd ymm1,ymm0,YMMWORD PTR [r14+rdx*1]
   12a51:	c4 e2 fd b8 14 16    	vfmadd231pd ymm2,ymm0,YMMWORD PTR [rsi+rdx*1]
   12a57:	48 83 c2 20          	add    rdx,0x20
   12a5b:	48 39 d1             	cmp    rcx,rdx
   12a5e:	c4 e2 fd b8 e0       	vfmadd231pd ymm4,ymm0,ymm0
   12a63:	75 db                	jne    12a40 <try_secant_tail.constprop.0+0x5b0>
   12a65:	c4 e3 7d 19 d6 01    	vextractf128 xmm6,ymm2,0x1
   12a6b:	c4 e3 7d 19 e5 01    	vextractf128 xmm5,ymm4,0x1
   12a71:	8b b5 d0 fe ff ff    	mov    esi,DWORD PTR [rbp-0x130]
   12a77:	c5 c9 58 f2          	vaddpd xmm6,xmm6,xmm2
   12a7b:	c4 e3 7d 19 ca 01    	vextractf128 xmm2,ymm1,0x1
   12a81:	c5 d1 58 ec          	vaddpd xmm5,xmm5,xmm4
   12a85:	c5 e9 58 d1          	vaddpd xmm2,xmm2,xmm1
   12a89:	c4 e3 7d 19 dc 01    	vextractf128 xmm4,ymm3,0x1
   12a8f:	89 f2                	mov    edx,esi
   12a91:	c5 d9 58 db          	vaddpd xmm3,xmm4,xmm3
   12a95:	83 e2 fc             	and    edx,0xfffffffc
   12a98:	c5 49 15 c6          	vunpckhpd xmm8,xmm6,xmm6
   12a9c:	c5 d1 15 c5          	vunpckhpd xmm0,xmm5,xmm5
   12aa0:	39 d6                	cmp    esi,edx
   12aa2:	89 d1                	mov    ecx,edx
   12aa4:	c5 e9 15 fa          	vunpckhpd xmm7,xmm2,xmm2
   12aa8:	c5 39 58 c6          	vaddpd xmm8,xmm8,xmm6
   12aac:	c5 f9 58 c5          	vaddpd xmm0,xmm0,xmm5
   12ab0:	c5 c1 58 fa          	vaddpd xmm7,xmm7,xmm2
   12ab4:	c5 e1 15 e3          	vunpckhpd xmm4,xmm3,xmm3
   12ab8:	c5 d9 58 e3          	vaddpd xmm4,xmm4,xmm3
   12abc:	c5 b9 14 ff          	vunpcklpd xmm7,xmm8,xmm7
   12ac0:	0f 84 99 00 00 00    	je     12b5f <try_secant_tail.constprop.0+0x6cf>
   12ac6:	29 ce                	sub    esi,ecx
   12ac8:	83 fe 01             	cmp    esi,0x1
   12acb:	74 61                	je     12b2e <try_secant_tail.constprop.0+0x69e>
   12acd:	4c 8b 95 f0 fe ff ff 	mov    r10,QWORD PTR [rbp-0x110]
   12ad4:	4c 8b a5 b8 fe ff ff 	mov    r12,QWORD PTR [rbp-0x148]
   12adb:	4d 8d 1c 09          	lea    r11,[r9+rcx*1]
   12adf:	c4 81 79 10 04 dc    	vmovupd xmm0,XMMWORD PTR [r12+r11*8]
   12ae5:	49 01 ca             	add    r10,rcx
   12ae8:	40 f6 c6 01          	test   sil,0x1
   12aec:	c4 e2 f9 b8 1c c8    	vfmadd231pd xmm3,xmm0,XMMWORD PTR [rax+rcx*8]
   12af2:	c4 c2 f9 b8 14 ce    	vfmadd231pd xmm2,xmm0,XMMWORD PTR [r14+rcx*8]
   12af8:	c4 82 f9 b8 34 d6    	vfmadd231pd xmm6,xmm0,XMMWORD PTR [r14+r10*8]
   12afe:	c4 e2 f9 b8 e8       	vfmadd231pd xmm5,xmm0,xmm0
   12b03:	c5 e1 15 e3          	vunpckhpd xmm4,xmm3,xmm3
   12b07:	c5 d9 58 e3          	vaddpd xmm4,xmm4,xmm3
   12b0b:	c5 c9 15 ce          	vunpckhpd xmm1,xmm6,xmm6
   12b0f:	c5 e9 15 da          	vunpckhpd xmm3,xmm2,xmm2
   12b13:	c5 f1 58 ce          	vaddpd xmm1,xmm1,xmm6
   12b17:	c5 e1 58 d2          	vaddpd xmm2,xmm3,xmm2
   12b1b:	c5 d1 15 c5          	vunpckhpd xmm0,xmm5,xmm5
   12b1f:	c5 f9 58 c5          	vaddpd xmm0,xmm0,xmm5
   12b23:	c5 f1 14 fa          	vunpcklpd xmm7,xmm1,xmm2
   12b27:	74 36                	je     12b5f <try_secant_tail.constprop.0+0x6cf>
   12b29:	83 e6 fe             	and    esi,0xfffffffe
   12b2c:	01 f2                	add    edx,esi
   12b2e:	48 63 ca             	movsxd rcx,edx
   12b31:	03 95 d0 fe ff ff    	add    edx,DWORD PTR [rbp-0x130]
   12b37:	c5 fb 10 14 cf       	vmovsd xmm2,QWORD PTR [rdi+rcx*8]
   12b3c:	48 63 d2             	movsxd rdx,edx
   12b3f:	c4 e2 e9 b9 24 c8    	vfmadd231sd xmm4,xmm2,QWORD PTR [rax+rcx*8]
   12b45:	c5 fb 12 da          	vmovddup xmm3,xmm2
   12b49:	c4 e2 e9 b9 c2       	vfmadd231sd xmm0,xmm2,xmm2
   12b4e:	c4 c1 7b 10 14 d6    	vmovsd xmm2,QWORD PTR [r14+rdx*8]
   12b54:	c4 c1 69 16 14 ce    	vmovhpd xmm2,xmm2,QWORD PTR [r14+rcx*8]
   12b5a:	c4 e2 e1 b8 fa       	vfmadd231pd xmm7,xmm3,xmm2
   12b5f:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
   12b63:	c5 f9 2f c2          	vcomisd xmm0,xmm2
   12b67:	0f 86 bb 03 00 00    	jbe    12f28 <try_secant_tail.constprop.0+0xa98>
   12b6d:	48 b8 00 00 00 00 00 	movabs rax,0x7ff0000000000000
   12b74:	00 f0 7f 
   12b77:	c4 e1 f9 7e c6       	vmovq  rsi,xmm0
   12b7c:	c4 e2 c8 f2 c0       	andn   rax,rsi,rax
   12b81:	0f 84 a1 03 00 00    	je     12f28 <try_secant_tail.constprop.0+0xa98>
   12b87:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
   12b8b:	c5 fb 10 35 00 00 00 	vmovsd xmm6,QWORD PTR [rip+0x0]        # 12b93 <try_secant_tail.constprop.0+0x703>
   12b92:	00 
   12b93:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   12b9a:	44 39 ad f8 fe ff ff 	cmp    DWORD PTR [rbp-0x108],r13d
   12ba1:	c5 c1 54 2d 00 00 00 	vandpd xmm5,xmm7,XMMWORD PTR [rip+0x0]        # 12ba9 <try_secant_tail.constprop.0+0x719>
   12ba8:	00 
   12ba9:	c5 cb 5e c0          	vdivsd xmm0,xmm6,xmm0
   12bad:	4a 8d 14 c0          	lea    rdx,[rax+r8*8]
   12bb1:	c5 fb 10 12          	vmovsd xmm2,QWORD PTR [rdx]
   12bb5:	c5 fb 59 da          	vmulsd xmm3,xmm0,xmm2
   12bb9:	0f 8e 61 18 00 00    	jle    14420 <try_secant_tail.constprop.0+0x1f90>
   12bbf:	c5 d1 15 cd          	vunpckhpd xmm1,xmm5,xmm5
   12bc3:	c5 f1 5f cd          	vmaxpd xmm1,xmm1,xmm5
   12bc7:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # 12bcf <try_secant_tail.constprop.0+0x73f>
   12bce:	00 
   12bcf:	c5 f3 59 c8          	vmulsd xmm1,xmm1,xmm0
   12bd3:	c5 f9 2f cd          	vcomisd xmm1,xmm5
   12bd7:	0f 87 d3 03 00 00    	ja     12fb0 <try_secant_tail.constprop.0+0xb20>
   12bdd:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # 12be5 <try_secant_tail.constprop.0+0x755>
   12be4:	00 
   12be5:	c5 d3 58 8d 60 fe ff 	vaddsd xmm1,xmm5,QWORD PTR [rbp-0x1a0]
   12bec:	ff 
   12bed:	c5 eb 5c d4          	vsubsd xmm2,xmm2,xmm4
   12bf1:	c5 e1 54 1d 00 00 00 	vandpd xmm3,xmm3,XMMWORD PTR [rip+0x0]        # 12bf9 <try_secant_tail.constprop.0+0x769>
   12bf8:	00 
   12bf9:	c5 e3 58 c9          	vaddsd xmm1,xmm3,xmm1
   12bfd:	c5 f3 59 0d 00 00 00 	vmulsd xmm1,xmm1,QWORD PTR [rip+0x0]        # 12c05 <try_secant_tail.constprop.0+0x775>
   12c04:	00 
   12c05:	c5 eb 59 d0          	vmulsd xmm2,xmm2,xmm0
   12c09:	c5 e9 54 15 00 00 00 	vandpd xmm2,xmm2,XMMWORD PTR [rip+0x0]        # 12c11 <try_secant_tail.constprop.0+0x781>
   12c10:	00 
   12c11:	c5 f9 2f d1          	vcomisd xmm2,xmm1
   12c15:	0f 87 95 03 00 00    	ja     12fb0 <try_secant_tail.constprop.0+0xb20>
   12c1b:	83 85 c0 fe ff ff 01 	add    DWORD PTR [rbp-0x140],0x1
   12c22:	41 83 c5 01          	add    r13d,0x1
   12c26:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
   12c2d:	00 00 00 
   12c30:	44 39 ad cc fe ff ff 	cmp    DWORD PTR [rbp-0x134],r13d
   12c37:	0f 8f f3 fc ff ff    	jg     12930 <try_secant_tail.constprop.0+0x4a0>
   12c3d:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 12c45 <try_secant_tail.constprop.0+0x7b5>
   12c44:	00 
   12c45:	c5 f8 77             	vzeroupper
   12c48:	48 8b b5 20 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1e0]
   12c4f:	bf 01 00 00 00       	mov    edi,0x1
   12c54:	c5 fb 11 85 f8 fe ff 	vmovsd QWORD PTR [rbp-0x108],xmm0
   12c5b:	ff 
   12c5c:	e8 00 00 00 00       	call   12c61 <try_secant_tail.constprop.0+0x7d1>
   12c61:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
   12c65:	c5 fb 10 85 f8 fe ff 	vmovsd xmm0,QWORD PTR [rbp-0x108]
   12c6c:	ff 
   12c6d:	c4 e1 cb 2a 95 48 ff 	vcvtsi2sd xmm2,xmm6,QWORD PTR [rbp-0xb8]
   12c74:	ff ff 
   12c76:	c4 e2 e9 bb 05 00 00 	vfmsub231sd xmm0,xmm2,QWORD PTR [rip+0x0]        # 12c7f <try_secant_tail.constprop.0+0x7ef>
   12c7d:	00 00 
   12c7f:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
   12c86:	c4 e1 cb 2a 8d 40 ff 	vcvtsi2sd xmm1,xmm6,QWORD PTR [rbp-0xc0]
   12c8d:	ff ff 
   12c8f:	c5 f3 58 0d 00 00 00 	vaddsd xmm1,xmm1,QWORD PTR [rip+0x0]        # 12c97 <try_secant_tail.constprop.0+0x807>
   12c96:	00 
   12c97:	c5 f3 58 c8          	vaddsd xmm1,xmm1,xmm0
   12c9b:	c5 fb 11 0d 00 00 00 	vmovsd QWORD PTR [rip+0x0],xmm1        # 12ca3 <try_secant_tail.constprop.0+0x813>
   12ca2:	00 
   12ca3:	e8 00 00 00 00       	call   12ca8 <try_secant_tail.constprop.0+0x818>
   12ca8:	48 8b bd 70 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x190]
   12caf:	e8 00 00 00 00       	call   12cb4 <try_secant_tail.constprop.0+0x824>
   12cb4:	48 8b bd 68 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x198]
   12cbb:	e8 00 00 00 00       	call   12cc0 <try_secant_tail.constprop.0+0x830>
   12cc0:	44 8b ad 0c ff ff ff 	mov    r13d,DWORD PTR [rbp-0xf4]
   12cc7:	44 8b 85 04 ff ff ff 	mov    r8d,DWORD PTR [rbp-0xfc]
   12cce:	45 85 ed             	test   r13d,r13d
   12cd1:	0f 85 46 1d 00 00    	jne    14a1d <try_secant_tail.constprop.0+0x258d>
   12cd7:	44 39 85 d0 fe ff ff 	cmp    DWORD PTR [rbp-0x130],r8d
   12cde:	4c 8d 65 c0          	lea    r12,[rbp-0x40]
   12ce2:	0f 84 d2 20 00 00    	je     14dba <try_secant_tail.constprop.0+0x292a>
   12ce8:	4c 89 b5 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],r14
   12cef:	48 8d 5d b0          	lea    rbx,[rbp-0x50]
   12cf3:	4d 89 fe             	mov    r14,r15
   12cf6:	c5 fb 10 03          	vmovsd xmm0,QWORD PTR [rbx]
   12cfa:	48 8b bd 78 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x188]
   12d01:	4c 89 f6             	mov    rsi,r14
   12d04:	e8 e7 75 ff ff       	call   a2f0 <bs_check_certified.constprop.0>
   12d09:	83 f8 01             	cmp    eax,0x1
   12d0c:	41 89 c5             	mov    r13d,eax
   12d0f:	0f 85 5d 1f 00 00    	jne    14c72 <try_secant_tail.constprop.0+0x27e2>
   12d15:	48 83 c3 08          	add    rbx,0x8
   12d19:	4c 03 b5 00 fe ff ff 	add    r14,QWORD PTR [rbp-0x200]
   12d20:	49 39 dc             	cmp    r12,rbx
   12d23:	75 d1                	jne    12cf6 <try_secant_tail.constprop.0+0x866>
   12d25:	48 8b 95 18 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xe8]
   12d2c:	48 8b bd b8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x148]
   12d33:	4c 8b 8d 20 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1e0]
   12d3a:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 12d42 <try_secant_tail.constprop.0+0x8b2>
   12d41:	00 
   12d42:	44 8b 85 d0 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x130]
   12d49:	8b 8d cc fe ff ff    	mov    ecx,DWORD PTR [rbp-0x134]
   12d4f:	48 8b b5 b0 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x150]
   12d56:	4c 8b b5 f8 fe ff ff 	mov    r14,QWORD PTR [rbp-0x108]
   12d5d:	e8 8e db fe ff       	call   8f0 <compat_scan_fused>
   12d62:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
   12d69:	85 c0                	test   eax,eax
   12d6b:	89 c2                	mov    edx,eax
   12d6d:	0f 85 0d 1f 00 00    	jne    14c80 <try_secant_tail.constprop.0+0x27f0>
   12d73:	48 8b b5 e8 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x218]
   12d7a:	48 8b 9d e0 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x220]
   12d81:	8b 85 04 ff ff ff    	mov    eax,DWORD PTR [rbp-0xfc]
   12d87:	c5 fb 10 85 40 ff ff 	vmovsd xmm0,QWORD PTR [rbp-0xc0]
   12d8e:	ff 
   12d8f:	48 85 f6             	test   rsi,rsi
   12d92:	c7 03 02 00 00 00    	mov    DWORD PTR [rbx],0x2
   12d98:	89 43 04             	mov    DWORD PTR [rbx+0x4],eax
   12d9b:	c5 fb 11 43 18       	vmovsd QWORD PTR [rbx+0x18],xmm0
   12da0:	0f 84 cc 1f 00 00    	je     14d72 <try_secant_tail.constprop.0+0x28e2>
   12da6:	8b 9d d0 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x130]
   12dac:	85 db                	test   ebx,ebx
   12dae:	0f 8e 88 22 00 00    	jle    1503c <try_secant_tail.constprop.0+0x2bac>
   12db4:	8d 43 ff             	lea    eax,[rbx-0x1]
   12db7:	48 8b 8d 18 ff ff ff 	mov    rcx,QWORD PTR [rbp-0xe8]
   12dbe:	83 f8 02             	cmp    eax,0x2
   12dc1:	0f 86 93 22 00 00    	jbe    1505a <try_secant_tail.constprop.0+0x2bca>
   12dc7:	89 da                	mov    edx,ebx
   12dc9:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   12dcd:	31 c0                	xor    eax,eax
   12dcf:	c1 ea 02             	shr    edx,0x2
   12dd2:	c5 fd 28 d3          	vmovapd ymm2,ymm3
   12dd6:	48 c1 e2 05          	shl    rdx,0x5
   12dda:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   12ddf:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   12de6:	00 00 00 00 
   12dea:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   12df1:	00 00 00 00 
   12df5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   12dfc:	00 00 00 00 
   12e00:	c5 fd 10 0c 06       	vmovupd ymm1,YMMWORD PTR [rsi+rax*1]
   12e05:	c5 fd 10 04 01       	vmovupd ymm0,YMMWORD PTR [rcx+rax*1]
   12e0a:	48 83 c0 20          	add    rax,0x20
   12e0e:	48 39 d0             	cmp    rax,rdx
   12e11:	c5 fd 5c c1          	vsubpd ymm0,ymm0,ymm1
   12e15:	c4 e2 f5 b8 d1       	vfmadd231pd ymm2,ymm1,ymm1
   12e1a:	c4 e2 fd b8 d8       	vfmadd231pd ymm3,ymm0,ymm0
   12e1f:	75 df                	jne    12e00 <try_secant_tail.constprop.0+0x970>
   12e21:	8b 85 d0 fe ff ff    	mov    eax,DWORD PTR [rbp-0x130]
   12e27:	c4 e3 7d 19 d8 01    	vextractf128 xmm0,ymm3,0x1
   12e2d:	c4 e3 7d 19 d1 01    	vextractf128 xmm1,ymm2,0x1
   12e33:	c5 f9 58 db          	vaddpd xmm3,xmm0,xmm3
   12e37:	c5 f1 58 d2          	vaddpd xmm2,xmm1,xmm2
   12e3b:	89 c2                	mov    edx,eax
   12e3d:	83 e2 fc             	and    edx,0xfffffffc
   12e40:	c5 e1 15 c3          	vunpckhpd xmm0,xmm3,xmm3
   12e44:	c5 e9 15 ca          	vunpckhpd xmm1,xmm2,xmm2
   12e48:	39 c2                	cmp    edx,eax
   12e4a:	89 d6                	mov    esi,edx
   12e4c:	c5 f9 58 c3          	vaddpd xmm0,xmm0,xmm3
   12e50:	c5 f1 58 ca          	vaddpd xmm1,xmm1,xmm2
   12e54:	0f 84 37 21 00 00    	je     14f91 <try_secant_tail.constprop.0+0x2b01>
   12e5a:	c5 f8 77             	vzeroupper
   12e5d:	8b 85 d0 fe ff ff    	mov    eax,DWORD PTR [rbp-0x130]
   12e63:	29 f0                	sub    eax,esi
   12e65:	83 f8 01             	cmp    eax,0x1
   12e68:	74 38                	je     12ea2 <try_secant_tail.constprop.0+0xa12>
   12e6a:	48 8b 9d e8 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x218]
   12e71:	c5 f9 10 04 f1       	vmovupd xmm0,XMMWORD PTR [rcx+rsi*8]
   12e76:	a8 01                	test   al,0x1
   12e78:	c5 f9 10 0c f3       	vmovupd xmm1,XMMWORD PTR [rbx+rsi*8]
   12e7d:	c5 f9 5c c1          	vsubpd xmm0,xmm0,xmm1
   12e81:	c4 e2 f1 b8 d1       	vfmadd231pd xmm2,xmm1,xmm1
   12e86:	c4 e2 e1 98 c0       	vfmadd132pd xmm0,xmm3,xmm0
   12e8b:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   12e8f:	c5 f1 58 c0          	vaddpd xmm0,xmm1,xmm0
   12e93:	c5 e9 15 ca          	vunpckhpd xmm1,xmm2,xmm2
   12e97:	c5 f1 58 ca          	vaddpd xmm1,xmm1,xmm2
   12e9b:	74 27                	je     12ec4 <try_secant_tail.constprop.0+0xa34>
   12e9d:	83 e0 fe             	and    eax,0xfffffffe
   12ea0:	01 c2                	add    edx,eax
   12ea2:	48 8b 85 e8 fd ff ff 	mov    rax,QWORD PTR [rbp-0x218]
   12ea9:	48 63 d2             	movsxd rdx,edx
   12eac:	c5 fb 10 14 d1       	vmovsd xmm2,QWORD PTR [rcx+rdx*8]
   12eb1:	c5 fb 10 1c d0       	vmovsd xmm3,QWORD PTR [rax+rdx*8]
   12eb6:	c5 eb 5c d3          	vsubsd xmm2,xmm2,xmm3
   12eba:	c4 e2 e1 b9 cb       	vfmadd231sd xmm1,xmm3,xmm3
   12ebf:	c4 e2 e9 b9 c2       	vfmadd231sd xmm0,xmm2,xmm2
   12ec4:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
   12ec8:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
   12ecc:	c5 f3 58 0d 00 00 00 	vaddsd xmm1,xmm1,QWORD PTR [rip+0x0]        # 12ed4 <try_secant_tail.constprop.0+0xa44>
   12ed3:	00 
   12ed4:	c5 fb 5e c1          	vdivsd xmm0,xmm0,xmm1
   12ed8:	48 8b 85 e0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x220]
   12edf:	c7 40 0c 01 00 00 00 	mov    DWORD PTR [rax+0xc],0x1
   12ee6:	c5 fb 11 40 20       	vmovsd QWORD PTR [rax+0x20],xmm0
   12eeb:	e8 00 00 00 00       	call   12ef0 <try_secant_tail.constprop.0+0xa60>
   12ef0:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   12ef7:	e8 00 00 00 00       	call   12efc <try_secant_tail.constprop.0+0xa6c>
   12efc:	48 8b bd 20 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe0]
   12f03:	e8 00 00 00 00       	call   12f08 <try_secant_tail.constprop.0+0xa78>
   12f08:	4c 89 f7             	mov    rdi,r14
   12f0b:	e8 00 00 00 00       	call   12f10 <try_secant_tail.constprop.0+0xa80>
   12f10:	4c 89 ff             	mov    rdi,r15
   12f13:	e8 00 00 00 00       	call   12f18 <try_secant_tail.constprop.0+0xa88>
   12f18:	e9 6c f6 ff ff       	jmp    12589 <try_secant_tail.constprop.0+0xf9>
   12f1d:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
   12f21:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
   12f25:	0f 1f 00             	nop    DWORD PTR [rax]
   12f28:	8b b5 d0 fe ff ff    	mov    esi,DWORD PTR [rbp-0x130]
   12f2e:	c5 f9 29 bd 80 fe ff 	vmovapd XMMWORD PTR [rbp-0x180],xmm7
   12f35:	ff 
   12f36:	c5 fb 11 a5 a0 fe ff 	vmovsd QWORD PTR [rbp-0x160],xmm4
   12f3d:	ff 
   12f3e:	c5 f8 77             	vzeroupper
   12f41:	e8 fa d2 fe ff       	call   240 <norm2>
   12f46:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
   12f4a:	c5 fb 10 a5 a0 fe ff 	vmovsd xmm4,QWORD PTR [rbp-0x160]
   12f51:	ff 
   12f52:	c5 f9 2f c2          	vcomisd xmm0,xmm2
   12f56:	c5 f9 28 bd 80 fe ff 	vmovapd xmm7,XMMWORD PTR [rbp-0x180]
   12f5d:	ff 
   12f5e:	0f 85 27 fc ff ff    	jne    12b8b <try_secant_tail.constprop.0+0x6fb>
   12f64:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   12f6b:	4a 8d 14 c0          	lea    rdx,[rax+r8*8]
   12f6f:	c5 fb 10 02          	vmovsd xmm0,QWORD PTR [rdx]
   12f73:	c5 f9 54 05 00 00 00 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x0]        # 12f7b <try_secant_tail.constprop.0+0xaeb>
   12f7a:	00 
   12f7b:	c5 f9 2f 05 00 00 00 	vcomisd xmm0,QWORD PTR [rip+0x0]        # 12f83 <try_secant_tail.constprop.0+0xaf3>
   12f82:	00 
   12f83:	77 2e                	ja     12fb3 <try_secant_tail.constprop.0+0xb23>
   12f85:	8b 9d f8 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x108]
   12f8b:	41 8d 45 01          	lea    eax,[r13+0x1]
   12f8f:	44 39 eb             	cmp    ebx,r13d
   12f92:	41 89 c5             	mov    r13d,eax
   12f95:	0f 4e d8             	cmovle ebx,eax
   12f98:	83 85 c0 fe ff ff 01 	add    DWORD PTR [rbp-0x140],0x1
   12f9f:	89 9d f8 fe ff ff    	mov    DWORD PTR [rbp-0x108],ebx
   12fa5:	e9 86 fc ff ff       	jmp    12c30 <try_secant_tail.constprop.0+0x7a0>
   12faa:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   12fb0:	c5 f8 77             	vzeroupper
   12fb3:	48 8b 0d 00 00 00 00 	mov    rcx,QWORD PTR [rip+0x0]        # 12fba <try_secant_tail.constprop.0+0xb2a>
   12fba:	c4 e1 f9 6e f9       	vmovq  xmm7,rcx
   12fbf:	c5 c3 58 2d 00 00 00 	vaddsd xmm5,xmm7,QWORD PTR [rip+0x0]        # 12fc7 <try_secant_tail.constprop.0+0xb37>
   12fc6:	00 
   12fc7:	48 89 c8             	mov    rax,rcx
   12fca:	c4 e1 f9 7e ee       	vmovq  rsi,xmm5
   12fcf:	f0 48 0f b1 35 00 00 	lock cmpxchg QWORD PTR [rip+0x0],rsi        # 12fd8 <try_secant_tail.constprop.0+0xb48>
   12fd6:	00 00 
   12fd8:	0f 85 49 21 00 00    	jne    15127 <try_secant_tail.constprop.0+0x2c97>
   12fde:	8b 85 0c ff ff ff    	mov    eax,DWORD PTR [rbp-0xf4]
   12fe4:	85 c0                	test   eax,eax
   12fe6:	89 85 80 fe ff ff    	mov    DWORD PTR [rbp-0x180],eax
   12fec:	0f 85 1a 14 00 00    	jne    1440c <try_secant_tail.constprop.0+0x1f7c>
   12ff2:	44 8b a5 00 ff ff ff 	mov    r12d,DWORD PTR [rbp-0x100]
   12ff9:	c5 fb 10 32          	vmovsd xmm6,QWORD PTR [rdx]
   12ffd:	44 89 e6             	mov    esi,r12d
   13000:	c5 fb 11 b5 a0 fe ff 	vmovsd QWORD PTR [rbp-0x160],xmm6
   13007:	ff 
   13008:	e8 33 d2 fe ff       	call   240 <norm2>
   1300d:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   13011:	c5 f9 2f c1          	vcomisd xmm0,xmm1
   13015:	75 31                	jne    13048 <try_secant_tail.constprop.0+0xbb8>
   13017:	c5 fb 10 b5 a0 fe ff 	vmovsd xmm6,QWORD PTR [rbp-0x160]
   1301e:	ff 
   1301f:	c5 c9 54 05 00 00 00 	vandpd xmm0,xmm6,XMMWORD PTR [rip+0x0]        # 13027 <try_secant_tail.constprop.0+0xb97>
   13026:	00 
   13027:	c5 f9 2f 05 00 00 00 	vcomisd xmm0,QWORD PTR [rip+0x0]        # 1302f <try_secant_tail.constprop.0+0xb9f>
   1302e:	00 
   1302f:	0f 87 45 1f 00 00    	ja     14f7a <try_secant_tail.constprop.0+0x2aea>
   13035:	83 85 c0 fe ff ff 01 	add    DWORD PTR [rbp-0x140],0x1
   1303c:	41 83 c5 01          	add    r13d,0x1
   13040:	e9 eb fb ff ff       	jmp    12c30 <try_secant_tail.constprop.0+0x7a0>
   13045:	0f 1f 00             	nop    DWORD PTR [rax]
   13048:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # 13050 <try_secant_tail.constprop.0+0xbc0>
   1304f:	00 
   13050:	8b 85 04 ff ff ff    	mov    eax,DWORD PTR [rbp-0xfc]
   13056:	49 63 dc             	movsxd rbx,r12d
   13059:	45 85 e4             	test   r12d,r12d
   1305c:	4c 8b 9d 20 ff ff ff 	mov    r11,QWORD PTR [rbp-0xe0]
   13063:	48 89 9d 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rbx
   1306a:	c5 d3 5e c0          	vdivsd xmm0,xmm5,xmm0
   1306e:	89 85 5c fe ff ff    	mov    DWORD PTR [rbp-0x1a4],eax
   13074:	48 8d 04 dd 00 00 00 	lea    rax,[rbx*8+0x0]
   1307b:	00 
   1307c:	48 8b b5 10 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xf0]
   13083:	4d 8d 0c 03          	lea    r9,[r11+rax*1]
   13087:	48 89 85 18 fe ff ff 	mov    QWORD PTR [rbp-0x1e8],rax
   1308e:	4d 8d 04 01          	lea    r8,[r9+rax*1]
   13092:	c5 fb 59 ad a0 fe ff 	vmulsd xmm5,xmm0,QWORD PTR [rbp-0x160]
   13099:	ff 
   1309a:	c5 fb 11 ad a0 fe ff 	vmovsd QWORD PTR [rbp-0x160],xmm5
   130a1:	ff 
   130a2:	0f 8e ee 15 00 00    	jle    14696 <try_secant_tail.constprop.0+0x2206>
   130a8:	41 83 fc 01          	cmp    r12d,0x1
   130ac:	0f 84 4f 16 00 00    	je     14701 <try_secant_tail.constprop.0+0x2271>
   130b2:	48 8d 04 dd f8 ff ff 	lea    rax,[rbx*8-0x8]
   130b9:	ff 
   130ba:	48 83 f8 10          	cmp    rax,0x10
   130be:	49 8d 41 f8          	lea    rax,[r9-0x8]
   130c2:	0f 97 c2             	seta   dl
   130c5:	48 29 f8             	sub    rax,rdi
   130c8:	48 83 f8 10          	cmp    rax,0x10
   130cc:	0f 97 c0             	seta   al
   130cf:	84 c2                	test   dl,al
   130d1:	0f 84 cd 16 00 00    	je     147a4 <try_secant_tail.constprop.0+0x2314>
   130d7:	49 8d 43 f8          	lea    rax,[r11-0x8]
   130db:	48 29 f8             	sub    rax,rdi
   130de:	48 83 f8 10          	cmp    rax,0x10
   130e2:	0f 86 bc 16 00 00    	jbe    147a4 <try_secant_tail.constprop.0+0x2314>
   130e8:	41 8d 44 24 ff       	lea    eax,[r12-0x1]
   130ed:	45 89 e2             	mov    r10d,r12d
   130f0:	83 f8 02             	cmp    eax,0x2
   130f3:	0f 86 c6 16 00 00    	jbe    147bf <try_secant_tail.constprop.0+0x232f>
   130f9:	44 89 e1             	mov    ecx,r12d
   130fc:	c4 e2 7d 19 d0       	vbroadcastsd ymm2,xmm0
   13101:	31 d2                	xor    edx,edx
   13103:	c1 e9 02             	shr    ecx,0x2
   13106:	48 c1 e1 05          	shl    rcx,0x5
   1310a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   13111:	00 00 00 00 
   13115:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   1311c:	00 00 00 00 
   13120:	c5 ed 59 0c 17       	vmulpd ymm1,ymm2,YMMWORD PTR [rdi+rdx*1]
   13125:	c4 c1 7d 11 0c 13    	vmovupd YMMWORD PTR [r11+rdx*1],ymm1
   1312b:	c4 c1 7d 11 0c 11    	vmovupd YMMWORD PTR [r9+rdx*1],ymm1
   13131:	48 83 c2 20          	add    rdx,0x20
   13135:	48 39 d1             	cmp    rcx,rdx
   13138:	75 e6                	jne    13120 <try_secant_tail.constprop.0+0xc90>
   1313a:	44 89 e2             	mov    edx,r12d
   1313d:	83 e2 fc             	and    edx,0xfffffffc
   13140:	41 39 d4             	cmp    r12d,edx
   13143:	89 d1                	mov    ecx,edx
   13145:	0f 84 31 15 00 00    	je     1467c <try_secant_tail.constprop.0+0x21ec>
   1314b:	45 89 e2             	mov    r10d,r12d
   1314e:	41 29 d2             	sub    r10d,edx
   13151:	41 83 fa 01          	cmp    r10d,0x1
   13155:	0f 84 6c 18 00 00    	je     149c7 <try_secant_tail.constprop.0+0x2537>
   1315b:	c5 f8 77             	vzeroupper
   1315e:	c5 fb 12 c8          	vmovddup xmm1,xmm0
   13162:	c5 f1 59 0c cf       	vmulpd xmm1,xmm1,XMMWORD PTR [rdi+rcx*8]
   13167:	c4 c1 79 11 0c cb    	vmovupd XMMWORD PTR [r11+rcx*8],xmm1
   1316d:	48 03 8d 28 fe ff ff 	add    rcx,QWORD PTR [rbp-0x1d8]
   13174:	41 f6 c2 01          	test   r10b,0x1
   13178:	c4 c1 79 11 0c cb    	vmovupd XMMWORD PTR [r11+rcx*8],xmm1
   1317e:	74 1b                	je     1319b <try_secant_tail.constprop.0+0xd0b>
   13180:	41 83 e2 fe          	and    r10d,0xfffffffe
   13184:	44 01 d2             	add    edx,r10d
   13187:	48 63 d2             	movsxd rdx,edx
   1318a:	c5 fb 59 04 d7       	vmulsd xmm0,xmm0,QWORD PTR [rdi+rdx*8]
   1318f:	c4 c1 7b 11 04 d3    	vmovsd QWORD PTR [r11+rdx*8],xmm0
   13195:	c4 c1 7b 11 04 d1    	vmovsd QWORD PTR [r9+rdx*8],xmm0
   1319b:	8b 95 5c fe ff ff    	mov    edx,DWORD PTR [rbp-0x1a4]
   131a1:	4c 89 cf             	mov    rdi,r9
   131a4:	44 89 e1             	mov    ecx,r12d
   131a7:	4c 89 9d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r11
   131ae:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   131b4:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   131bb:	e8 d0 01 ff ff       	call   3390 <project_cgs2>
   131c0:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   131c7:	44 89 e6             	mov    esi,r12d
   131ca:	c5 fb 11 85 c8 fd ff 	vmovsd QWORD PTR [rbp-0x238],xmm0
   131d1:	ff 
   131d2:	4c 89 cf             	mov    rdi,r9
   131d5:	e8 66 d0 fe ff       	call   240 <norm2>
   131da:	83 bd 50 fe ff ff 02 	cmp    DWORD PTR [rbp-0x1b0],0x2
   131e1:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   131e8:	44 89 e2             	mov    edx,r12d
   131eb:	4c 8b 9d 38 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1c8]
   131f2:	c5 f9 28 d0          	vmovapd xmm2,xmm0
   131f6:	0f 86 b6 15 00 00    	jbe    147b2 <try_secant_tail.constprop.0+0x2322>
   131fc:	44 89 e2             	mov    edx,r12d
   131ff:	31 c0                	xor    eax,eax
   13201:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   13205:	c1 ea 02             	shr    edx,0x2
   13208:	48 c1 e2 05          	shl    rdx,0x5
   1320c:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
   13213:	00 00 
   13215:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   1321c:	00 00 00 00 
   13220:	c5 fd 10 04 07       	vmovupd ymm0,YMMWORD PTR [rdi+rax*1]
   13225:	c4 c1 7d 59 04 03    	vmulpd ymm0,ymm0,YMMWORD PTR [r11+rax*1]
   1322b:	48 83 c0 20          	add    rax,0x20
   1322f:	48 39 d0             	cmp    rax,rdx
   13232:	c5 f5 58 c8          	vaddpd ymm1,ymm1,ymm0
   13236:	75 e8                	jne    13220 <try_secant_tail.constprop.0+0xd90>
   13238:	c4 e3 7d 19 c8 01    	vextractf128 xmm0,ymm1,0x1
   1323e:	41 f6 c4 03          	test   r12b,0x3
   13242:	c5 f9 58 c1          	vaddpd xmm0,xmm0,xmm1
   13246:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   1324a:	c5 f1 58 c8          	vaddpd xmm1,xmm1,xmm0
   1324e:	0f 84 20 14 00 00    	je     14674 <try_secant_tail.constprop.0+0x21e4>
   13254:	44 89 e0             	mov    eax,r12d
   13257:	83 e0 fc             	and    eax,0xfffffffc
   1325a:	89 c1                	mov    ecx,eax
   1325c:	c5 f8 77             	vzeroupper
   1325f:	44 89 e2             	mov    edx,r12d
   13262:	29 c2                	sub    edx,eax
   13264:	83 fa 01             	cmp    edx,0x1
   13267:	74 1e                	je     13287 <try_secant_tail.constprop.0+0xdf7>
   13269:	c4 c1 79 10 2c c3    	vmovupd xmm5,XMMWORD PTR [r11+rax*8]
   1326f:	c4 e2 d1 b8 04 c7    	vfmadd231pd xmm0,xmm5,XMMWORD PTR [rdi+rax*8]
   13275:	f6 c2 01             	test   dl,0x1
   13278:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   1327c:	c5 f1 58 c8          	vaddpd xmm1,xmm1,xmm0
   13280:	74 14                	je     13296 <try_secant_tail.constprop.0+0xe06>
   13282:	83 e2 fe             	and    edx,0xfffffffe
   13285:	01 d1                	add    ecx,edx
   13287:	48 63 c9             	movsxd rcx,ecx
   1328a:	c4 c1 7b 10 34 cb    	vmovsd xmm6,QWORD PTR [r11+rcx*8]
   13290:	c4 e2 c9 b9 0c cf    	vfmadd231sd xmm1,xmm6,QWORD PTR [rdi+rcx*8]
   13296:	c5 fb 10 b5 a0 fe ff 	vmovsd xmm6,QWORD PTR [rbp-0x160]
   1329d:	ff 
   1329e:	c5 cb 5c e9          	vsubsd xmm5,xmm6,xmm1
   132a2:	c5 fb 11 ad 08 fe ff 	vmovsd QWORD PTR [rbp-0x1f8],xmm5
   132a9:	ff 
   132aa:	44 89 e6             	mov    esi,r12d
   132ad:	4c 89 9d 30 fe ff ff 	mov    QWORD PTR [rbp-0x1d0],r11
   132b4:	4c 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r9
   132bb:	c5 fb 11 95 50 fe ff 	vmovsd QWORD PTR [rbp-0x1b0],xmm2
   132c2:	ff 
   132c3:	e8 78 cf fe ff       	call   240 <norm2>
   132c8:	db ad 30 ff ff ff    	fld    TBYTE PTR [rbp-0xd0]
   132ce:	c5 fb 11 85 f0 fd ff 	vmovsd QWORD PTR [rbp-0x210],xmm0
   132d5:	ff 
   132d6:	db bd 40 fe ff ff    	fstp   TBYTE PTR [rbp-0x1c0]
   132dc:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 132e3 <try_secant_tail.constprop.0+0xe53>
   132e3:	e8 00 00 00 00       	call   132e8 <try_secant_tail.constprop.0+0xe58>
   132e8:	c5 fb 10 95 50 fe ff 	vmovsd xmm2,QWORD PTR [rbp-0x1b0]
   132ef:	ff 
   132f0:	4c 8b 8d 38 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c8]
   132f7:	4c 8b 9d 30 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1d0]
   132fe:	d9 ee                	fldz
   13300:	c5 fb 10 88 00 00 00 	vmovsd xmm1,QWORD PTR [rax+0x0]
   13307:	00 
   13308:	db ad 40 fe ff ff    	fld    TBYTE PTR [rbp-0x1c0]
   1330e:	db f1                	fcomi  st,st(1)
   13310:	dd d9                	fstp   st(1)
   13312:	0f 86 99 07 00 00    	jbe    13ab1 <try_secant_tail.constprop.0+0x1621>
   13318:	d9 c0                	fld    st(0)
   1331a:	d9 fa                	fsqrt
   1331c:	dd 9d 40 fe ff ff    	fstp   QWORD PTR [rbp-0x1c0]
   13322:	c5 fb 10 85 40 fe ff 	vmovsd xmm0,QWORD PTR [rbp-0x1c0]
   13329:	ff 
   1332a:	c5 f9 2f c1          	vcomisd xmm0,xmm1
   1332e:	76 08                	jbe    13338 <try_secant_tail.constprop.0+0xea8>
   13330:	c5 fb 11 80 00 00 00 	vmovsd QWORD PTR [rax+0x0],xmm0
   13337:	00 
   13338:	c5 f9 2f 05 00 00 00 	vcomisd xmm0,QWORD PTR [rip+0x0]        # 13340 <try_secant_tail.constprop.0+0xeb0>
   1333f:	00 
   13340:	0f 82 ff 0e 00 00    	jb     14245 <try_secant_tail.constprop.0+0x1db5>
   13346:	dd d8                	fstp   st(0)
   13348:	eb 02                	jmp    1334c <try_secant_tail.constprop.0+0xebc>
   1334a:	dd d8                	fstp   st(0)
   1334c:	45 85 ed             	test   r13d,r13d
   1334f:	0f 88 4b 02 00 00    	js     135a0 <try_secant_tail.constprop.0+0x1110>
   13355:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 1335c <try_secant_tail.constprop.0+0xecc>
   1335c:	e8 00 00 00 00       	call   13361 <try_secant_tail.constprop.0+0xed1>
   13361:	48 63 98 00 00 00 00 	movsxd rbx,DWORD PTR [rax+0x0]
   13368:	83 80 00 00 00 00 01 	add    DWORD PTR [rax+0x0],0x1
   1336f:	85 db                	test   ebx,ebx
   13371:	0f 8e 0c 02 00 00    	jle    13583 <try_secant_tail.constprop.0+0x10f3>
   13377:	8d 53 ff             	lea    edx,[rbx-0x1]
   1337a:	83 fa 07             	cmp    edx,0x7
   1337d:	0f 86 75 19 00 00    	jbe    14cf8 <try_secant_tail.constprop.0+0x2868>
   13383:	c4 c1 79 6e c5       	vmovd  xmm0,r13d
   13388:	c4 e2 7d 58 c0       	vpbroadcastd ymm0,xmm0
   1338d:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   13394:	00 
   13395:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   1339a:	0f 85 16 1c 00 00    	jne    14fb6 <try_secant_tail.constprop.0+0x2b26>
   133a0:	41 89 dc             	mov    r12d,ebx
   133a3:	41 c1 ec 03          	shr    r12d,0x3
   133a7:	41 83 fc 01          	cmp    r12d,0x1
   133ab:	0f 84 1f 1c 00 00    	je     14fd0 <try_secant_tail.constprop.0+0x2b40>
   133b1:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   133b8:	00 
   133b9:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   133be:	0f 85 a1 1b 00 00    	jne    14f65 <try_secant_tail.constprop.0+0x2ad5>
   133c4:	41 83 fc 02          	cmp    r12d,0x2
   133c8:	0f 84 b3 00 00 00    	je     13481 <try_secant_tail.constprop.0+0xff1>
   133ce:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   133d5:	00 
   133d6:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   133db:	0f 85 2a 1c 00 00    	jne    1500b <try_secant_tail.constprop.0+0x2b7b>
   133e1:	41 83 fc 03          	cmp    r12d,0x3
   133e5:	0f 84 96 00 00 00    	je     13481 <try_secant_tail.constprop.0+0xff1>
   133eb:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   133f2:	00 
   133f3:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   133f8:	0f 85 1a 1c 00 00    	jne    15018 <try_secant_tail.constprop.0+0x2b88>
   133fe:	41 83 fc 04          	cmp    r12d,0x4
   13402:	74 7d                	je     13481 <try_secant_tail.constprop.0+0xff1>
   13404:	c5 fd 7f 85 d0 fe ff 	vmovdqa YMMWORD PTR [rbp-0x130],ymm0
   1340b:	ff 
   1340c:	c5 f8 77             	vzeroupper
   1340f:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 13416 <try_secant_tail.constprop.0+0xf86>
   13416:	e8 00 00 00 00       	call   1341b <try_secant_tail.constprop.0+0xf8b>
   1341b:	c5 fd 6f 85 d0 fe ff 	vmovdqa ymm0,YMMWORD PTR [rbp-0x130]
   13422:	ff 
   13423:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   1342a:	00 
   1342b:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   13430:	0f 85 c8 1b 00 00    	jne    14ffe <try_secant_tail.constprop.0+0x2b6e>
   13436:	41 83 fc 05          	cmp    r12d,0x5
   1343a:	74 45                	je     13481 <try_secant_tail.constprop.0+0xff1>
   1343c:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   13443:	00 
   13444:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   13449:	0f 85 22 1c 00 00    	jne    15071 <try_secant_tail.constprop.0+0x2be1>
   1344f:	41 83 fc 06          	cmp    r12d,0x6
   13453:	74 2c                	je     13481 <try_secant_tail.constprop.0+0xff1>
   13455:	c5 fd 76 88 00 00 00 	vpcmpeqd ymm1,ymm0,YMMWORD PTR [rax+0x0]
   1345c:	00 
   1345d:	c4 e2 7d 17 c9       	vptest ymm1,ymm1
   13462:	0f 85 16 1c 00 00    	jne    1507e <try_secant_tail.constprop.0+0x2bee>
   13468:	41 83 fc 07          	cmp    r12d,0x7
   1346c:	74 13                	je     13481 <try_secant_tail.constprop.0+0xff1>
   1346e:	c5 fd 76 80 00 00 00 	vpcmpeqd ymm0,ymm0,YMMWORD PTR [rax+0x0]
   13475:	00 
   13476:	c4 e2 7d 17 c0       	vptest ymm0,ymm0
   1347b:	0f 85 0a 1c 00 00    	jne    1508b <try_secant_tail.constprop.0+0x2bfb>
   13481:	f6 c3 07             	test   bl,0x7
   13484:	0f 84 28 19 00 00    	je     14db2 <try_secant_tail.constprop.0+0x2922>
   1348a:	89 d8                	mov    eax,ebx
   1348c:	83 e0 f8             	and    eax,0xfffffff8
   1348f:	89 85 80 fe ff ff    	mov    DWORD PTR [rbp-0x180],eax
   13495:	c5 f8 77             	vzeroupper
   13498:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 1349f <try_secant_tail.constprop.0+0x100f>
   1349f:	e8 00 00 00 00       	call   134a4 <try_secant_tail.constprop.0+0x1014>
   134a4:	48 63 95 80 fe ff ff 	movsxd rdx,DWORD PTR [rbp-0x180]
   134ab:	44 3b ac 90 00 00 00 	cmp    r13d,DWORD PTR [rax+rdx*4+0x0]
   134b2:	00 
   134b3:	0f 84 e7 00 00 00    	je     135a0 <try_secant_tail.constprop.0+0x1110>
   134b9:	44 8d 62 01          	lea    r12d,[rdx+0x1]
   134bd:	44 39 e3             	cmp    ebx,r12d
   134c0:	0f 8e b8 00 00 00    	jle    1357e <try_secant_tail.constprop.0+0x10ee>
   134c6:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 134cd <try_secant_tail.constprop.0+0x103d>
   134cd:	e8 00 00 00 00       	call   134d2 <try_secant_tail.constprop.0+0x1042>
   134d2:	4d 63 e4             	movsxd r12,r12d
   134d5:	46 3b ac a0 00 00 00 	cmp    r13d,DWORD PTR [rax+r12*4+0x0]
   134dc:	00 
   134dd:	0f 84 bd 00 00 00    	je     135a0 <try_secant_tail.constprop.0+0x1110>
   134e3:	8b 85 80 fe ff ff    	mov    eax,DWORD PTR [rbp-0x180]
   134e9:	44 8d 60 02          	lea    r12d,[rax+0x2]
   134ed:	44 39 e3             	cmp    ebx,r12d
   134f0:	0f 8e 88 00 00 00    	jle    1357e <try_secant_tail.constprop.0+0x10ee>
   134f6:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 134fd <try_secant_tail.constprop.0+0x106d>
   134fd:	e8 00 00 00 00       	call   13502 <try_secant_tail.constprop.0+0x1072>
   13502:	4d 63 e4             	movsxd r12,r12d
   13505:	46 3b ac a0 00 00 00 	cmp    r13d,DWORD PTR [rax+r12*4+0x0]
   1350c:	00 
   1350d:	48 8d 90 00 00 00 00 	lea    rdx,[rax+0x0]
   13514:	0f 84 86 00 00 00    	je     135a0 <try_secant_tail.constprop.0+0x1110>
   1351a:	8b b5 80 fe ff ff    	mov    esi,DWORD PTR [rbp-0x180]
   13520:	8d 46 03             	lea    eax,[rsi+0x3]
   13523:	39 c3                	cmp    ebx,eax
   13525:	7e 57                	jle    1357e <try_secant_tail.constprop.0+0x10ee>
   13527:	48 98                	cdqe
   13529:	44 3b 2c 82          	cmp    r13d,DWORD PTR [rdx+rax*4]
   1352d:	74 71                	je     135a0 <try_secant_tail.constprop.0+0x1110>
   1352f:	8d 46 04             	lea    eax,[rsi+0x4]
   13532:	39 c3                	cmp    ebx,eax
   13534:	7e 48                	jle    1357e <try_secant_tail.constprop.0+0x10ee>
   13536:	48 98                	cdqe
   13538:	44 3b 2c 82          	cmp    r13d,DWORD PTR [rdx+rax*4]
   1353c:	74 62                	je     135a0 <try_secant_tail.constprop.0+0x1110>
   1353e:	8d 46 05             	lea    eax,[rsi+0x5]
   13541:	39 c3                	cmp    ebx,eax
   13543:	7e 39                	jle    1357e <try_secant_tail.constprop.0+0x10ee>
   13545:	48 98                	cdqe
   13547:	44 3b 2c 82          	cmp    r13d,DWORD PTR [rdx+rax*4]
   1354b:	74 53                	je     135a0 <try_secant_tail.constprop.0+0x1110>
   1354d:	8d 46 06             	lea    eax,[rsi+0x6]
   13550:	39 c3                	cmp    ebx,eax
   13552:	7e 2a                	jle    1357e <try_secant_tail.constprop.0+0x10ee>
   13554:	48 98                	cdqe
   13556:	44 3b 2c 82          	cmp    r13d,DWORD PTR [rdx+rax*4]
   1355a:	74 44                	je     135a0 <try_secant_tail.constprop.0+0x1110>
   1355c:	44 8d 66 07          	lea    r12d,[rsi+0x7]
   13560:	44 39 e3             	cmp    ebx,r12d
   13563:	7e 19                	jle    1357e <try_secant_tail.constprop.0+0x10ee>
   13565:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 1356c <try_secant_tail.constprop.0+0x10dc>
   1356c:	e8 00 00 00 00       	call   13571 <try_secant_tail.constprop.0+0x10e1>
   13571:	4d 63 e4             	movsxd r12,r12d
   13574:	46 3b ac a0 00 00 00 	cmp    r13d,DWORD PTR [rax+r12*4+0x0]
   1357b:	00 
   1357c:	74 22                	je     135a0 <try_secant_tail.constprop.0+0x1110>
   1357e:	83 fb 40             	cmp    ebx,0x40
   13581:	74 1d                	je     135a0 <try_secant_tail.constprop.0+0x1110>
   13583:	48 8d 3d 00 00 00 00 	lea    rdi,[rip+0x0]        # 1358a <try_secant_tail.constprop.0+0x10fa>
   1358a:	e8 00 00 00 00       	call   1358f <try_secant_tail.constprop.0+0x10ff>
   1358f:	8d 53 01             	lea    edx,[rbx+0x1]
   13592:	89 90 00 00 00 00    	mov    DWORD PTR [rax+0x0],edx
   13598:	44 89 ac 98 00 00 00 	mov    DWORD PTR [rax+rbx*4+0x0],r13d
   1359f:	00 
   135a0:	48 8b b5 20 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1e0]
   135a7:	bf 01 00 00 00       	mov    edi,0x1
   135ac:	e8 00 00 00 00       	call   135b1 <try_secant_tail.constprop.0+0x1121>
   135b1:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
   135b5:	c5 fb 10 3d 00 00 00 	vmovsd xmm7,QWORD PTR [rip+0x0]        # 135bd <try_secant_tail.constprop.0+0x112d>
   135bc:	00 
   135bd:	c4 e1 d3 2a 85 48 ff 	vcvtsi2sd xmm0,xmm5,QWORD PTR [rbp-0xb8]
   135c4:	ff ff 
   135c6:	c4 e2 c1 a9 05 00 00 	vfmadd213sd xmm0,xmm7,QWORD PTR [rip+0x0]        # 135cf <try_secant_tail.constprop.0+0x113f>
   135cd:	00 00 
   135cf:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
   135d6:	c4 e1 d3 2a 8d 40 ff 	vcvtsi2sd xmm1,xmm5,QWORD PTR [rbp-0xc0]
   135dd:	ff ff 
   135df:	c5 f3 5c 0d 00 00 00 	vsubsd xmm1,xmm1,QWORD PTR [rip+0x0]        # 135e7 <try_secant_tail.constprop.0+0x1157>
   135e6:	00 
   135e7:	c5 fb 58 c1          	vaddsd xmm0,xmm0,xmm1
   135eb:	c5 fb 11 05 00 00 00 	vmovsd QWORD PTR [rip+0x0],xmm0        # 135f3 <try_secant_tail.constprop.0+0x1163>
   135f2:	00 
   135f3:	e8 00 00 00 00       	call   135f8 <try_secant_tail.constprop.0+0x1168>
   135f8:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   135ff:	e8 00 00 00 00       	call   13604 <try_secant_tail.constprop.0+0x1174>
   13604:	48 8b bd 20 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe0]
   1360b:	e8 00 00 00 00       	call   13610 <try_secant_tail.constprop.0+0x1180>
   13610:	4c 89 f7             	mov    rdi,r14
   13613:	e8 00 00 00 00       	call   13618 <try_secant_tail.constprop.0+0x1188>
   13618:	4c 89 ff             	mov    rdi,r15
   1361b:	e8 00 00 00 00       	call   13620 <try_secant_tail.constprop.0+0x1190>
   13620:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
   13627:	e8 00 00 00 00       	call   1362c <try_secant_tail.constprop.0+0x119c>
   1362c:	48 8b bd 70 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x190]
   13633:	e8 00 00 00 00       	call   13638 <try_secant_tail.constprop.0+0x11a8>
   13638:	48 8b bd 68 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x198]
   1363f:	e8 00 00 00 00       	call   13644 <try_secant_tail.constprop.0+0x11b4>
   13644:	45 31 ed             	xor    r13d,r13d
   13647:	e9 3d ef ff ff       	jmp    12589 <try_secant_tail.constprop.0+0xf9>
   1364c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   13650:	8b bd cc fe ff ff    	mov    edi,DWORD PTR [rbp-0x134]
   13656:	41 8d 85 00 08 00 00 	lea    eax,[r13+0x800]
   1365d:	c5 fb 10 ad 10 fe ff 	vmovsd xmm5,QWORD PTR [rbp-0x1f0]
   13664:	ff 
   13665:	c5 d1 16 8d 60 fe ff 	vmovhpd xmm1,xmm5,QWORD PTR [rbp-0x1a0]
   1366c:	ff 
   1366d:	39 f8                	cmp    eax,edi
   1366f:	0f 4f c7             	cmovg  eax,edi
   13672:	89 85 f8 fe ff ff    	mov    DWORD PTR [rbp-0x108],eax
   13678:	41 89 c0             	mov    r8d,eax
   1367b:	48 8b 15 00 00 00 00 	mov    rdx,QWORD PTR [rip+0x0]        # 13682 <try_secant_tail.constprop.0+0x11f2>
   13682:	45 29 e8             	sub    r8d,r13d
   13685:	c4 e1 f9 6e fa       	vmovq  xmm7,rdx
   1368a:	c5 c3 58 35 00 00 00 	vaddsd xmm6,xmm7,QWORD PTR [rip+0x0]        # 13692 <try_secant_tail.constprop.0+0x1202>
   13691:	00 
   13692:	48 89 d0             	mov    rax,rdx
   13695:	c4 e1 f9 7e f1       	vmovq  rcx,xmm6
   1369a:	f0 48 0f b1 0d 00 00 	lock cmpxchg QWORD PTR [rip+0x0],rcx        # 136a3 <try_secant_tail.constprop.0+0x1213>
   136a1:	00 00 
   136a3:	0f 85 e0 1a 00 00    	jne    15189 <try_secant_tail.constprop.0+0x2cf9>
   136a9:	48 8b 15 00 00 00 00 	mov    rdx,QWORD PTR [rip+0x0]        # 136b0 <try_secant_tail.constprop.0+0x1220>
   136b0:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
   136b4:	c4 c1 53 2a c0       	vcvtsi2sd xmm0,xmm5,r8d
   136b9:	c4 e1 f9 6e fa       	vmovq  xmm7,rdx
   136be:	48 89 d0             	mov    rax,rdx
   136c1:	c5 fb 58 f7          	vaddsd xmm6,xmm0,xmm7
   136c5:	c4 e1 f9 7e f1       	vmovq  rcx,xmm6
   136ca:	f0 48 0f b1 0d 00 00 	lock cmpxchg QWORD PTR [rip+0x0],rcx        # 136d3 <try_secant_tail.constprop.0+0x1243>
   136d1:	00 00 
   136d3:	0f 85 56 1a 00 00    	jne    1512f <try_secant_tail.constprop.0+0x2c9f>
   136d9:	44 89 85 a0 fe ff ff 	mov    DWORD PTR [rbp-0x160],r8d
   136e0:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
   136e7:	49 63 d0             	movsxd rdx,r8d
   136ea:	31 f6                	xor    esi,esi
   136ec:	c5 f9 29 8d 80 fe ff 	vmovapd XMMWORD PTR [rbp-0x180],xmm1
   136f3:	ff 
   136f4:	b9 00 08 00 00       	mov    ecx,0x800
   136f9:	c5 f8 77             	vzeroupper
   136fc:	e8 00 00 00 00       	call   13701 <try_secant_tail.constprop.0+0x1271>
   13701:	48 8b 8d b8 fd ff ff 	mov    rcx,QWORD PTR [rbp-0x248]
   13708:	31 f6                	xor    esi,esi
   1370a:	48 8b bd 70 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x190]
   13711:	48 89 ca             	mov    rdx,rcx
   13714:	e8 00 00 00 00       	call   13719 <try_secant_tail.constprop.0+0x1289>
   13719:	4c 8b a5 68 fe ff ff 	mov    r12,QWORD PTR [rbp-0x198]
   13720:	48 8b 8d c0 fd ff ff 	mov    rcx,QWORD PTR [rbp-0x240]
   13727:	31 f6                	xor    esi,esi
   13729:	48 89 ca             	mov    rdx,rcx
   1372c:	4c 89 e7             	mov    rdi,r12
   1372f:	e8 00 00 00 00       	call   13734 <try_secant_tail.constprop.0+0x12a4>
   13734:	48 8b 85 f8 fd ff ff 	mov    rax,QWORD PTR [rbp-0x208]
   1373b:	31 c9                	xor    ecx,ecx
   1373d:	31 d2                	xor    edx,edx
   1373f:	44 8b 85 a0 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x160]
   13746:	4c 89 65 90          	mov    QWORD PTR [rbp-0x70],r12
   1374a:	48 8d 3d 7f 13 ff ff 	lea    rdi,[rip+0xffffffffffff137f]        # 4ad0 <try_secant_tail._omp_fn.0>
   13751:	48 89 85 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],rax
   13758:	48 8b 05 00 00 00 00 	mov    rax,QWORD PTR [rip+0x0]        # 1375f <try_secant_tail.constprop.0+0x12cf>
   1375f:	c5 f9 6f ad a0 fd ff 	vmovdqa xmm5,XMMWORD PTR [rbp-0x260]
   13766:	ff 
   13767:	c5 f9 28 8d 80 fe ff 	vmovapd xmm1,XMMWORD PTR [rbp-0x180]
   1376e:	ff 
   1376f:	44 89 45 a0          	mov    DWORD PTR [rbp-0x60],r8d
   13773:	48 89 85 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],rax
   1377a:	44 8b a5 d0 fe ff ff 	mov    r12d,DWORD PTR [rbp-0x130]
   13781:	c5 f9 6f b5 d0 fd ff 	vmovdqa xmm6,XMMWORD PTR [rbp-0x230]
   13788:	ff 
   13789:	48 8b 85 78 fe ff ff 	mov    rax,QWORD PTR [rbp-0x188]
   13790:	44 89 6d 9c          	mov    DWORD PTR [rbp-0x64],r13d
   13794:	48 8b b5 20 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1e0]
   1379b:	4c 89 b5 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],r14
   137a2:	44 89 65 98          	mov    DWORD PTR [rbp-0x68],r12d
   137a6:	48 89 85 60 ff ff ff 	mov    QWORD PTR [rbp-0xa0],rax
   137ad:	c5 f9 7f 6d 80       	vmovdqa XMMWORD PTR [rbp-0x80],xmm5
   137b2:	c5 f9 29 8d 70 ff ff 	vmovapd XMMWORD PTR [rbp-0x90],xmm1
   137b9:	ff 
   137ba:	c5 f9 7f b5 40 ff ff 	vmovdqa XMMWORD PTR [rbp-0xc0],xmm6
   137c1:	ff 
   137c2:	e8 00 00 00 00       	call   137c7 <try_secant_tail.constprop.0+0x1337>
   137c7:	8b b5 98 fe ff ff    	mov    esi,DWORD PTR [rbp-0x168]
   137cd:	44 8b 85 a0 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x160]
   137d4:	85 f6                	test   esi,esi
   137d6:	0f 8e 95 01 00 00    	jle    13971 <try_secant_tail.constprop.0+0x14e1>
   137dc:	45 85 e4             	test   r12d,r12d
   137df:	c5 fb 10 55 b8       	vmovsd xmm2,QWORD PTR [rbp-0x48]
   137e4:	c5 fb 10 45 b0       	vmovsd xmm0,QWORD PTR [rbp-0x50]
   137e9:	0f 8e 12 01 00 00    	jle    13901 <try_secant_tail.constprop.0+0x1471>
   137ef:	44 8b 8d 9c fd ff ff 	mov    r9d,DWORD PTR [rbp-0x264]
   137f6:	44 89 85 a0 fe ff ff 	mov    DWORD PTR [rbp-0x160],r8d
   137fd:	45 31 d2             	xor    r10d,r10d
   13800:	31 f6                	xor    esi,esi
   13802:	44 89 ad 80 fe ff ff 	mov    DWORD PTR [rbp-0x180],r13d
   13809:	4c 8b 9d 70 fe ff ff 	mov    r11,QWORD PTR [rbp-0x190]
   13810:	44 89 c8             	mov    eax,r9d
   13813:	89 9d 5c fe ff ff    	mov    DWORD PTR [rbp-0x1a4],ebx
   13819:	4c 8b ad b0 fd ff ff 	mov    r13,QWORD PTR [rbp-0x250]
   13820:	4c 89 b5 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r14
   13827:	c1 e8 02             	shr    eax,0x2
   1382a:	8b 9d 98 fd ff ff    	mov    ebx,DWORD PTR [rbp-0x268]
   13830:	44 8b b5 98 fe ff ff 	mov    r14d,DWORD PTR [rbp-0x168]
   13837:	48 c1 e0 05          	shl    rax,0x5
   1383b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   13840:	81 fb fb ff ff 7f    	cmp    ebx,0x7ffffffb
   13846:	4c 8d 04 f5 00 00 00 	lea    r8,[rsi*8+0x0]
   1384d:	00 
   1384e:	0f 87 54 02 00 00    	ja     13aa8 <try_secant_tail.constprop.0+0x1618>
   13854:	4b 8d 0c 03          	lea    rcx,[r11+r8*1]
   13858:	31 d2                	xor    edx,edx
   1385a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   13860:	c5 fd 10 0c 11       	vmovupd ymm1,YMMWORD PTR [rcx+rdx*1]
   13865:	c4 c1 75 58 0c 17    	vaddpd ymm1,ymm1,YMMWORD PTR [r15+rdx*1]
   1386b:	c4 c1 7d 11 0c 17    	vmovupd YMMWORD PTR [r15+rdx*1],ymm1
   13871:	48 83 c2 20          	add    rdx,0x20
   13875:	48 39 d0             	cmp    rax,rdx
   13878:	75 e6                	jne    13860 <try_secant_tail.constprop.0+0x13d0>
   1387a:	41 f6 c1 03          	test   r9b,0x3
   1387e:	0f 84 6c 01 00 00    	je     139f0 <try_secant_tail.constprop.0+0x1560>
   13884:	44 89 ca             	mov    edx,r9d
   13887:	83 e2 fc             	and    edx,0xfffffffc
   1388a:	89 d1                	mov    ecx,edx
   1388c:	44 89 cf             	mov    edi,r9d
   1388f:	29 d7                	sub    edi,edx
   13891:	83 ff 01             	cmp    edi,0x1
   13894:	74 24                	je     138ba <try_secant_tail.constprop.0+0x142a>
   13896:	4d 8d 24 d7          	lea    r12,[r15+rdx*8]
   1389a:	48 01 f2             	add    rdx,rsi
   1389d:	40 f6 c7 01          	test   dil,0x1
   138a1:	c4 c1 79 10 0c 24    	vmovupd xmm1,XMMWORD PTR [r12]
   138a7:	c4 c1 71 58 0c d3    	vaddpd xmm1,xmm1,XMMWORD PTR [r11+rdx*8]
   138ad:	c4 c1 79 11 0c 24    	vmovupd XMMWORD PTR [r12],xmm1
   138b3:	74 21                	je     138d6 <try_secant_tail.constprop.0+0x1446>
   138b5:	83 e7 fe             	and    edi,0xfffffffe
   138b8:	01 f9                	add    ecx,edi
   138ba:	48 63 c9             	movsxd rcx,ecx
   138bd:	4d 01 d8             	add    r8,r11
   138c0:	48 c1 e1 03          	shl    rcx,0x3
   138c4:	c4 c1 7b 10 0c 0f    	vmovsd xmm1,QWORD PTR [r15+rcx*1]
   138ca:	c4 c1 73 58 0c 08    	vaddsd xmm1,xmm1,QWORD PTR [r8+rcx*1]
   138d0:	c4 c1 7b 11 0c 0f    	vmovsd QWORD PTR [r15+rcx*1],xmm1
   138d6:	41 83 c2 01          	add    r10d,0x1
   138da:	4c 01 ee             	add    rsi,r13
   138dd:	45 39 d6             	cmp    r14d,r10d
   138e0:	0f 85 5a ff ff ff    	jne    13840 <try_secant_tail.constprop.0+0x13b0>
   138e6:	44 8b 85 a0 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x160]
   138ed:	44 8b ad 80 fe ff ff 	mov    r13d,DWORD PTR [rbp-0x180]
   138f4:	8b 9d 5c fe ff ff    	mov    ebx,DWORD PTR [rbp-0x1a4]
   138fa:	4c 8b b5 40 fe ff ff 	mov    r14,QWORD PTR [rbp-0x1c0]
   13901:	8b 95 98 fe ff ff    	mov    edx,DWORD PTR [rbp-0x168]
   13907:	48 8b b5 68 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x198]
   1390e:	c5 f9 14 c2          	vunpcklpd xmm0,xmm0,xmm2
   13912:	c5 f9 28 c0          	vmovapd xmm0,xmm0
   13916:	d1 ea                	shr    edx,1
   13918:	48 89 f0             	mov    rax,rsi
   1391b:	48 c1 e2 05          	shl    rdx,0x5
   1391f:	48 01 f2             	add    rdx,rsi
   13922:	0f 1f 00             	nop    DWORD PTR [rax]
   13925:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   1392c:	00 00 00 00 
   13930:	c5 fd 58 00          	vaddpd ymm0,ymm0,YMMWORD PTR [rax]
   13934:	48 83 c0 20          	add    rax,0x20
   13938:	48 39 d0             	cmp    rax,rdx
   1393b:	75 f3                	jne    13930 <try_secant_tail.constprop.0+0x14a0>
   1393d:	8b b5 98 fe ff ff    	mov    esi,DWORD PTR [rbp-0x168]
   13943:	c5 f9 28 c8          	vmovapd xmm1,xmm0
   13947:	c4 e3 7d 19 c0 01    	vextractf128 xmm0,ymm0,0x1
   1394d:	c5 f1 58 c0          	vaddpd xmm0,xmm1,xmm0
   13951:	40 f6 c6 01          	test   sil,0x1
   13955:	74 15                	je     1396c <try_secant_tail.constprop.0+0x14dc>
   13957:	89 f0                	mov    eax,esi
   13959:	48 8b bd 68 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x198]
   13960:	83 e0 fe             	and    eax,0xfffffffe
   13963:	48 c1 e0 04          	shl    rax,0x4
   13967:	c5 f9 58 04 07       	vaddpd xmm0,xmm0,XMMWORD PTR [rdi+rax*1]
   1396c:	c5 f9 29 45 b0       	vmovapd XMMWORD PTR [rbp-0x50],xmm0
   13971:	45 85 c0             	test   r8d,r8d
   13974:	0f 8e 96 09 00 00    	jle    14310 <try_secant_tail.constprop.0+0x1e80>
   1397a:	8b b5 58 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1a8]
   13980:	ba 2f 00 00 00       	mov    edx,0x2f
   13985:	41 8d 48 ff          	lea    ecx,[r8-0x1]
   13989:	8d 46 20             	lea    eax,[rsi+0x20]
   1398c:	39 d0                	cmp    eax,edx
   1398e:	0f 42 c2             	cmovb  eax,edx
   13991:	39 c1                	cmp    ecx,eax
   13993:	0f 82 eb 00 00 00    	jb     13a84 <try_secant_tail.constprop.0+0x15f4>
   13999:	85 f6                	test   esi,esi
   1399b:	89 f2                	mov    edx,esi
   1399d:	74 6e                	je     13a0d <try_secant_tail.constprop.0+0x157d>
   1399f:	48 8b 85 a8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x158]
   139a6:	89 f1                	mov    ecx,esi
   139a8:	eb 11                	jmp    139bb <try_secant_tail.constprop.0+0x152b>
   139aa:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   139b0:	83 c3 01             	add    ebx,0x1
   139b3:	48 83 c0 01          	add    rax,0x1
   139b7:	39 da                	cmp    edx,ebx
   139b9:	74 54                	je     13a0f <try_secant_tail.constprop.0+0x157f>
   139bb:	80 38 00             	cmp    BYTE PTR [rax],0x0
   139be:	74 f0                	je     139b0 <try_secant_tail.constprop.0+0x1520>
   139c0:	41 01 dd             	add    r13d,ebx
   139c3:	48 8b bd 00 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x200]
   139ca:	48 8b 9d b0 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x150]
   139d1:	49 63 c5             	movsxd rax,r13d
   139d4:	48 0f af f8          	imul   rdi,rax
   139d8:	48 03 bd b8 fe ff ff 	add    rdi,QWORD PTR [rbp-0x148]
   139df:	48 8d 14 c3          	lea    rdx,[rbx+rax*8]
   139e3:	c5 f8 77             	vzeroupper
   139e6:	e9 c8 f5 ff ff       	jmp    12fb3 <try_secant_tail.constprop.0+0xb23>
   139eb:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   139f0:	41 83 c2 01          	add    r10d,0x1
   139f4:	45 39 d6             	cmp    r14d,r10d
   139f7:	0f 84 e9 fe ff ff    	je     138e6 <try_secant_tail.constprop.0+0x1456>
   139fd:	4c 01 ee             	add    rsi,r13
   13a00:	4c 8d 04 f5 00 00 00 	lea    r8,[rsi*8+0x0]
   13a07:	00 
   13a08:	e9 47 fe ff ff       	jmp    13854 <try_secant_tail.constprop.0+0x13c4>
   13a0d:	31 c9                	xor    ecx,ecx
   13a0f:	44 89 c3             	mov    ebx,r8d
   13a12:	c5 f9 6e c9          	vmovd  xmm1,ecx
   13a16:	c5 e9 ef d2          	vpxor  xmm2,xmm2,xmm2
   13a1a:	be 20 00 00 00       	mov    esi,0x20
   13a1f:	8b 85 58 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1a8]
   13a25:	c5 f9 6e de          	vmovd  xmm3,esi
   13a29:	c4 e2 7d 58 c9       	vpbroadcastd ymm1,xmm1
   13a2e:	c5 f5 fe 0d 00 00 00 	vpaddd ymm1,ymm1,YMMWORD PTR [rip+0x0]        # 13a36 <try_secant_tail.constprop.0+0x15a6>
   13a35:	00 
   13a36:	c4 e2 7d 58 db       	vpbroadcastd ymm3,xmm3
   13a3b:	29 c3                	sub    ebx,eax
   13a3d:	48 03 85 a8 fe ff ff 	add    rax,QWORD PTR [rbp-0x158]
   13a44:	89 da                	mov    edx,ebx
   13a46:	c1 ea 05             	shr    edx,0x5
   13a49:	48 c1 e2 05          	shl    rdx,0x5
   13a4d:	48 01 c2             	add    rdx,rax
   13a50:	eb 1f                	jmp    13a71 <try_secant_tail.constprop.0+0x15e1>
   13a52:	0f 1f 00             	nop    DWORD PTR [rax]
   13a55:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   13a5c:	00 00 00 00 
   13a60:	48 83 c0 20          	add    rax,0x20
   13a64:	c5 f5 fe cb          	vpaddd ymm1,ymm1,ymm3
   13a68:	48 39 d0             	cmp    rax,rdx
   13a6b:	0f 84 c1 07 00 00    	je     14232 <try_secant_tail.constprop.0+0x1da2>
   13a71:	c5 ed 74 00          	vpcmpeqb ymm0,ymm2,YMMWORD PTR [rax]
   13a75:	c5 fd 74 c2          	vpcmpeqb ymm0,ymm0,ymm2
   13a79:	c4 e2 7d 17 c0       	vptest ymm0,ymm0
   13a7e:	74 e0                	je     13a60 <try_secant_tail.constprop.0+0x15d0>
   13a80:	c5 f9 7e cb          	vmovd  ebx,xmm1
   13a84:	48 8b 85 a8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x158]
   13a8b:	48 63 db             	movsxd rbx,ebx
   13a8e:	eb 0d                	jmp    13a9d <try_secant_tail.constprop.0+0x160d>
   13a90:	48 83 c3 01          	add    rbx,0x1
   13a94:	41 39 d8             	cmp    r8d,ebx
   13a97:	0f 8e 73 08 00 00    	jle    14310 <try_secant_tail.constprop.0+0x1e80>
   13a9d:	80 3c 18 00          	cmp    BYTE PTR [rax+rbx*1],0x0
   13aa1:	74 ed                	je     13a90 <try_secant_tail.constprop.0+0x1600>
   13aa3:	e9 18 ff ff ff       	jmp    139c0 <try_secant_tail.constprop.0+0x1530>
   13aa8:	31 c9                	xor    ecx,ecx
   13aaa:	31 d2                	xor    edx,edx
   13aac:	e9 db fd ff ff       	jmp    1388c <try_secant_tail.constprop.0+0x13fc>
   13ab1:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   13ab5:	c5 f9 2f c1          	vcomisd xmm0,xmm1
   13ab9:	76 0b                	jbe    13ac6 <try_secant_tail.constprop.0+0x1636>
   13abb:	48 c7 80 00 00 00 00 	mov    QWORD PTR [rax+0x0],0x0
   13ac2:	00 00 00 00 
   13ac6:	c5 fb 10 1d 00 00 00 	vmovsd xmm3,QWORD PTR [rip+0x0]        # 13ace <try_secant_tail.constprop.0+0x163e>
   13acd:	00 
   13ace:	c5 f9 2f d3          	vcomisd xmm2,xmm3
   13ad2:	0f 86 ae 07 00 00    	jbe    14286 <try_secant_tail.constprop.0+0x1df6>
   13ad8:	c5 f9 28 c3          	vmovapd xmm0,xmm3
   13adc:	c5 eb 5c c8          	vsubsd xmm1,xmm2,xmm0
   13ae0:	c5 f9 2f 0d 00 00 00 	vcomisd xmm1,QWORD PTR [rip+0x0]        # 13ae8 <try_secant_tail.constprop.0+0x1658>
   13ae7:	00 
   13ae8:	0f 86 7e 07 00 00    	jbe    1426c <try_secant_tail.constprop.0+0x1ddc>
   13aee:	44 8b 95 04 ff ff ff 	mov    r10d,DWORD PTR [rbp-0xfc]
   13af5:	45 39 d4             	cmp    r12d,r10d
   13af8:	0f 8e 4c f8 ff ff    	jle    1334a <try_secant_tail.constprop.0+0xeba>
   13afe:	8b 85 08 ff ff ff    	mov    eax,DWORD PTR [rbp-0xf8]
   13b04:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
   13b0b:	41 39 c2             	cmp    r10d,eax
   13b0e:	0f 8c d5 00 00 00    	jl     13be9 <try_secant_tail.constprop.0+0x1759>
   13b14:	dd d8                	fstp   st(0)
   13b16:	83 f8 07             	cmp    eax,0x7
   13b19:	48 63 8d 00 ff ff ff 	movsxd rcx,DWORD PTR [rbp-0x100]
   13b20:	0f 8e 5e 0b 00 00    	jle    14684 <try_secant_tail.constprop.0+0x21f4>
   13b26:	85 c9                	test   ecx,ecx
   13b28:	8d 51 03             	lea    edx,[rcx+0x3]
   13b2b:	8d 34 85 00 00 00 00 	lea    esi,[rax*4+0x0]
   13b32:	0f 49 d1             	cmovns edx,ecx
   13b35:	c1 fa 02             	sar    edx,0x2
   13b38:	39 d0                	cmp    eax,edx
   13b3a:	0f 4f f1             	cmovg  esi,ecx
   13b3d:	41 89 f0             	mov    r8d,esi
   13b40:	44 39 c0             	cmp    eax,r8d
   13b43:	0f 8d b5 08 00 00    	jge    143fe <try_secant_tail.constprop.0+0x1f6e>
   13b49:	48 b8 ff ff ff ff ff 	movabs rax,0x1fffffffffffffff
   13b50:	ff ff 1f 
   13b53:	31 d2                	xor    edx,edx
   13b55:	49 63 f0             	movsxd rsi,r8d
   13b58:	48 f7 f1             	div    rcx
   13b5b:	48 39 f0             	cmp    rax,rsi
   13b5e:	0f 82 9a 08 00 00    	jb     143fe <try_secant_tail.constprop.0+0x1f6e>
   13b64:	48 0f af f1          	imul   rsi,rcx
   13b68:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
   13b6f:	44 89 85 a0 fe ff ff 	mov    DWORD PTR [rbp-0x160],r8d
   13b76:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   13b7d:	4c 89 9d 30 fe ff ff 	mov    QWORD PTR [rbp-0x1d0],r11
   13b84:	48 c1 e6 03          	shl    rsi,0x3
   13b88:	c5 fb 11 95 40 fe ff 	vmovsd QWORD PTR [rbp-0x1c0],xmm2
   13b8f:	ff 
   13b90:	c5 fb 11 9d 38 fe ff 	vmovsd QWORD PTR [rbp-0x1c8],xmm3
   13b97:	ff 
   13b98:	e8 00 00 00 00       	call   13b9d <try_secant_tail.constprop.0+0x170d>
   13b9d:	48 85 c0             	test   rax,rax
   13ba0:	48 89 c7             	mov    rdi,rax
   13ba3:	0f 84 55 08 00 00    	je     143fe <try_secant_tail.constprop.0+0x1f6e>
   13ba9:	44 8b 85 a0 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x160]
   13bb0:	48 89 85 10 ff ff ff 	mov    QWORD PTR [rbp-0xf0],rax
   13bb7:	db ad 30 ff ff ff    	fld    TBYTE PTR [rbp-0xd0]
   13bbd:	44 8b 95 04 ff ff ff 	mov    r10d,DWORD PTR [rbp-0xfc]
   13bc4:	4c 8b 9d 30 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1d0]
   13bcb:	44 89 85 08 ff ff ff 	mov    DWORD PTR [rbp-0xf8],r8d
   13bd2:	c5 fb 10 9d 38 fe ff 	vmovsd xmm3,QWORD PTR [rbp-0x1c8]
   13bd9:	ff 
   13bda:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   13be1:	c5 fb 10 95 40 fe ff 	vmovsd xmm2,QWORD PTR [rbp-0x1c0]
   13be8:	ff 
   13be9:	49 63 c2             	movsxd rax,r10d
   13bec:	48 0f af 85 28 fe ff 	imul   rax,QWORD PTR [rbp-0x1d8]
   13bf3:	ff 
   13bf4:	45 85 e4             	test   r12d,r12d
   13bf7:	4c 8d 04 c5 00 00 00 	lea    r8,[rax*8+0x0]
   13bfe:	00 
   13bff:	48 89 85 a0 fe ff ff 	mov    QWORD PTR [rbp-0x160],rax
   13c06:	4a 8d 04 07          	lea    rax,[rdi+r8*1]
   13c0a:	0f 8e d4 00 00 00    	jle    13ce4 <try_secant_tail.constprop.0+0x1854>
   13c10:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # 13c18 <try_secant_tail.constprop.0+0x1788>
   13c17:	00 
   13c18:	41 83 fc 01          	cmp    r12d,0x1
   13c1c:	c5 d3 5e e2          	vdivsd xmm4,xmm5,xmm2
   13c20:	0f 84 59 11 00 00    	je     14d7f <try_secant_tail.constprop.0+0x28ef>
   13c26:	48 8b 9d 18 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1e8]
   13c2d:	48 89 c2             	mov    rdx,rax
   13c30:	49 8d 4c 1b 08       	lea    rcx,[r11+rbx*1+0x8]
   13c35:	48 29 ca             	sub    rdx,rcx
   13c38:	48 83 fa 10          	cmp    rdx,0x10
   13c3c:	0f 86 19 13 00 00    	jbe    14f5b <try_secant_tail.constprop.0+0x2acb>
   13c42:	41 8d 54 24 ff       	lea    edx,[r12-0x1]
   13c47:	44 89 e6             	mov    esi,r12d
   13c4a:	83 fa 02             	cmp    edx,0x2
   13c4d:	0f 86 74 13 00 00    	jbe    14fc7 <try_secant_tail.constprop.0+0x2b37>
   13c53:	44 89 e1             	mov    ecx,r12d
   13c56:	c4 e2 7d 19 cc       	vbroadcastsd ymm1,xmm4
   13c5b:	31 d2                	xor    edx,edx
   13c5d:	c1 e9 02             	shr    ecx,0x2
   13c60:	48 c1 e1 05          	shl    rcx,0x5
   13c64:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   13c6a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   13c71:	00 00 00 00 
   13c75:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   13c7c:	00 00 00 00 
   13c80:	c4 c1 75 59 04 11    	vmulpd ymm0,ymm1,YMMWORD PTR [r9+rdx*1]
   13c86:	c5 fd 11 04 10       	vmovupd YMMWORD PTR [rax+rdx*1],ymm0
   13c8b:	48 83 c2 20          	add    rdx,0x20
   13c8f:	48 39 d1             	cmp    rcx,rdx
   13c92:	75 ec                	jne    13c80 <try_secant_tail.constprop.0+0x17f0>
   13c94:	44 89 e2             	mov    edx,r12d
   13c97:	83 e2 fc             	and    edx,0xfffffffc
   13c9a:	41 39 d4             	cmp    r12d,edx
   13c9d:	89 d1                	mov    ecx,edx
   13c9f:	74 43                	je     13ce4 <try_secant_tail.constprop.0+0x1854>
   13ca1:	44 89 e6             	mov    esi,r12d
   13ca4:	29 d6                	sub    esi,edx
   13ca6:	83 fe 01             	cmp    esi,0x1
   13ca9:	74 2b                	je     13cd6 <try_secant_tail.constprop.0+0x1846>
   13cab:	48 8b 9d 28 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1d8]
   13cb2:	c5 fb 12 c4          	vmovddup xmm0,xmm4
   13cb6:	48 01 cb             	add    rbx,rcx
   13cb9:	48 03 8d a0 fe ff ff 	add    rcx,QWORD PTR [rbp-0x160]
   13cc0:	40 f6 c6 01          	test   sil,0x1
   13cc4:	c4 c1 79 59 04 db    	vmulpd xmm0,xmm0,XMMWORD PTR [r11+rbx*8]
   13cca:	c5 f9 11 04 cf       	vmovupd XMMWORD PTR [rdi+rcx*8],xmm0
   13ccf:	74 13                	je     13ce4 <try_secant_tail.constprop.0+0x1854>
   13cd1:	83 e6 fe             	and    esi,0xfffffffe
   13cd4:	01 f2                	add    edx,esi
   13cd6:	48 63 d2             	movsxd rdx,edx
   13cd9:	c4 c1 5b 59 24 d1    	vmulsd xmm4,xmm4,QWORD PTR [r9+rdx*8]
   13cdf:	c5 fb 11 24 d0       	vmovsd QWORD PTR [rax+rdx*8],xmm4
   13ce4:	41 83 fa 5f          	cmp    r10d,0x5f
   13ce8:	44 8b 9d 00 ff ff ff 	mov    r11d,DWORD PTR [rbp-0x100]
   13cef:	0f 8e d3 0a 00 00    	jle    147c8 <try_secant_tail.constprop.0+0x2338>
   13cf5:	d9 ee                	fldz
   13cf7:	d9 c9                	fxch   st(1)
   13cf9:	db f1                	fcomi  st,st(1)
   13cfb:	dd d9                	fstp   st(1)
   13cfd:	0f 86 f3 09 00 00    	jbe    146f6 <try_secant_tail.constprop.0+0x2266>
   13d03:	d9 c0                	fld    st(0)
   13d05:	c5 eb 58 05 00 00 00 	vaddsd xmm0,xmm2,QWORD PTR [rip+0x0]        # 13d0d <try_secant_tail.constprop.0+0x187d>
   13d0c:	00 
   13d0d:	c5 fb 10 ad c8 fd ff 	vmovsd xmm5,QWORD PTR [rbp-0x238]
   13d14:	ff 
   13d15:	d9 fa                	fsqrt
   13d17:	c5 d3 5e c0          	vdivsd xmm0,xmm5,xmm0
   13d1b:	dd 9d c0 fe ff ff    	fstp   QWORD PTR [rbp-0x140]
   13d21:	c5 fb 10 8d c0 fe ff 	vmovsd xmm1,QWORD PTR [rbp-0x140]
   13d28:	ff 
   13d29:	c4 e2 e1 99 c8       	vfmadd132sd xmm1,xmm3,xmm0
   13d2e:	c5 fb 11 8d c0 fe ff 	vmovsd QWORD PTR [rbp-0x140],xmm1
   13d35:	ff 
   13d36:	dd 85 c0 fe ff ff    	fld    QWORD PTR [rbp-0x140]
   13d3c:	d8 c8                	fmul   st,st(0)
   13d3e:	d8 c0                	fadd   st,st(0)
   13d40:	45 85 db             	test   r11d,r11d
   13d43:	0f 8e 05 12 00 00    	jle    14f4e <try_secant_tail.constprop.0+0x2abe>
   13d49:	41 8d 53 ff          	lea    edx,[r11-0x1]
   13d4d:	83 fa 02             	cmp    edx,0x2
   13d50:	0f 86 4f 12 00 00    	jbe    14fa5 <try_secant_tail.constprop.0+0x2b15>
   13d56:	44 89 d9             	mov    ecx,r11d
   13d59:	48 89 c2             	mov    rdx,rax
   13d5c:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   13d60:	c1 e9 02             	shr    ecx,0x2
   13d63:	48 c1 e1 05          	shl    rcx,0x5
   13d67:	48 01 c1             	add    rcx,rax
   13d6a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   13d71:	00 00 00 00 
   13d75:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   13d7c:	00 00 00 00 
   13d80:	c5 fd 10 02          	vmovupd ymm0,YMMWORD PTR [rdx]
   13d84:	48 83 c2 20          	add    rdx,0x20
   13d88:	48 39 ca             	cmp    rdx,rcx
   13d8b:	c5 fd 59 c0          	vmulpd ymm0,ymm0,ymm0
   13d8f:	c5 f5 58 c8          	vaddpd ymm1,ymm1,ymm0
   13d93:	75 eb                	jne    13d80 <try_secant_tail.constprop.0+0x18f0>
   13d95:	c4 e3 7d 19 c8 01    	vextractf128 xmm0,ymm1,0x1
   13d9b:	44 89 da             	mov    edx,r11d
   13d9e:	c5 f9 58 c9          	vaddpd xmm1,xmm0,xmm1
   13da2:	83 e2 fc             	and    edx,0xfffffffc
   13da5:	41 39 d3             	cmp    r11d,edx
   13da8:	89 d1                	mov    ecx,edx
   13daa:	c5 f1 15 c1          	vunpckhpd xmm0,xmm1,xmm1
   13dae:	c5 f9 58 c1          	vaddpd xmm0,xmm0,xmm1
   13db2:	74 3b                	je     13def <try_secant_tail.constprop.0+0x195f>
   13db4:	44 89 de             	mov    esi,r11d
   13db7:	29 ce                	sub    esi,ecx
   13db9:	83 fe 01             	cmp    esi,0x1
   13dbc:	74 24                	je     13de2 <try_secant_tail.constprop.0+0x1952>
   13dbe:	48 03 8d a0 fe ff ff 	add    rcx,QWORD PTR [rbp-0x160]
   13dc5:	40 f6 c6 01          	test   sil,0x1
   13dc9:	c5 f9 10 04 cf       	vmovupd xmm0,XMMWORD PTR [rdi+rcx*8]
   13dce:	c4 e2 f9 b8 c8       	vfmadd231pd xmm1,xmm0,xmm0
   13dd3:	c5 f1 15 c1          	vunpckhpd xmm0,xmm1,xmm1
   13dd7:	c5 f9 58 c1          	vaddpd xmm0,xmm0,xmm1
   13ddb:	74 12                	je     13def <try_secant_tail.constprop.0+0x195f>
   13ddd:	83 e6 fe             	and    esi,0xfffffffe
   13de0:	01 f2                	add    edx,esi
   13de2:	48 63 d2             	movsxd rdx,edx
   13de5:	c5 fb 10 0c d0       	vmovsd xmm1,QWORD PTR [rax+rdx*8]
   13dea:	c4 e2 f1 b9 c1       	vfmadd231sd xmm0,xmm1,xmm1
   13def:	c5 fb 5c 05 00 00 00 	vsubsd xmm0,xmm0,QWORD PTR [rip+0x0]        # 13df7 <try_secant_tail.constprop.0+0x1967>
   13df6:	00 
   13df7:	c5 f9 54 05 00 00 00 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x0]        # 13dff <try_secant_tail.constprop.0+0x196f>
   13dfe:	00 
   13dff:	c5 fb 58 f3          	vaddsd xmm6,xmm0,xmm3
   13e03:	c5 fb 11 b5 c0 fe ff 	vmovsd QWORD PTR [rbp-0x140],xmm6
   13e0a:	ff 
   13e0b:	dd 85 c0 fe ff ff    	fld    QWORD PTR [rbp-0x140]
   13e11:	d8 c8                	fmul   st,st(0)
   13e13:	d9 ca                	fxch   st(2)
   13e15:	de c1                	faddp  st(1),st
   13e17:	de c1                	faddp  st(1),st
   13e19:	45 85 e4             	test   r12d,r12d
   13e1c:	db bd 30 ff ff ff    	fstp   TBYTE PTR [rbp-0xd0]
   13e22:	0f 8e d6 00 00 00    	jle    13efe <try_secant_tail.constprop.0+0x1a6e>
   13e28:	c5 fb 10 b5 08 fe ff 	vmovsd xmm6,QWORD PTR [rbp-0x1f8]
   13e2f:	ff 
   13e30:	41 83 fc 01          	cmp    r12d,0x1
   13e34:	48 8b 8d 18 ff ff ff 	mov    rcx,QWORD PTR [rbp-0xe8]
   13e3b:	c5 cb 5e d2          	vdivsd xmm2,xmm6,xmm2
   13e3f:	0f 84 8a 0b 00 00    	je     149cf <try_secant_tail.constprop.0+0x253f>
   13e45:	4a 8d 74 07 08       	lea    rsi,[rdi+r8*1+0x8]
   13e4a:	48 89 ca             	mov    rdx,rcx
   13e4d:	48 29 f2             	sub    rdx,rsi
   13e50:	48 83 fa 10          	cmp    rdx,0x10
   13e54:	0f 86 75 0b 00 00    	jbe    149cf <try_secant_tail.constprop.0+0x253f>
   13e5a:	41 8d 54 24 ff       	lea    edx,[r12-0x1]
   13e5f:	44 89 e6             	mov    esi,r12d
   13e62:	83 fa 02             	cmp    edx,0x2
   13e65:	0f 86 55 11 00 00    	jbe    14fc0 <try_secant_tail.constprop.0+0x2b30>
   13e6b:	c1 ee 02             	shr    esi,0x2
   13e6e:	c4 e2 7d 19 ca       	vbroadcastsd ymm1,xmm2
   13e73:	31 d2                	xor    edx,edx
   13e75:	48 c1 e6 05          	shl    rsi,0x5
   13e79:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   13e80:	c5 fd 10 04 10       	vmovupd ymm0,YMMWORD PTR [rax+rdx*1]
   13e85:	c4 e2 f5 a8 04 11    	vfmadd213pd ymm0,ymm1,YMMWORD PTR [rcx+rdx*1]
   13e8b:	c5 fd 11 04 11       	vmovupd YMMWORD PTR [rcx+rdx*1],ymm0
   13e90:	48 83 c2 20          	add    rdx,0x20
   13e94:	48 39 f2             	cmp    rdx,rsi
   13e97:	75 e7                	jne    13e80 <try_secant_tail.constprop.0+0x19f0>
   13e99:	44 89 e3             	mov    ebx,r12d
   13e9c:	83 e3 fc             	and    ebx,0xfffffffc
   13e9f:	44 39 e3             	cmp    ebx,r12d
   13ea2:	89 9d 80 fe ff ff    	mov    DWORD PTR [rbp-0x180],ebx
   13ea8:	89 da                	mov    edx,ebx
   13eaa:	74 52                	je     13efe <try_secant_tail.constprop.0+0x1a6e>
   13eac:	44 89 e6             	mov    esi,r12d
   13eaf:	29 de                	sub    esi,ebx
   13eb1:	83 fe 01             	cmp    esi,0x1
   13eb4:	74 31                	je     13ee7 <try_secant_tail.constprop.0+0x1a57>
   13eb6:	48 8b 9d a0 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x160]
   13ebd:	4c 8d 04 d1          	lea    r8,[rcx+rdx*8]
   13ec1:	c5 fb 12 c2          	vmovddup xmm0,xmm2
   13ec5:	c4 c1 79 10 30       	vmovupd xmm6,XMMWORD PTR [r8]
   13eca:	48 01 da             	add    rdx,rbx
   13ecd:	40 f6 c6 01          	test   sil,0x1
   13ed1:	c4 e2 c9 98 04 d7    	vfmadd132pd xmm0,xmm6,XMMWORD PTR [rdi+rdx*8]
   13ed7:	c4 c1 79 11 00       	vmovupd XMMWORD PTR [r8],xmm0
   13edc:	74 20                	je     13efe <try_secant_tail.constprop.0+0x1a6e>
   13ede:	83 e6 fe             	and    esi,0xfffffffe
   13ee1:	01 b5 80 fe ff ff    	add    DWORD PTR [rbp-0x180],esi
   13ee7:	48 63 b5 80 fe ff ff 	movsxd rsi,DWORD PTR [rbp-0x180]
   13eee:	c5 fb 10 3c f1       	vmovsd xmm7,QWORD PTR [rcx+rsi*8]
   13ef3:	c4 e2 c1 99 14 f0    	vfmadd132sd xmm2,xmm7,QWORD PTR [rax+rsi*8]
   13ef9:	c5 fb 11 14 f1       	vmovsd QWORD PTR [rcx+rsi*8],xmm2
   13efe:	41 8d 42 01          	lea    eax,[r10+0x1]
   13f02:	89 85 04 ff ff ff    	mov    DWORD PTR [rbp-0xfc],eax
   13f08:	8b 85 0c ff ff ff    	mov    eax,DWORD PTR [rbp-0xf4]
   13f0e:	85 c0                	test   eax,eax
   13f10:	89 85 c0 fe ff ff    	mov    DWORD PTR [rbp-0x140],eax
   13f16:	0f 85 21 ed ff ff    	jne    12c3d <try_secant_tail.constprop.0+0x7ad>
   13f1c:	48 8b 15 00 00 00 00 	mov    rdx,QWORD PTR [rip+0x0]        # 13f23 <try_secant_tail.constprop.0+0x1a93>
   13f23:	c4 e1 f9 6e f2       	vmovq  xmm6,rdx
   13f28:	c5 cb 58 2d 00 00 00 	vaddsd xmm5,xmm6,QWORD PTR [rip+0x0]        # 13f30 <try_secant_tail.constprop.0+0x1aa0>
   13f2f:	00 
   13f30:	48 89 d0             	mov    rax,rdx
   13f33:	c4 e1 f9 7e e9       	vmovq  rcx,xmm5
   13f38:	f0 48 0f b1 0d 00 00 	lock cmpxchg QWORD PTR [rip+0x0],rcx        # 13f41 <try_secant_tail.constprop.0+0x1ab1>
   13f3f:	00 00 
   13f41:	0f 85 4a 12 00 00    	jne    15191 <try_secant_tail.constprop.0+0x2d01>
   13f47:	8b 85 d0 fe ff ff    	mov    eax,DWORD PTR [rbp-0x130]
   13f4d:	3b 85 04 ff ff ff    	cmp    eax,DWORD PTR [rbp-0xfc]
   13f53:	0f 84 e4 ec ff ff    	je     12c3d <try_secant_tail.constprop.0+0x7ad>
   13f59:	41 89 c1             	mov    r9d,eax
   13f5c:	8b 85 90 fd ff ff    	mov    eax,DWORD PTR [rbp-0x270]
   13f62:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   13f69:	41 ba 02 00 00 00    	mov    r10d,0x2
   13f6f:	44 89 ce             	mov    esi,r9d
   13f72:	45 89 cc             	mov    r12d,r9d
   13f75:	83 c0 01             	add    eax,0x1
   13f78:	89 85 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],eax
   13f7e:	c5 f8 77             	vzeroupper
   13f81:	e8 ba c2 fe ff       	call   240 <norm2>
   13f86:	48 63 85 5c fe ff ff 	movsxd rax,DWORD PTR [rbp-0x1a4]
   13f8d:	48 0f af 85 f0 fe ff 	imul   rax,QWORD PTR [rbp-0x110]
   13f94:	ff 
   13f95:	4c 8b 9d 10 ff ff ff 	mov    r11,QWORD PTR [rbp-0xf0]
   13f9c:	c5 fb 10 2d 00 00 00 	vmovsd xmm5,QWORD PTR [rip+0x0]        # 13fa4 <try_secant_tail.constprop.0+0x1b14>
   13fa3:	00 
   13fa4:	44 89 ad 5c fe ff ff 	mov    DWORD PTR [rbp-0x1a4],r13d
   13fab:	4c 89 bd 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r15
   13fb2:	45 31 ff             	xor    r15d,r15d
   13fb5:	48 89 85 a0 fe ff ff 	mov    QWORD PTR [rbp-0x160],rax
   13fbc:	49 8d 1c c3          	lea    rbx,[r11+rax*8]
   13fc0:	4c 89 f0             	mov    rax,r14
   13fc3:	4c 29 d8             	sub    rax,r11
   13fc6:	c5 fb 11 85 60 fe ff 	vmovsd QWORD PTR [rbp-0x1a0],xmm0
   13fcd:	ff 
   13fce:	c5 fb 11 ad 80 fe ff 	vmovsd QWORD PTR [rbp-0x180],xmm5
   13fd5:	ff 
   13fd6:	4c 8d 68 f8          	lea    r13,[rax-0x8]
   13fda:	4b 8d 3c fe          	lea    rdi,[r14+r15*8]
   13fde:	45 85 e4             	test   r12d,r12d
   13fe1:	49 89 f9             	mov    r9,rdi
   13fe4:	0f 8e 4e 03 00 00    	jle    14338 <try_secant_tail.constprop.0+0x1ea8>
   13fea:	45 89 e0             	mov    r8d,r12d
   13fed:	41 c1 e8 02          	shr    r8d,0x2
   13ff1:	49 c1 e0 05          	shl    r8,0x5
   13ff5:	83 bd 9c fe ff ff 02 	cmp    DWORD PTR [rbp-0x164],0x2
   13ffc:	0f 86 9f 0d 00 00    	jbe    14da1 <try_secant_tail.constprop.0+0x2911>
   14002:	31 c0                	xor    eax,eax
   14004:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   14008:	66 90                	xchg   ax,ax
   1400a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   14011:	00 00 00 00 
   14015:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   1401c:	00 00 00 00 
   14020:	c5 fd 10 04 07       	vmovupd ymm0,YMMWORD PTR [rdi+rax*1]
   14025:	c5 fd 59 04 03       	vmulpd ymm0,ymm0,YMMWORD PTR [rbx+rax*1]
   1402a:	48 83 c0 20          	add    rax,0x20
   1402e:	4c 39 c0             	cmp    rax,r8
   14031:	c5 f5 58 c8          	vaddpd ymm1,ymm1,ymm0
   14035:	75 e9                	jne    14020 <try_secant_tail.constprop.0+0x1b90>
   14037:	c4 e3 7d 19 c8 01    	vextractf128 xmm0,ymm1,0x1
   1403d:	44 89 e2             	mov    edx,r12d
   14040:	c5 f9 58 c1          	vaddpd xmm0,xmm0,xmm1
   14044:	83 e2 fc             	and    edx,0xfffffffc
   14047:	41 39 d4             	cmp    r12d,edx
   1404a:	89 d0                	mov    eax,edx
   1404c:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   14050:	c5 f1 58 c8          	vaddpd xmm1,xmm1,xmm0
   14054:	74 4d                	je     140a3 <try_secant_tail.constprop.0+0x1c13>
   14056:	44 89 e1             	mov    ecx,r12d
   14059:	29 c1                	sub    ecx,eax
   1405b:	83 f9 01             	cmp    ecx,0x1
   1405e:	74 2b                	je     1408b <try_secant_tail.constprop.0+0x1bfb>
   14060:	48 8b b5 a0 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x160]
   14067:	48 01 c6             	add    rsi,rax
   1406a:	4c 01 f8             	add    rax,r15
   1406d:	f6 c1 01             	test   cl,0x1
   14070:	c4 c1 79 10 3c f3    	vmovupd xmm7,XMMWORD PTR [r11+rsi*8]
   14076:	c4 c2 c1 b8 04 c6    	vfmadd231pd xmm0,xmm7,XMMWORD PTR [r14+rax*8]
   1407c:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   14080:	c5 f1 58 c8          	vaddpd xmm1,xmm1,xmm0
   14084:	74 13                	je     14099 <try_secant_tail.constprop.0+0x1c09>
   14086:	83 e1 fe             	and    ecx,0xfffffffe
   14089:	01 ca                	add    edx,ecx
   1408b:	48 63 d2             	movsxd rdx,edx
   1408e:	c5 fb 10 3c d3       	vmovsd xmm7,QWORD PTR [rbx+rdx*8]
   14093:	c4 e2 c1 b9 0c d7    	vfmadd231sd xmm1,xmm7,QWORD PTR [rdi+rdx*8]
   14099:	41 83 fc 01          	cmp    r12d,0x1
   1409d:	0f 84 53 09 00 00    	je     149f6 <try_secant_tail.constprop.0+0x2566>
   140a3:	4c 89 f8             	mov    rax,r15
   140a6:	48 2b 85 a0 fe ff ff 	sub    rax,QWORD PTR [rbp-0x160]
   140ad:	49 8d 44 c5 00       	lea    rax,[r13+rax*8+0x0]
   140b2:	48 83 f8 10          	cmp    rax,0x10
   140b6:	0f 86 3a 09 00 00    	jbe    149f6 <try_secant_tail.constprop.0+0x2566>
   140bc:	83 bd 9c fe ff ff 02 	cmp    DWORD PTR [rbp-0x164],0x2
   140c3:	0f 86 d0 0e 00 00    	jbe    14f99 <try_secant_tail.constprop.0+0x2b09>
   140c9:	c4 e2 7d 19 d1       	vbroadcastsd ymm2,xmm1
   140ce:	31 c0                	xor    eax,eax
   140d0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   140d5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   140dc:	00 00 00 00 
   140e0:	c5 fd 10 04 03       	vmovupd ymm0,YMMWORD PTR [rbx+rax*1]
   140e5:	c4 e2 ed ac 04 07    	vfnmadd213pd ymm0,ymm2,YMMWORD PTR [rdi+rax*1]
   140eb:	c5 fd 11 04 07       	vmovupd YMMWORD PTR [rdi+rax*1],ymm0
   140f0:	48 83 c0 20          	add    rax,0x20
   140f4:	4c 39 c0             	cmp    rax,r8
   140f7:	75 e7                	jne    140e0 <try_secant_tail.constprop.0+0x1c50>
   140f9:	44 89 e0             	mov    eax,r12d
   140fc:	83 e0 fc             	and    eax,0xfffffffc
   140ff:	41 39 c4             	cmp    r12d,eax
   14102:	89 c2                	mov    edx,eax
   14104:	0f 84 a8 0b 00 00    	je     14cb2 <try_secant_tail.constprop.0+0x2822>
   1410a:	44 89 e1             	mov    ecx,r12d
   1410d:	29 c1                	sub    ecx,eax
   1410f:	83 f9 01             	cmp    ecx,0x1
   14112:	74 39                	je     1414d <try_secant_tail.constprop.0+0x1cbd>
   14114:	4a 8d 34 3a          	lea    rsi,[rdx+r15*1]
   14118:	48 03 95 a0 fe ff ff 	add    rdx,QWORD PTR [rbp-0x160]
   1411f:	c5 fb 12 c1          	vmovddup xmm0,xmm1
   14123:	f6 c1 01             	test   cl,0x1
   14126:	49 8d 34 f6          	lea    rsi,[r14+rsi*8]
   1412a:	48 89 b5 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rsi
   14131:	48 8b b5 50 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1b0]
   14138:	c5 f9 10 2e          	vmovupd xmm5,XMMWORD PTR [rsi]
   1413c:	c4 c2 d1 9c 04 d3    	vfnmadd132pd xmm0,xmm5,XMMWORD PTR [r11+rdx*8]
   14142:	c5 f9 11 06          	vmovupd XMMWORD PTR [rsi],xmm0
   14146:	74 17                	je     1415f <try_secant_tail.constprop.0+0x1ccf>
   14148:	83 e1 fe             	and    ecx,0xfffffffe
   1414b:	01 c8                	add    eax,ecx
   1414d:	48 98                	cdqe
   1414f:	c5 fb 10 34 c7       	vmovsd xmm6,QWORD PTR [rdi+rax*8]
   14154:	c4 e2 c9 9d 0c c3    	vfnmadd132sd xmm1,xmm6,QWORD PTR [rbx+rax*8]
   1415a:	c5 fb 11 0c c7       	vmovsd QWORD PTR [rdi+rax*8],xmm1
   1415f:	44 89 e6             	mov    esi,r12d
   14162:	c5 f8 77             	vzeroupper
   14165:	e8 d6 c0 fe ff       	call   240 <norm2>
   1416a:	c5 fb 10 b5 80 fe ff 	vmovsd xmm6,QWORD PTR [rbp-0x180]
   14171:	ff 
   14172:	c5 f9 2f f0          	vcomisd xmm6,xmm0
   14176:	0f 87 d5 01 00 00    	ja     14351 <try_secant_tail.constprop.0+0x1ec1>
   1417c:	c5 fb 10 3d 00 00 00 	vmovsd xmm7,QWORD PTR [rip+0x0]        # 14184 <try_secant_tail.constprop.0+0x1cf4>
   14183:	00 
   14184:	83 bd 9c fe ff ff 02 	cmp    DWORD PTR [rbp-0x164],0x2
   1418b:	c5 c3 5e d0          	vdivsd xmm2,xmm7,xmm0
   1418f:	0f 86 90 0e 00 00    	jbe    15025 <try_secant_tail.constprop.0+0x2b95>
   14195:	44 89 e0             	mov    eax,r12d
   14198:	c4 e2 7d 19 ca       	vbroadcastsd ymm1,xmm2
   1419d:	c1 e8 02             	shr    eax,0x2
   141a0:	48 c1 e0 05          	shl    rax,0x5
   141a4:	48 01 f8             	add    rax,rdi
   141a7:	0f 1f 00             	nop    DWORD PTR [rax]
   141aa:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   141b1:	00 00 00 00 
   141b5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   141bc:	00 00 00 00 
   141c0:	c5 f5 59 07          	vmulpd ymm0,ymm1,YMMWORD PTR [rdi]
   141c4:	48 83 c7 20          	add    rdi,0x20
   141c8:	c5 fd 11 47 e0       	vmovupd YMMWORD PTR [rdi-0x20],ymm0
   141cd:	48 39 c7             	cmp    rdi,rax
   141d0:	75 ee                	jne    141c0 <try_secant_tail.constprop.0+0x1d30>
   141d2:	44 89 e2             	mov    edx,r12d
   141d5:	83 e2 fc             	and    edx,0xfffffffc
   141d8:	41 39 d4             	cmp    r12d,edx
   141db:	89 d0                	mov    eax,edx
   141dd:	74 36                	je     14215 <try_secant_tail.constprop.0+0x1d85>
   141df:	44 89 e1             	mov    ecx,r12d
   141e2:	29 c1                	sub    ecx,eax
   141e4:	83 f9 01             	cmp    ecx,0x1
   141e7:	74 1d                	je     14206 <try_secant_tail.constprop.0+0x1d76>
   141e9:	4c 01 f8             	add    rax,r15
   141ec:	c5 fb 12 c2          	vmovddup xmm0,xmm2
   141f0:	f6 c1 01             	test   cl,0x1
   141f3:	c4 c1 79 59 04 c6    	vmulpd xmm0,xmm0,XMMWORD PTR [r14+rax*8]
   141f9:	c4 c1 79 11 04 c6    	vmovupd XMMWORD PTR [r14+rax*8],xmm0
   141ff:	74 14                	je     14215 <try_secant_tail.constprop.0+0x1d85>
   14201:	83 e1 fe             	and    ecx,0xfffffffe
   14204:	01 ca                	add    edx,ecx
   14206:	48 63 d2             	movsxd rdx,edx
   14209:	c4 c1 6b 59 14 d1    	vmulsd xmm2,xmm2,QWORD PTR [r9+rdx*8]
   1420f:	c4 c1 7b 11 14 d1    	vmovsd QWORD PTR [r9+rdx*8],xmm2
   14215:	41 83 ea 01          	sub    r10d,0x1
   14219:	0f 84 9b 01 00 00    	je     143ba <try_secant_tail.constprop.0+0x1f2a>
   1421f:	4c 03 bd f0 fe ff ff 	add    r15,QWORD PTR [rbp-0x110]
   14226:	4b 8d 3c fe          	lea    rdi,[r14+r15*8]
   1422a:	49 89 f9             	mov    r9,rdi
   1422d:	e9 c3 fd ff ff       	jmp    13ff5 <try_secant_tail.constprop.0+0x1b65>
   14232:	f6 c3 1f             	test   bl,0x1f
   14235:	0f 84 d5 00 00 00    	je     14310 <try_secant_tail.constprop.0+0x1e80>
   1423b:	83 e3 e0             	and    ebx,0xffffffe0
   1423e:	01 cb                	add    ebx,ecx
   14240:	e9 3f f8 ff ff       	jmp    13a84 <try_secant_tail.constprop.0+0x15f4>
   14245:	c5 fb 58 0d 00 00 00 	vaddsd xmm1,xmm0,QWORD PTR [rip+0x0]        # 1424d <try_secant_tail.constprop.0+0x1dbd>
   1424c:	00 
   1424d:	c5 fb 10 1d 00 00 00 	vmovsd xmm3,QWORD PTR [rip+0x0]        # 14255 <try_secant_tail.constprop.0+0x1dc5>
   14254:	00 
   14255:	c5 f3 59 cb          	vmulsd xmm1,xmm1,xmm3
   14259:	c4 e2 f1 99 c0       	vfmadd132sd xmm0,xmm1,xmm0
   1425e:	c5 f9 2f d0          	vcomisd xmm2,xmm0
   14262:	0f 87 74 f8 ff ff    	ja     13adc <try_secant_tail.constprop.0+0x164c>
   14268:	dd d8                	fstp   st(0)
   1426a:	eb 02                	jmp    1426e <try_secant_tail.constprop.0+0x1dde>
   1426c:	dd d8                	fstp   st(0)
   1426e:	c5 eb 58 c0          	vaddsd xmm0,xmm2,xmm0
   14272:	c5 fb 10 0d 00 00 00 	vmovsd xmm1,QWORD PTR [rip+0x0]        # 1427a <try_secant_tail.constprop.0+0x1dea>
   14279:	00 
   1427a:	c5 f9 2f c8          	vcomisd xmm1,xmm0
   1427e:	0f 86 c8 f0 ff ff    	jbe    1334c <try_secant_tail.constprop.0+0xebc>
   14284:	eb 02                	jmp    14288 <try_secant_tail.constprop.0+0x1df8>
   14286:	dd d8                	fstp   st(0)
   14288:	c5 fb 10 b5 a0 fe ff 	vmovsd xmm6,QWORD PTR [rbp-0x160]
   1428f:	ff 
   14290:	c5 c9 54 05 00 00 00 	vandpd xmm0,xmm6,XMMWORD PTR [rip+0x0]        # 14298 <try_secant_tail.constprop.0+0x1e08>
   14297:	00 
   14298:	c5 fb 58 05 00 00 00 	vaddsd xmm0,xmm0,QWORD PTR [rip+0x0]        # 142a0 <try_secant_tail.constprop.0+0x1e10>
   1429f:	00 
   142a0:	c5 fb 58 85 f0 fd ff 	vaddsd xmm0,xmm0,QWORD PTR [rbp-0x210]
   142a7:	ff 
   142a8:	c5 fb 59 05 00 00 00 	vmulsd xmm0,xmm0,QWORD PTR [rip+0x0]        # 142b0 <try_secant_tail.constprop.0+0x1e20>
   142af:	00 
   142b0:	c5 fb 10 bd 08 fe ff 	vmovsd xmm7,QWORD PTR [rbp-0x1f8]
   142b7:	ff 
   142b8:	c5 c1 54 0d 00 00 00 	vandpd xmm1,xmm7,XMMWORD PTR [rip+0x0]        # 142c0 <try_secant_tail.constprop.0+0x1e30>
   142bf:	00 
   142c0:	c5 f9 2f c8          	vcomisd xmm1,xmm0
   142c4:	0f 86 34 01 00 00    	jbe    143fe <try_secant_tail.constprop.0+0x1f6e>
   142ca:	44 3b a5 04 ff ff ff 	cmp    r12d,DWORD PTR [rbp-0xfc]
   142d1:	0f 84 a3 0c 00 00    	je     14f7a <try_secant_tail.constprop.0+0x2aea>
   142d7:	48 8b bd 78 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x188]
   142de:	4c 89 de             	mov    rsi,r11
   142e1:	e8 8a f9 fe ff       	call   3c70 <local_dependency_svd>
   142e6:	83 f8 01             	cmp    eax,0x1
   142e9:	0f 85 5d f0 ff ff    	jne    1334c <try_secant_tail.constprop.0+0xebc>
   142ef:	c7 85 0c ff ff ff 01 	mov    DWORD PTR [rbp-0xf4],0x1
   142f6:	00 00 00 
   142f9:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 14301 <try_secant_tail.constprop.0+0x1e71>
   14300:	00 
   14301:	e9 42 e9 ff ff       	jmp    12c48 <try_secant_tail.constprop.0+0x7b8>
   14306:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
   1430d:	00 00 00 
   14310:	44 01 85 c0 fe ff ff 	add    DWORD PTR [rbp-0x140],r8d
   14317:	44 8b ad f8 fe ff ff 	mov    r13d,DWORD PTR [rbp-0x108]
   1431e:	e9 0d e9 ff ff       	jmp    12c30 <try_secant_tail.constprop.0+0x7a0>
   14323:	41 83 ea 01          	sub    r10d,0x1
   14327:	0f 84 8d 00 00 00    	je     143ba <try_secant_tail.constprop.0+0x1f2a>
   1432d:	4c 03 bd f0 fe ff ff 	add    r15,QWORD PTR [rbp-0x110]
   14334:	4f 8d 0c fe          	lea    r9,[r14+r15*8]
   14338:	44 89 e6             	mov    esi,r12d
   1433b:	4c 89 cf             	mov    rdi,r9
   1433e:	e8 fd be fe ff       	call   240 <norm2>
   14343:	c5 fb 10 b5 80 fe ff 	vmovsd xmm6,QWORD PTR [rbp-0x180]
   1434a:	ff 
   1434b:	c5 f9 2f f0          	vcomisd xmm6,xmm0
   1434f:	76 d2                	jbe    14323 <try_secant_tail.constprop.0+0x1e93>
   14351:	8b 85 90 fd ff ff    	mov    eax,DWORD PTR [rbp-0x270]
   14357:	48 8b b5 78 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x188]
   1435e:	4c 89 cf             	mov    rdi,r9
   14361:	4c 89 9d 30 fe ff ff 	mov    QWORD PTR [rbp-0x1d0],r11
   14368:	44 89 95 50 fe ff ff 	mov    DWORD PTR [rbp-0x1b0],r10d
   1436f:	8d 14 c5 00 00 00 00 	lea    edx,[rax*8+0x0]
   14376:	29 c2                	sub    edx,eax
   14378:	48 b8 03 ed 92 d1 32 	movabs rax,0xd1b54a32d192ed03
   1437f:	4a b5 d1 
   14382:	83 c2 0a             	add    edx,0xa
   14385:	44 29 d2             	sub    edx,r10d
   14388:	48 63 d2             	movsxd rdx,edx
   1438b:	48 0f af d0          	imul   rdx,rax
   1438f:	48 03 95 78 fd ff ff 	add    rdx,QWORD PTR [rbp-0x288]
   14396:	e8 05 f7 fe ff       	call   3aa0 <secant_refresh>
   1439b:	44 8b 95 50 fe ff ff 	mov    r10d,DWORD PTR [rbp-0x1b0]
   143a2:	4c 03 bd f0 fe ff ff 	add    r15,QWORD PTR [rbp-0x110]
   143a9:	4c 8b 9d 30 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1d0]
   143b0:	41 83 ea 01          	sub    r10d,0x1
   143b4:	0f 85 20 fc ff ff    	jne    13fda <try_secant_tail.constprop.0+0x1b4a>
   143ba:	8b 85 38 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1c8]
   143c0:	44 8b ad 5c fe ff ff 	mov    r13d,DWORD PTR [rbp-0x1a4]
   143c7:	4c 8b bd 40 fe ff ff 	mov    r15,QWORD PTR [rbp-0x1c0]
   143ce:	89 85 90 fd ff ff    	mov    DWORD PTR [rbp-0x270],eax
   143d4:	e9 63 ec ff ff       	jmp    1303c <try_secant_tail.constprop.0+0xbac>
   143d9:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
   143dd:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
   143e1:	31 d2                	xor    edx,edx
   143e3:	31 c9                	xor    ecx,ecx
   143e5:	c5 f9 28 ef          	vmovapd xmm5,xmm7
   143e9:	c5 f9 28 df          	vmovapd xmm3,xmm7
   143ed:	c5 f9 28 d7          	vmovapd xmm2,xmm7
   143f1:	c5 f9 28 f7          	vmovapd xmm6,xmm7
   143f5:	c5 f9 28 c4          	vmovapd xmm0,xmm4
   143f9:	e9 c8 e6 ff ff       	jmp    12ac6 <try_secant_tail.constprop.0+0x636>
   143fe:	8b 85 0c ff ff ff    	mov    eax,DWORD PTR [rbp-0xf4]
   14404:	85 c0                	test   eax,eax
   14406:	0f 84 29 ec ff ff    	je     13035 <try_secant_tail.constprop.0+0xba5>
   1440c:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 14414 <try_secant_tail.constprop.0+0x1f84>
   14413:	00 
   14414:	e9 2f e8 ff ff       	jmp    12c48 <try_secant_tail.constprop.0+0x7b8>
   14419:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   14420:	48 8b 0d 00 00 00 00 	mov    rcx,QWORD PTR [rip+0x0]        # 14427 <try_secant_tail.constprop.0+0x1f97>
   14427:	c5 fb 12 f3          	vmovddup xmm6,xmm3
   1442b:	c4 e1 f9 6e f9       	vmovq  xmm7,rcx
   14430:	c5 c3 58 3d 00 00 00 	vaddsd xmm7,xmm7,QWORD PTR [rip+0x0]        # 14438 <try_secant_tail.constprop.0+0x1fa8>
   14437:	00 
   14438:	48 89 c8             	mov    rax,rcx
   1443b:	c4 e1 f9 7e fe       	vmovq  rsi,xmm7
   14440:	f0 48 0f b1 35 00 00 	lock cmpxchg QWORD PTR [rip+0x0],rsi        # 14449 <try_secant_tail.constprop.0+0x1fb9>
   14447:	00 00 
   14449:	0f 85 af 0c 00 00    	jne    150fe <try_secant_tail.constprop.0+0x2c6e>
   1444f:	41 8d 45 01          	lea    eax,[r13+0x1]
   14453:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
   14457:	49 ba eb 11 31 13 bb 	movabs r10,0x94d049bb133111eb
   1445e:	49 d0 94 
   14461:	49 b8 15 7c 4a 7f b9 	movabs r8,0x9e3779b97f4a7c15
   14468:	79 37 9e 
   1446b:	48 63 c8             	movsxd rcx,eax
   1446e:	89 85 f8 fe ff ff    	mov    DWORD PTR [rbp-0x108],eax
   14474:	4c 03 85 f8 fd ff ff 	add    r8,QWORD PTR [rbp-0x208]
   1447b:	49 bb b9 e5 e4 1c 6d 	movabs r11,0xbf58476d1ce4e5b9
   14482:	47 58 bf 
   14485:	48 89 c8             	mov    rax,rcx
   14488:	49 0f af cb          	imul   rcx,r11
   1448c:	49 0f af c2          	imul   rax,r10
   14490:	4c 01 c0             	add    rax,r8
   14493:	48 89 c6             	mov    rsi,rax
   14496:	48 c1 ee 1e          	shr    rsi,0x1e
   1449a:	48 31 f0             	xor    rax,rsi
   1449d:	49 0f af c3          	imul   rax,r11
   144a1:	48 89 c6             	mov    rsi,rax
   144a4:	48 c1 ee 1b          	shr    rsi,0x1b
   144a8:	48 31 c6             	xor    rsi,rax
   144ab:	4a 8d 04 01          	lea    rax,[rcx+r8*1]
   144af:	48 89 c1             	mov    rcx,rax
   144b2:	49 0f af f2          	imul   rsi,r10
   144b6:	48 c1 e9 1e          	shr    rcx,0x1e
   144ba:	48 31 c1             	xor    rcx,rax
   144bd:	49 0f af cb          	imul   rcx,r11
   144c1:	48 89 c8             	mov    rax,rcx
   144c4:	48 c1 e8 1b          	shr    rax,0x1b
   144c8:	48 31 c8             	xor    rax,rcx
   144cb:	48 89 f1             	mov    rcx,rsi
   144ce:	49 0f af c2          	imul   rax,r10
   144d2:	48 c1 e9 1f          	shr    rcx,0x1f
   144d6:	48 31 f1             	xor    rcx,rsi
   144d9:	48 c1 e9 0b          	shr    rcx,0xb
   144dd:	c4 e1 c3 2a c9       	vcvtsi2sd xmm1,xmm7,rcx
   144e2:	48 89 c1             	mov    rcx,rax
   144e5:	48 c1 e9 1f          	shr    rcx,0x1f
   144e9:	48 31 c1             	xor    rcx,rax
   144ec:	48 c1 e9 0b          	shr    rcx,0xb
   144f0:	c4 e1 c3 2a d1       	vcvtsi2sd xmm2,xmm7,rcx
   144f5:	c5 f1 14 ca          	vunpcklpd xmm1,xmm1,xmm2
   144f9:	c5 fb 12 3d 00 00 00 	vmovddup xmm7,QWORD PTR [rip+0x0]        # 14501 <try_secant_tail.constprop.0+0x2071>
   14500:	00 
   14501:	c5 fb 12 15 00 00 00 	vmovddup xmm2,QWORD PTR [rip+0x0]        # 14509 <try_secant_tail.constprop.0+0x2079>
   14508:	00 
   14509:	8b 8d d0 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x130]
   1450f:	c4 e2 e9 98 cf       	vfmadd132pd xmm1,xmm2,xmm7
   14514:	c5 f1 59 8d 80 fd ff 	vmulpd xmm1,xmm1,XMMWORD PTR [rbp-0x280]
   1451b:	ff 
   1451c:	85 c9                	test   ecx,ecx
   1451e:	c5 c9 59 f1          	vmulpd xmm6,xmm6,xmm1
   14522:	0f 8e 10 01 00 00    	jle    14638 <try_secant_tail.constprop.0+0x21a8>
   14528:	48 8b 85 00 fe ff ff 	mov    rax,QWORD PTR [rbp-0x200]
   1452f:	c5 73 59 c8          	vmulsd xmm9,xmm1,xmm0
   14533:	83 bd d0 fe ff ff 01 	cmp    DWORD PTR [rbp-0x130],0x1
   1453a:	c5 f1 15 c9          	vunpckhpd xmm1,xmm1,xmm1
   1453e:	c5 f3 59 c8          	vmulsd xmm1,xmm1,xmm0
   14542:	49 8d 0c 07          	lea    rcx,[r15+rax*1]
   14546:	0f 84 e4 07 00 00    	je     14d30 <try_secant_tail.constprop.0+0x28a0>
   1454c:	49 8d 47 20          	lea    rax,[r15+0x20]
   14550:	48 39 c1             	cmp    rcx,rax
   14553:	0f 82 d7 07 00 00    	jb     14d30 <try_secant_tail.constprop.0+0x28a0>
   14559:	83 bd 9c fe ff ff 02 	cmp    DWORD PTR [rbp-0x164],0x2
   14560:	0f 86 c8 0a 00 00    	jbe    1502e <try_secant_tail.constprop.0+0x2b9e>
   14566:	8b b5 d0 fe ff ff    	mov    esi,DWORD PTR [rbp-0x130]
   1456c:	c4 42 7d 19 c1       	vbroadcastsd ymm8,xmm9
   14571:	c4 e2 7d 19 f9       	vbroadcastsd ymm7,xmm1
   14576:	31 c0                	xor    eax,eax
   14578:	c1 ee 02             	shr    esi,0x2
   1457b:	48 c1 e6 05          	shl    rsi,0x5
   1457f:	90                   	nop
   14580:	c5 fd 10 14 07       	vmovupd ymm2,YMMWORD PTR [rdi+rax*1]
   14585:	c4 41 7d 28 d0       	vmovapd ymm10,ymm8
   1458a:	c4 42 ed a8 14 07    	vfmadd213pd ymm10,ymm2,YMMWORD PTR [r15+rax*1]
   14590:	c4 41 7d 11 14 07    	vmovupd YMMWORD PTR [r15+rax*1],ymm10
   14596:	c4 e2 c5 a8 14 01    	vfmadd213pd ymm2,ymm7,YMMWORD PTR [rcx+rax*1]
   1459c:	c5 fd 11 14 01       	vmovupd YMMWORD PTR [rcx+rax*1],ymm2
   145a1:	48 83 c0 20          	add    rax,0x20
   145a5:	48 39 f0             	cmp    rax,rsi
   145a8:	75 d6                	jne    14580 <try_secant_tail.constprop.0+0x20f0>
   145aa:	8b b5 d0 fe ff ff    	mov    esi,DWORD PTR [rbp-0x130]
   145b0:	89 f3                	mov    ebx,esi
   145b2:	83 e3 fc             	and    ebx,0xfffffffc
   145b5:	39 de                	cmp    esi,ebx
   145b7:	89 d8                	mov    eax,ebx
   145b9:	74 7d                	je     14638 <try_secant_tail.constprop.0+0x21a8>
   145bb:	29 de                	sub    esi,ebx
   145bd:	83 fe 01             	cmp    esi,0x1
   145c0:	41 89 f0             	mov    r8d,esi
   145c3:	74 49                	je     1460e <try_secant_tail.constprop.0+0x217e>
   145c5:	49 8d 34 c7          	lea    rsi,[r15+rax*8]
   145c9:	c4 41 7b 12 c1       	vmovddup xmm8,xmm9
   145ce:	c5 fb 12 f9          	vmovddup xmm7,xmm1
   145d2:	49 01 c1             	add    r9,rax
   145d5:	48 8b 8d f0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x110]
   145dc:	48 01 c1             	add    rcx,rax
   145df:	48 8b 85 b8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x148]
   145e6:	41 f6 c0 01          	test   r8b,0x1
   145ea:	c4 a1 79 10 14 c8    	vmovupd xmm2,XMMWORD PTR [rax+r9*8]
   145f0:	c4 62 e9 a8 06       	vfmadd213pd xmm8,xmm2,XMMWORD PTR [rsi]
   145f5:	c5 79 11 06          	vmovupd XMMWORD PTR [rsi],xmm8
   145f9:	c4 c2 c1 a8 14 cf    	vfmadd213pd xmm2,xmm7,XMMWORD PTR [r15+rcx*8]
   145ff:	c4 c1 79 11 14 cf    	vmovupd XMMWORD PTR [r15+rcx*8],xmm2
   14605:	74 31                	je     14638 <try_secant_tail.constprop.0+0x21a8>
   14607:	41 83 e0 fe          	and    r8d,0xfffffffe
   1460b:	44 01 c3             	add    ebx,r8d
   1460e:	48 63 c3             	movsxd rax,ebx
   14611:	c5 fb 10 14 c7       	vmovsd xmm2,QWORD PTR [rdi+rax*8]
   14616:	c4 42 e9 a9 0c c7    	vfmadd213sd xmm9,xmm2,QWORD PTR [r15+rax*8]
   1461c:	c4 41 7b 11 0c c7    	vmovsd QWORD PTR [r15+rax*8],xmm9
   14622:	8b 85 d0 fe ff ff    	mov    eax,DWORD PTR [rbp-0x130]
   14628:	01 d8                	add    eax,ebx
   1462a:	48 98                	cdqe
   1462c:	c4 c2 f1 a9 14 c7    	vfmadd213sd xmm2,xmm1,QWORD PTR [r15+rax*8]
   14632:	c4 c1 7b 11 14 c7    	vmovsd QWORD PTR [r15+rax*8],xmm2
   14638:	c5 c9 58 75 b0       	vaddpd xmm6,xmm6,XMMWORD PTR [rbp-0x50]
   1463d:	c5 fb 10 12          	vmovsd xmm2,QWORD PTR [rdx]
   14641:	c5 f9 29 75 b0       	vmovapd XMMWORD PTR [rbp-0x50],xmm6
   14646:	e9 74 e5 ff ff       	jmp    12bbf <try_secant_tail.constprop.0+0x72f>
   1464b:	48 8b 3d 00 00 00 00 	mov    rdi,QWORD PTR [rip+0x0]        # 14652 <try_secant_tail.constprop.0+0x21c2>
   14652:	e8 00 00 00 00       	call   14657 <try_secant_tail.constprop.0+0x21c7>
   14657:	48 8b 3d 00 00 00 00 	mov    rdi,QWORD PTR [rip+0x0]        # 1465e <try_secant_tail.constprop.0+0x21ce>
   1465e:	e8 00 00 00 00       	call   14663 <try_secant_tail.constprop.0+0x21d3>
   14663:	48 8b 3d 00 00 00 00 	mov    rdi,QWORD PTR [rip+0x0]        # 1466a <try_secant_tail.constprop.0+0x21da>
   1466a:	e8 00 00 00 00       	call   1466f <try_secant_tail.constprop.0+0x21df>
   1466f:	e9 af de ff ff       	jmp    12523 <try_secant_tail.constprop.0+0x93>
   14674:	c5 f8 77             	vzeroupper
   14677:	e9 1a ec ff ff       	jmp    13296 <try_secant_tail.constprop.0+0xe06>
   1467c:	c5 f8 77             	vzeroupper
   1467f:	e9 17 eb ff ff       	jmp    1319b <try_secant_tail.constprop.0+0xd0b>
   14684:	ba 08 00 00 00       	mov    edx,0x8
   14689:	39 d1                	cmp    ecx,edx
   1468b:	0f 4e d1             	cmovle edx,ecx
   1468e:	41 89 d0             	mov    r8d,edx
   14691:	e9 aa f4 ff ff       	jmp    13b40 <try_secant_tail.constprop.0+0x16b0>
   14696:	8b 95 5c fe ff ff    	mov    edx,DWORD PTR [rbp-0x1a4]
   1469c:	4c 89 cf             	mov    rdi,r9
   1469f:	44 89 e1             	mov    ecx,r12d
   146a2:	4c 89 9d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r11
   146a9:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   146b0:	e8 db ec fe ff       	call   3390 <project_cgs2>
   146b5:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   146bc:	44 89 e6             	mov    esi,r12d
   146bf:	c5 fb 11 85 c8 fd ff 	vmovsd QWORD PTR [rbp-0x238],xmm0
   146c6:	ff 
   146c7:	4c 89 cf             	mov    rdi,r9
   146ca:	e8 71 bb fe ff       	call   240 <norm2>
   146cf:	c5 fb 10 b5 a0 fe ff 	vmovsd xmm6,QWORD PTR [rbp-0x160]
   146d6:	ff 
   146d7:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   146de:	4c 8b 9d 50 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1b0]
   146e5:	c5 f9 28 d0          	vmovapd xmm2,xmm0
   146e9:	c5 fb 11 b5 08 fe ff 	vmovsd QWORD PTR [rbp-0x1f8],xmm6
   146f0:	ff 
   146f1:	e9 b4 eb ff ff       	jmp    132aa <try_secant_tail.constprop.0+0xe1a>
   146f6:	d9 05 00 00 00 00    	fld    DWORD PTR [rip+0x0]        # 146fc <try_secant_tail.constprop.0+0x226c>
   146fc:	e9 3f f6 ff ff       	jmp    13d40 <try_secant_tail.constprop.0+0x18b0>
   14701:	48 89 c2             	mov    rdx,rax
   14704:	31 c0                	xor    eax,eax
   14706:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   1470a:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   14711:	00 00 00 00 
   14715:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
   1471c:	00 00 00 00 
   14720:	c5 fb 59 0c 07       	vmulsd xmm1,xmm0,QWORD PTR [rdi+rax*1]
   14725:	c4 c1 7b 11 0c 03    	vmovsd QWORD PTR [r11+rax*1],xmm1
   1472b:	c4 c1 7b 11 0c 01    	vmovsd QWORD PTR [r9+rax*1],xmm1
   14731:	48 83 c0 08          	add    rax,0x8
   14735:	48 39 c2             	cmp    rdx,rax
   14738:	75 e6                	jne    14720 <try_secant_tail.constprop.0+0x2290>
   1473a:	8b 95 5c fe ff ff    	mov    edx,DWORD PTR [rbp-0x1a4]
   14740:	4c 89 cf             	mov    rdi,r9
   14743:	44 89 e1             	mov    ecx,r12d
   14746:	4c 89 9d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r11
   1474d:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   14754:	e8 37 ec fe ff       	call   3390 <project_cgs2>
   14759:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   14760:	44 89 e6             	mov    esi,r12d
   14763:	c5 fb 11 85 c8 fd ff 	vmovsd QWORD PTR [rbp-0x238],xmm0
   1476a:	ff 
   1476b:	4c 89 cf             	mov    rdi,r9
   1476e:	e8 cd ba fe ff       	call   240 <norm2>
   14773:	41 8d 44 24 ff       	lea    eax,[r12-0x1]
   14778:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   1477f:	4c 8b 9d 50 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1b0]
   14786:	83 f8 02             	cmp    eax,0x2
   14789:	c5 f9 28 d0          	vmovapd xmm2,xmm0
   1478d:	0f 87 69 ea ff ff    	ja     131fc <try_secant_tail.constprop.0+0xd6c>
   14793:	31 c9                	xor    ecx,ecx
   14795:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   14799:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   1479d:	31 c0                	xor    eax,eax
   1479f:	e9 bb ea ff ff       	jmp    1325f <try_secant_tail.constprop.0+0xdcf>
   147a4:	48 8b 95 18 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1e8]
   147ab:	31 c0                	xor    eax,eax
   147ad:	e9 6e ff ff ff       	jmp    14720 <try_secant_tail.constprop.0+0x2290>
   147b2:	31 c9                	xor    ecx,ecx
   147b4:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   147b8:	31 c0                	xor    eax,eax
   147ba:	e9 aa ea ff ff       	jmp    13269 <try_secant_tail.constprop.0+0xdd9>
   147bf:	31 d2                	xor    edx,edx
   147c1:	31 c9                	xor    ecx,ecx
   147c3:	e9 96 e9 ff ff       	jmp    1315e <try_secant_tail.constprop.0+0xcce>
   147c8:	45 85 db             	test   r11d,r11d
   147cb:	0f 8e f8 08 00 00    	jle    150c9 <try_secant_tail.constprop.0+0x2c39>
   147d1:	41 8d 53 ff          	lea    edx,[r11-0x1]
   147d5:	83 fa 02             	cmp    edx,0x2
   147d8:	0f 86 da 08 00 00    	jbe    150b8 <try_secant_tail.constprop.0+0x2c28>
   147de:	44 89 d9             	mov    ecx,r11d
   147e1:	48 89 c2             	mov    rdx,rax
   147e4:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   147e8:	c1 e9 02             	shr    ecx,0x2
   147eb:	48 c1 e1 05          	shl    rcx,0x5
   147ef:	48 01 c1             	add    rcx,rax
   147f2:	c5 fd 10 02          	vmovupd ymm0,YMMWORD PTR [rdx]
   147f6:	48 83 c2 20          	add    rdx,0x20
   147fa:	48 39 ca             	cmp    rdx,rcx
   147fd:	c5 fd 59 c0          	vmulpd ymm0,ymm0,ymm0
   14801:	c5 f5 58 c8          	vaddpd ymm1,ymm1,ymm0
   14805:	75 eb                	jne    147f2 <try_secant_tail.constprop.0+0x2362>
   14807:	c4 e3 7d 19 c8 01    	vextractf128 xmm0,ymm1,0x1
   1480d:	44 89 d9             	mov    ecx,r11d
   14810:	c5 f9 58 c9          	vaddpd xmm1,xmm0,xmm1
   14814:	83 e1 fc             	and    ecx,0xfffffffc
   14817:	41 39 cb             	cmp    r11d,ecx
   1481a:	89 ca                	mov    edx,ecx
   1481c:	c5 f1 15 c1          	vunpckhpd xmm0,xmm1,xmm1
   14820:	c5 f9 58 c1          	vaddpd xmm0,xmm0,xmm1
   14824:	74 3b                	je     14861 <try_secant_tail.constprop.0+0x23d1>
   14826:	44 89 de             	mov    esi,r11d
   14829:	29 d6                	sub    esi,edx
   1482b:	83 fe 01             	cmp    esi,0x1
   1482e:	74 24                	je     14854 <try_secant_tail.constprop.0+0x23c4>
   14830:	48 03 95 a0 fe ff ff 	add    rdx,QWORD PTR [rbp-0x160]
   14837:	40 f6 c6 01          	test   sil,0x1
   1483b:	c5 f9 10 04 d7       	vmovupd xmm0,XMMWORD PTR [rdi+rdx*8]
   14840:	c4 e2 f9 b8 c8       	vfmadd231pd xmm1,xmm0,xmm0
   14845:	c5 f1 15 c1          	vunpckhpd xmm0,xmm1,xmm1
   14849:	c5 f9 58 c1          	vaddpd xmm0,xmm0,xmm1
   1484d:	74 12                	je     14861 <try_secant_tail.constprop.0+0x23d1>
   1484f:	83 e6 fe             	and    esi,0xfffffffe
   14852:	01 f1                	add    ecx,esi
   14854:	48 63 d1             	movsxd rdx,ecx
   14857:	c5 fb 10 0c d0       	vmovsd xmm1,QWORD PTR [rax+rdx*8]
   1485c:	c4 e2 f1 b9 c1       	vfmadd231sd xmm0,xmm1,xmm1
   14861:	c5 fb 5c 35 00 00 00 	vsubsd xmm6,xmm0,QWORD PTR [rip+0x0]        # 14869 <try_secant_tail.constprop.0+0x23d9>
   14868:	00 
   14869:	c5 fb 11 b5 c0 fe ff 	vmovsd QWORD PTR [rbp-0x140],xmm6
   14870:	ff 
   14871:	dd 85 c0 fe ff ff    	fld    QWORD PTR [rbp-0x140]
   14877:	d8 c8                	fmul   st,st(0)
   14879:	45 85 d2             	test   r10d,r10d
   1487c:	0f 8e 3e 01 00 00    	jle    149c0 <try_secant_tail.constprop.0+0x2530>
   14882:	45 85 db             	test   r11d,r11d
   14885:	0f 8e 35 01 00 00    	jle    149c0 <try_secant_tail.constprop.0+0x2530>
   1488b:	44 89 da             	mov    edx,r11d
   1488e:	44 89 ad 60 fe ff ff 	mov    DWORD PTR [rbp-0x1a0],r13d
   14895:	31 db                	xor    ebx,ebx
   14897:	45 31 c9             	xor    r9d,r9d
   1489a:	44 89 a5 40 fe ff ff 	mov    DWORD PTR [rbp-0x1c0],r12d
   148a1:	c1 ea 02             	shr    edx,0x2
   148a4:	4c 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r8
   148ab:	48 c1 e2 05          	shl    rdx,0x5
   148af:	4c 89 b5 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r14
   148b6:	45 8d 73 ff          	lea    r14d,[r11-0x1]
   148ba:	4c 89 bd 30 fe ff ff 	mov    QWORD PTR [rbp-0x1d0],r15
   148c1:	4d 63 fb             	movsxd r15,r11d
   148c4:	41 83 fe 02          	cmp    r14d,0x2
   148c8:	4e 8d 24 cd 00 00 00 	lea    r12,[r9*8+0x0]
   148cf:	00 
   148d0:	0f 86 0a 04 00 00    	jbe    14ce0 <try_secant_tail.constprop.0+0x2850>
   148d6:	4a 8d 34 27          	lea    rsi,[rdi+r12*1]
   148da:	31 c9                	xor    ecx,ecx
   148dc:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   148e0:	c5 fd 10 04 0e       	vmovupd ymm0,YMMWORD PTR [rsi+rcx*1]
   148e5:	c5 fd 59 04 08       	vmulpd ymm0,ymm0,YMMWORD PTR [rax+rcx*1]
   148ea:	48 83 c1 20          	add    rcx,0x20
   148ee:	48 39 ca             	cmp    rdx,rcx
   148f1:	c5 f5 58 c8          	vaddpd ymm1,ymm1,ymm0
   148f5:	75 e9                	jne    148e0 <try_secant_tail.constprop.0+0x2450>
   148f7:	c4 e3 7d 19 c8 01    	vextractf128 xmm0,ymm1,0x1
   148fd:	44 89 d9             	mov    ecx,r11d
   14900:	c5 f9 58 c1          	vaddpd xmm0,xmm0,xmm1
   14904:	83 e1 fc             	and    ecx,0xfffffffc
   14907:	41 39 cb             	cmp    r11d,ecx
   1490a:	89 ce                	mov    esi,ecx
   1490c:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   14910:	c5 f1 58 c8          	vaddpd xmm1,xmm1,xmm0
   14914:	c5 f9 13 8d c0 fe ff 	vmovlpd QWORD PTR [rbp-0x140],xmm1
   1491b:	ff 
   1491c:	74 64                	je     14982 <try_secant_tail.constprop.0+0x24f2>
   1491e:	45 89 d8             	mov    r8d,r11d
   14921:	41 29 f0             	sub    r8d,esi
   14924:	41 83 f8 01          	cmp    r8d,0x1
   14928:	74 36                	je     14960 <try_secant_tail.constprop.0+0x24d0>
   1492a:	4c 8b ad a0 fe ff ff 	mov    r13,QWORD PTR [rbp-0x160]
   14931:	49 01 f5             	add    r13,rsi
   14934:	4c 01 ce             	add    rsi,r9
   14937:	41 f6 c0 01          	test   r8b,0x1
   1493b:	c4 a1 79 10 34 ef    	vmovupd xmm6,XMMWORD PTR [rdi+r13*8]
   14941:	c4 e2 c9 b8 04 f7    	vfmadd231pd xmm0,xmm6,XMMWORD PTR [rdi+rsi*8]
   14947:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   1494b:	c5 f1 58 c0          	vaddpd xmm0,xmm1,xmm0
   1494f:	c5 f9 13 85 c0 fe ff 	vmovlpd QWORD PTR [rbp-0x140],xmm0
   14956:	ff 
   14957:	74 29                	je     14982 <try_secant_tail.constprop.0+0x24f2>
   14959:	41 83 e0 fe          	and    r8d,0xfffffffe
   1495d:	44 01 c1             	add    ecx,r8d
   14960:	48 63 c9             	movsxd rcx,ecx
   14963:	c5 fb 10 b5 c0 fe ff 	vmovsd xmm6,QWORD PTR [rbp-0x140]
   1496a:	ff 
   1496b:	48 8d 34 cf          	lea    rsi,[rdi+rcx*8]
   1496f:	c5 fb 10 2c c8       	vmovsd xmm5,QWORD PTR [rax+rcx*8]
   14974:	c4 a2 d1 b9 34 26    	vfmadd231sd xmm6,xmm5,QWORD PTR [rsi+r12*1]
   1497a:	c5 fb 11 b5 c0 fe ff 	vmovsd QWORD PTR [rbp-0x140],xmm6
   14981:	ff 
   14982:	dd 85 c0 fe ff ff    	fld    QWORD PTR [rbp-0x140]
   14988:	83 c3 01             	add    ebx,0x1
   1498b:	4d 01 f9             	add    r9,r15
   1498e:	44 39 d3             	cmp    ebx,r10d
   14991:	d8 c8                	fmul   st,st(0)
   14993:	d8 c0                	fadd   st,st(0)
   14995:	de c1                	faddp  st(1),st
   14997:	0f 85 27 ff ff ff    	jne    148c4 <try_secant_tail.constprop.0+0x2434>
   1499d:	44 8b ad 60 fe ff ff 	mov    r13d,DWORD PTR [rbp-0x1a0]
   149a4:	44 8b a5 40 fe ff ff 	mov    r12d,DWORD PTR [rbp-0x1c0]
   149ab:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   149b2:	4c 8b b5 38 fe ff ff 	mov    r14,QWORD PTR [rbp-0x1c8]
   149b9:	4c 8b bd 30 fe ff ff 	mov    r15,QWORD PTR [rbp-0x1d0]
   149c0:	de c1                	faddp  st(1),st
   149c2:	e9 52 f4 ff ff       	jmp    13e19 <try_secant_tail.constprop.0+0x1989>
   149c7:	c5 f8 77             	vzeroupper
   149ca:	e9 b8 e7 ff ff       	jmp    13187 <try_secant_tail.constprop.0+0xcf7>
   149cf:	48 8b b5 18 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1e8]
   149d6:	31 d2                	xor    edx,edx
   149d8:	c5 fb 10 04 10       	vmovsd xmm0,QWORD PTR [rax+rdx*1]
   149dd:	c4 e2 e9 a9 04 11    	vfmadd213sd xmm0,xmm2,QWORD PTR [rcx+rdx*1]
   149e3:	c5 fb 11 04 11       	vmovsd QWORD PTR [rcx+rdx*1],xmm0
   149e8:	48 83 c2 08          	add    rdx,0x8
   149ec:	48 39 d6             	cmp    rsi,rdx
   149ef:	75 e7                	jne    149d8 <try_secant_tail.constprop.0+0x2548>
   149f1:	e9 08 f5 ff ff       	jmp    13efe <try_secant_tail.constprop.0+0x1a6e>
   149f6:	48 8b 95 00 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x200]
   149fd:	31 c0                	xor    eax,eax
   149ff:	c5 fb 10 04 03       	vmovsd xmm0,QWORD PTR [rbx+rax*1]
   14a04:	c4 e2 f1 ad 04 07    	vfnmadd213sd xmm0,xmm1,QWORD PTR [rdi+rax*1]
   14a0a:	c5 fb 11 04 07       	vmovsd QWORD PTR [rdi+rax*1],xmm0
   14a0f:	48 83 c0 08          	add    rax,0x8
   14a13:	48 39 c2             	cmp    rdx,rax
   14a16:	75 e7                	jne    149ff <try_secant_tail.constprop.0+0x256f>
   14a18:	e9 42 f7 ff ff       	jmp    1415f <try_secant_tail.constprop.0+0x1ccf>
   14a1d:	48 8b 85 e0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x220]
   14a24:	8b 9d d0 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x130]
   14a2a:	48 8d 3d ff bb fe ff 	lea    rdi,[rip+0xfffffffffffebbff]        # 630 <relres._omp_fn.0>
   14a31:	48 c7 85 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],0x0
   14a38:	00 00 00 00 
   14a3c:	c5 f9 6e bd cc fe ff 	vmovd  xmm7,DWORD PTR [rbp-0x134]
   14a43:	ff 
   14a44:	c5 f9 6f ad d0 fd ff 	vmovdqa xmm5,XMMWORD PTR [rbp-0x230]
   14a4b:	ff 
   14a4c:	c7 85 58 ff ff ff 00 	mov    DWORD PTR [rbp-0xa8],0x0
   14a53:	00 00 00 
   14a56:	c7 00 03 00 00 00    	mov    DWORD PTR [rax],0x3
   14a5c:	48 8b b5 20 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1e0]
   14a63:	44 89 40 04          	mov    DWORD PTR [rax+0x4],r8d
   14a67:	c4 e3 41 22 c3 01    	vpinsrd xmm0,xmm7,ebx,0x1
   14a6d:	48 8b 85 18 ff ff ff 	mov    rax,QWORD PTR [rbp-0xe8]
   14a74:	48 c7 85 40 ff ff ff 	mov    QWORD PTR [rbp-0xc0],0x0
   14a7b:	00 00 00 00 
   14a7f:	48 89 85 70 ff ff ff 	mov    QWORD PTR [rbp-0x90],rax
   14a86:	48 63 85 cc fe ff ff 	movsxd rax,DWORD PTR [rbp-0x134]
   14a8d:	48 0f af 85 f0 fe ff 	imul   rax,QWORD PTR [rbp-0x110]
   14a94:	ff 
   14a95:	c5 f9 d6 85 78 ff ff 	vmovq  QWORD PTR [rbp-0x88],xmm0
   14a9c:	ff 
   14a9d:	c7 85 48 ff ff ff 00 	mov    DWORD PTR [rbp-0xb8],0x0
   14aa4:	00 00 00 
   14aa7:	c5 f9 7f ad 60 ff ff 	vmovdqa XMMWORD PTR [rbp-0xa0],xmm5
   14aae:	ff 
   14aaf:	48 3d 3f 42 0f 00    	cmp    rax,0xf423f
   14ab5:	0f 9f c2             	setg   dl
   14ab8:	81 fb 7f 01 00 00    	cmp    ebx,0x17f
   14abe:	0f 9e c0             	setle  al
   14ac1:	31 c9                	xor    ecx,ecx
   14ac3:	21 c2                	and    edx,eax
   14ac5:	83 f2 01             	xor    edx,0x1
   14ac8:	0f b6 d2             	movzx  edx,dl
   14acb:	e8 00 00 00 00       	call   14ad0 <try_secant_tail.constprop.0+0x2640>
   14ad0:	db ad 50 ff ff ff    	fld    TBYTE PTR [rbp-0xb0]
   14ad6:	db ad 40 ff ff ff    	fld    TBYTE PTR [rbp-0xc0]
   14adc:	d9 ee                	fldz
   14ade:	df f1                	fcomip st,st(1)
   14ae0:	0f 84 81 02 00 00    	je     14d67 <try_secant_tail.constprop.0+0x28d7>
   14ae6:	d9 fa                	fsqrt
   14ae8:	d9 c9                	fxch   st(1)
   14aea:	48 8b b5 e8 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x218]
   14af1:	48 8b 85 e0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x220]
   14af8:	48 85 f6             	test   rsi,rsi
   14afb:	d9 fa                	fsqrt
   14afd:	de f1                	fdivrp st(1),st
   14aff:	dd 58 18             	fstp   QWORD PTR [rax+0x18]
   14b02:	0f 84 45 05 00 00    	je     1504d <try_secant_tail.constprop.0+0x2bbd>
   14b08:	8b 9d d0 fe ff ff    	mov    ebx,DWORD PTR [rbp-0x130]
   14b0e:	85 db                	test   ebx,ebx
   14b10:	0f 8e 82 05 00 00    	jle    15098 <try_secant_tail.constprop.0+0x2c08>
   14b16:	8d 43 ff             	lea    eax,[rbx-0x1]
   14b19:	48 8b 8d 18 ff ff ff 	mov    rcx,QWORD PTR [rbp-0xe8]
   14b20:	83 f8 02             	cmp    eax,0x2
   14b23:	0f 86 78 05 00 00    	jbe    150a1 <try_secant_tail.constprop.0+0x2c11>
   14b29:	89 da                	mov    edx,ebx
   14b2b:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   14b2f:	31 c0                	xor    eax,eax
   14b31:	c1 ea 02             	shr    edx,0x2
   14b34:	c5 fd 28 d3          	vmovapd ymm2,ymm3
   14b38:	48 c1 e2 05          	shl    rdx,0x5
   14b3c:	c5 fd 10 0c 06       	vmovupd ymm1,YMMWORD PTR [rsi+rax*1]
   14b41:	c5 fd 10 04 01       	vmovupd ymm0,YMMWORD PTR [rcx+rax*1]
   14b46:	48 83 c0 20          	add    rax,0x20
   14b4a:	48 39 d0             	cmp    rax,rdx
   14b4d:	c5 fd 5c c1          	vsubpd ymm0,ymm0,ymm1
   14b51:	c4 e2 f5 b8 d1       	vfmadd231pd ymm2,ymm1,ymm1
   14b56:	c4 e2 fd b8 d8       	vfmadd231pd ymm3,ymm0,ymm0
   14b5b:	75 df                	jne    14b3c <try_secant_tail.constprop.0+0x26ac>
   14b5d:	c4 e3 7d 19 dc 01    	vextractf128 xmm4,ymm3,0x1
   14b63:	8b b5 d0 fe ff ff    	mov    esi,DWORD PTR [rbp-0x130]
   14b69:	8b bd d0 fe ff ff    	mov    edi,DWORD PTR [rbp-0x130]
   14b6f:	c5 d9 58 e3          	vaddpd xmm4,xmm4,xmm3
   14b73:	c4 e3 7d 19 d3 01    	vextractf128 xmm3,ymm2,0x1
   14b79:	c5 e1 58 d2          	vaddpd xmm2,xmm3,xmm2
   14b7d:	83 e6 fc             	and    esi,0xfffffffc
   14b80:	39 f7                	cmp    edi,esi
   14b82:	89 b5 94 fd ff ff    	mov    DWORD PTR [rbp-0x26c],esi
   14b88:	89 f0                	mov    eax,esi
   14b8a:	c5 d9 15 cc          	vunpckhpd xmm1,xmm4,xmm4
   14b8e:	c5 e9 15 c2          	vunpckhpd xmm0,xmm2,xmm2
   14b92:	c5 f1 58 cc          	vaddpd xmm1,xmm1,xmm4
   14b96:	c5 f9 58 c2          	vaddpd xmm0,xmm0,xmm2
   14b9a:	0f 84 a5 04 00 00    	je     15045 <try_secant_tail.constprop.0+0x2bb5>
   14ba0:	c5 f8 77             	vzeroupper
   14ba3:	8b 95 d0 fe ff ff    	mov    edx,DWORD PTR [rbp-0x130]
   14ba9:	29 c2                	sub    edx,eax
   14bab:	83 fa 01             	cmp    edx,0x1
   14bae:	74 3d                	je     14bed <try_secant_tail.constprop.0+0x275d>
   14bb0:	48 8b 9d e8 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x218]
   14bb7:	c5 f9 10 04 c1       	vmovupd xmm0,XMMWORD PTR [rcx+rax*8]
   14bbc:	f6 c2 01             	test   dl,0x1
   14bbf:	c5 f9 10 0c c3       	vmovupd xmm1,XMMWORD PTR [rbx+rax*8]
   14bc4:	c5 f9 5c c1          	vsubpd xmm0,xmm0,xmm1
   14bc8:	c4 e2 f1 b8 d1       	vfmadd231pd xmm2,xmm1,xmm1
   14bcd:	c4 e2 d9 98 c0       	vfmadd132pd xmm0,xmm4,xmm0
   14bd2:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   14bd6:	c5 f1 58 c8          	vaddpd xmm1,xmm1,xmm0
   14bda:	c5 e9 15 c2          	vunpckhpd xmm0,xmm2,xmm2
   14bde:	c5 f9 58 c2          	vaddpd xmm0,xmm0,xmm2
   14be2:	74 2f                	je     14c13 <try_secant_tail.constprop.0+0x2783>
   14be4:	83 e2 fe             	and    edx,0xfffffffe
   14be7:	01 95 94 fd ff ff    	add    DWORD PTR [rbp-0x26c],edx
   14bed:	48 63 85 94 fd ff ff 	movsxd rax,DWORD PTR [rbp-0x26c]
   14bf4:	48 8b 9d e8 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x218]
   14bfb:	c5 fb 10 14 c1       	vmovsd xmm2,QWORD PTR [rcx+rax*8]
   14c00:	c5 fb 10 1c c3       	vmovsd xmm3,QWORD PTR [rbx+rax*8]
   14c05:	c5 eb 5c d3          	vsubsd xmm2,xmm2,xmm3
   14c09:	c4 e2 e1 b9 c3       	vfmadd231sd xmm0,xmm3,xmm3
   14c0e:	c4 e2 e9 b9 ca       	vfmadd231sd xmm1,xmm2,xmm2
   14c13:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
   14c17:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
   14c1b:	c5 fb 58 05 00 00 00 	vaddsd xmm0,xmm0,QWORD PTR [rip+0x0]        # 14c23 <try_secant_tail.constprop.0+0x2793>
   14c22:	00 
   14c23:	c5 f3 5e c0          	vdivsd xmm0,xmm1,xmm0
   14c27:	48 8b 85 e0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x220]
   14c2e:	c5 fb 11 40 20       	vmovsd QWORD PTR [rax+0x20],xmm0
   14c33:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
   14c3a:	41 bd 01 00 00 00    	mov    r13d,0x1
   14c40:	e8 00 00 00 00       	call   14c45 <try_secant_tail.constprop.0+0x27b5>
   14c45:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   14c4c:	e8 00 00 00 00       	call   14c51 <try_secant_tail.constprop.0+0x27c1>
   14c51:	48 8b bd 20 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe0]
   14c58:	e8 00 00 00 00       	call   14c5d <try_secant_tail.constprop.0+0x27cd>
   14c5d:	4c 89 f7             	mov    rdi,r14
   14c60:	e8 00 00 00 00       	call   14c65 <try_secant_tail.constprop.0+0x27d5>
   14c65:	4c 89 ff             	mov    rdi,r15
   14c68:	e8 00 00 00 00       	call   14c6d <try_secant_tail.constprop.0+0x27dd>
   14c6d:	e9 17 d9 ff ff       	jmp    12589 <try_secant_tail.constprop.0+0xf9>
   14c72:	4c 8b b5 f8 fe ff ff 	mov    r14,QWORD PTR [rbp-0x108]
   14c79:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
   14c80:	e8 00 00 00 00       	call   14c85 <try_secant_tail.constprop.0+0x27f5>
   14c85:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
   14c8c:	e8 00 00 00 00       	call   14c91 <try_secant_tail.constprop.0+0x2801>
   14c91:	48 8b bd 20 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe0]
   14c98:	e8 00 00 00 00       	call   14c9d <try_secant_tail.constprop.0+0x280d>
   14c9d:	4c 89 f7             	mov    rdi,r14
   14ca0:	e8 00 00 00 00       	call   14ca5 <try_secant_tail.constprop.0+0x2815>
   14ca5:	4c 89 ff             	mov    rdi,r15
   14ca8:	e8 00 00 00 00       	call   14cad <try_secant_tail.constprop.0+0x281d>
   14cad:	e9 92 e9 ff ff       	jmp    13644 <try_secant_tail.constprop.0+0x11b4>
   14cb2:	44 89 e6             	mov    esi,r12d
   14cb5:	c5 f8 77             	vzeroupper
   14cb8:	e8 83 b5 fe ff       	call   240 <norm2>
   14cbd:	c5 fb 10 bd 80 fe ff 	vmovsd xmm7,QWORD PTR [rbp-0x180]
   14cc4:	ff 
   14cc5:	c5 f9 2f f8          	vcomisd xmm7,xmm0
   14cc9:	0f 87 82 f6 ff ff    	ja     14351 <try_secant_tail.constprop.0+0x1ec1>
   14ccf:	c5 fb 10 35 00 00 00 	vmovsd xmm6,QWORD PTR [rip+0x0]        # 14cd7 <try_secant_tail.constprop.0+0x2847>
   14cd6:	00 
   14cd7:	c5 cb 5e d0          	vdivsd xmm2,xmm6,xmm0
   14cdb:	e9 b5 f4 ff ff       	jmp    14195 <try_secant_tail.constprop.0+0x1d05>
   14ce0:	48 c7 85 c0 fe ff ff 	mov    QWORD PTR [rbp-0x140],0x0
   14ce7:	00 00 00 00 
   14ceb:	31 c9                	xor    ecx,ecx
   14ced:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   14cf1:	31 f6                	xor    esi,esi
   14cf3:	e9 26 fc ff ff       	jmp    1491e <try_secant_tail.constprop.0+0x248e>
   14cf8:	44 3b a8 00 00 00 00 	cmp    r13d,DWORD PTR [rax+0x0]
   14cff:	0f 84 9b e8 ff ff    	je     135a0 <try_secant_tail.constprop.0+0x1110>
   14d05:	83 fb 01             	cmp    ebx,0x1
   14d08:	0f 84 75 e8 ff ff    	je     13583 <try_secant_tail.constprop.0+0x10f3>
   14d0e:	44 3b a8 00 00 00 00 	cmp    r13d,DWORD PTR [rax+0x0]
   14d15:	0f 84 85 e8 ff ff    	je     135a0 <try_secant_tail.constprop.0+0x1110>
   14d1b:	83 fb 02             	cmp    ebx,0x2
   14d1e:	41 bc 02 00 00 00    	mov    r12d,0x2
   14d24:	0f 85 cc e7 ff ff    	jne    134f6 <try_secant_tail.constprop.0+0x1066>
   14d2a:	e9 54 e8 ff ff       	jmp    13583 <try_secant_tail.constprop.0+0x10f3>
   14d2f:	90                   	nop
   14d30:	48 8b b5 00 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x200]
   14d37:	31 c0                	xor    eax,eax
   14d39:	c5 fb 10 14 07       	vmovsd xmm2,QWORD PTR [rdi+rax*1]
   14d3e:	c5 79 29 cf          	vmovapd xmm7,xmm9
   14d42:	c4 c2 e9 a9 3c 07    	vfmadd213sd xmm7,xmm2,QWORD PTR [r15+rax*1]
   14d48:	c4 c1 7b 11 3c 07    	vmovsd QWORD PTR [r15+rax*1],xmm7
   14d4e:	c4 e2 f1 a9 14 01    	vfmadd213sd xmm2,xmm1,QWORD PTR [rcx+rax*1]
   14d54:	c5 fb 11 14 01       	vmovsd QWORD PTR [rcx+rax*1],xmm2
   14d59:	48 83 c0 08          	add    rax,0x8
   14d5d:	48 39 c6             	cmp    rsi,rax
   14d60:	75 d7                	jne    14d39 <try_secant_tail.constprop.0+0x28a9>
   14d62:	e9 d1 f8 ff ff       	jmp    14638 <try_secant_tail.constprop.0+0x21a8>
   14d67:	dd d8                	fstp   st(0)
   14d69:	d9 e8                	fld1
   14d6b:	d9 c9                	fxch   st(1)
   14d6d:	e9 78 fd ff ff       	jmp    14aea <try_secant_tail.constprop.0+0x265a>
   14d72:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 14d7a <try_secant_tail.constprop.0+0x28ea>
   14d79:	00 
   14d7a:	e9 59 e1 ff ff       	jmp    12ed8 <try_secant_tail.constprop.0+0xa48>
   14d7f:	48 8b 8d 18 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1e8]
   14d86:	31 d2                	xor    edx,edx
   14d88:	c4 c1 5b 59 04 11    	vmulsd xmm0,xmm4,QWORD PTR [r9+rdx*1]
   14d8e:	c5 fb 11 04 10       	vmovsd QWORD PTR [rax+rdx*1],xmm0
   14d93:	48 83 c2 08          	add    rdx,0x8
   14d97:	48 39 d1             	cmp    rcx,rdx
   14d9a:	75 ec                	jne    14d88 <try_secant_tail.constprop.0+0x28f8>
   14d9c:	e9 43 ef ff ff       	jmp    13ce4 <try_secant_tail.constprop.0+0x1854>
   14da1:	31 d2                	xor    edx,edx
   14da3:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   14da7:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   14dab:	31 c0                	xor    eax,eax
   14dad:	e9 a4 f2 ff ff       	jmp    14056 <try_secant_tail.constprop.0+0x1bc6>
   14db2:	c5 f8 77             	vzeroupper
   14db5:	e9 c4 e7 ff ff       	jmp    1357e <try_secant_tail.constprop.0+0x10ee>
   14dba:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 14dc2 <try_secant_tail.constprop.0+0x2932>
   14dc1:	00 
   14dc2:	48 8b b5 b0 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x150]
   14dc9:	44 89 85 d0 fe ff ff 	mov    DWORD PTR [rbp-0x130],r8d
   14dd0:	4c 8b 8d 20 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1e0]
   14dd7:	8b 8d cc fe ff ff    	mov    ecx,DWORD PTR [rbp-0x134]
   14ddd:	48 8b 95 18 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xe8]
   14de4:	48 8b bd b8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x148]
   14deb:	e8 00 bb fe ff       	call   8f0 <compat_scan_fused>
   14df0:	48 8b b5 e8 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x218]
   14df7:	48 8b 9d e0 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x220]
   14dfe:	83 f8 01             	cmp    eax,0x1
   14e01:	44 8b 85 d0 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x130]
   14e08:	c5 fb 10 85 40 ff ff 	vmovsd xmm0,QWORD PTR [rbp-0xc0]
   14e0f:	ff 
   14e10:	19 c0                	sbb    eax,eax
   14e12:	83 e0 fe             	and    eax,0xfffffffe
   14e15:	44 89 43 04          	mov    DWORD PTR [rbx+0x4],r8d
   14e19:	83 c0 03             	add    eax,0x3
   14e1c:	48 85 f6             	test   rsi,rsi
   14e1f:	c5 fb 11 43 18       	vmovsd QWORD PTR [rbx+0x18],xmm0
   14e24:	89 03                	mov    DWORD PTR [rbx],eax
   14e26:	0f 84 ac 02 00 00    	je     150d8 <try_secant_tail.constprop.0+0x2c48>
   14e2c:	45 85 c0             	test   r8d,r8d
   14e2f:	0f 8e b0 02 00 00    	jle    150e5 <try_secant_tail.constprop.0+0x2c55>
   14e35:	41 8d 40 ff          	lea    eax,[r8-0x1]
   14e39:	48 8b 95 18 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xe8]
   14e40:	83 f8 02             	cmp    eax,0x2
   14e43:	0f 86 c7 02 00 00    	jbe    15110 <try_secant_tail.constprop.0+0x2c80>
   14e49:	44 89 c1             	mov    ecx,r8d
   14e4c:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   14e50:	31 c0                	xor    eax,eax
   14e52:	c1 e9 02             	shr    ecx,0x2
   14e55:	c5 fd 28 e1          	vmovapd ymm4,ymm1
   14e59:	48 c1 e1 05          	shl    rcx,0x5
   14e5d:	c5 fd 10 14 06       	vmovupd ymm2,YMMWORD PTR [rsi+rax*1]
   14e62:	c5 fd 10 04 02       	vmovupd ymm0,YMMWORD PTR [rdx+rax*1]
   14e67:	48 83 c0 20          	add    rax,0x20
   14e6b:	48 39 c8             	cmp    rax,rcx
   14e6e:	c5 fd 5c c2          	vsubpd ymm0,ymm0,ymm2
   14e72:	c4 e2 ed b8 e2       	vfmadd231pd ymm4,ymm2,ymm2
   14e77:	c4 e2 fd b8 c8       	vfmadd231pd ymm1,ymm0,ymm0
   14e7c:	75 df                	jne    14e5d <try_secant_tail.constprop.0+0x29cd>
   14e7e:	c4 e3 7d 19 cb 01    	vextractf128 xmm3,ymm1,0x1
   14e84:	c4 e3 7d 19 e2 01    	vextractf128 xmm2,ymm4,0x1
   14e8a:	45 89 c5             	mov    r13d,r8d
   14e8d:	c5 e1 58 d9          	vaddpd xmm3,xmm3,xmm1
   14e91:	c5 e9 58 d4          	vaddpd xmm2,xmm2,xmm4
   14e95:	41 83 e5 fc          	and    r13d,0xfffffffc
   14e99:	45 39 c5             	cmp    r13d,r8d
   14e9c:	44 89 e8             	mov    eax,r13d
   14e9f:	c5 e1 15 cb          	vunpckhpd xmm1,xmm3,xmm3
   14ea3:	c5 e9 15 c2          	vunpckhpd xmm0,xmm2,xmm2
   14ea7:	c5 f1 58 cb          	vaddpd xmm1,xmm1,xmm3
   14eab:	c5 f9 58 c2          	vaddpd xmm0,xmm0,xmm2
   14eaf:	0f 84 1b 02 00 00    	je     150d0 <try_secant_tail.constprop.0+0x2c40>
   14eb5:	c5 f8 77             	vzeroupper
   14eb8:	44 89 c1             	mov    ecx,r8d
   14ebb:	29 c1                	sub    ecx,eax
   14ebd:	83 f9 01             	cmp    ecx,0x1
   14ec0:	74 3c                	je     14efe <try_secant_tail.constprop.0+0x2a6e>
   14ec2:	48 8b 9d e8 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x218]
   14ec9:	c5 f9 10 04 c2       	vmovupd xmm0,XMMWORD PTR [rdx+rax*8]
   14ece:	f6 c1 01             	test   cl,0x1
   14ed1:	c5 f9 10 0c c3       	vmovupd xmm1,XMMWORD PTR [rbx+rax*8]
   14ed6:	c5 f9 5c c1          	vsubpd xmm0,xmm0,xmm1
   14eda:	c4 e2 f1 b8 d1       	vfmadd231pd xmm2,xmm1,xmm1
   14edf:	c4 e2 e1 98 c0       	vfmadd132pd xmm0,xmm3,xmm0
   14ee4:	c5 f9 15 c8          	vunpckhpd xmm1,xmm0,xmm0
   14ee8:	c5 f1 58 c8          	vaddpd xmm1,xmm1,xmm0
   14eec:	c5 e9 15 c2          	vunpckhpd xmm0,xmm2,xmm2
   14ef0:	c5 f9 58 c2          	vaddpd xmm0,xmm0,xmm2
   14ef4:	74 2c                	je     14f22 <try_secant_tail.constprop.0+0x2a92>
   14ef6:	89 c8                	mov    eax,ecx
   14ef8:	83 e0 fe             	and    eax,0xfffffffe
   14efb:	41 01 c5             	add    r13d,eax
   14efe:	48 8b 85 e8 fd ff ff 	mov    rax,QWORD PTR [rbp-0x218]
   14f05:	4d 63 e5             	movsxd r12,r13d
   14f08:	c4 a1 7b 10 14 e2    	vmovsd xmm2,QWORD PTR [rdx+r12*8]
   14f0e:	c4 a1 7b 10 1c e0    	vmovsd xmm3,QWORD PTR [rax+r12*8]
   14f14:	c5 eb 5c d3          	vsubsd xmm2,xmm2,xmm3
   14f18:	c4 e2 e1 b9 c3       	vfmadd231sd xmm0,xmm3,xmm3
   14f1d:	c4 e2 e9 b9 ca       	vfmadd231sd xmm1,xmm2,xmm2
   14f22:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
   14f26:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
   14f2a:	c5 fb 58 05 00 00 00 	vaddsd xmm0,xmm0,QWORD PTR [rip+0x0]        # 14f32 <try_secant_tail.constprop.0+0x2aa2>
   14f31:	00 
   14f32:	c5 f3 5e c0          	vdivsd xmm0,xmm1,xmm0
   14f36:	48 8b 85 e0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x220]
   14f3d:	c7 40 0c 00 00 00 00 	mov    DWORD PTR [rax+0xc],0x0
   14f44:	c5 fb 11 40 20       	vmovsd QWORD PTR [rax+0x20],xmm0
   14f49:	e9 e5 fc ff ff       	jmp    14c33 <try_secant_tail.constprop.0+0x27a3>
   14f4e:	dd 05 00 00 00 00    	fld    QWORD PTR [rip+0x0]        # 14f54 <try_secant_tail.constprop.0+0x2ac4>
   14f54:	d9 ca                	fxch   st(2)
   14f56:	e9 ba ee ff ff       	jmp    13e15 <try_secant_tail.constprop.0+0x1985>
   14f5b:	48 89 d9             	mov    rcx,rbx
   14f5e:	31 d2                	xor    edx,edx
   14f60:	e9 23 fe ff ff       	jmp    14d88 <try_secant_tail.constprop.0+0x28f8>
   14f65:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 14f6d <try_secant_tail.constprop.0+0x2add>
   14f6c:	00 
   14f6d:	c5 f9 7e 85 80 fe ff 	vmovd  DWORD PTR [rbp-0x180],xmm0
   14f74:	ff 
   14f75:	e9 1b e5 ff ff       	jmp    13495 <try_secant_tail.constprop.0+0x1005>
   14f7a:	c7 85 0c ff ff ff 01 	mov    DWORD PTR [rbp-0xf4],0x1
   14f81:	00 00 00 
   14f84:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 14f8c <try_secant_tail.constprop.0+0x2afc>
   14f8b:	00 
   14f8c:	e9 b7 dc ff ff       	jmp    12c48 <try_secant_tail.constprop.0+0x7b8>
   14f91:	c5 f8 77             	vzeroupper
   14f94:	e9 2b df ff ff       	jmp    12ec4 <try_secant_tail.constprop.0+0xa34>
   14f99:	31 c0                	xor    eax,eax
   14f9b:	44 89 e1             	mov    ecx,r12d
   14f9e:	31 d2                	xor    edx,edx
   14fa0:	e9 6f f1 ff ff       	jmp    14114 <try_secant_tail.constprop.0+0x1c84>
   14fa5:	31 d2                	xor    edx,edx
   14fa7:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   14fab:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   14faf:	31 c9                	xor    ecx,ecx
   14fb1:	e9 fe ed ff ff       	jmp    13db4 <try_secant_tail.constprop.0+0x1924>
   14fb6:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 14fbe <try_secant_tail.constprop.0+0x2b2e>
   14fbd:	00 
   14fbe:	eb ad                	jmp    14f6d <try_secant_tail.constprop.0+0x2add>
   14fc0:	31 d2                	xor    edx,edx
   14fc2:	e9 ef ee ff ff       	jmp    13eb6 <try_secant_tail.constprop.0+0x1a26>
   14fc7:	31 d2                	xor    edx,edx
   14fc9:	31 c9                	xor    ecx,ecx
   14fcb:	e9 db ec ff ff       	jmp    13cab <try_secant_tail.constprop.0+0x181b>
   14fd0:	44 3b a8 00 00 00 00 	cmp    r13d,DWORD PTR [rax+0x0]
   14fd7:	0f 84 19 01 00 00    	je     150f6 <try_secant_tail.constprop.0+0x2c66>
   14fdd:	83 fb 09             	cmp    ebx,0x9
   14fe0:	41 bc 09 00 00 00    	mov    r12d,0x9
   14fe6:	c7 85 80 fe ff ff 08 	mov    DWORD PTR [rbp-0x180],0x8
   14fed:	00 00 00 
   14ff0:	0f 84 f8 00 00 00    	je     150ee <try_secant_tail.constprop.0+0x2c5e>
   14ff6:	c5 f8 77             	vzeroupper
   14ff9:	e9 c8 e4 ff ff       	jmp    134c6 <try_secant_tail.constprop.0+0x1036>
   14ffe:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 15006 <try_secant_tail.constprop.0+0x2b76>
   15005:	00 
   15006:	e9 62 ff ff ff       	jmp    14f6d <try_secant_tail.constprop.0+0x2add>
   1500b:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 15013 <try_secant_tail.constprop.0+0x2b83>
   15012:	00 
   15013:	e9 55 ff ff ff       	jmp    14f6d <try_secant_tail.constprop.0+0x2add>
   15018:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 15020 <try_secant_tail.constprop.0+0x2b90>
   1501f:	00 
   15020:	e9 48 ff ff ff       	jmp    14f6d <try_secant_tail.constprop.0+0x2add>
   15025:	31 d2                	xor    edx,edx
   15027:	31 c0                	xor    eax,eax
   15029:	e9 b1 f1 ff ff       	jmp    141df <try_secant_tail.constprop.0+0x1d4f>
   1502e:	44 8b 85 d0 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x130]
   15035:	31 c0                	xor    eax,eax
   15037:	e9 89 f5 ff ff       	jmp    145c5 <try_secant_tail.constprop.0+0x2135>
   1503c:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   15040:	e9 93 de ff ff       	jmp    12ed8 <try_secant_tail.constprop.0+0xa48>
   15045:	c5 f8 77             	vzeroupper
   15048:	e9 c6 fb ff ff       	jmp    14c13 <try_secant_tail.constprop.0+0x2783>
   1504d:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 15055 <try_secant_tail.constprop.0+0x2bc5>
   15054:	00 
   15055:	e9 cd fb ff ff       	jmp    14c27 <try_secant_tail.constprop.0+0x2797>
   1505a:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   1505e:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   15062:	31 f6                	xor    esi,esi
   15064:	c5 f9 28 d3          	vmovapd xmm2,xmm3
   15068:	c5 f9 28 c1          	vmovapd xmm0,xmm1
   1506c:	e9 ec dd ff ff       	jmp    12e5d <try_secant_tail.constprop.0+0x9cd>
   15071:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 15079 <try_secant_tail.constprop.0+0x2be9>
   15078:	00 
   15079:	e9 ef fe ff ff       	jmp    14f6d <try_secant_tail.constprop.0+0x2add>
   1507e:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 15086 <try_secant_tail.constprop.0+0x2bf6>
   15085:	00 
   15086:	e9 e2 fe ff ff       	jmp    14f6d <try_secant_tail.constprop.0+0x2add>
   1508b:	c5 fd 6f 05 00 00 00 	vmovdqa ymm0,YMMWORD PTR [rip+0x0]        # 15093 <try_secant_tail.constprop.0+0x2c03>
   15092:	00 
   15093:	e9 d5 fe ff ff       	jmp    14f6d <try_secant_tail.constprop.0+0x2add>
   15098:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   1509c:	e9 86 fb ff ff       	jmp    14c27 <try_secant_tail.constprop.0+0x2797>
   150a1:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
   150a5:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   150a9:	31 c0                	xor    eax,eax
   150ab:	c5 f9 28 d4          	vmovapd xmm2,xmm4
   150af:	c5 f9 28 c8          	vmovapd xmm1,xmm0
   150b3:	e9 eb fa ff ff       	jmp    14ba3 <try_secant_tail.constprop.0+0x2713>
   150b8:	31 c9                	xor    ecx,ecx
   150ba:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
   150be:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   150c2:	31 d2                	xor    edx,edx
   150c4:	e9 5d f7 ff ff       	jmp    14826 <try_secant_tail.constprop.0+0x2396>
   150c9:	d9 e8                	fld1
   150cb:	e9 a9 f7 ff ff       	jmp    14879 <try_secant_tail.constprop.0+0x23e9>
   150d0:	c5 f8 77             	vzeroupper
   150d3:	e9 4a fe ff ff       	jmp    14f22 <try_secant_tail.constprop.0+0x2a92>
   150d8:	c5 fb 10 05 00 00 00 	vmovsd xmm0,QWORD PTR [rip+0x0]        # 150e0 <try_secant_tail.constprop.0+0x2c50>
   150df:	00 
   150e0:	e9 51 fe ff ff       	jmp    14f36 <try_secant_tail.constprop.0+0x2aa6>
   150e5:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   150e9:	e9 48 fe ff ff       	jmp    14f36 <try_secant_tail.constprop.0+0x2aa6>
   150ee:	c5 f8 77             	vzeroupper
   150f1:	e9 8d e4 ff ff       	jmp    13583 <try_secant_tail.constprop.0+0x10f3>
   150f6:	c5 f8 77             	vzeroupper
   150f9:	e9 a2 e4 ff ff       	jmp    135a0 <try_secant_tail.constprop.0+0x1110>
   150fe:	48 89 c1             	mov    rcx,rax
   15101:	e9 25 f3 ff ff       	jmp    1442b <try_secant_tail.constprop.0+0x1f9b>
   15106:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
   1510d:	00 00 00 
   15110:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
   15114:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
   15118:	31 c0                	xor    eax,eax
   1511a:	c5 f9 28 d3          	vmovapd xmm2,xmm3
   1511e:	c5 f9 28 c8          	vmovapd xmm1,xmm0
   15122:	e9 91 fd ff ff       	jmp    14eb8 <try_secant_tail.constprop.0+0x2a28>
   15127:	48 89 c1             	mov    rcx,rax
   1512a:	e9 8b de ff ff       	jmp    12fba <try_secant_tail.constprop.0+0xb2a>
   1512f:	48 89 c2             	mov    rdx,rax
   15132:	e9 82 e5 ff ff       	jmp    136b9 <try_secant_tail.constprop.0+0x1229>
   15137:	e8 00 00 00 00       	call   1513c <try_secant_tail.constprop.0+0x2cac>
   1513c:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
   15143:	e8 00 00 00 00       	call   15148 <try_secant_tail.constprop.0+0x2cb8>
   15148:	48 8b bd 70 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x190]
   1514f:	e8 00 00 00 00       	call   15154 <try_secant_tail.constprop.0+0x2cc4>
   15154:	48 8b bd 68 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x198]
   1515b:	e8 00 00 00 00       	call   15160 <try_secant_tail.constprop.0+0x2cd0>
   15160:	4c 89 f7             	mov    rdi,r14
   15163:	e8 00 00 00 00       	call   15168 <try_secant_tail.constprop.0+0x2cd8>
   15168:	4c 89 ff             	mov    rdi,r15
   1516b:	e8 00 00 00 00       	call   15170 <try_secant_tail.constprop.0+0x2ce0>
   15170:	48 8b bd 78 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x188]
   15177:	e8 a4 b0 fe ff       	call   220 <bs_free>
   1517c:	e9 02 d4 ff ff       	jmp    12583 <try_secant_tail.constprop.0+0xf3>
   15181:	48 89 c2             	mov    rdx,rax
   15184:	e9 08 d8 ff ff       	jmp    12991 <try_secant_tail.constprop.0+0x501>
   15189:	48 89 c2             	mov    rdx,rax
   1518c:	e9 f4 e4 ff ff       	jmp    13685 <try_secant_tail.constprop.0+0x11f5>
   15191:	48 89 c2             	mov    rdx,rax
   15194:	e9 8a ed ff ff       	jmp    13f23 <try_secant_tail.constprop.0+0x1a93>
